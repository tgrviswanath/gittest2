angular.module('smc').directive("convertDecimal", [function () {
    return {
        restrict: "EA",
        replace: true,
        scope: {ngModel:'='},

        link: function (scope, element, attrs) {
            element.bind('blur', function () {
                var value = scope.ngModel.indexOf('.');
                if(scope.ngModel){
                    if(value == -1){
                        scope.ngModel = scope.ngModel + '.00'
                    }
                }
                scope.$apply();
            });

            element.bind('focus', function () {
                if(scope.ngModel){
                    if(scope.ngModel.indexOf('.') != -1){
                        var org_val = scope.ngModel.split('.')[0];
                        scope.ngModel = org_val;
                    }
                }
                scope.$apply();
            });
        }
    };
}]);

angular.module('smc').directive("convertHours", [function () {
    return {
        restrict: "EA",
        replace: true,
        scope: {ngModel:'='},

        link: function (scope, element, attrs) {
            element.bind('blur', function () {
                var value = scope.ngModel.indexOf(':');
                if(scope.ngModel){
                    if(value == -1){
                        scope.ngModel = scope.ngModel + ':00'
                    }
                    var len = scope.ngModel.split(':')[0].length;
                    if(len == 1){
                        scope.ngModel = '0'+scope.ngModel;
                    }
                }
                scope.$apply();
            });
        }
    };
}]);



angular.module('smc').directive('multiDatepicker',[function () {
   
   return {
        restrict: "AC",
        require: '?ngModel',

        link: function (scope, element, attrs, ngModel) {
            element.multiDatesPicker({
                todayHighlight: false,
                dateFormat: 'dd-mm-yy',
                maxPicks: 10,
                minDate: attrs.minDate,
                maxDate: attrs.maxDate
                 
            });
            element.bind('blur', function () {
                var date = element[0].value;
                var eleIndex = parseInt(element[0].name[element[0].name.length-1]);
                if(date.indexOf(',') != -1){
                    var array = [];
                    var dates = date.split(',');
                    for(var i in dates){
                        if(dates[i].indexOf(' ') != -1){
                            var splitedDate = dates[i].split(' ')[1].split('-');
                            var needDate = splitedDate[1]+'/'+splitedDate[0]+'/'+splitedDate[2];
                            array.push(new Date(needDate))
                        }else{
                            var splitedDate1 = dates[i].split('-');
                            var needDate1 = splitedDate1[1]+'/'+splitedDate1[0]+'/'+splitedDate1[2];
                            array.push(new Date(needDate1))
                        }
                    }
                }else{
                   array  = new Date(date);
                }
                var maxDate=new Date(Math.max.apply(null,array));
                var minDate=new Date(Math.min.apply(null,array));
                var timeDiff = Math.abs(maxDate.getTime() - minDate.getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
                scope.$emit('diffdays',diffDays,eleIndex);

                scope.$apply(function() {
                    ngModel.$setViewValue(element[0].value);
                });
            });
        }
    };
}]);

angular.module('smc').filter('capitalize', function() {
    return function(input) {
      return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
});


angular.module('smc').directive("jqueryDatePickerWeekend", function () {
    return {
        restrict:'AC',
        require: '?ngModel',
        link: function(scope, element, attrs, ngModel){

            function dateTimeChange(current_time,$input){
                //console.log(current_time, $input, scope.$eval(attrs.ngModel));
                this.hide();
            }

            element.datepicker({ 
                   beforeShowDay: $.datepicker.noWeekends,
                   dateFormat:'dd-mm-yy',
                   minDate : attrs.minDate,
               });
            
        }
    };
});




