angular.module('smc').factory('httpPostFactory', function ($http) {
	return function (file, data, callback) {
		$http({ 
			url: file,
			method: "POST",
			data: data,
			transformRequest: angular.identity,
			headers:{
				'Content-Type': undefined
			}
		}).success(function (response) {
			callback(response);
		});
	};
});

angular.module('smc.ui.notify', []).factory('NotifyFactory', [
    function () {
        toastr.options = {
            "closeButton": true,
            "positionClass": "toast-bottom-right",
            "timeOut": "3000"
        };
        return {
            log: function (type, message) {
                return toastr[type](message);
            }
        };
    }
]);
