(function() {
    'use strict';
	angular
	    .module('smc')
	    .factory('DataService' , DataService);

    DataService.$inject = ['$q','$http','smcConfig', "Base64"]

    function DataService($q,$http,smcConfig, Base64){
        return{
            //POST
            post : function(action,query){
                var request_from = "";
                var request_id = "";
                var unique_id = "";
                var req_date_time = "";
                var request_authentication = "";
                //req_date_time = moment().format('DD-MM-YYYY hh:mm:ss Z');
                var date_time = new Date();
                req_date_time = date_time.getTime();
                unique_id = uuid4();
                request_id = request_from + ":" + unique_id;
                request_authentication = "wMusmc6Rtas6ZLHeelbawOstd4pdmQwRrUlZECvR";
                var service = smcConfig.services[action];
                var deferred = $q.defer();
                $http.post(service.url, query,{
                    'headers' : {
                        'Content-Type'  : "application/json"
                     }
                }).success(function(data) {
					deferred.resolve(data);
				}).error(function(error,status) {
                    deferred.reject(error,status);
				});
                return deferred.promise;  
            },

            //GET
            get  : function(action,query){
                var request_from = "";
                var request_id = "";
                var unique_id = "";
                var req_date_time = "";
                var request_authentication = "";
                var date_time = new Date();
                req_date_time = date_time.getTime();
                unique_id = uuid4();
                request_id = request_from + ":" + unique_id;
                request_authentication = "wMusmc6Rtas6ZLHeelbawOstd4pdmQwRrUlZECvR";
                var service = smcConfig.services[action];
                var deferred = $q.defer();
				$http.get(service.url, {params: query ,
                    'headers' : {
                        'Content-Type'  : "application/json"
                    }
                }).success(function(data) {
					deferred.resolve(data);
				}).error(function(error,status){
					deferred.reject(error,status);
				});
                return deferred.promise;
            }
        }
    }


    function uuid4() {
        //// return uuid of form xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
        var uuid = '', ii;
        for (ii = 0; ii < 32; ii += 1) {
          switch (ii) {
          case 8:
          case 20:
            uuid += '-';
            uuid += (Math.random() * 16 | 0).toString(16);
            break;
          case 12:
            uuid += '-';
            uuid += '4';
            break;
          case 16:
            uuid += '-';
            uuid += (Math.random() * 4 | 8).toString(16);
            break;
          default:
            uuid += (Math.random() * 16 | 0).toString(16);
          }
        }
        return uuid;
      };
})();

(function(){
    'use strict';
    angular
        .module('smc')
        .factory('Base64', Base64);

    function Base64(){
        var keyStr = 'ABCDEFGHIJKLMNOP' +
            'QRSTUVWXYZabcdef' +
            'ghijklmnopqrstuv' +
            'wxyz0123456789+/' +
            '=';
        return {
            encode: function (input) {
                var output = "";
                var chr1, chr2, chr3 = "";
                var enc1, enc2, enc3, enc4 = "";
                var i = 0;

                do {
                    chr1 = input.charCodeAt(i++);
                    chr2 = input.charCodeAt(i++);
                    chr3 = input.charCodeAt(i++);

                    enc1 = chr1 >> 2;
                    enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                    enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                    enc4 = chr3 & 63;

                    if (isNaN(chr2)) {
                        enc3 = enc4 = 64;
                    } else if (isNaN(chr3)) {
                        enc4 = 64;
                    }

                    output = output +
                        keyStr.charAt(enc1) +
                        keyStr.charAt(enc2) +
                        keyStr.charAt(enc3) +
                        keyStr.charAt(enc4);
                    chr1 = chr2 = chr3 = "";
                    enc1 = enc2 = enc3 = enc4 = "";
                } while (i < input.length);

                return output;
            },

            decode: function (input) {
                var output = "";
                var chr1, chr2, chr3 = "";
                var enc1, enc2, enc3, enc4 = "";
                var i = 0;

                // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
                var base64test = /[^A-Za-z0-9\+\/\=]/g;
                if (base64test.exec(input)) {
                    alert("There were invalid base64 characters in the input text.\n" +
                        "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                        "Expect errors in decoding.");
                }
                input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

                do {
                    enc1 = keyStr.indexOf(input.charAt(i++));
                    enc2 = keyStr.indexOf(input.charAt(i++));
                    enc3 = keyStr.indexOf(input.charAt(i++));
                    enc4 = keyStr.indexOf(input.charAt(i++));

                    chr1 = (enc1 << 2) | (enc2 >> 4);
                    chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                    chr3 = ((enc3 & 3) << 6) | enc4;

                    output = output + String.fromCharCode(chr1);

                    if (enc3 != 64) {
                        output = output + String.fromCharCode(chr2);
                    }
                    if (enc4 != 64) {
                        output = output + String.fromCharCode(chr3);
                    }

                    chr1 = chr2 = chr3 = "";
                    enc1 = enc2 = enc3 = enc4 = "";

                } while (i < input.length);

                return output;
            }
        };
    }
})();



(function(){
    'user strict';
    angular
      .module('smc')
      .filter('capitalise', function(){
          return function(text) {
            if(text){
               var data = angular.uppercase(text);
                return data;
            } else {
                return "";
            }
          };
    });
})();

(function(){
    'use strict';
    angular
        .module('smc')
        .filter('underscoreless', underscoreless);

    function underscoreless(){
        return function (input) {
            var data = angular.lowercase(input);
            return data.replace(' ', '_');
        }
    }
})();

(function(){
    'user strict';
    angular
        .module('smc')
        .filter('spacetrim', ['$sce',function($sce){
            return function(text){
                return text.trim();
            }
        }]);
})();

(function(){
    'user strict';
    angular
        .module('smc')
        .filter('date', ['$sce',function($sce){
            return function(text){
                var dates = String(text).replace("00:00:00.0","");
                return dates;
            }
        }]);
})();

(function(){
    'user strict';
    angular
        .module('smc')
        .filter('to_trusted', ['$sce',function($sce){
            return function(text){
                return $sce.trustAsHtml(text);
            }
        }]);
})();

(function(){
    'user strict';
    angular
      .module('smc')
      .filter('ampm', function(){
          return function(text) {
            if(text){
                var time_slot = text.split(':');

                time_slot_1 = parseInt(time_slot[0]);
                  if(time_slot_1 > 12){
                    time_slot_1 = time_slot_1 - 12;
                  }
                if(time_slot_1 == 0){
                    time_slot_1 = '12';
                }
                if(time_slot_1 < 10){
                    time_slot_1 = '0'+time_slot_1;
                }

                return time_slot_1+':'+time_slot[1];
            } else {
                return "";
            }
          };
    });
})();

(function(){
    'user strict';
    angular
      .module('smc')
      .filter('removeampm', function(){
          return function(text) {
            if(text){
                var time_slot = text;
                time_slot = time_slot.replace(' PM','');
                time_slot = time_slot.replace(' AM','');
                return time_slot;
            } else {
                return "";
            }
          };
    });
})();
