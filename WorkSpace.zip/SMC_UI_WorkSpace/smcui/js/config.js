APIBUSINESSPOINT = "http://49.207.183.211:8081/smc/rest/api"; // Local End Point IP

//APIBUSINESSPOINT = "http://49.207.183.211:8081/smctest/rest/api"; // Local End Point IP

//APIBUSINESSPOINT = "http://49.207.183.211:8081/smctest/rest/api"; // Local End Point IP

//APIBUSINESSPOINT = "http://58.185.196.131:8080/smcdev/rest/api";

//APIBUSINESSPOINT = "http://smc360-dev.info-labtest.com:8080/smcdev/rest/api";

//APIBUSINESSPOINT = "http://49.207.183.211:8081/smcuat/rest/api";

//APIBUSINESSPOINT = "http://smc360.info-labtest.com/service/smc/rest/api"

VERSIONNAME = 'V1.1.4';
var curY = new Date();
var yearNow = curY.getFullYear();
COPYRIGHTSYEAR = yearNow;
(function () {
    'use strict';
    var BUSINESS_SERVICE = APIBUSINESSPOINT;
    angular.module('smc').constant('smcConfig', {
        viewBaseUrl: 'views/',
        services: {
            GetApplicantUIDsList: {
                url: BUSINESS_SERVICE + '/adjudication/applicant/uids',
                name: 'Applicant UIDs List'
            },
            GetLawFirmList: {
                url: BUSINESS_SERVICE + '/adjudication/lawfirms',
                name: 'Law Firm List'
            },
            GetContractTypeList: {
                url: BUSINESS_SERVICE + '/adjudication/contracttypes',
                name: 'Contract Type List'
            },
            GetDisputeNatureList: {
                url: BUSINESS_SERVICE + '/adjudication/disputenatures',
                name: 'Dispute Nature List'
            },
            SaveAAForm: {
                url: BUSINESS_SERVICE + '/adjudication/aaform/save',
                name: 'Save AA1 From'
            },
            SubmitAAForm: {
                url: BUSINESS_SERVICE + '/adjudication/aaform/submit',
                name: 'Submit AA1 From'
            },
            caseMemberLogin: {
                url: BUSINESS_SERVICE + '/contact/member/login',
                name: 'Login for Lawyer'
            },
            LawyerPasswordReset: {
                url: BUSINESS_SERVICE + '/adjudication/lawyer/reset',
                name: 'Password Reset for lawyer'
            },
            ModeOfDocumentSubmission: {
                url: BUSINESS_SERVICE + '/common/codeinfo/Mode_Of_Documents_Submission_AA_Application',
                name: 'Mode Of Documents Submission AA Application'
            },
            GetPurposeRegulation: {
                url: BUSINESS_SERVICE + '/common/codeinfo/PURPOSE_OF_REGULATION',
                name: 'Get Purpose Regulation'
            },
            UploadFileSubmisson: {
                url: BUSINESS_SERVICE + '/common/upload/file',
                name: 'Submit Upload File'
            },
            GetDepositeAmount: {
                url: BUSINESS_SERVICE + '/adjudication/payment/depositamount',
                name: 'Get deposit amount'
            },
            PaymentSubmit: {
                url: BUSINESS_SERVICE + '/adjudication/payment',
                name: 'Submit Payment'
            },
            GetLawyerCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/lawyer/cases',
                name: 'Lawyer Case List'
            },
            GetSingleCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/case/details',
                name: 'Single Case list'
            },
            GetSingleCaseStatus: {
                url: BUSINESS_SERVICE + '/adjudication/case/status/',
                name: 'Single Case Status'
            },
            GetDetailsAboutCase: {
                url: BUSINESS_SERVICE + '/adjudication/case/documentStatus/',
                name: 'single case details'
            },
            GetBankDetails: {
                url: BUSINESS_SERVICE + '/common/bank/details',
                name: 'Bank Details'
            },

            UploadSupportDocuments: {
                url: BUSINESS_SERVICE + '/adjudication/aaform/upload/documents',
                name: 'Upload Support Documents'
            },
            SmcMemberLogin: {
                url: BUSINESS_SERVICE + '/contact/staff/login',
                name: 'SMC Member Login'
            },
            MemberProfilePicture: {
                url: BUSINESS_SERVICE + '/contact/member/profile/picture/upload',
                name: 'To upload profile picture using Ajax call'
            },
            GetMemberProfile: {
                url: BUSINESS_SERVICE + '/contact/member/profile/picture/view/',
                name: 'To Get Member Profile Picture'
            },
            GetMemberCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases',
                name: 'Member Case List'
            },
            GetAdjudicationCaseList: {
                url: BUSINESS_SERVICE + '/contact/adjudicator/cases',
                name: 'To get Adjudication Case List Handled by Adjudicator'
            },
            GetAdjudicatorConflictDetails: {
                url: BUSINESS_SERVICE + '/contact/adjudicator/conflict/details',
                name: 'To Get Adjudicator Conflict Details'
            },
            GetPartyIdentifierList: {
                url: BUSINESS_SERVICE + '/contact/party/identifiers',
                name: 'To get Party Identifier List'
            },
            AddConflictDetailByAdjudicator: {
                url: BUSINESS_SERVICE + '/contact/adjudicator/conflict/detail/add',
                name: 'To Add Conflict Detail by Adjudicator'
            },
            DeleteConflictDetail: {
                url: BUSINESS_SERVICE + '/contact/adjudicator/conflict/detail/delete/',
                name: 'To Delete Conflict Detail by Adjudicator'
            },
            OfficerGetAdjudicatorConflictDetails: {
                url: BUSINESS_SERVICE + '/contact/smcOfficer/conflict/details',
                name: 'To Get Adjudicator Conflict Details'
            },
            AddConflictDetailByOfficer: {
                url: BUSINESS_SERVICE + '/contact/smcOfficer/conflict/detail/add',
                name: 'To Add Conflict Detail by Officer'
            },
            OfficerDelectConflictData : {
                url : BUSINESS_SERVICE+ '/contact/smcOfficer/conflict/detail/delete',
                name : 'Officer Delect Conflict Data'
            },
            GetMemberProfessionalRequirementDetails: {
                url: BUSINESS_SERVICE + '/contact/member/professional/requirements',
                name: 'To get Member Professional Requirement Details'
            },
            GetSeminarProgramList: {
                url: BUSINESS_SERVICE + '/contact/seminar/programs',
                name: 'To get Seminar Program List'
            },
            MemberDetailsFromToken :{
                url: BUSINESS_SERVICE + '/contact/appoint/adjudicator/terms/conditions/details/',
                name: 'To get member details for terms & conditions using token'
            },
            AcceptTermsandConditionsbyMember:{
                 url: BUSINESS_SERVICE + '/contact/member/accept/tc',
                name: 'To Accept Terms and conditions by invited member'
            },
            GetCaseListbyFilter: {
                url: BUSINESS_SERVICE + '/adjudication/cases/filter',
                name: 'Case List filter'
            },
            GetIncompleteCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/incomplete',
                name: 'Case incomplete List filter'
            },
            GetInprogressCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/inprogress',
                name: 'Case incomplete List filter'
            },
            GetARformDetails: {
                url: BUSINESS_SERVICE + '/adjudication/case/respondent/details/',
                name: 'Get Details to AR form'
            },
            SaveARForm: {
                url: BUSINESS_SERVICE + '/adjudication/arform/save',
                name: 'Save AR1 From'
            },
            SubmitARForm: {
                url: BUSINESS_SERVICE + '/adjudication/arform/submit',
                name: 'Submit AR1 From'
            },
            GetRespondentcaseList: {
                url: BUSINESS_SERVICE + '/adjudication/respondent/caseList',
                name: 'Respondent Case List'
            },
            GetMemberList: {
                url: BUSINESS_SERVICE + '/adjudication/members',
                name: 'Get Smc officers and Assistant managers'
            },
            AssignCaseToOfficer: {
                url: BUSINESS_SERVICE + '/adjudication/assignCase',
                name: 'assign case to case officer'
            },
            GetMissedDocuments: {
                url: BUSINESS_SERVICE + '/adjudication/aaform/misseddocuments/',
                name: 'to Get Missed Documents'
            },
            AAformAuditTrail: {
                url: BUSINESS_SERVICE + '/adjudication/aaform/update',
                name: 'to AA Form update'
            },
            ARformAuditTrail: {
                url: BUSINESS_SERVICE + '/adjudication/arform/update',
                name: 'to AR Form Update'
            },
            AcknowledgementUpdate: {
                url: BUSINESS_SERVICE + '/adjudication/ackSupporDocuments',
                name: 'date sent for Acknowledgement'
            },
            UpdateReceiptDate: {
                url: BUSINESS_SERVICE + '/adjudication/smcOfficer/receiptDate',
                name: 'update receipt date'
            },
            GetAdjudicatorsList: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators',
                name: 'Get Adjudicators List'
            },
            GenerateAdjudicators: {
                url: BUSINESS_SERVICE + '/adjudication/generate/adjudicators/approval',
                name: 'Invite Adjudicators'
            },
            GetPayeeName: {
                url: BUSINESS_SERVICE + '/adjudication/payee/',
                name: 'get payee name to update'
            },
            UpdatePayeeName: {
                url: BUSINESS_SERVICE + '/adjudication/update/payeeName',
                name: 'update payee name'
            },
            GetAmendPayeeData : {
                url : BUSINESS_SERVICE + '/adjudication/view/payeeName/',
                name : 'get amend payee details'
            },
            GetChangesPayeeList: {
                url: BUSINESS_SERVICE + '/adjudication/payeeNames',
                name: 'get changes payee list'
            },
            GetPayeeChangeDetails: {
                url: BUSINESS_SERVICE + '/adjudication/payeeName/detail/',
                name: 'get payee details'
            },
            GetConfirmMessageAAform: {
                url: BUSINESS_SERVICE + '/adjudication/displayMessages/AA-SUBMIT-CONFIRM',
                name: 'Get Confirm Display Massage for Submit'
            },
            GetConfirmMessageARform: {
                url: BUSINESS_SERVICE + '/adjudication/displayMessages/AR-SUBMIT-CONFIRM',
                name: 'Get Confirm Display Massage for Submit'
            },
            ResponsePayeeChanges: {
                url: BUSINESS_SERVICE + '/adjudication/submit/payeeName',
                name: 'response for payee changes'
            },
            GetPendingAdjudicators: {
                url: BUSINESS_SERVICE + '/adjudication/pending/approvals',
                name: 'Get pending adjudicator approval list'
            },
            ViewPendingAdjudicator: {
                url: BUSINESS_SERVICE + '/adjudication/pending/approval/view/',
                name: 'View pending adjudicator'
            },
            DeletePendingAdjudicator: {
                url: BUSINESS_SERVICE + '/adjudication/case/adjudicator/delete',
                name: 'Delete pending adjudicator'
            },
            ResponsePendingAdjudicators: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/approve',
                name: 'approval for Adjudicators'
            },
            GetProposedAdjudicators: {
                url: BUSINESS_SERVICE + '/adjudication/smcOfficer/proposed/adjudicators',
                name: 'Get Proposed Adjudicators list'
            },
            InviteTypeAdjudicators: {
                url: BUSINESS_SERVICE + '/adjudication/invite/adjudicators',
                name: 'invite type adjudicators'
            },
            MediatorInviteListDetails:{
                url: BUSINESS_SERVICE + '/contact/upload/members',
                name: 'To upload list of members to be invited'
            },
            AppointAdjudicator: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/override/appoint',
                name: 'Appoint Adjudicator to Case'
            },
            AdjudicatorLogin: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/login',
                name: 'Adjudicator login'
            },
            AdjudicatorToRespondList: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/torespond/caselist',
                name: 'Adjudicator torespond case list'
            },
            AdjudicatorProgressList: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/inprogress/caselist',
                name: 'Adjudicator Progresss Case List'
            },
            AdjudicatorRejectedCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/rejected/caselist',
                name: 'Adjudicator rejected case list'
            },
            AdjudicatorConflictedCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/conflict/caselist',
                name: 'Adjudicator conflicted case list'
            },
            AdjudicatorAcceptCase: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/case/accept',
                name: 'adjudicator accept a case'
            },
            AdjudicatorRejectCase: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/case/reject',
                name: 'adjudicator reject a case'
            },
            AdjudicatorAcceptanceRate: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/acceptanceRate/',
                name: 'adjudicator acceptance Rate'
            },
            ViewInviteAdjudicator: {
                url: BUSINESS_SERVICE + '/adjudication/invites/adjudicators/view',
                name: 'SMC Officer Can view invite Adjudicator List'
            },
            AdjudicatorSubmitWithSignature: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/case/accept/submit',
                name: 'signature Submit'
            },
            GetVehicleNUmber: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/vehicleNumber/',
                name: 'Get Vehicle No for Adjudicator'
            },
            SaveSchedule: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/save',
                name: 'save schedule'
            },
            UpdateSchedule: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/adjudicator/update',
                name: 'update schedule'
            },
            GetCaseSchedule: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/details/',
                name: 'Get schedule About Case'
            },
            OfficerUpdateSchedule: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/smcOfficer/update',
                name: 'Update Schedule by SMC officer'
            },
            DownloadAAForm: {
                url: BUSINESS_SERVICE + '/adjudication/aaform/download/',
                name: 'Download AA Form'
            },
            DownloadARForm: {
                url: BUSINESS_SERVICE + '/adjudication/arform/download/',
                name: 'Download AR Form'
            },
            DownloadARAForm : {
                url : BUSINESS_SERVICE + '/adjudication/araForm/download/',
                name : 'Download ARA Form'
            },
            DownloadSupportingDocument: {
                url: BUSINESS_SERVICE + '/adjudication/download/supportDocument/',
                name: 'Download Supporting Document'
            },
            DownloadAnnexAform: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/download/annexA/',
                name: 'Download Annex A Form'
            },
            DownloadAnnexFform: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/download/annexF/',
                name: 'Download Annex F Form'
            },
            DownloadAnnexCRespondent: {
                url: BUSINESS_SERVICE + '/adjudication/download/letter/respondent/annexC/',
                name: 'Download Pdf Annex C Respondent'
            },
            DownloadAnnexCClaimant: {
                url: BUSINESS_SERVICE + '/adjudication/download/letter/claimant/annexC/',
                name: 'Download Pdf Annex C Claimant'
            },
            DownloadAnnexCRegulation: {
                url: BUSINESS_SERVICE + '/adjudication/download/letter/regulation/annexC/',
                name: 'Download Pdf Annex C Regulation'
            },
            DownloadAnnexGAppointment: {
                url: BUSINESS_SERVICE + '/adjudication/download/letter/adjudicator/annexG/',
                name: 'Download Pdf Annex G Appointment confirmaion'
            },
            GetCancelApplicationReasons: {
                url: BUSINESS_SERVICE + '/adjudication/case/cancel/reasons',
                name: 'get reasons for cancel'
            },
            CancelApplication: {
                url: BUSINESS_SERVICE + '/adjudication/case/request/cancel',
                name: 'cancel case application'
            },
            GetCancelledCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/canceled',
                name: 'get canceled case list'
            },
            GetCancellationDetails: {
                url: BUSINESS_SERVICE + '/adjudication/case/request/cancel/view/',
                name: 'get canceled details'
            },
            GetRefundData: {
                url: BUSINESS_SERVICE + '/adjudication/payment/refund/view/',
                name: 'get refund Data'
            },
            DownloadApprovedMemo : {
                url : BUSINESS_SERVICE + '/adjudication/payment/refund/download/',
                name : 'Download Approved Memo'
            },
            SubmitRefundData: {
                url: BUSINESS_SERVICE + '/adjudication/payment/refund/submit',
                name: 'sent request'
            },
            requestRefundData: {
                url: BUSINESS_SERVICE + '/adjudication/payment/refund/send/approval',
                name: 'request RefundData'
            },
            GetTimeSheetData: {
                url: BUSINESS_SERVICE + '/adjudication/case/timesheet/view/',
                name: 'Time Sheet Details'
            },
            SaveTimeSheet: {
                url: BUSINESS_SERVICE + '/adjudication/case/timesheet/save',
                name: 'Save Timesheet'
            },
            SubmitTimeSheet: {
                url: BUSINESS_SERVICE + '/adjudication/case/timesheet/submit',
                name: 'Submit Timesheet'
            },
            DeleteTimeSheetData: {
                url: BUSINESS_SERVICE + '/adjudication/case/timesheet/delete/',
                name: 'Delete Timesheet Schedule'
            },
            SubmitEOTRequest: {
                url: BUSINESS_SERVICE + '/adjudication/case/adjudicator/timeLine/extension',
                name: 'Submit EOT Request'
            },
            SendAdjudicatorMessage: {
                url: BUSINESS_SERVICE + '/adjudication/case/sender/message/send',
                name: 'Adjudicator Send message'
            },
            ViewMessages: {
                url: BUSINESS_SERVICE + '/adjudication/case/sender/message/view',
                name: 'View all messages'
            },
            SMCofficerRequestEOT: {
                url: BUSINESS_SERVICE + '/adjudication/case/smcOfficer/timeLine/extension',
                name: 'EOT Request by officer'
            },
            SaveReplyMessage: {
                url: BUSINESS_SERVICE + '/adjudication/case/recipient/reply/add',
                name: 'Save Message'
            },
            SendReplyMessage: {
                url: BUSINESS_SERVICE + '/adjudication/case/recipient/reply/send',
                name: 'Send message'
            },
            SaveRequestTopUp: {
                url: BUSINESS_SERVICE + '/adjudication/additional/deposit/save',
                name: 'Save Topup Request'
            },
            SaveDraftDetermine: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/save',
                name: 'Save Draft Determine'
            },
            viewAdditionalDeposits: {
                url: BUSINESS_SERVICE + '/adjudication/additional/deposits/',
                name: 'get additional Deposit by officer'
            },
            SentDepositRequestClaimant: {
                url: BUSINESS_SERVICE + '/adjudication/additional/deposit/smcOfficer/update',
                name: 'Submit additional Deposit'
            },
            DownloadPerformaInvoice: {
                url: BUSINESS_SERVICE + '/adjudication/download/invoice/',
                name: 'download performa invoice'
            },
            AdditionalDeposit: {
                url: BUSINESS_SERVICE + '/adjudication/payment/additional/deposit',
                name: 'Additional Deposit'
            },
            GetDeterminationList: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/view/',
                name: 'Get Determination List'
            },
            GetDeterminationVersionDetails: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/smcOfficer/view',
                name: 'get version Detais'
            },
            OfficerResponseToDetermination: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/submit',
                name: 'Officer Response To Determination'
            },
            OfficerResponseToTimeSheet: {
                url: BUSINESS_SERVICE + '/adjudication/case/timesheet/smcOfficer/submit',
                name: 'Officer Response To TimeSheet'
            },
            ViewAdjudicatorCost: {
                url: BUSINESS_SERVICE + '/adjudication/case/timesheet/adjudicatorCost/view',
                name: 'View Adjudicator Cost'
            },
            ResubmitDetrminationRequest: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/reSubmit',
                name: 'Resubmit Detrmination Request'
            },
            CancelSchedule: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/cancel',
                name: 'Cancel Schedule'
            },
            GetDeterminedCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/determined',
                name: 'Get Detrmined Case List'
            },
            GetViewGenerateMemo: {
                url: BUSINESS_SERVICE + '/adjudication/case/generate/memo/view/',
                name: 'Get View Generate Memo'
            },
            GetViewGenerateMemoOfBOD: {
                url: BUSINESS_SERVICE + '/adjudication/case/view/memo/bod/',
                name: 'Get View BOD Memo'
            },
            SentDeterminedApproval: {
                url: BUSINESS_SERVICE + '/adjudication/case/generate/memo/send/approval',
                name: 'Sent Determined Approval'
            },
            GetPendingPaymentApproval: {
                url: BUSINESS_SERVICE + '/adjudication/case/smcManager/pending/approvals',
                name: 'Get Pending Payment Approval'
            },
            ViewPendingPaymentDetails: {
                url: BUSINESS_SERVICE + '/adjudication/case/smcManager/pending/payment/view',
                name: 'View Pending Payment Details'
            },
            SubmitResponsePendingPayment: {
                url: BUSINESS_SERVICE + '/adjudication/case/smcManager/pending/payment/submit',
                name: 'Submit Response Pending Payment'
            },
            GetDeterminationListAdjudicator: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/determined/caselist',
                name: 'Get Determination List Adjudicator'
            },
            IssueAmendedRequest: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/amended/request',
                name: 'Issue Amended Request'
            },
            UploadAdjudicatorInvoice: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/invoice/upload',
                name: 'Upload Adjudicator Invoice'
            },
            ApproveAmendedOfficer: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/amended/view/',
                name: 'Approve Amended Officer'
            },
            SubmitAmendedApprove: {
                url: BUSINESS_SERVICE + '/adjudication/case/determination/amended/submit',
                name: 'Submit Amended Approve'
            },
            ViewUploadedInvoice: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/invoice/view/',
                name: 'ViewUploadedInvoice'
            },
            GetPendingPaymentsCases: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/payment/caselist',
                name: 'Get Pending Payments Cases'
            },
            GetRefundApprovalList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/smcManager/payment/refund',
                name: 'Get Refund Approval List'
            },
            ViewRefundCaseDetail: {
                url: BUSINESS_SERVICE + '/adjudication/payment/refund/smcManager/view/',
                name: 'View Refund Case Detail'
            },
            ResponseAbtRefund: {
                url: BUSINESS_SERVICE + '/adjudication/payment/refund/smcManager/submit',
                name: 'Response Abt Refund'
            },
            GetOutgoingPaymentCases: {
                url: BUSINESS_SERVICE + '/adjudication/cases/outgoing/payment',
                name: 'Get Outgoing Payment Cases'
            },
            OfficerGetCourierList: {
                url: BUSINESS_SERVICE + '/adjudication/courier/details/view',
                name: 'Officer Get Courier List'
            },
            OfficerAddCourier: {
                url: BUSINESS_SERVICE + '/adjudication/courier/details/add',
                name: 'Officer Add Courier'
            },
            GetSingleCourierDetails: {
                url: BUSINESS_SERVICE + '/adjudication/courier/details/view/',
                name: 'Get Single Courier Details'
            },
            OfficerUpdateCourier: {
                url: BUSINESS_SERVICE + '/adjudication/courier/details/update',
                name: 'Officer Update Courier'
            },
            OfficerGetCodeList: {
                url: BUSINESS_SERVICE + '/common/codeinfo',
                name: 'Officer Get Code List'
            },
            updateCodeTableValue: {
                url: BUSINESS_SERVICE + '/common/update/codeinfo',
                name: 'update Code Table Value'
            },
            GetUnassignedMemberList: {
                url: BUSINESS_SERVICE + '/adjudication/unassigned/members',
                name: 'Get Unassigned Member List'
            },
            GetAssignedCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/assigned/staff/caseNumbers',
                name: 'Get Assigned Case List'
            },
            SubmitReassignedCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/reassign/cases',
                name: 'Submit Reassigned Case List'
            },
            GetAllAdjudicatorList: {
                url: BUSINESS_SERVICE + '/adjudication/all/adjudicators',
                name: 'Get All Adjudicator List'
            },
            GetCaseLoadList: {
                url: BUSINESS_SERVICE + '/adjudication/case/load',
                name: 'Get Case Load List'
            },
            GetToDoList: {
                url: BUSINESS_SERVICE + '/adjudication/todo/list',
                name: 'Get ToDo List'
            },
            GetAllDetermineList: {
                url: BUSINESS_SERVICE + '/adjudication/view/determine/list',
                name: 'Get All Determine List'
            },
            DownloadDetermineDocument: {
                url: BUSINESS_SERVICE + '/adjudication/download/determination/',
                name: 'Download Determine Document'
            },
            GetAllGenetateReports: {
                url: BUSINESS_SERVICE + '/adjudication/generate/report',
                name: 'Get All Genetate Reports'
            },
            DownloadReportsDocument: {
                url: BUSINESS_SERVICE + '/adjudication/download/report',
                name: 'Download Reports Document'
            },
            GetAdditionalReports: {
                url: BUSINESS_SERVICE + '/adjudication/generate/additional/report',
                name: 'Get Additional Reports'
            },
            ExportAdjudicatorList: {
                url: BUSINESS_SERVICE + '/adjudication/export/adjudicator/list/',
                name: 'Export Adjudicator List'
            },

            AdjudicatorResignationRequest: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/resign/request',
                name: 'Adjudicator Resignation Request Initiated'
            },
            ViewResignationRequest: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/resign/request/view/',
                name: 'View  Resignation Request'
            },
            ApproveResignationRequest: {
                url: BUSINESS_SERVICE + '/adjudication/smcOfficer/approve/adjudicator/resign',
                name: 'Approve Resignation Request'
            },
            ViewResignationRequestBySMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/cases/smcManager/adjudicator/resign',
                name: 'View  Resignation Request by SMC Management'
            },
            ResignationRequestSubmitSMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/smcManager/approve/adjudicator/resign',
                name: 'Approve Resignation Request'
            },
            AdjudicatorResignationTimeCostSubmit: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/time/cost/submit',
                name: 'Adjudicator Resignation Time Cost Submit'
            },
            ViewAdjudicatorResignationTimeCost: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/time/cost/view/',
                name: 'View Adjudicator Resignation Time Cost'
            },
            AdjudicatorResignationTimeCostSubmitToSMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/smcOfficer/submit/adjudicator/timeCost',
                name: 'Adjudicator Resignation Time Cost Sumit to SMC Manager by SMC Officer'
            },
            ViewAdjudicatorResignationTimeCostBySMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/cases/smcManager/adjudicator/resign/timeCost',
                name: 'View Adjudicator Resignation Time Cost by SMC Manager'
            },
            ViewManagementAdjudicatorFees: {
                url: BUSINESS_SERVICE + '/adjudication/smcManager/adjudicator/timeCost/view',
                name: 'View Pending Approval Payment Information'
            },
            AdjudicatorResignationTimeCostSubmitBySMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/smcManager/submit/adjudicator/timeCost',
                name: 'Adjudicator Resignation Time Cost Sumit by SMC Manager'
            },
            ViewAdjudicatorResignedCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicators/resigned/caselist',
                name: 'Adjudicator Resigned Case List View Tab'
            },
            ViewAdjudicatorResignedTimeCostAmend: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/resign/amend/timeCost/',
                name: 'View Adjudicator Resigned Time Cost Amended'
            },
            AdjudicatorResignationTimeCostReSubmit: {
                url: BUSINESS_SERVICE + '/adjudication/adjudicator/resign/time/cost/reSubmit',
                name: 'Adjudicator Resignation Time Cost Re-Sumit'
            },
            SubmitWithDrawByClaimant: {
                url: BUSINESS_SERVICE + '/adjudication/case/withdrawn/request',
                name: 'Submit WithDraw By Claimant'
            },
            GetWithDrawDetails: {
                url: BUSINESS_SERVICE + '/adjudication/case/withdrawn/view/',
                name: 'Get WithDraw Details'
            },
            DownloadWithDrawAck : {
                url : BUSINESS_SERVICE + '/adjudication/download/withdrawal/acknowledgement/',
                name : 'Download WithDraw Ack'
            },
            SubmitWithDrawByOfficer: {
                url: BUSINESS_SERVICE + '/adjudication/case/withdrawn/submit',
                name: 'Submit WithDraw By Officer'
            },
            GetWithDrawCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/withdrawn',
                name: 'Get WithDraw Case List'
            },
            GetWithDrawnCaseList: {
                url: BUSINESS_SERVICE + '/adjudication/cases/adjudicator/withdrawn',
                name: 'Get WithDrawn Case List'
            },

            GetARAFormDetails: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/view/',
                name: 'Get ARA Form Details'
            },
            SaveARAForm: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/save',
                name: 'Save ARA Form'
            },
            SubmitARAForm: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/submit',
                name: 'Submit ARA Form'
            },
            ARADepositeAmount: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/payment/depositamount/',
                name: 'Deposite Amount For ARA Case'
            },
            ARAPaymentSubmit: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/payment',
                name: 'ARA Payment Submit'
            },
            CancelARAApplication: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/request/cancel',
                name: 'Cancel ARA Application'
            },
            GetARARefundData: {
                url: BUSINESS_SERVICE + '/adjudication/ara/payment/refund/view/',
                name: 'View ARA Refund details'
            },
            requestARARefundData: {
                url: BUSINESS_SERVICE + '/adjudication/ara/payment/refund/send/approval',
                name: 'request ARA Refund Data'
            },
            ResponseAbtARARefund: {
                url: BUSINESS_SERVICE + '/adjudication/ara/payment/refund/smcManager/submit',
                name: 'Response Abt ARA Refund'
            },
            GenerateAdjudicatorsARA: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/generate/adjudicators/approval',
                name: 'Generate Adjudicators ARA'
            },
            ResponsePendingAdjudicatorsARA: {
                url: BUSINESS_SERVICE + '/adjudication/araForm/adjudicators/approve',
                name: 'Response Pending Adjudicators ARA'
            },
            InviteTypeAdjudicatorsARA: {
                url: BUSINESS_SERVICE + '/adjudication/ara/invite/adjudicators',
                name: 'Invite Type Adjudicators ARA'
            },
            AdjudicatorAcceptCaseARA: {
                url: BUSINESS_SERVICE + '/adjudication/ara/adjudicator/case/accept',
                name: 'Adjudicator Accept Case ARA'
            },
            AdjudicatorSubmitWithSignatureARA: {
                url: BUSINESS_SERVICE + '/adjudication/ara/adjudicator/case/accept/submit',
                name: 'Adjudicator Submit With Signature ARA'
            },
            SaveARASchedule: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/schedule/save',
                name: 'Save ARA Schedule'
            },
            GetARATimeSheetData: {
                url: BUSINESS_SERVICE + '/adjudication/case/ara/timesheet/view/',
                name: 'Get ARA TimeSheet Data'
            },
            SaveARATimeSheet: {
                url: BUSINESS_SERVICE + '/adjudication/case/ara/timesheet/save',
                name: 'Save ARA TimeSheet'
            },
            SubmitARATimeSheet: {
                url: BUSINESS_SERVICE + '/adjudication/case/ara/timesheet/submit',
                name: 'Submit ARA TimeSheet'
            },
            ViewARATimeSheetOfficer: {
                url: BUSINESS_SERVICE + '/adjudication/case/ara/smcOfficer/timesheet/view/',
                name: 'View ARA TimeSheet Officer'
            },
            SubmitARATimeSheetofficer: {
                url: BUSINESS_SERVICE + '/adjudication/case/ara/timesheet/smcOfficer/submit',
                name: 'Submit ARA TimeSheet officer'
            },
            SubmitARAWithDrawByOfficer: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/withdrawn/submit',
                name: 'Submit ARA WithDraw By Officer'
            },
            SaveARADraftDetermine: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/determination/save',
                name: 'Save ARA Draft Determine'
            },
            OfficerResponseToARADetermination: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/determination/submit',
                name: 'Officer Response To ARA Determination'
            },
            ARAIssueAmendedRequest: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/determination/amended/request',
                name: 'ARAIssueAmendedRequest'
            },
            SubmitARAAmendedApprove: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/determination/amended/submit',
                name: 'Submit ARA Amended Approve'
            },
            SaveRequestARATopUp: {
                url: BUSINESS_SERVICE + '/adjudication/ara/additional/deposit/save',
                name: 'Save Request ARA TopUp'
            },
            SentARADepositRequestClaimant: {
                url: BUSINESS_SERVICE + '/adjudication/ara/additional/deposit/smcOfficer/update',
                name: 'Sent ARA Deposit Request Claimant'
            },
            AdjudicatorARAResignationTimeCostSubmit: {
                url: BUSINESS_SERVICE + '/adjudication/ara/adjudicator/time/cost/submit',
                name: 'Adjudicator ARA Resignation TimeCost Submit'
            },
            SubmitARAWithDrawByRespondant: {
                url: BUSINESS_SERVICE + '/adjudication/ara/case/withdrawn/request',
                name: 'Submit ARA WithDraw By Respondant'
            },
            ARAAdditionalDeposit: {
                url: BUSINESS_SERVICE + '/adjudication/ara/payment/additional/deposit',
                name: 'ARA Additional Deposit'
            },
            AdjudicatorResignationARATimeCostSubmitToSMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/ara/smcOfficer/submit/adjudicator/timeCost',
                name: 'Adjudicator Resignation ARA TimeCost Submit To SMCManager'
            },
            AdjudicatorARAResignationTimeCostSubmitBySMCManager: {
                url: BUSINESS_SERVICE + '/adjudication/ara/smcManager/submit/adjudicator/timeCost',
                name: 'Adjudicator ARA Resignation TimeCost Submit By SMCManager'
            },

            AdminGetUserList: {
                url: BUSINESS_SERVICE + '/contact/users',
                name: 'Admin Get User List'
            },
            AdminAddaUser: {
                url: BUSINESS_SERVICE + '/contact/user/add',
                name: 'Admin Add a User'
            },
            GetaSingleUserDetails: {
                url: BUSINESS_SERVICE + '/contact/user/view/',
                name: 'Get a Single User Details'
            },
            AdminUserStatusUpdate: {
                url: BUSINESS_SERVICE + '/contact/update/user/status',
                name: 'Admin User Status Update'
            },
            AdminGetRoleRights: {
                url: BUSINESS_SERVICE + '/contact/member/roles/access',
                name: 'Admin Get Role Rights'
            },
            AdminGetModulesRoles: {
                url: BUSINESS_SERVICE + '/contact/member/modules/roles',
                name: 'Admin Get Modules Roles'
            },
            AdminSubmitMapRoles: {
                url: BUSINESS_SERVICE + '/contact/assign/user/role/access',
                name: 'AdminSubmitMapRoles'
            },
            AdminGetEvents: {
                url: BUSINESS_SERVICE + '/contact/public/calendar/dates',
                name: 'Admin Get Events'
            },
            AdminAddEvents: {
                url: BUSINESS_SERVICE + '/contact/public/calendar/add',
                name: 'Admin Add Events'
            },
            RemoveEvent: {
                url: BUSINESS_SERVICE + '/contact/public/calendar/date/remove/',
                name: 'Remove Event'
            },
            AdminUpdateEvents: {
                url: BUSINESS_SERVICE + '/contact/public/calendar/update',
                name: 'Admin Update Events'
            },
            GetAssignedRoles: {
                url: BUSINESS_SERVICE + '/contact/view/user/role',
                name: 'Get Assigned Roles'
            },
            AdminSubmitUpdateMapRoles: {
                url: BUSINESS_SERVICE + '/contact/update/user/role/access',
                name: 'Admin Submit Update MapRoles'
            },
            AdminGetReportList: {
                url: BUSINESS_SERVICE + '/contact/admin/report',
                name: 'Admin Get Report List'
            },
            SubmitShareAccess: {
                url: BUSINESS_SERVICE + '/contact/case/access/share',
                name: 'Submit Share Access'
            },
            GetShredCases: {
                url: BUSINESS_SERVICE + '/contact/case/access/shared/users/',
                name: 'Get shared case mails'
            },
            SubmitRemoveAccess: {
                url: BUSINESS_SERVICE + '/contact/case/access/remove',
                name: 'Submit Remove Access'
            },
            GetAssignedAccess: {
                url: BUSINESS_SERVICE + '/contact/view/user/role/access',
                name: 'Get Assigned Access'
            },
            GetAllModules: {
                url: BUSINESS_SERVICE + '/contact/member/modules',
                name: 'Get All Modules'
            },
            GetRolesFromModule: {
                url: BUSINESS_SERVICE + '/contact/member/roles/',
                name: 'Get Roles From Module'
            },
            GetSalutationList: {
                url: BUSINESS_SERVICE + '/common/salutations',
                name: 'Salutation list for Mediation Forms'
            },
            MediationDistriputeList: {
                url: BUSINESS_SERVICE + '/mediation/disputeTypes',
                name: 'Distripute list for Mediation Forms'
            },
            MediationSpecialisationList: {
                url: BUSINESS_SERVICE + '/mediation/specialisation',
                name: 'Specialisation list for Mediation Forms'
            },
            GetMemberTimesheet: {
                url: BUSINESS_SERVICE + '/contact/member/timesheet/view',
                name: ' To view Timesheet Details List for the Member'
            },
            AddMemberTimesheet: {
                url: BUSINESS_SERVICE + '/contact/member/timesheet/save',
                name: ' To add Timesheet Details List for the Member'
            },
            EditMemberTimesheet: {
                url: BUSINESS_SERVICE + '/contact/member/timesheet/view/',
                name: ' To view Timesheet Details by Id'
            },
            UpdateMemberTimesheet: {
                url: BUSINESS_SERVICE + '/contact/member/timesheet/update',
                name: ' To update Timesheet Details by Id'
            },
            DeleteMemberTimesheet: {
                url: BUSINESS_SERVICE + '/contact/member/timesheet/delete',
                name: ' To delete Timesheet Details by Id'
            },
            ContactGetTrainingSummary: {
                url: BUSINESS_SERVICE + '/contact/training/summary/',
                name: 'To get Training Summary'
            },
            ContactGetTrainingDetails:{
                url: BUSINESS_SERVICE + '/contact/training/details',
                name: 'To get Training Details'
            },
            ContactGetCoachingDetails:{
                url: BUSINESS_SERVICE + '/contact/coaching/details',
                name: 'To get Coaching Details'
            },
            ContactGetAssessmentDetails:{
                url: BUSINESS_SERVICE + '/contact/assessment/details',
                name: 'To get Assessment Details'
            },
            ContactAddSdrpCase: {
                url: BUSINESS_SERVICE + '/contact/member/sdrp/case/add',
                name: 'To save SDRP case by member'
            },
            ContactGetSdrpCaseList: {
                url: BUSINESS_SERVICE + '/contact/member/sdrp/case/view',
                name: 'To view SDRP case by memberr'
            },
            ContactDeleteSdrpCase: {
                url: BUSINESS_SERVICE + '/contact/member/sdrp/case/delete',
                name: 'To delete SDRP case by memberr'
            },
            ContactGetSDRPResultDetails:{
                url: BUSINESS_SERVICE + '/contact/member/case/results?caseType=SDRP',
                 name: 'To get case result by member'
            },
            ContactGetNeCaseList: {
                url: BUSINESS_SERVICE + '/contact/member/ne/case/view',
                name: 'Contact Get Ne case list'
            },
            ContactAddNeCase: {
                url: BUSINESS_SERVICE + '/contact/member/ne/case/add',
                name: 'Contact Add Ne case'
            },
            ContactDeleteNeCase: {
                url: BUSINESS_SERVICE + '/contact/member/ne/case/delete',
                name: 'Contact Delete Ne case'
            },
            MemberGetNECaseResultList: {
                url: BUSINESS_SERVICE + '/contact/member/case/results?caseType=NE',
                name: 'To Get Mediator Case Results details'
            },
            ContactAddCfpCaseList: {
                url: BUSINESS_SERVICE + '/contact/member/cfp/case/add',
                name: 'To save CFP case by member'
            },
            ContactDeleteCfpCaseList: {
                url: BUSINESS_SERVICE + '/contact/member/cfp/case/delete',
                name: 'To delete CFP case by member'
            },
            ContactGetCfpCaseList: {
                url: BUSINESS_SERVICE + '/contact/member/cfp/case/view',
                name: 'To get CFP case by member'
            },
            ContactGetCFPResultDetails:{
                url: BUSINESS_SERVICE + '/contact/member/case/results?caseType=CFP',
                name: 'To get case result by member'
            },
            MediationIndustryList: {
                url: BUSINESS_SERVICE + '/common/industry',
                name: 'Industry list for Mediation Forms'
            },
            GetLanguageList: {
                url: BUSINESS_SERVICE + '/common/languages',
                name: 'Language list for Mediation Forms'
            },
            MediationAgeGroupList: {
                url: BUSINESS_SERVICE + '/common/ages',
                name: 'Age Group list for Mediation Forms'
            },
            MediationHearAboutusList: {
                url: BUSINESS_SERVICE + '/common/hearaboutus',
                name: 'Hear About Us list for Mediation Forms'
            },
            MediationCountryCodeList: {
                url: BUSINESS_SERVICE + '/common/countrycode',
                name: 'Country Code list for Mediation Forms'
            },
            MediationMediatorList: {
                url: BUSINESS_SERVICE + '/mediation/mediators',
                name: 'Mediator List for Mediation Forms'
            },
            MediationSaveCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/cmsform/save',
                name: 'Save CMS Form for Mediation Forms'
            },
            MediationSaveSCCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/sccmsform/save',
                name: 'Save SCCMS Form for Mediation Forms'
            },
            MediationSaveCPEForm: {
                url: BUSINESS_SERVICE + '/mediation/cpeform/save',
                name: 'Save CPE Form for Mediation Forms'
            },
            MediationSubmitCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/cmsform/submit',
                name: 'Submit CMS FOrm'
            },
            MediationSubmitSCCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/sccmsform/submit',
                name: 'Submit SCCMS FOrm'
            },
            MediationSubmitCPEForm: {
                url: BUSINESS_SERVICE + '/mediation/cpeform/submit',
                name: 'Submit CPE Form'
            },
            MediationDownloadForm: {
                url: BUSINESS_SERVICE + '/mediation/download/',
                name: 'Download Mediation Form'
            },
            GetMediationIncompleteCaseList: {
                url: BUSINESS_SERVICE + '/mediation/cases/incomplete',
                name: 'Get Mediation Incomplete Case List'
            },
            GetMediationInprogressCaseList: {
                url: BUSINESS_SERVICE + '/mediation/cases/inprogess',
                name: 'Get Mediation Inprogess Case List'
            },
            AssignMediationCaseToOfficer: {
                url: BUSINESS_SERVICE + '/mediation/assign/case',
                name: 'Assign Mediation Case To Officer'
            },
            UpdateMediationPayeeName: {
                url: BUSINESS_SERVICE + '/mediation/update/payeeName',
                name: 'Update Mediation Payee Name'
            },
            GetMediationPayeeName: {
                url: BUSINESS_SERVICE + '/mediation/payee/',
                name: 'Get Mediation Payee Name'
            },
            ViewCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/cmsform/view/',
                name: 'View CMS Form'
            },
            ViewSCCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/sccmsform/view/',
                name: 'View SCCMS Form'
            },
            ViewCPEForm: {
                url: BUSINESS_SERVICE + '/mediation/cpeform/view/',
                name: 'View CPE Form'
            },
            ChangeMediationType: {
                url: BUSINESS_SERVICE + '/mediation/type/change',
                name: 'Change Mediation Type'
            },
            UpdateQuantumDispute: {
                url: BUSINESS_SERVICE + '/mediation/update/quantumdispute',
                name: 'Update Quantum Dispute'
            },
            GetCancelCaseReasons: {
                url: BUSINESS_SERVICE + '/mediation/case/cancel/reasons',
                name: 'Get Cancel Case Reasons'
            },
            CancelMediationCase: {
                url: BUSINESS_SERVICE + '/mediation/case/request/cancel',
                name: 'Cancel Mediation Case'
            },
            GetMediationLapsedCaseList: {
                url: BUSINESS_SERVICE + '/mediation/lapsed/view',
                name: 'Get Mediation Lapsed Case List'
            },
            GetLapsedCancelDetail: {
                url: BUSINESS_SERVICE + '/mediation/case/request/cancel/view/',
                name: 'GetLapsedCancelDetail'
            },
            DownloadCMSForm: {
                url: BUSINESS_SERVICE + '/mediation/download/',
                name: 'DownloadCMSForm'
            },
            UpdateFormParties: {
                url: BUSINESS_SERVICE + '/mediation/addorupdate/party',
                name: 'UpdateFormParties'
            },
            GetFormOnlyRespondentsDetailsByRespondent: {
                url: BUSINESS_SERVICE + '/mediation/case/respondent/view',
                name: 'Get Respondents Details By Respondent'
            },
            MediationPaymentSubmit: {
                url: BUSINESS_SERVICE + '/mediation/payment',
                name: "Mediation Payment Submit"
            },
            GetFormAllDetailsByRespondent: {
                url: BUSINESS_SERVICE + '/mediation/case/respondent/viewdetails',
                name: "Get Response Form Data"
            },
            FinalResponseofRedpondent: {
                url: BUSINESS_SERVICE + '/mediation/respondent/accept/case',
                name: 'Accept or reject case'
            },

            GetRespondentcaseSummaryByCaseNumberMediation: {
                url: BUSINESS_SERVICE + '/mediation/case/members/summary',
                name: 'Get Respondent case summary'

            },
            UpdateRespondentDatabyRedpondent: {
                url: BUSINESS_SERVICE + '/mediation/respondent/details/update',
                name: 'Update Respondent Details'
            },

            ProgramMasterDatasList: {
                url: BUSINESS_SERVICE + '/training/masterprogram/view',
                name: 'Get Program Master Datas List with Filter'
            },
            GetCategoryList: {
                url: BUSINESS_SERVICE + '/training/masterprogram/category',
                name: 'Get Category List'
            },
            GetProgramNameList: {
                url: BUSINESS_SERVICE + '/training/masterprogram/name/',
                name: 'Get Program Name List'
            },
            AddProgramMasterDetails: {
                url: BUSINESS_SERVICE + '/training/masterprogram/add',
                name: 'Add Program Master Details'
            },
            UpdateProgramMasterDetail: {
                url: BUSINESS_SERVICE + '/training/masterprogram/update',
                name: 'Update Program Master Detail'
            },
            CheckAvailabilityProgram: {
                url: BUSINESS_SERVICE + '/training/masterprogram/available',
                name: 'Check Availability Of Program Name'
            },
            ViewScheduleTrainingProgramList: {
                url: BUSINESS_SERVICE + '/training/schedule/program/view',
                name: 'View Schedule Training Program List '
            },
            GetScheduleNameList: {
                url: BUSINESS_SERVICE + '/training/schedule/name',
                name: 'Get Schedule Name List'
            },
            GetEventList: {
                url: BUSINESS_SERVICE + '/training/masterprogram/event',
                name: 'Get Event List'
            },
            AddTrainingSchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/program/add',
                name: 'Add Training Schedule'
            },
            UpdateTrainingSchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/program/update',
                name: 'Update Training Schedule'
            },
            ResubmitTrainingSchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/program/resubmit',
                name: 'Resubmit Training Schedule'
            },
            GetSingleSchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/program/view/',
                name: 'Get Single Schedule'
            },
            TrainingScheduleRequest: {
                url: BUSINESS_SERVICE + '/training/schedule/program/send/approval',
                name: 'Training Schedule Request'
            },
            GetTrainingApprovalList: {
                url: BUSINESS_SERVICE + '/training/schedule/program/manager/view',
                name: 'Get Training Approval List'
            },
            ManagerUpdateTrainingSchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/program/manager/update',
                name: 'Manager Update Training Schedule'
            },
            GetMembersList: {
                url: BUSINESS_SERVICE + '/training/program/memberlist',
                name: 'Get Trainers List'
            },
            GetProgramDateList: {
                url: BUSINESS_SERVICE + '/training/view/program/datelist',
                name: 'Get Program Dates'
            },
            SaveTimeSessionOfficer: {
                url: BUSINESS_SERVICE + '/training/add/programsession/save',
                name: 'Save Time Session'
            },
            SubmitTimeSessionOfficer: {
                url: BUSINESS_SERVICE + '/training/add/programsession/submit',
                name: 'Submit Time Session'
            },
            TrainingDeleteSchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/program/delete',
                name: 'Training Delete Schedule'
            },
            TrainingDeleteScheduleByManager: {
                url: BUSINESS_SERVICE + '/training/schedule/program/manager/delete',
                name: 'Training Delete Schedule By Manager'
            },
            ContactTrainer: {
                url: BUSINESS_SERVICE + '/training/trainer/request/availability',
                name: 'Contact trainer'
            },
            ContactCoach: {
                url: BUSINESS_SERVICE + '/training/coach/request/availability',
                name: 'Contact Coach'
            },
            ContactAssessor: {
                url: BUSINESS_SERVICE + '/training/assessor/request/availability',
                name: 'Contact Assessor'
            },
            GetTrainerPendingList: {
                url: BUSINESS_SERVICE + '/training/member/invite',
                name: 'Get Trainer Pending List'
            },
            ViewTrainerProgramById: {
                url: BUSINESS_SERVICE + '/training/trainer/program/view',
                name: 'View Trainer Program By Id'
            },
            ViewAssessorProgramById: {
                url: BUSINESS_SERVICE + '/training/assessor/program/view',
                name: 'View assessor Program By Id'
            },
            ViewCoachProgramById: {
                url: BUSINESS_SERVICE + '/training/coach/programlist',
                name: 'View Coach Program By Id'
            },
            TrainerSubmitAvalaibility: {
                url: BUSINESS_SERVICE + '/training/trainer/confirm/availability',
                name: 'Trainer Submit Avalaibility'
            },
            AssessorSubmitAvalaibility: {
                url: BUSINESS_SERVICE + '/training/assessor/confirm/availability',
                name: 'assessor Submit Avalaibility'
            },
            CoachSubmitAvalaibility: {
                url: BUSINESS_SERVICE + '/training/coach/availability',
                name: 'coach Submit Avalaibility'
            },
            GetProgramListBySchedule: {
                url: BUSINESS_SERVICE + '/training/schedule/view/programlist/',
                name: 'Get Program List By Schedule'
            },
            ViewTrainerStatus: {
                url: BUSINESS_SERVICE + '/training/trainer/availability',
                name: 'View Trainer Status'
            },
            ViewAssessorStatus: {
                url: BUSINESS_SERVICE + '/training/assessor/availability',
                name: 'View assessor Status'
            },
            SendTrainerListToManager: {
                url: BUSINESS_SERVICE + '/training/trainer/request/approval',
                name: 'Send Triners List To Manager'
            },
            SendAssessorListToManager: {
                url: BUSINESS_SERVICE + '/training/assessor/request/approval',
                name: 'Send Triners List To Manager'
            },
            GetTrainingTrainersApprovalList: {
                url: BUSINESS_SERVICE + '/training/approval/trainer/list',
                name: 'Get Training Trainers Approval List'
            },
            GetTrainingAssessorsApprovalList: {
                url: BUSINESS_SERVICE + '/training/approval/assessor/list',
                name: 'Get Training Assessors Approval List'
            },
            ViewTrainerProgramByManager: {
                url: BUSINESS_SERVICE + '/training/manager/trainer/view',
                name: 'View Trainer Program By Manager'
            },
            ViewAssessorProgramByManager: {
                url: BUSINESS_SERVICE + '/training/manager/assessor/view',
                name: 'View Assessors Program By Manager'
            },
            submitTrainerByManger: {
                url: BUSINESS_SERVICE + '/training/trainer/approval',
                name: 'submit Trainers By Manger'
            },

            GetContactsTobeCompletedList: {
                url: BUSINESS_SERVICE + '/contact/approved/members',
                name: 'Get Approved Member List From Training'
            },
            Invitealladjudicatorfrmapprovedlis: {
                url: BUSINESS_SERVICE + '/contact/invite/adjudicators',
                name: ' Invite Adjudicator from Approved Memebr List By SMC Officer'
            },
            InviteAllMediatorFromApprovedList: {
                url: BUSINESS_SERVICE + '/contact/invite/mediators',
                name: ' Invite Mediator from Approved Memebr List By Contact Officer'
            },
            CertificatedPrintedList: {
                url: BUSINESS_SERVICE + '/contact/certificate/printed/members',
                name: 'certificate printed member list'
            },

            GetTermsandConditionsDetails: {
                url: BUSINESS_SERVICE + '/contact/appoint/adjudicator/terms/conditions/details/',
                name: ' Invite Adjudicator from Approved Memebr List By SMC Officer'
            },
            GetMemberRoleDetails: {
                url: BUSINESS_SERVICE + '/contact/member/role/',
                name: 'To Get Member Role Details'
            },
            GetSmcMemberRoleDetails: {
                url: BUSINESS_SERVICE + '/contact/smc/member/roles',
                name: 'To Get SMC Member Roles Details'
            },
            AdjudicatorAccepetdMemberDetails: {
                url: BUSINESS_SERVICE + '/contact/accepted/members',
                name: 'Accepted Member List'
            },
            AdjudicatorInviteList: {
                url: BUSINESS_SERVICE + '/contact/member/invite/list',
                name: 'adjudicator acceptance Rate'
            },
            GetMemberRenewalList:{
                url: BUSINESS_SERVICE + '/contact/member/renewal/list',
                name: 'Get renewal member list'
            },
            InviteAllMembersFromApprovedList: {
                url: BUSINESS_SERVICE + '/contact/member/invite',
                name: 'Member invite from list'
            },
            GetmemberdetailsforTermsandconditions: {
                url: BUSINESS_SERVICE + '/contact/appoint/adjudicator/terms/conditions/details/',
                name: 'To get Member Details for Terms & Conditions'
            },
            AcceptTermsandConditionsbyAdjudicator: {
                url: BUSINESS_SERVICE + '/contact/member/accept/adjudicator/tc',
                name: 'To Accept Terms & Conditions by Adjudicator'
            },
            UpdatememberStatusBySMCOfficer: {
                url: BUSINESS_SERVICE + '/contact/update/smc/member/status',
                name: 'To get Not Interested Member List'
            },
            NotInterestedMemberlist: {
                url: BUSINESS_SERVICE + '/contact/not/interested/members',
                name: ' To Update SMC Member Status by SMC Officer'
            },
            GenerateCertificateBySmcOfficer: {
                url: BUSINESS_SERVICE + '/contact/generate/certificates',
                name: 'To Generate Certificate by SMC Officer'
            },
            ChangePassword: {
                url: BUSINESS_SERVICE + '/contact/user/password/change',
                name: 'change password'
            },
            ResetPasswordRequest: {
                url: BUSINESS_SERVICE + '/contact/user/password/reset',
                name: 'reset password'
            },
            GetMembersRoleWithId: {
                url: BUSINESS_SERVICE + '/contact/smc/member/roles',
                name: 'Get Members Role With Id'
            },
            ViewMemberProfileDetails: {
                url: BUSINESS_SERVICE + '/contact/member/profile/view/',
                name: 'To View Member Profile Details'
            },
            ViewMembershipProfileDetails: {
                url: BUSINESS_SERVICE + '/contact/member/membership/view/',
                name: 'To View Member Profile Details'
            },
            MemberProfileUpdate: {
                url: BUSINESS_SERVICE + '/contact/member/profile/update',
                name: ' To Update Member Profile Details'
            },
            GetOrganizationList: {
                url: BUSINESS_SERVICE + '/contact/organisations',
                name: 'To get Organisation List'
            },
            GetAdjudicatorCaseSummary: {
                url: BUSINESS_SERVICE + '/contact/adjudicator/case/summary/',
                name: 'To get Adjudicator Case Summary'
            },
            ToUpdatemembersUnavailabilityDate: {
                url: BUSINESS_SERVICE + '/contact/member/update/unavailability',
                name: 'To Update the Member’s Unavailability Date'
            },
            GetDecliendAdjudicationCases: {
                url: BUSINESS_SERVICE + '/contact/adjudicator/declined/cases',
                name: 'To get Declined Adjudication Cases by Adjudicator'
            },
            AddMemberProfessionalRequirementByAdudicator: {
                url: BUSINESS_SERVICE + '/contact/member/professional/requirement/add',
                name: 'To Add Member Professional Requirement By Adjudicator'
            },
            DeleteMemberProfessionalRequirement: {
                url: BUSINESS_SERVICE + '/contact/member/professional/requirement/delete/',
                name: 'To Delete Member Professional Requirement By SMC Member'
            },
            ViewMemberProfessionalRequirementDetail: {
                url: BUSINESS_SERVICE + '/contact/member/professional/requirement/view/',
                name: 'To View Member Professional Requirement Detail'
            },
            UpdateMemberProfessionalRequirement: {
                url: BUSINESS_SERVICE + '/contact/member/professional/requirement/update',
                name: 'To Update Member Professional Requirement By SMC Member'
            },
            AddMemberProfessionalRequirementBySMCOfficer: {
                url: BUSINESS_SERVICE + '/contact/smcOfficer/professional/requirement/add',
                name: 'To Add Member Professional Requiremtn Detail by SMC Officer'
            },
            UpdateMemberProfessionalRequirementBySMCOfficer: {
                url: BUSINESS_SERVICE + '/contact/smcOfficer/professional/requirement/update',
                name: 'To Update Member Professional Requiremtn Detail by SMC Officer'
            },
            UpdateMemberProfessionalRequirementDetailsBySMCOfficer: {
                url: BUSINESS_SERVICE + '/contact/smcOfficer/professional/requirement/update',
                name: 'To update Member professional Requirement Details by SMC Officer'
            },
            ToGetAdjudicatorsList: {
                url: BUSINESS_SERVICE + '/contact/member/adjudciators',
                name: 'To Get Adjudicator List'
            },
            OfficerGetMemberProfessionalRequirements: {
                url: BUSINESS_SERVICE + '/contact/smcOfficer/professional/requirements',
                name: 'To get Member Professional Requirement List for SMC Officer'
            },
            submitAssessorByManger: {
                url: BUSINESS_SERVICE + '/training/assessor/approval',
                name: 'submit Assessors ByManger'
            },

            GetTrainerTermsConditionBySchedule: {
                url: BUSINESS_SERVICE + '/training/trainer/approved/program/view',
                name: 'Get Trainer Terms Condition By Schedule'
            },
            TrainingAcceptedTerms: {
                url: BUSINESS_SERVICE + '/training/trainer/accept/program',
                name: 'Training Accepted Terms'
            },
            ViewTrainerProgramStatusByOfficer: {
                url: BUSINESS_SERVICE + '/training/officer/trainer/view',
                name: 'View Trainer Program Status By Officer'
            },
            ViewAssessorProgramStatusByOfficer: {
                url: BUSINESS_SERVICE + '/training/officer/assessor/view',
                name: 'View Trainer Program Status By Officer'
            },
            PleaseAdviceARDueDate: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/arDueDate',
                name: 'Please Advice AR Due Date'
            },
            PleaseAdviceDetermineDate: {
                url: BUSINESS_SERVICE + '/adjudication/case/schedule/determineDueDate',
                name: 'Please Advice Determine Date'
            },
            ViewTimeSessionCoachByOfficer: {
                url: BUSINESS_SERVICE + '/training/view/programsession',
                name: 'View Time Session Coach By Officer'
            },
            ViewContactCoachStatus: {
                url: BUSINESS_SERVICE + '/training/coach/status',
                name: 'View Contact Coach Status'
            },
            AppointedContactCoaches: {
                url: BUSINESS_SERVICE + '/training/coach/appoint',
                name: 'Appointed Contact Coaches'
            },
            MediationUpdateFormData: {
                url: BUSINESS_SERVICE + '/mediation/update/formfields',
                name: 'Mediation Update form'
            },

            GetPartiesMediatorAndDates: {
                url: BUSINESS_SERVICE + '/mediation/view/case/memberdates/',
                name: 'Get Parties Mediator And Dates'
            },
            UpdateMediationDateByOfficer: {
                url: BUSINESS_SERVICE + '/mediation/smcofficer/update/dates',
                name: 'Update Mediation Date By Officer'
            },
            GetUpdatedMediationDate: {
                url: BUSINESS_SERVICE + '/mediation/smcofficer/view/mediationdates',
                name: 'GetUpdatedMediationDate'
            },
            CodeInfo: {
                url: BUSINESS_SERVICE + '/common/codeinfo/value',
                name: 'Professional requirement for adjudication'
            },
            GetTheChallengeIDandAnswer: {
                url: BUSINESS_SERVICE + '/common/challenge/get',
                name: 'Get the Challenge IDand Answer'
            },
            GetMediationVenueName: {
                url: BUSINESS_SERVICE + '/mediation/venues',
                name: 'Get all the Mediation Venues'
            },
            GetMediationVenueDuration: {
                url: BUSINESS_SERVICE + '/mediation/venue/durations',
                name: 'Get the Mediation Venue Durations'
            },
            GetMediationvenueroomByvenueid: {
                url: BUSINESS_SERVICE + '/mediation/venue/',
                name: 'Get the Mediation Venue Rooms by VenueId'
            },
            GetVenueManagementDetailsforCase: {
                url: BUSINESS_SERVICE + '/mediation/case/',
                name: 'Get Venue management details for case'
            },
            SaveMediationVenueManagementDetails: {
                url: BUSINESS_SERVICE + '/mediation/venue/management/add',
                name: '12.5 To Save Mediation Venue Management Details'
            },
            UpdateVenueDetailsForParticularCase: {
                url: BUSINESS_SERVICE + '/mediation/case/venue/management/update'
            },
            ToViewDeadlineDateoftheParties: {
                url: BUSINESS_SERVICE + '/mediation/deadline/dates/',
                name: 'To View DeadLine Date of the Parties'
            },
            UpdateDeadLIneDateForCase: {
                url: BUSINESS_SERVICE + '/mediation/smcofficer/deadline/update',
                name: 'SMC Officer to update Deadline Date for Parties.'
            },
            GetMediationVenueManagementDetails: {
                url: BUSINESS_SERVICE + '/mediation/venue/management/view',
                name: '12.7 To View Venue Management Details'
            },
            UpdateMediationVenueManagementDetails: {
                url: BUSINESS_SERVICE + '/mediation/venue/management/update',
                name: '12.6 To Update Mediation Venue Management Details'
            },
            UpdateMediationDateForCaseBySmcOfficer: {
                url: BUSINESS_SERVICE + '/mediation/smcofficer/venue/update/mediationdates',
                name: 'SMC Officer to update Mediation Date for Case'
            },
            GetCourierCaseListForSMCOfficer: {
                url: BUSINESS_SERVICE + '/adjudication/courier/cases',
                name: 'To Get Courier Case List for SMC Officer'
            },
            GetTemplateTypes: {
                url: BUSINESS_SERVICE + '/common/template/templatetypes',
                name: 'Get Template Types'
            },
            GetModuleList:{
                url:BUSINESS_SERVICE+'/common/modules/details',
                name:'Get Modules List'
            },
            GetTemplatesList:{
                url:BUSINESS_SERVICE+'/common/template/',
                name:'Get Template List'
            },
            GetTemplatesDetail:{
                url:BUSINESS_SERVICE+'/common/template/view/',
                name:'Get Template Detail'
            },
            UpdateTemplatesDetail:{
                url:BUSINESS_SERVICE+'/common/template/update',
                name:'Update Template List'
            },
            GetModuleById: {
                url: BUSINESS_SERVICE + '/common/template/templatetypes',
                name: 'Get Template Types'
            },
            GetCourierDocumentTypeList: {
                url: BUSINESS_SERVICE + '/common/documentTypes',
                name: 'Get Courier Document Type List'
            },
            GetCourierTimeList: {
                url: BUSINESS_SERVICE + '/common/courierTimes',
                name: 'Get Courier Time List'
            },
            ViewAllCourierDetails:{
                url:BUSINESS_SERVICE+'/adjudication/courier/details/view',
                name:'View All Courier Details with Filter'
            },
            ViewSingleCourierDetail:{
                url:BUSINESS_SERVICE+'/adjudication/courier/details/view/',
                name:'View Single Courier Details'
            },
            GenerateSMSMessageForCourier:{
                url:BUSINESS_SERVICE+'/adjudication/generate/courier/sms',
                name:'Generate SMS Message for Courier'
            },
            UpdateCourierStatusToSelfCollected:{
                url:BUSINESS_SERVICE+'/adjudication/smcOfficer/update/courier/selfCollected',
                name:'SMC Officer Update Courier Status to Self Collected'
            },
            ArrangeCourierServiceWithSMS:{
                url:BUSINESS_SERVICE+'/adjudication/smcOfficer/arrange/courier',
                name:'SMC Officer Arrange Courier Service with SMS'
            },
            GetCourierViewingStatus:{
                url:BUSINESS_SERVICE+'/adjudication/courier/cases/status',
                name:' To Get Courier Viewing Status Tab for SMC Officer'
            },
            GetHealthCheckForAdjudicationCase:{
                url:BUSINESS_SERVICE+'/adjudication/health/check/',
                name:'To Get Health Check for Adjudication Case'
            },
             ViewCourierStatus:{
                url:BUSINESS_SERVICE+'/adjudication/view/courier/details/',
                name:'To Get Courier Status'
            },
            UploadCourierDetail:{
                url:BUSINESS_SERVICE+'/adjudication/upload/courier/document/',
                name:'To Upload Courier Detail'
            },
            GetEmailLogDetail:{
                url:BUSINESS_SERVICE+'/adjudication/email/logs/view',
                name:'To Get Email Log'
            },
             ResendEmailLogDetail:{
                url:BUSINESS_SERVICE+'/adjudication/email/resend',
                name:'To Resend Email Log'
            },
            OfficerGetLawfirmList:{
                url:BUSINESS_SERVICE+'/contact/lawFirms',
                name:'To Get Lawfirm List'
            },
            OfficerAddLawfirm : {
                url :  BUSINESS_SERVICE + '/contact/lawFirm/add',
                name : 'Add lawfirm'
            },
            OfficerUpdateLawfirm : {
                url :  BUSINESS_SERVICE + '/contact/lawFirm/update',
                name : 'Modify lawfirm'
            },
            OfficerDeleteLawfirm : {
                url :  BUSINESS_SERVICE + '/contact/lawFirm/delete',
                name : 'Delete lawfirm'
            },
            ModifyPartyName :{
                url :BUSINESS_SERVICE + '/adjudication/update/partyname',
                name : 'To Modify Claimant/Respondant Name'
            },
            GetLatestDeteminations : {
                url : BUSINESS_SERVICE + '/adjudication/case/determination/top/version/view/',
                name : 'Get Latest Deteminations'
            },
            ViewDateOfServices : {
                url : BUSINESS_SERVICE + '/adjudication/inprogress/view/dates/',
                name : 'View Date of services'
            },
            UpdateChequePostedDate : {
                url : BUSINESS_SERVICE + '/adjudication/case/cheque/postedDate/save',
                name : 'Update Posted Date for a cheque in AA'
            },
            ViewChequePostedDate : {
                url : BUSINESS_SERVICE + '/adjudication/case/cheque/postedDate/view/',
                name : 'View Posted Date for a cheque'
            },
            UpdateChequePostedDateARA : {
                url : BUSINESS_SERVICE + '/adjudication/ara/case/cheque/postedDate/save',
                name : 'Update Posted Date for a cheque in ARA'
            },
            ViewFaxLog :{
                url : BUSINESS_SERVICE +'/adjudication/efax/logs/view',
                name : 'View the Fax logs for the case'
            },
            GetFaxDetail : {
                url : BUSINESS_SERVICE +'/adjudication/efax/report/',
                name : 'View the Fax detail for the case'
            },
            AuditTrialData : {
                url : BUSINESS_SERVICE +'/adjudication/smcOfficer/audit',
                name : 'View Audit Trial Data'
            },
            DownloadFaxData:{
                url : BUSINESS_SERVICE+'/adjudication/efax/report/download/',
                name : 'Download Fax data'
            },
            UpdateDetrminationRequest : {
                url : BUSINESS_SERVICE + '/adjudication/ara/case/determination/update',
                name : 'Update Dtermination'
            },
            GetTriningToDoListOfficer : {
                url : BUSINESS_SERVICE + '/training/officer/todo',
                name : 'Training to-do list'
            },
            GetTriningToDoListManager : {
                url : BUSINESS_SERVICE + '/training/manager/todo',
                name : 'Training to-do list'
            },
            GetApprovedProgramList : {
                url : BUSINESS_SERVICE + '/training/approved/programlist/view',
                name : 'Get Approved Program List'
            },
            TrainingProgramUpdateDetails : {
                url : BUSINESS_SERVICE + '/training/program/update/venue',
                name : 'Training Program Update Details'
            },
            GetHealthCheckForTrainingProg : {
                url : BUSINESS_SERVICE + '/training/program/status/',
                name : 'Get Health Check For Training Prog'
            },
            ContactGetPanelList : {
                url : BUSINESS_SERVICE + '/contact/panels/view',
                name : 'Contact Officer Get Panel List'
            },
            ContactAddPanel : {
                url : BUSINESS_SERVICE + '/contact/panel/add',
                name : 'Contact Officer add panel'
            },
            ContactEditPanel : {
                url : BUSINESS_SERVICE + '/contact/panel/update',
                name : 'Contact Officer update panel'
            },
            ContactGetSMCMemberList : {
                url : BUSINESS_SERVICE + '/contact/smcmember/details',
                name : 'Contact Officer Get SMC Member List'
            },
            ContactGetSMCMembershipList : {
                url : BUSINESS_SERVICE + '/contact/member/membership/details',
                name : 'Contact Officer Get SMC Member List'
            },
            ContactGetNonMemberList : {
                url : BUSINESS_SERVICE + '/contact/nonmember/details/list',
                name : 'Contact Officer Get Non Member List'
            },
            MediatorRegistration :{
                url : BUSINESS_SERVICE + '/contact/mediator/registration',
                name : 'Mediator Registration'
            },
            GetMediatorRegisterPaymentDetail :{
                url : BUSINESS_SERVICE + '/contact/mediator/payable/amount',
                name : 'Get Mediator Payable Amount'
            },
            MakeMediatorPayment:{
                url : BUSINESS_SERVICE + '/contact/payment',
                name : 'Make Mediator Payment'
            },
            ContactProfileView : {
                url : BUSINESS_SERVICE + '/contact/smcmember/view/',
                name : 'Contact officer view details'
            },
            GetCollectionReports : {
                url : BUSINESS_SERVICE + '/adjudication/payment/report',
                name : 'Collection Reports Adjudication'
            },
            UpdateCollectionReceiptDate : {
                url : BUSINESS_SERVICE + '/adjudication/payment/update/receipt',
                name : 'Collection report update receipt'
            },
            ContactGetComplaintList : {
                url : BUSINESS_SERVICE + '/contact/complaint/list',
                name : 'Contact Officer Complaint List'
            },
            ContactGetMembersbyRole : {
                url : BUSINESS_SERVICE + '/contact/member/name/',
                name : 'Contact Officer Get Member List'
            },
            ContactAddComplaint : {
                url : BUSINESS_SERVICE + '/contact/save/complaint',
                name : 'Add Complaint'
            },
            GetBalancePaymentReports : {
                url : BUSINESS_SERVICE + '/adjudication/adjudciators/balance/payment/report',
                name : 'Get Balance Payment Report'
            },
            ContactAddWatchlist : {
                url : BUSINESS_SERVICE + '/contact/watch/save',
                name : 'Add Watch list'
            },
            UpdateWatch: {
                url : BUSINESS_SERVICE + '/contact/watch/update',
                name  : 'Get Update Watch'
            },
            DeleteWatch: {
                url : BUSINESS_SERVICE + '/contact/watch/delete',
                name  : 'Get Delete Watch'
            },
            GetWatchbyWatchId :{
                url : BUSINESS_SERVICE + '/contact/watch/view/',
                name  : 'Get Invited Mediator List'
            },
            ContactGetMemberList :{
                url: BUSINESS_SERVICE+'/contact/smcmembers',
                name: 'To Get SMC Members List'
            },
            ContactGetMemberTypeList :{
                url: BUSINESS_SERVICE+'/contact/member/type/SMC Member',
                name: 'To Get SMC Members Type List'
            },
            ContactUpdateUserId :{
                url: BUSINESS_SERVICE+'/contact/smcmember/update',
                name: 'To Update User Id'
            },
            ContactGetWatchList :{
                url: BUSINESS_SERVICE+'/contact/watch/list/view',
                name: 'Contact Officer Watch List'
            },
            ContactGetOtherCetegoryMembers:{
                url: BUSINESS_SERVICE+'/contact/other/member/category',
                name: 'To View Other New Member Categories'
            },
            ContactOtherCategoryMembersList:{
                url: BUSINESS_SERVICE+'/contact/othermember/detail/list',
                name: 'To get New Member Categories list'
            },
            ContactSaveOtherCetegoryMembers:{
                url: BUSINESS_SERVICE+'/contact/othermember/save',
                name: 'To get New Member Categories list'
            },
            ContactUpdateOtherCetegoryMembers:{
                url: BUSINESS_SERVICE+'/contact/othermember/update',
                name: 'To get New Member Categories list'
            },
            PaymentGenerateInvoice : {
                url : BUSINESS_SERVICE + '/adjudication/generate/invoice',
                name : 'Payment Generate Invoice'
            },
            PaymentGenerateReceipt : {
                url : BUSINESS_SERVICE + '/adjudication/generate/receipt',
                name : 'Payment Generate Receipt'
            },
            PaymentGenerateProforma : {
                url : BUSINESS_SERVICE + '/adjudication/generate/proforma',
                name : 'Payment Generate Proforma'
            },
            GetPaymentModes : {
                url : BUSINESS_SERVICE + '/finance/paymentmode',
                name : 'Get Payment Modes'
            },
            GetPaymentTypes : {
                url : BUSINESS_SERVICE + '/finance/paymenttype',
                name : 'Get payment types'
            },
            GetFailedInvoices : {
                url : BUSINESS_SERVICE + '/adjudication/payment/invoice/',
                name : 'Get Failed Invoices'
            },
            AddPaymentByOfficer : {
                url : BUSINESS_SERVICE + '/adjudication/payment/add',
                name : 'Add Payment By SMC Officer'
            },
            GetPaymentDetailstoView : {
                url : BUSINESS_SERVICE + '/adjudication/cheque/status/',
                name : 'Get Payment Details to View'
            },
            UpdateChequeDetails : {
                url : BUSINESS_SERVICE + '/adjudication/payment/update/cheque',
                name : 'Update Cheque Details'
            },
            PreviewProgram : {
                url : BUSINESS_SERVICE + '/training/program/preview/',
                name : 'Preview Program'
            },
            GetBillingMatters : {
                url : BUSINESS_SERVICE + '/finance/billing/matters',
                name : 'Get Billing Matters'
            },
            TrainingProgramPublish : {
                url : BUSINESS_SERVICE + '/training/program/publish',
                name : 'Training Program Publish'
            },
            GetRolesByMemberId : {
                url : BUSINESS_SERVICE + '/contact/member/roles/view/',
                name : 'Get Roles By Member Id'
            },
            GetMembershipDetails : {
                url : BUSINESS_SERVICE + '/contact/membership/details/view',
                name : 'Get Membership Details'
            },
            UpdateMembershipDetails : {
                url : BUSINESS_SERVICE + '/contact/membership/status/update',
                name : 'Update Membership Details'
            },
            GetUpdateMemberStatusList : {
                url : BUSINESS_SERVICE + '/contact/membership/approval/sent/list',
                name  : 'Get Update Member Status List'
            },
            GetWaiverMasterDatas : {
                url : BUSINESS_SERVICE + '/contact/membership/waivers',
                name : 'Get Waiver Master Datas'
            },
            GetMemberWaiverData : {
                url : BUSINESS_SERVICE + '/contact/membership/waiver/',
                name : 'Get Member Waiver Data'
            },
            UpdateWaiverData : {
                url : BUSINESS_SERVICE + '/contact/waiver/details/update',
                name : 'Update Waiver Data'
            },
            ExportSMCMemberList : {
                url : BUSINESS_SERVICE + '/contact/export/member/list',
                name : 'Export SMC Member List'
            },
            SMCMemberGenerateLetter : {
                url : BUSINESS_SERVICE + '/contact/generate/member/letter',
                name : 'SMC Member Generate Letter'
            },
            SMCMemberSendMail : {
                url : BUSINESS_SERVICE + '/contact/generate/member/email',
                name : 'SMC Member Send Mail'
            },
            SMCMemberRenewalLetter : {
                url : BUSINESS_SERVICE  + '/contact/generate/member/renewal/letter',
                name : 'SMC Member Renewal Letter'
            },
            GetInvitedMeidators : {
                url : BUSINESS_SERVICE + '/training/program/participants',
                name  : 'Get Invited Mediator List'
            },
            GetComplaintsByMember : {
                url : BUSINESS_SERVICE + '/contact/member/complaints/view',
                name : 'Get Complaints By Member'
            },
            GetComplaintsByManager : {
                url : BUSINESS_SERVICE + '/contact/member/management/complaints/view',
                name : 'Get Complaints By Manager'
            },
            GetCategoryMasterData : {
                url : BUSINESS_SERVICE + '/contact/adjudicator/categories',
                name : 'Get Category Master Data'
            },
            GetMemberCategoryData : {
                url : BUSINESS_SERVICE + '/contact/adjudicator/category/',
                name : 'Get Member Category Data'
            },
            UpdateMemberCategory : {
                url : BUSINESS_SERVICE + '/contact/adjudicator/category/update',
                name: 'Update Member Category'
            },
            GetProfileImageByOfficer : {
                url : BUSINESS_SERVICE + '/contact/smcofficer/member/profile/picture/view/',
                name : 'Get Profile Image By Officer'
            },
            GetNonMemberCategoryDetails : {
                url : BUSINESS_SERVICE + '/contact/nonmember/category?includeParty=true',
                name : 'Get Non Member Category Details'
            },
            GetNonMemberDesignationDetails : {
                url : BUSINESS_SERVICE + '/contact/designation/levels',
                name : 'Get NonMember Designation Details'
            },
            GetServiceProviderTypes : {
                url : BUSINESS_SERVICE + '/contact/service/provider/types',
                name : 'Get Service Provider Types'
            },
            GetIndustries : {
                url : BUSINESS_SERVICE + '/common/industry',
                name: 'Get Industries'
            },
            GetLevelOfDesignations: {
                url : BUSINESS_SERVICE + '/contact/designation/levels',
                name : 'get level of designations'
            },
            AddNonMember : {
                url : BUSINESS_SERVICE + '/contact/nonmember/add',
                name : 'Add Non-member'
            },
            GetNonMemberDetails : {
                url : BUSINESS_SERVICE + '/contact/nonmember/details',
                name : 'Get Non Member details'
            },
            UpdateNonMember : {
                url : BUSINESS_SERVICE + '/contact/nonmember/update',
                name : 'Update Non Member'
            },
            GetNonMemberPartyDetails : {
                url : BUSINESS_SERVICE + '/contact/party/details',
                name : 'Get Non Member Party Details'
            },
            UpdateNonMemberPartyDetails : {
                url : BUSINESS_SERVICE + '/contact/party/update',
                name : 'Update Non Member Party Details'
            },
            ExportSMCNonMemberList : {
                url :BUSINESS_SERVICE + '/contact/export/non/member/list',
                name : 'Export SMC Non Member List'
            },
            SMCNonMemberGenerateLetter : {
                url : BUSINESS_SERVICE + '/contact/generate/nonmember/letter',
                name : 'SMC Non Member Generate Letter'
            },
            ChangeActionStatusManager : {
                url : BUSINESS_SERVICE + '/contact/membership/approval/status/update',
                name : 'Change Action Status Manager'
            },
            GetContactCollectionReports : {
                url : BUSINESS_SERVICE + '/contact/payment/report',
                name : 'Get Contact Collection Reports'
            },
            ContactUpdateCollectionReceiptDate : {
                url : BUSINESS_SERVICE + '/contact/payment/update/receipt',
                name : 'Update Collection Receipt Date'
            },
            AddPaymentByContactOfficer :{
                url : BUSINESS_SERVICE + '/contact/payment/add',
                name : 'Add Payment By Contact Officer'
            },
            GetContactPaymentDetailstoView : {
                url : BUSINESS_SERVICE + '/contact/cheque/status/',
                name : 'Get Contact Payment Details to View'
            },
            ContactUpdateChequeDetails : {
                url : BUSINESS_SERVICE + '/contact/payment/update/cheque',
                name : 'Contact Update Cheque Details'
            },
            GetContactFailedInvoices : {
                url : BUSINESS_SERVICE + '/contact/payment/invoice',
                name : 'Get Contact Failed Invoices'
            },
            ExportContactCollectionList : {
                url : BUSINESS_SERVICE + '/contact/export/collection/report',
                name : 'Export Contact Collection List'
            },
            DownloadCollectionReportInvoice : {
                url : BUSINESS_SERVICE + '/contact/generate/invoice',
                name : 'Download Collection Report Invoice'
            },
            DownloadCollectionReportReceipt : {
                url : BUSINESS_SERVICE + '/contact/generate/receipt',
                name : 'Download Collection Report Receipt'
            },
            RegenerateCollectionReportInvoice : {
                url : BUSINESS_SERVICE + '/contact/regenerate/invoice',
                name : 'Regenerate Collection Report Invoice'
            },
            GetContactBalancePaymentReports : {
                url : BUSINESS_SERVICE + '/contact/balance/payment/report',
                name : 'Get Contact Balance Payment Reports'
            },
            GetNatureOfOccupationList : {
                url : BUSINESS_SERVICE + '/contact/occupationnature',
                name : 'Get Nature Of Occupation List'
            },
            GetProfessionalBackgroundList : {
                url : BUSINESS_SERVICE + '/contact/background',
                name: 'Get Professional Background List'
            },
            GetMediatorExpertiseByMember : {
                url : BUSINESS_SERVICE + '/contact/mediator/expertise/view',
                name : 'Get Mediator Expertise By Member'
            },
            UpdateMediatorExpertiseByMember : {
                url : BUSINESS_SERVICE + '/contact/mediator/expertise/update',
                name : 'Update Mediator Expertise By Member'
            },
            GetMediatorCalanderData : {
                url : BUSINESS_SERVICE + '/contact/member/calender/dates',
                name : 'Get Mediator Calander Data'
            },
            GetMediatorCaseSummaryByMember : {
                url : BUSINESS_SERVICE + '/contact/case/summary/mediatior/view',
                name : 'Get Mediator Case Summary By Member'
            },
            GetCommercialRatesByMember : {
                url : BUSINESS_SERVICE + '/contact/member/commercial/rates/view',
                name : 'Get Commercial Rates ByMember'
            },
            UpdateCommercialRatesByMember : {
                url : BUSINESS_SERVICE + '/contact/member/commercial/rates/save',
                name : 'Update Commercial Rates By Member'
            },
            GetPanelInformationListByMember : {
                url : BUSINESS_SERVICE + '/contact/member/panels/view',
                name : 'Get Panel Information List By Member'
            },
            GetSMCMediationCaseListByMember : {
                url : BUSINESS_SERVICE + '/contact/member/smc/mediation/case/view',
                name : 'Get SMC Mediation Case List By Member'
            },
            GetSMCMediationCaseListByOfficer : {
                url : BUSINESS_SERVICE + '/contact/officer/smc/mediation/case/view',
                name : 'Get SMC Mediation Case List By Officer'
            },
            GetNonSMCCaseList : {
                url : BUSINESS_SERVICE + '/contact/member/smc/non/mediation/case/view',
                name : 'Get Non SMC Case List'
            },
            GetAdjudicatorCaseSummaryBySMCOfficer : {
                url : BUSINESS_SERVICE + '/contact/adjudicator/case/summary/detail',
                name : 'Get Adjudicator Case Summary By SMC Officer'
            },
            OfficerGetDeclinedCaseList : {
                url : BUSINESS_SERVICE +'/contact/adjudicator/declined/case/list',
                name : 'Officer Get Declined Case List'
            },
            GetMediatorCaseSummaryByOfficer : {
                url : BUSINESS_SERVICE + '/contact/case/summary/smcofficer/view',
                name : 'Get Mediator Case Summary By Officer'
            },
            GetStatusOfMediatedList : {
                url : BUSINESS_SERVICE + '/contact/statusofcase',
                name : 'Get Status Of Mediated List'
            },
            GetMediatedCaseList : {
                url : BUSINESS_SERVICE + '/contact/case/mediated',
                name : 'Get Mediated Case List'
            },
            GetMediationSubjectList : {
                url : BUSINESS_SERVICE + '/contact/subject/matter/mediation',
                name : 'Get Mediation Subject List'
            },
            AddNonSmcCaseByMember : {
                url : BUSINESS_SERVICE + '/contact/member/smc/non/mediation/case/save',
                name : 'Add Non Smc Case By Member'
            },
            DeleteNonSmcCaseByMember : {
                url : BUSINESS_SERVICE  + '/contact/member/smc/non/mediation/case/delete',
                name : 'Delete Non Smc Case By Member'
            },
            GetSpecDataByMember : {
                url : BUSINESS_SERVICE + '/contact/member/specialisation/view',
                name : 'Get Spec Data By Member'
            },
            UpdateSpecDataByMember : {
                url : BUSINESS_SERVICE + '/contact/member/specialisation/save',
                name : 'Update Spec Data By Member'
            },
            GetSpecialisationList : {
                url : BUSINESS_SERVICE + '/contact/specialisation',
                name : 'Get Specialisation List'
            },
            GetCoMediationList : {
                url : BUSINESS_SERVICE + '/contact/comediator/list',
                name : 'Get Co-Mediation List'
            },
            UpdateMediatorExpertiseByOfficer : {
                url : BUSINESS_SERVICE + '/contact/mediator/expertise/smcofficer/update',
                name : 'Update Mediator Expertise By Officer'
            },
            GetMediatorExpertiseByOfficer : {
                url : BUSINESS_SERVICE + '/contact/officer/mediator/expertise/view',
                name : 'Get Mediator Expertise By Officer'
            },
            OfficerGetNECaseResultList : {
                url : BUSINESS_SERVICE + '/contact/member/case/results?caseType=NE',
                name : 'Officer Get NE Case Result List'
            },
            ContactGetNECaseListByOfficer : {
                url :BUSINESS_SERVICE + '/contact/officer/ne/case/view',
                name : 'Contact Get NE Case List By Officer'
            },
            OfficerGetSDRPCaseResultList : {
                url : BUSINESS_SERVICE + '/contact/member/case/results?caseType=SDRP',
                name : 'Officer Get SDRP Case Result List'
            },
            ContactGetSDRPCaseListByOfficer : {
                url : BUSINESS_SERVICE + '/contact/officer/sdrp/case/view',
                name : 'Contact Get SDRP Case List By Officer'
            },
            ContactOfficerAddSdrpCaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/sdrp/case/add',
                name : 'Contact Officer Add Sdrp Case List'
            },
            ContactOfficerUpdateSdrpCaseList : {
                url :BUSINESS_SERVICE + '/contact/officer/sdrp/case/update',
                name : 'Contact Officer Update Sdrp Case List'
            },
            ContactOfficerDeleteSdrpCaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/sdrp/case/delete',
                name : 'Contact Officer Delete Sdrp Case List'
            },
            ContactGetCfpCaseListByOfficer : {
                url : BUSINESS_SERVICE + '/contact/officer/cfp/case/view',
                name : 'Contact Get Cfp Case List By Officer'
            },
            OfficerGetCFPCaseResultList : {
                url : BUSINESS_SERVICE + '/contact/member/case/results?caseType=CFP',
                name : 'Officer Get CFP Case Result List'
            },
            ContactOfficerAddCfpCaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/cfp/case/add',
                name : 'Contact Officer Add Cfp Case List'
            },
            ContactOfficerUpdateCfpCaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/cfp/case/update',
                name : 'Contact Officer Update Cfp Case List'
            },
            ContactOfficerDeleteCfpCaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/cfp/case/delete',
                name : 'Contact Officer Delete Cfp Case List'
            },
            ContactOfficerUpdateLastContactedDate : {
                url : BUSINESS_SERVICE + '/contact/officer/member/contacted/date/update',
                name : 'Contact Officer Update Last Contacted Date'
            },
            GetMediatorCategoryData : {
                url : BUSINESS_SERVICE + '/contact/mediator/category/',
                name : 'Get Mediator Category Url'
            },
            UpdateMediatorCategory : {
                url : BUSINESS_SERVICE + '/contact/mediator/category/update',
                name : 'Update Mediator Category'
            },
            GetPanelInfoListByOfficer : {
                url : BUSINESS_SERVICE + '/contact/smcofficer/member/panels/view',
                name : 'Get Panel Info List By Officer'
            },
            GetPanelNameList : {
                url : BUSINESS_SERVICE + '/contact/panels',
                name : 'Get Panel Name List'
            },
            AddPanelInfoByOfficer : {
                url : BUSINESS_SERVICE + '/contact/smcofficer/member/panel/add',
                name : 'Add Panel Info By Officer'
            },
            DeletePanelInfoByOfficer : {
                url : BUSINESS_SERVICE + '/contact/smcofficer/member/panel/delete',
                name : 'Delete Panel Info By Officer'
            },
            UpdatePanelInfoByOfficer : {
                url  : BUSINESS_SERVICE  + '/contact/smcofficer/member/panel/update',
                name : 'Update Panel Info By Officer'
            },
            OfficerGetTrainingDetails :{
                url : BUSINESS_SERVICE + '/contact/officer/training/details',
                name : 'Officer Get Training Details'
            },
            ContactOfficerUpdateACTA : {
                url :BUSINESS_SERVICE  + '/contact/member/acta/certified/update',
                name : 'Contact Officer Update ACTA'
            },
            OfficerGetCoachDetails : {
                url : BUSINESS_SERVICE + '/contact/officer/coaching/details',
                name : 'Officer Get Coach Details'
            },
            OfficerGetAssessorDetails : {
                url : BUSINESS_SERVICE + '/contact/officer/assessment/details',
                name : 'Officer Get Assessor Details'
            },
            ContactOfficerAddNECaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/ne/case/add',
                name : 'Contact Officer Add NE Case List'
            },
            ContactOfficerUpdateNECaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/ne/case/update',
                name : 'Contact Officer Update NE Case List'
            },
            ContactOfficerDeleteNECaseList : {
                url : BUSINESS_SERVICE + '/contact/officer/ne/case/delete',
                name : 'Contact Officer Delete NE CaseList'
            },
            ContactGetNonMemberListByManager : {
                url : BUSINESS_SERVICE + '/contact/management/nonmember/details/list',
                name :'Contact Get Non Member List By Manager'
            },
            GetAdjudicatorTouchPointList : {
                url : BUSINESS_SERVICE + '/contact/member/adjudication/cases',
                name : 'Get Adjudicator Touch Point List'
            },
            GetMediatorTouchPointList : {
                url : BUSINESS_SERVICE + '/contact/member/mediation/touchpoint',
                name : 'Get Mediator Touch Point List'
            },
            GetTrainingTouchPointList : {
                url : BUSINESS_SERVICE + '/contact/member/training/cases',
                name : 'Get Training Touch Point List'
            },
            GetCFPTouchPointList : {
                url : BUSINESS_SERVICE + '/contact/member/cfp/touchpoint',
                name: 'Get CFP Touch Point List'
            },
            GetSDRPTouchPointList : {
                url : BUSINESS_SERVICE + '/contact/touchpoint/sdrp/view',
                name : 'Get SDRP Touch Point List'
            },
            GetNETouchPointList : {
                url : BUSINESS_SERVICE + '/contact/touchpoint/ne/view',
                name : 'Get NE Touch Point List'
            },
            GetComplaintTouchPointList : {
                url : BUSINESS_SERVICE + '/contact/touchpoint/complaint/view',
                name : 'Get Complaint Touch Point List'
            },
            RunInvokeRenewalProcess : {
                url : BUSINESS_SERVICE + '/contact/member/invoke/renewal/process',
                name : 'Run Invoke Renewal Process'
            },
            ContactGetWaiverAndRenewalList : {
                url : BUSINESS_SERVICE + '/contact/officer/member/renewal/list',
                name : 'Contact Get Waiver And Renewal List'
            },
            GetPromoteTrainerListByManager : {
                url : BUSINESS_SERVICE + '/contact/management/training/promotion/member/view',
                name : 'Get Promote Trainer List By Manager'
            },
            GetTrainerCategoryMasterData : {
                url : BUSINESS_SERVICE + '/contact/adjudication/faculty/category',
                name : 'Get Trainer Category Master Data'
            },
            GetRecommendationTrainerMasterData : {
                url : BUSINESS_SERVICE + '/contact/recommendation/trainer',
                name : 'Get Recommendation Trainer Master Data'
            },
            GetTrainerSummaryData : {
                url : BUSINESS_SERVICE + '/contact/member/training/summary/view',
                name : 'Get Trainer Summary Data'
            },
            UpdateTrainerSummary : {
                url : BUSINESS_SERVICE + '/contact/member/training/summary/update',
                name : 'Update Trainer Summary'
            },
            GetPromoteTrainerDetails : {
                url :BUSINESS_SERVICE + '/contact/smcOfficer/promote/trainer/view',
                name : 'Get Promote Trainer Details'
            },
            SubmitTrainerPromoteByOfficer : {
                url : BUSINESS_SERVICE + '/contact/smcOfficer/promote/trainer/submit',
                name : 'Submit Trainer Promote By Officer'
            },
            ContactGetToDoList : {
                url : BUSINESS_SERVICE + '/contact/officer/todo',
                name : 'Contact Get To Do List'
            },
            ContactOfficerInvokeRenewalProcess : {
                url : BUSINESS_SERVICE + '/contact/officer/invoke/member/membership/renewals',
                name : 'Contact Officer Invoke Renewal Process'
            },
            ContactOfficerSubmitWaiverToManager : {
                url : BUSINESS_SERVICE + '/contact/officer/member/waiver/submit',
                name : 'Contact Officer Submit Waiver To Manager'
            },
            SubmitCancelInvoiceToManager : {
                url : BUSINESS_SERVICE + '/contact/officer/request/cancel/invoice',
                name : 'Submit Cancel Invoice To Manager'
            },
            GetWaiverListByManager : {
                url : BUSINESS_SERVICE + '/contact/management/member/renewal/list',
                name: 'Get Waiver List By Manager'
            },
            GetCancellationInvoiceListByManager : {
                url : BUSINESS_SERVICE + '/contact/manager/view/cancel/invoices',
                name : 'Get Cancellation Invoice List By Manager'
            },
            ActionCancellationInvoiceListByManager : {
                url : BUSINESS_SERVICE + '/contact/manager/approve/cancel/invoice',
                name : 'Action Cancellation Invoice List By Manager'
            },
            OfficerGetWatchListReport : {
                url : BUSINESS_SERVICE + '/contact/watch/list/report/view',
                name : 'Officer Get Watch List Report'
            },
            GetMemberRenewalPaymentDetails : {
                url : BUSINESS_SERVICE + '/contact/member/renewal/payable/amount',
                name : 'Get Member Renewal Payment Details'
            },
            MakeMemberRenewalPayment : {
                url : BUSINESS_SERVICE + '/contact/member/renewal/payment',
                name : 'Make Member Renewal Payment'
            },
            UpdateMemberAcceptenceForRenewal : {
                url : BUSINESS_SERVICE + '/contact/member/renewal/accept/tc',
                name : 'Update Member Acceptence For Renewal'
            },
            ActionPromoteTrainerByManager : {
                url : BUSINESS_SERVICE + '/contact/management/training/promotion/approval',
                name : 'Action Promote Trainer By Manager'
            },
            OfficerGetMonthlyRenewalList : {
                url : BUSINESS_SERVICE + '/contact/officer/monthly/revenue/reports/view',
                name : 'Officer Get Monthly Renewal List'
            },
            GetInvoiceMemberByOfficer : {
                url : BUSINESS_SERVICE + '/contact/view/member/detail',
                name : 'Get Invoice Member By Officer'
            },
            ContactAddInvoiceByOfficer : {
                url : BUSINESS_SERVICE + '/contact/invoice/add',
                name : 'Contact Add Invoice By Officer'
            },
            GetPublishedProgramListinEvent : {
                url : BUSINESS_SERVICE + '/training/programs/published',
                name : 'Get Published Program List in Event'
            }
        },
        error_messages: {
            ServiceNotWorking: 'Service Error Try'
        },
        versionNo: VERSIONNAME,
        copyrightsYear: COPYRIGHTSYEAR
    });
})();

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}
