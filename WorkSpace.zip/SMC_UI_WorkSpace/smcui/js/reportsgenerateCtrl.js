(function() {
    'use strict';
    angular
        .module('smc')
        .controller('reportsgenerateCtrl',reportsgenerateCtrl);

    reportsgenerateCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function reportsgenerateCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
       
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = true;
        
    	 // to receive filter case list
        $scope.$on('reportCases', function(event, caselist) { 
                $scope.reports = caselist; 
                $scope.shownodataavailable = false;
         });
    }
})();


