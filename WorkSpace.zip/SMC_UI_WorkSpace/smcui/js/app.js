(function () {
    'use strict';

    angular.module('smc', ['ui.router', 'ui.bootstrap', 'ngCookies', 'angular-loading-bar', 'ngSanitize',

            'naif.base64', '720kb.tooltips', 'smc.ui.notify', 'ui.calendar', 'multipleDatePicker','moment-picker','ngCke'
        ])
        .config(config)
        .run(init);

    config.$inject = ['$stateProvider', '$urlRouterProvider', 'smcConfig', '$httpProvider',
        'smcTemplateProvider', 'cfpLoadingBarProvider','momentPickerProvider'
    ];

    function config($stateProvider, $urlRouterProvider, smcConfig, $httpProvider, smcTemplateProvider,
        cfpLoadingBarProvider,momentPickerProvider) {

        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
        $urlRouterProvider.otherwise('/404');


        $urlRouterProvider.when('', '/aa-1');
        $urlRouterProvider.when('/', '/aa-1');


        $stateProvider.state('smclayout', {
                abstract: true,
                views: {
                    mainContent: {
                        templateUrl: smcTemplateProvider.template('common/layout.html')
                    }
                }
            })
            .state('smclayout.aa1formlayout', {
                parent: 'smclayout',
                views: {
                    headerContanier: {
                        templateUrl: smcTemplateProvider.template('common/header-container.html'),
                    },

                    mainContainer: {
                        templateUrl: smcTemplateProvider.template('aa1/common/aa1-form-layout.html'),
                    },

                    footerContainer: {
                        templateUrl: smcTemplateProvider.template('common/footer-container.html'),
                    }
                },
            })
            .state('smclayout.aa1formlayout.aa1', {
                url: '/aa-1',
                parent: 'smclayout.aa1formlayout',
                views: {
                    formAa1Header: {
                        templateUrl: smcTemplateProvider.template('aa1/common/aa1-form-header.html'),
                    },

                    formAa1Fields: {
                        templateUrl: smcTemplateProvider.template('aa1/aa-form1.html'),
                        controller: 'aa1formCtrl'
                    }
                },
            })

        .state('smclayout.aa1formlayout.aaFormNew', {
            url: '/AAFormNew',
            parent: 'smclayout.aa1formlayout',
            views: {
                formAa1Header: {
                    templateUrl: smcTemplateProvider.template('aa1/common/aa1-form-header.html'),
                },

                formAa1Fields: {
                    templateUrl: smcTemplateProvider.template('aa1/aa-form-new.html'),
                    controller: 'aa1formCtrl'
                }
            },
        })



        .state('smclayout.membershiplayout', {
                parent: 'smclayout',
                views: {
                    headerContanier: {
                        template: '',
                    },

                    mainContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/common/layout.html'),
                    },

                    footerContainer: {
                        templateUrl: smcTemplateProvider.template('common/footer-container.html'),
                    }
                },
            })
            .state('smclayout.mediationlayout', {
                parent: 'smclayout',
                views: {
                    headerContanier: {
                        template: '',
                    },

                    mainContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/common/layout.html'),
                    },

                    footerContainer: {
                        templateUrl: smcTemplateProvider.template('common/footer-container.html'),
                    }
                },
            })
            .state('smclayout.membershiplayout.login', {
                url: '/login',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-default.html'),
                        controller : 'defaultPageHeaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/login.html'),
                        controller: 'loginformCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.membersdashboard', {
                url: '/membersdashboard',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-dashboard.html'),
                        controller: 'dashboardPageheaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('common/casemember/dashboard.html'),
                        controller: 'loginboardCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.lawyercasesummary', {
                url: '/lawyercasesummary',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/lawyer-case-summary.html'),
                        controller: 'lawyerCaseDetailCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.lawyercaseview', {
                url: '/lawyercaseview',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/aa-form-view.html'),
                        controller: 'aa1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.submitformprocess', {
                url: '/submitformprocess',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('aa1/aa-form1.html'),
                        controller: 'aa1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.paymentprocess', {
                url: '/paymentprocess',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('aa1/payment.html'),
                        controller: 'paymentCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })

        .state('smclayout.membershiplayout.arapaymentprocess', {
            url: '/arapaymentprocess',
            parent: 'smclayout.membershiplayout',
            views: {
                pageHaderMenu: {
                    templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                    controller: 'pageheaderMemberCtrl'
                },

                pageHaderBanner: {
                    template: '',
                },

                leftContanier: {
                    template: '',
                },

                centerContainer: {
                    templateUrl: smcTemplateProvider.template('respondant/ara-payment.html'),
                    controller: 'araPaymentCtrl'
                },

                rightContainer: {
                    template: '',
                }
            },
        })

        .state('smclayout.membershiplayout.pendinguploadprocess', {
                url: '/pendinguploadprocess',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/pending-document.html'),
                        controller: 'uploadCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.additionaldeposit', {
                url: '/additionaldeposit',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/add_deposit.html'),
                        controller: 'addDepositCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })

        .state('smclayout.membershiplayout.araadditionaldeposit', {
            url: '/respondent/additionaldeposit',
            parent: 'smclayout.membershiplayout',
            views: {
                pageHaderMenu: {
                    templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                    controller: 'pageheaderMemberCtrl'
                },

                pageHaderBanner: {
                    template: '',
                },

                leftContanier: {
                    template: '',
                },

                centerContainer: {
                    templateUrl: smcTemplateProvider.template('respondant/ara_add_deposite.html'),
                    controller: 'araAddDepositCtrl'
                },

                rightContainer: {
                    template: '',
                }
            },
        })

        .state('smclayout.membershiplayout.respondantcasesummary', {
                url: '/respondant/casesummary',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('respondant/respondant-case-summary.html'),
                        controller: 'respondentCaseDetailCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.respondantcaseview', {
                url: '/respondant/respondantcaseview',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('respondant/ar-form-view.html'),
                        controller: 'ar1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.respondantsubmitform', {
                url: '/respondant/submitform',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('respondant/ar-form1.html'),
                        controller: 'ar1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.submitARAForm', {
                url: '/respondant/submitaraform',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('respondant/ara-form.html'),
                        controller: 'araformCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            

        .state('smclayout.membershiplayout.memberlogin', {
                url: '/member/login',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-default.html'),
                        controller : 'defaultPageHeaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/login.html'),
                        controller: 'memberloginCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.memberdashboard', {
                url: '/member/dashboard',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-dashboard.html'),
                        controller: 'dashboardPageheaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/dashboard.html'),
                        controller: 'memberDashboardCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.updateaa1', {
                url: '/member/updateaa1',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/update-aa-form1.html'),
                        controller: 'updateAA1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.viewARAForm', {
                url: '/view/araform',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/view-ara-form.html'),
                        controller: 'viewaraformCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })

        .state('smclayout.membershiplayout.updatear', {
            url: '/member/updatear',
            parent: 'smclayout.membershiplayout',
            views: {
                pageHaderMenu: {
                    templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                    controller: 'pageheaderMemberCtrl'
                },

                pageHaderBanner: {
                    template: '',
                },

                leftContanier: {
                    template: '',
                },

                centerContainer: {
                    templateUrl: smcTemplateProvider.template('member/update-ar-form.html'),
                    controller: 'updateARformCtrl'
                },

                rightContainer: {
                    template: '',
                }
            },
        })

        .state('smclayout.membershiplayout.membercaselist', {
            parent: 'smclayout.membershiplayout',
            views: {
                pageHaderMenu: {
                    templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                    controller: 'pageheaderMemberCtrl'
                },

                pageHaderBanner: {
                    template: '',
                },

                leftContanier: {
                    template: '',
                },

                centerContainer: {
                    templateUrl: smcTemplateProvider.template('member/case-list.html'),
                    controller: 'memberCaseListCtrl'
                },

                rightContainer: {
                    template: '',
                }
            },
        })
            .state('smclayout.membershiplayout.membercaselist.incomplete', {
                url: '/member/caselist/incomplete',
                parent: 'smclayout.membershiplayout.membercaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('member/in-complete-case-list.html'),
                        controller: 'incompleteCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.membercaselist.inprogress', {
                url: '/member/caselist/inprogress',
                parent: 'smclayout.membershiplayout.membercaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('member/in-progress-case-list.html'),
                        controller: 'inprogressCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.membercaselist.cancelled', {
                url: '/member/caselist/cancelled',
                parent: 'smclayout.membershiplayout.membercaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('member/cancelled-case-list.html'),
                        controller: 'cancelledCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.changepayee', {
                url: '/member/changes/payee',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('management/changespayeelist.html'),
                        controller: 'changePayeeCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.pendingapproval', {
                url: '/member/pending/adjudicators',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('management/pendingadjudicators.html'),
                        controller: 'inviteAdjudicatorCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.paymentapproval', {
                url: '/member/pending/payment',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('management/pendingpayment.html'),
                        controller: 'pendingpaymentCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.refundapproval', {
                url: '/member/pending/refund',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('management/pendingrefund.html'),
                        controller: 'pendingrefundCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })

        .state('smclayout.membershiplayout.resignationapproval', {
            url: '/member/adjudicator/resignation',
            parent: 'smclayout.membershiplayout',
            views: {
                pageHaderMenu: {
                    templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                    controller: 'pageheaderMemberCtrl'
                },

                pageHaderBanner: {
                    template: '',
                },

                leftContanier: {
                    template: '',
                },

                centerContainer: {
                    templateUrl: smcTemplateProvider.template('management/resignationadjudicator.html'),
                    controller: 'smcManagerResignationCtrl'
                },

                rightContainer: {
                    template: '',
                }
            },
        })

        .state('smclayout.membershiplayout.adjudicatorlogin', {
                url: '/adjudicator/login',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-default.html'),
                        controller : 'defaultPageHeaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('adjudicator/login.html'),
                        controller: 'adjudicatorloginCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist', {
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('adjudicator/case-list.html'),
                        controller: 'adjudicatorCaseListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorinvitelist', {
                url: '/adjudicator/invitelist',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('adjudicator/List-of-Invites.html'),
                        controller: 'adjudicatorInviteListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.memberrenewallist', {
                url: '/adjudicator/memberrenewallist',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('common/renewal-list.html'),
                        controller: 'memberRenewalListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.torespond', {
                url: '/adjudicator/caselist/torespond',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/torespond-case-list.html'),
                        controller: 'torespondCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.inprogress', {
                url: '/adjudicator/caselist/inprogress',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/inprogress-case-list.html'),
                        controller: 'adjInprogressCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.rejected', {
                url: '/adjudicator/caselist/rejected',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/rejected-case-list.html'),
                        controller: 'rejectedCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.conflicted', {
                url: '/adjudicator/caselist/conflicted',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/conflicted-case-list.html'),
                        controller: 'conflictedCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.determined', {
                url: '/adjudicator/caselist/determined',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/determined-case-list.html'),
                        controller: 'adjdeterminedCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.withdrawn', {
                url: '/adjudicator/caselist/withdrawn',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/withdrawn-case-list.html'),
                        controller: 'adjwithdrawnCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.resigned', {
                url: '/adjudicator/caselist/resigned',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/resigned-case-list.html'),
                        controller: 'adjResignedCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorcaselist.pendingpayments', {
                url: '/adjudicator/caselist/pendingpayments',
                parent: 'smclayout.membershiplayout.adjudicatorcaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('adjudicator/pendingpayments-case-list.html'),
                        controller: 'pendingpaymentsCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.AAview', {
                url: '/adjudicator/caselist/aaview',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('lawyer/aa-form-view.html'),
                        controller: 'aa1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.ARview', {
                url: '/adjudicator/caselist/arview',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('respondant/ar-form-view.html'),
                        controller: 'ar1formCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.membercaselist.determined', {
                url: '/member/caselist/determined',
                parent: 'smclayout.membershiplayout.membercaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('member/determined-case-list.html'),
                        controller: 'determinedCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.membercaselist.withdraw', {
                url: '/member/caselist/withdraw',
                parent: 'smclayout.membershiplayout.membercaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('member/withdraw-case-list.html'),
                        controller: 'withdrawCaseCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.membercaselist.outgoingpayment', {
                url: '/member/caselist/outgoingpayment',
                parent: 'smclayout.membershiplayout.membercaselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('member/outgoingpayment-case-list.html'),
                        controller: 'outgoingpaymentCaseCtrl'
                    }
                },
            })

        .state('smclayout.cmsFormLayout', {
                parent: 'smclayout',
                views: {
                    headerContanier: {
                        templateUrl: smcTemplateProvider.template('common/header-container.html'),
                    },

                    mainContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/common/form-layout.html'),
                    },

                    footerContainer: {
                        templateUrl: smcTemplateProvider.template('common/footer-container.html'),
                    }
                },
            })
            .state('smclayout.cmsFormLayout.mediationType', {
                url: '/mediationForm',
                parent: 'smclayout.cmsFormLayout',
                views: {
                    formHeader: {
                        templateUrl: smcTemplateProvider.template('mediation/common/form-header.html'),
                    },

                    formFields: {
                        templateUrl: smcTemplateProvider.template('mediation/mediation-form.html'),
                        controller: 'mediationCtrl'
                    }
                },
            })
            .state('smclayout.cmsFormLayout.cms', {
                parent: 'smclayout.cmsFormLayout',
                views: {
                    formHeader: {
                        templateUrl: smcTemplateProvider.template('mediation/common/form-header.html'),
                    },

                    formFields: {
                        templateUrl: smcTemplateProvider.template('mediation/cms-form.html'),
                        controller: 'cmsFormCtrl'
                    }
                },
            })
            .state('smclayout.cmsFormLayout.applicantupdatecmstosubmit',{
                parent: 'smclayout.cmsFormLayout',
                url : '/applicant/update/cms',
                views: {
                    formHeader: {
                        templateUrl: smcTemplateProvider.template('mediation/common/form-header.html'),
                    },

                    formFields: {
                        templateUrl: smcTemplateProvider.template('mediation/cms-form.html'),
                        controller: 'cmsFormCtrl'
                    }
                },
            })
            .state('smclayout.cmsFormLayout.sccms', {
                parent: 'smclayout.cmsFormLayout',
                views: {
                    formHeader: {
                        templateUrl: smcTemplateProvider.template('mediation/common/form-header.html'),
                    },

                    formFields: {
                        templateUrl: smcTemplateProvider.template('mediation/cms-form.html'),
                        controller: 'cmsFormCtrl'
                    }
                },
            })
            .state('smclayout.cmsFormLayout.applicantupdatesccmstosubmit',{
                parent: 'smclayout.cmsFormLayout',
                url : '/applicant/update/sccms',
                views: {
                    formHeader: {
                        templateUrl: smcTemplateProvider.template('mediation/common/form-header.html'),
                    },

                    formFields: {
                        templateUrl: smcTemplateProvider.template('mediation/cms-form.html'),
                        controller: 'cmsFormCtrl'
                    }
                },
            })

        .state('smclayout.cmsFormLayout.cpe', {
                parent: 'smclayout.membershiplayout',
                url: '/cpe',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/cms-form.html'),
                        controller: 'cmsFormCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.cmsFormLayout.venueManagement', {
                parent: 'smclayout.membershiplayout',
                url: '/venueManagement',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/venue-management.html'),
                        controller: 'venueManagementCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            
            .state('smclayout.mediationlayout.venuemanagementforacase', {
                url: '/mediation/venuemanagementforacase',
                parent: 'smclayout.mediationlayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/venue-management-for-a-case.html'),
                        controller: 'venuemanagementCaseListCtrl'

                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.cmsFormLayout.viewForm', {
                parent: 'smclayout.membershiplayout',
                url: '/mediation/officer/view',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/view-form.html'),
                        controller: 'viewCmsFormCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.cmsFormLayout.updateForm', {
                parent: 'smclayout.membershiplayout',
                url: '/mediation/parties/update',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/update-form.html'),
                        controller: 'updatePartiesCmsFormCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.userlist', {
                url: '/admin/users',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('admin/user-list.html'),
                        controller: 'adminUsersListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.adminreports', {
                url: '/admin/adminreports',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('admin/admin-reports.html'),
                        controller: 'adminReportsCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.changepassword', {
                url: '/member/changepassword',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('common/change-password.html'),
                        controller: 'changePasswordCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.resetpassword', {
                url: '/member/resetpassword',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-default.html'),
                        controller : 'defaultPageHeaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('common/reset-password.html'),
                        controller: 'resetPasswordCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.publicCalendar', {
                url: '/admin/publicCalendar',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('admin/public-calendar.html'),
                        controller: 'publicCalendarCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.managecourier', {
                url: '/member/couriers',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/courier-list.html'),
                        controller: 'courierManageCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.collectionreports', {
                url: '/member/collectionreports',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/collection-reports.html'),
                        controller: 'collectionReportsCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.blncepaymentreports', {
                url: '/member/payment/balancereports',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/balance-payment-reports.html'),
                        controller: 'blncePaymentReportsCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.lawFirmManagement', {
                url: '/member/lawfirms',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/lawfirm-list.html'),
                        controller: 'lawfirmManageCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.reassign', {
                url: '/member/reassign',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/reassign-caselist.html'),
                        controller: 'reassignCaseCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.adjudicatorlist', {
                url: '/member/adjudicators',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/adjudicator-list.html'),
                        controller: 'listAdjudicatorCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.codetable', {
                url: '/member/codetable',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/code-table.html'),
                        controller: 'codeTableCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.caseload', {
                url: '/member/caseload',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('management/case-load.html'),
                        controller: 'caseLoadCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.todolist', {
                url: '/member/todolist',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/todo-list.html'),
                        controller: 'todolistCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.determinationlist', {
                url: '/member/determinationslist',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/determination-list.html'),
                        controller: 'determinationslistCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.generatereports', {
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('member/generate-reports-caselist.html'),
                        controller: 'generatereportsCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.membershiplayout.generatereports.reports', {
                url: '/member/reports',
                parent: 'smclayout.membershiplayout.generatereports',
                views: {
                    reportList: {
                        templateUrl: smcTemplateProvider.template('member/generate-reports.html'),
                        controller: 'reportsgenerateCtrl'
                    }
                },
            })
            .state('smclayout.membershiplayout.generatereports.additionalreport', {
                url: '/member/additional/reports',
                parent: 'smclayout.membershiplayout.generatereports',
                views: {
                    reportList: {
                        templateUrl: smcTemplateProvider.template('member/additional-reports.html'),
                        controller: 'additionalReportsCtrl'
                    }
                },
            })

        .state('smclayout.traininglayout', {

                parent: 'smclayout',
                views: {
                    headerContanier: {
                        template: '',
                    },

                    mainContainer: {
                        templateUrl: smcTemplateProvider.template('training/common/layout.html'),
                    },

                    footerContainer: {
                        templateUrl: smcTemplateProvider.template('common/footer-container.html'),
                    }
                },
            })
            .state('smclayout.traininglayout.trainingmaster', {
                url: '/training/trainingmaster',
                parent: 'smclayout.traininglayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/officer/training-master.html'),
                        controller: 'trainingmasterCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.traininglayout.monthschedule', {
                url: '/training/monthschedule',
                parent: 'smclayout.traininglayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/officer/month-schedule.html'),
                        controller: 'monthscheduleCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.traininglayout.programManagement', {
                url: '/training/management/program',
                parent: 'smclayout.traininglayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/manager/schedule-approval.html'),
                        controller: 'trainScheduleApprovalCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.traininglayout.pendingmembersappointment', {
                url: '/training/member/approval',
                parent: 'smclayout.traininglayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/manager/members-approval.html'),
                        controller: 'trainersApprovalCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.traininglayout.trainerscheduleapproval', {
                url: '/training/trainer/approval',
                parent: 'smclayout.traininglayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/trainer/schedule-approval.html'),
                        controller: 'trainerSchedulePendingCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.traininglayout.traineracceptterms', {
                url: '/training/trainer/acceptterms',
                parent: 'smclayout.traininglayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/trainer/terms-conditions-accept.html'),
                        controller: 'trainerAcceptTermsCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.mediationlayout.respondantresponseform', {
                parent: 'smclayout.mediationlayout',
                url: '/mediation/respondent/response',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/respondent/responseForm.html'),
                        controller: 'responseFormCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.mediationlayout.respondantcasesummaries', {
                parent: 'smclayout.mediationlayout',
                url: '/mediation/respondent/casesummary',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/respondent/case-summary.html'),
                        controller: 'mediationCaseSummaryCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.mediationlayout.applicantcasesummary', {
                parent: 'smclayout.mediationlayout',
                url: '/mediation/applicant/casesummary',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/respondent/case-summary.html'),
                        controller: 'mediationCaseSummaryCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.mediationlayout.paymentprocess', {
                parent: 'smclayout.mediationlayout',
                url: '/mediation/payment/summary',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/payment/payment.html'),
                        controller: 'mediationpaymentCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.mediationlayout.caselist', {
                parent: 'smclayout.mediationlayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/case-list.html'),
                        controller: 'mediationCaseListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.mediationlayout.caselist.incomplete', {
                url: '/mediation/caselist/incomplete',
                parent: 'smclayout.mediationlayout.caselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/in-complete-case-list.html'),
                        controller: 'mediationIncompleteCaseCtrl'
                    }
                },
            })
            .state('smclayout.mediationlayout.caselist.inprogress', {
                url: '/mediation/caselist/inprogress',
                parent: 'smclayout.mediationlayout.caselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/in-progress-case-list.html'),
                        controller: 'mediationInprogressCaseCtrl'
                    }
                },
            })
            .state('smclayout.mediationlayout.caselist.lapsed', {
                url: '/mediation/caselist/lapsed',
                parent: 'smclayout.mediationlayout.caselist',
                views: {
                    memberCaseList: {
                        templateUrl: smcTemplateProvider.template('mediation/officer/lapsed-case-list.html'),
                        controller: 'mediationLapsedCaseCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout', {
                parent: 'smclayout',
                views: {
                    headerContanier: {
                        template: '',
                    },
                    leftContanier: {
                        template: '',
                    },
                    mainContainer: {
                        templateUrl: smcTemplateProvider.template('mediation/common/layout.html'),
                    },
                    footerContainer: {
                        templateUrl: smcTemplateProvider.template('common/footer-container.html'),
                    }
                },
            })
            .state('smclayout.contactlayout.caselist', {
                parent: 'smclayout.contactlayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/MemberInvite.html'),
                        controller: 'contactsListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.contactlayout.caselist.tobeinvited', {
                url: '/contacts/caselist/tobeinvited',
                parent: 'smclayout.contactlayout.caselist',
                views: {
                    contactsCaseList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/tobe-invite-case-list.html'),
                        controller: 'contactstobeinvitedCaseCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.caselist.accepted', {
                url: '/contacts/caselist/accepted',
                parent: 'smclayout.contactlayout.caselist',
                views: {
                    contactsCaseList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/accepted-case-list.html'),
                        controller: 'contactsAcceptedlistCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.caselist.certificateprinted', {
                url: '/contacts/caselist/certificateprinted',
                parent: 'smclayout.contactlayout.caselist',
                views: {
                    contactsCaseList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/certificateprinted-case-list.html'),
                        controller: 'contactscertificateprintedlistCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.caselist.notInterested', {
                url: '/contacts/caselist/notInterested',
                parent: 'smclayout.contactlayout.caselist',
                views: {
                    contactsCaseList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/notInterested-case-list.html'),
                        controller: 'contactsnotInterestedylistCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.todolist', {
                url: '/contacts/officer/todolist',
                parent: 'smclayout.contactlayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },
                    pageHaderBanner: {
                        template: '',
                    },
                    leftContanier: {
                        template: '',
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/toDoList.html'),
                        controller: 'toDoListCtrl'
                    },
                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.contactlayout.MemberInvite', {
                url: '/contacts/officer/MemberInvite',
                parent: 'smclayout.contactlayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },
                    pageHaderBanner: {
                        template: '',
                    },
                    leftContanier: {
                        template: '',
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/MemberInvite.html'),
                        controller: 'contactsListCtrl'
                    },
                    rightContainer: {
                        template: '',
                    }


                }
            })
            .state('smclayout.contactlayout.mediatorRegisteration', {
                url: "/smcmemberaccount/mediatorRegisteration",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },
                    pageHaderBanner: {
                        template: '',
                    },
                    leftContanier: {
                        // templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/common/left-menu.html'),
                        // controller: 'leftmenuController'
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/mediator-registeration.html'),
                        controller: 'mediatorRegisterCtrl'
                    }
                },
                params:{
                    'participantId':null,
                    'memberRoleName':null
                }

            })
            .state('smclayout.contactlayout.mediatorRegisterationPayment', {
                url: "/smcmemberaccount/mediatorRegisterationPayment",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },
                    pageHaderBanner: {
                        template: '',
                    },
                    leftContanier: {
                        // templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/common/left-menu.html'),
                        // controller: 'leftmenuController'
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/mediator-registeration-payment.html'),
                        controller: 'mediatorRegisterPaymentCtrl'
                    }
                },
                params:{
                    'loginId': null ,
                    'smcMemberId':null,
                    'memberRoleName':null
                }

            })
             .state('smclayout.contactlayout.mediatorRenewalPayment', {
                url: "/smcmemberaccount/mediatorRenewalPayment",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        // templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/common/left-menu.html'),
                        // controller: 'leftmenuController'
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/renewal-payment.html'),
                        controller: 'renewalPaymentCtrl'

                    }
                }

            })
            .state('smclayout.contactlayout.mediatorPaymentSuccess', {
                url: "/smcmemberaccount/mediatorPaymentSuccess",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        // templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/common/left-menu.html'),
                        // controller: 'leftmenuController'
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/mediator-payment-success.html'),
                        controller: 'mediatorRegisterCtrl'

                    }
                }

            })
            .state('smclayout.contactlayout.cfpPayment', {
                url: "/smcmemberaccount/cfpPayment/:participantId",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },
                    pageHaderBanner: {
                        template: '',
                    },
                    leftContanier: {
                        // templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/common/left-menu.html'),
                        // controller: 'leftmenuController'
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/cfp-payment.html'),
                        controller: 'cfpPaymentCtrl'
                    }
                }
            })

            .state('smclayout.contactlayout.tandconditions', {
                    url: "/contacts/termsandconditions/{contactId}",
                    views: {
                        pageHaderMenu: {
                            // templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                            // controller: 'pageheaderMemberCtrl'
                        },
                        centerContainer: {
                            templateUrl: smcTemplateProvider.template('contacts/terms-and-conditions.html'),
                            controller: 'tcCtrl'
                        }
                    }
            })
            .state('smclayout.contactlayout.sdrptermsandconditions', {
                    url: "/contacts/sdrptermsandconditions/{contactId}",
                    views: {
                        pageHaderMenu: {
                            // templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                            // controller: 'pageheaderMemberCtrl'
                        },
                        centerContainer: {
                            templateUrl: smcTemplateProvider.template('contacts/sdrp-terms-and-conditions.html'),
                            controller: 'sdrpTermsandConditionsCtrl'
                        }
                    }
            })

            .state('smclayout.contactlayout.smcmemberprofilemenulist',{
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/common/left-menu.html'),
                        controller: 'leftmenuController'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.profileinformation', {
                url: "/contact/member/profile",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/profile-information.html'),
                        controller: 'profileCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.adjudicatorcasessummary', {
                url: "/contact/member/casesummary",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/adjudicator-cases-summary.html'),
                        controller: 'adjudicatorCaseCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.adjudicatorcasedetails', {
                url: "/contact/member/casedetails",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/adjudicator-case-details.html'),
                        controller: 'adjudicatorCaseDetailsCtrl'
                    }

                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.adjudicatorconflictDetails', {
                url: "/contact/member/conflictdetails",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/adjudicator-conflict-details.html'),
                        controller: 'adjudicatorConflictsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.continualprofessionaldevelopmentrequirement', {
                url: "/contact/member/continualprofessionaldevelopmentrequirement",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/continual-professional-development-requirement.html'),
                        controller: 'continualprofessionaldevelopmentrequirementCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.continualprofessionaldevelopmentrequirementsop', {
                url: "/contact/officer/continualprofessionaldevelopmentrequirementsop/:id",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/continual-professional-sop.html'),
                        controller: 'continualProfessionalSOPCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.mediatorexpertise', {
                url: "/contact/member/mediatorexpertise",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/mediator-expertise.html'),
                        controller: 'mediatorexpertiseCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.mediationcalendar', {
                url: "/contact/member/mediationcalendar",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/mediator-calender.html'),
                        controller: 'mediatorCalendarCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.mediationcasessummary', {
                url: "/contact/member/mediationcasessummary",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/mediation-cases-summary.html'),
                        controller: 'mediatorCaseSummaryCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.commercialrates', {
                url: "/contact/member/commercialrates",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/commercial-rates.html'),
                        controller: 'commercialRateCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.panelinformation', {
                url: "/contact/member/panelinformation",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/panel-information.html'),
                        controller: 'mediatorPanelInformationCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.smcmediationcasesdetails', {
                url: "/contact/member/smcmediationcasesdetails",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/SMC-mediation-cases-details.html'),
                        controller: 'smcMediationCaseDetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.nonmediationcasesdetails', {
                url: "/contact/member/nonmediationcasesdetails",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/details-of-non-SMC-mediation-cases.html'),
                        controller: 'nonSMCCaseDetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.committeonmediationstandardscms', {
                url: "/contact/member/committeonmediationstandardscms",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/committeon-Mediation-standards-CMS.html'),
                        //controller: 'nonMediationCaseDetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.specialisation', {
                url: "/contact/member/specialisation",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/specialisation.html'),
                        controller: 'memberSpecialisationCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.timesheet', {
                url: "/contact/member/timesheet",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/timesheet.html'),
                        controller: 'timesheetCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.trainingsummary',{
                url:"/contact/member/trainingsummary",
                parent:'smclayout.contactlayout.smcmemberprofilemenulist',
                views:{
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/trainingsummary.html'),
                        controller: 'trainingSummaryCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.trainingdetails',{
                url:"/contact/member/trainingdetails",
                parent:'smclayout.contactlayout.smcmemberprofilemenulist',
                views:{
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/trainingdetails.html'),
                        controller: 'trainingDetailsCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.assessmentdetails',{
                url:"/contact/member/assessmentdetails",
                parent:'smclayout.contactlayout.smcmemberprofilemenulist',
                views:{
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/assessmentdetails.html'),
                        controller: 'assessmentDetailsCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.coachingdetails',{
                url:"/contact/member/coachingdetails",
                parent:'smclayout.contactlayout.smcmemberprofilemenulist',
                views:{
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/coachingdetails.html'),
                        controller: 'coachingDetailsCtrl'
                    }
                }
            })

            .state('smclayout.contactlayout.smcmemberprofilemenulist.sdrpcases', {
                url: "/contact/member/sdrpcases",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/sdrpcases.html'),
                        controller: 'sdrpCasesCtrl'
                         }
                },
            })
            .state('smclayout.contactlayout.smcmemberprofilemenulist.neutralevaluatorcasesdetails', {
                url: "/contact/member/neutralevaluatorcasesdetails",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/neutralevaluatorcasesdetails.html'),
                        controller: 'neutralEvaluatorCtrl'
                    }
                },
            })

            .state('smclayout.contactlayout.smcmemberprofilemenulist.cfpcases', {
                url: "/contact/member/cfpcases",
                parent: 'smclayout.contactlayout.smcmemberprofilemenulist',
                views: {
                    smcMemberMenu: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/cfp-cases.html'),
                        controller: 'cfpCasesCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.adjudicatorlist', {
                url: "/smcmemberaccount/adjudicatorlist",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/smcmemberaccount/adjudicator_list.html'),
                        controller: 'contactAdjudicationlistCtrl'

                    }
                }
            })

        
            .state('smclayout.mediationlayout.emailTemplate', {
                url: '/admin/emailTemplate',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('common/email-template-view.html'),
                        controller: 'emailTemplateCtrl'

                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
             .state('smclayout.membershiplayout.courierservicemanagement', {
                url: '/courierservicemanagement',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('adjudicator/courier-service-management.html'),
                        controller: 'CourierServiceManagementCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
             .state('smclayout.traininglayout.todolist', {
                url: '/training/officer/todolist',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/common/todo-list.html'),
                        controller: 'trainingtodolistCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
             .state('smclayout.traininglayout.listofprograms', {
                url: '/training/officer/listofprograms',
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/officer/approvedprograms.html'),
                        controller: 'approvedProgramsCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })

            .state('smclayout.contactlayout.panelmanagement', {
                url: "/contact/panelmanagement",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/panel-management.html'),
                        controller: 'panelManagementCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.manageothermembers', {
                url: "/contact/manageothermembers",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/manage-other-members.html'),
                        controller: 'manageOtherMembersCtrl'
                    }
                }
            })

            .state('smclayout.contactlayout.managecomplaints', {
                url: "/contact/complaintmanagement",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/complaint-management.html'),
                        controller: 'complaintManagementCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.watchlist', {
                url: "/contact/watchlist",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/watch-list.html'),
                        controller: 'watchListCtrl'
                    }
                }
            })

            .state('smclayout.contactlayout.waiverreport', {
                url: "/contact/waiverreport",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/waiver-report.html'),
                        controller: 'waiverReportCtrl'
                    }
                }
            })

            .state('smclayout.contactlayout.addwatchlist', {
                url: "/contact/addwatchlist",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/add-watch-list.html'),
                        controller: 'addWatchListCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.useridupdate', {
                url: "/contact/useridupdate",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/user-id-update.html'),
                        controller: 'userIdUpdateCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.memberstatusupdate', {
                url: "/contact/memberstatusupdate",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/manager/member-status-update.html'),
                        controller: 'updateMemberStatusCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.waivercaseslist', {
                url: "/contact/waivercaseslist",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/manager/waiver-case-list.html'),
                        controller: 'managerWaiverCaseListCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.trainerpromotion', {
                url: "/contact/trainerpromotion",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/manager/trainer-promotion.html'),
                        controller: 'trainerPromotionCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.approveinvoicecancellation', {
                url: "/contact/approveinvoicecancellation",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/manager/renewal-invoice-cancellation.html'),
                        controller: 'managerInvoiceCancellationCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.smcmembermanagement', {
                url: "/contact/smcmembermanagement",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/smcmembermanage.html'),
                        controller: 'smcMemberManagementCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.smcnonmembermanagement', {
                url: "/contact/nonmembermanagement",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/nonmembermanage.html'),
                        controller: 'nonMemberManagementCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.collectionreports', {
                url: "/contact/collectionreports",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/collectionreports.html'),
                        controller: 'contactCollectionReportsCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.balancepaymentreports', {
                url: "/contact/balancepaymentreports",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/balancepaymentreports.html'),
                        controller: 'contactbalancepaymentreportsCtrl' 
                    }
                }
            })
            .state('smclayout.contactlayout.monthlyrenewalreport', {
                url: "/contact/monthlyrenewalreport",
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/monthlyrenewalreport.html'),
                        controller: 'monthlyRenewalReportCtrl'
                    }
                }
            })
            .state('smclayout.contactlayout.additionalrights', {
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu.html'),
                        controller: 'pageheaderMemberCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        
                    },
                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/additional-rights-menu.html'),
                        controller: 'additionalRightsMenuCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.basicprofile', {
                url: "/contact/additionalrights/profile/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/basic-profile.html'),
                        controller: 'basicProfileCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.membershipdetails', {
                url: "/contact/additionalrights/membershipdetails/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/membershipdetails.html'),
                        controller: 'membershipDetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.waiverdetails', {
                url: "/contact/additionalrights/waiverdetails/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/waiver-details.html'),
                        controller: 'waiverDetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.adjudicatorcategory', {
                url: "/contact/additionalrights/adjudicatorcategory/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/adjudicator-category.html'),
                        controller: 'adjudicatorCategoryCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.continualprofessionaldevelopmentrequirements', {
                url: "/contact/additionalrights/continualprofessionaldevelopmentrequirements/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/continual-requirements.html'),
                        controller: 'continualRequirementsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.adjudicatorconflicts', {
                url: "/contact/additionalrights/adjudicatorconflicts/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/adjudicator-conflict.html'),
                        controller: 'officerAdjConflictsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.adjudicatorCaseSummary', {
                url: "/contact/additionalrights/adjudicatorcasesummary/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/adjudicator-casesummary.html'),
                        controller: 'adjudicatorCaseSummaryCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.mediationcasesummary', {
                url: "/contact/additionalrights/mediationcasesummary/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/mediation-case-summary.html'),
                        controller: 'mediationCaseSummaryCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.mediatorexpertise', {
                url: "/contact/additionalrights/mediatorexpertise/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/mediation-expertise.html'),
                        controller: 'OfficerMediatorExpertiseCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.mediationcasedetails', {
                url: "/contact/additionalrights/mediationcasedetails/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/mediation-case-details.html'),
                        controller: 'officerMediationCaseDetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.necaselist', {
                url: "/contact/additionalrights/necaselist/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/ne-case-list.html'),
                        controller: 'necaselistCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.sdrpcaselist', {
                url: "/contact/additionalrights/sdrpcaselist/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/sdrpcaselist.html'),
                        controller: 'sdrpcaselistCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.cfpcaselist', {
                url: "/contact/additionalrights/cfpcaselist/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/cfpcaselist.html'),
                        controller: 'cfpcaselistCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.mediatorcategory', {
                url: "/contact/additionalrights/mediatorcategory/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/mediator-category.html'),
                        controller: 'mediatorCategoryCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.panelinformation', {
                url: "/contact/additionalrights/panelinformation/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/panel-information.html'),
                        controller: 'panelInfoCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.trainingdetails', {
                url: "/contact/additionalrights/trainingdetails/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/trainingdetails.html'),
                        controller: 'trainingdetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.coachdetails', {
                url: "/contact/additionalrights/coachdetails/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/coachdetails.html'),
                        controller: 'coachdetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.assessordetails', {
                url: "/contact/additionalrights/assessordetails/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/assessordetails.html'),
                        controller: 'assessordetailsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.touchpoints', {
                url: "/contact/additionalrights/touchpoints/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/touchpoints.html'),
                        controller: 'touchpointsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.additionalrights.trainingsummaries', {
                url: "/contact/additionalrights/trainingsummaries/:memberId",
                parent: 'smclayout.contactlayout.additionalrights',
                views: {
                    addRightsList: {
                        templateUrl: smcTemplateProvider.template('contacts/officer/additionalrights/trainingsummaries.html'),
                        controller: 'trainingsummariesCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.registerationProcess', {
                parent: 'smclayout.membershiplayout',
                views: {
                    pageHaderMenu: {
                        templateUrl: smcTemplateProvider.template('common/page-header-menu-default.html'),
                        controller : 'defaultPageHeaderCtrl'
                    },

                    pageHaderBanner: {
                        template: '',
                    },

                    leftContanier: {
                        template: '',
                    },

                    centerContainer: {
                        templateUrl: smcTemplateProvider.template('training/registrationprocess/process-list.html'),
                        controller: 'processListCtrl'
                    },

                    rightContainer: {
                        template: '',
                    }
                },
            })
            .state('smclayout.contactlayout.registerationProcess.publishedprograms', {
                url: "/contact/publishedprograms",
                parent: 'smclayout.contactlayout.registerationProcess',
                views: {
                    regidterProcessPage: {
                        templateUrl: smcTemplateProvider.template('training/registrationprocess/published-programs.html'),
                        controller: 'publishedProgramsCtrl'
                    }
                },
            })
            .state('smclayout.contactlayout.registerationProcess.viewprogram', {
                url: "/contact/publishedprograms/viewprogram/:programId",
                parent: 'smclayout.contactlayout.registerationProcess',
                views: {
                    regidterProcessPage: {
                        templateUrl: smcTemplateProvider.template('training/registrationprocess/view-program.html'),
                        controller: 'viewProgramCtrl'
                    }
                },
            })
    }


    init.$inject = ["smcConfig", '$state', '$http', '$cookies', '$rootScope', 'DataService', '$templateCache', '$location', 'smcTemplate'];

    function init(smcConfig, $state, $http, $cookies, $rootScope, DataService, $templateCache, $location, smcTemplate) {


        $rootScope.currentPageName = undefined;
        $templateCache.removeAll();
        $rootScope.versionNo = smcConfig.versionNo;
        $rootScope.copyrightsYear = smcConfig.copyrightsYear;
        smcTemplate.selectedVersion($rootScope.versionNo);

        $rootScope.menuactiveclass = function (path) {
            if ($location.path().substr(0, path.length) === path) {

                return 'active';
            } else {
                return '';
            }
        }
    }
})();


angular.module('smc').run(function ($rootScope) {
    $rootScope.safeApply = function (fn) {
        var phase = $rootScope.$$phase;
        if (phase === '$apply' || phase === '$digest') {
            if (fn && (typeof (fn) === 'function')) {
                fn();
            }
        } else {
            this.$apply(fn);
        }
    };
});
angular.module('smc').run(["$rootScope", "$anchorScroll" , function ($rootScope, $anchorScroll) {
    $rootScope.$on("$locationChangeSuccess", function() {
                $anchorScroll();
    });
}]);
