(function(){
	'use strict';

    var fullyear = new Date();
    var curyear = fullyear.getFullYear() + 30;
    var range = "1915:"+curyear;

	angular.module('smc').constant('jqDatePickerDefaultConfig', {
//	 lang:'en',
//	 timepicker:false,
	 //format:'Y-m-d',
     dateFormat:'dd-mm-yy',
     changeMonth: true,
     changeYear: true,
//	 closeOnDateSelect: true,
//	 scrollInput: false
     yearRange: range
	});

    angular.module('smc').controller('JqueryDatePickerController', DatePickerController);

	DatePickerController.$inject = ['$scope', '$attrs', '$parse', 'jqDatePickerDefaultConfig'];

	function DatePickerController($scope, $attrs, $parse, defaultConfig){
		//var dateOptions = $parse($attrs.dateConfigOptions) || {};
		//this.dateOptions = angular.extent(dateOptions, defaultConfig);
	}

    angular.module('smc').directive('jqueryDatePicker', JqueryDatePicker);

	JqueryDatePicker.$inject = ['jqDatePickerDefaultConfig'];

	function JqueryDatePicker(defaultConfig){

		return {
		    restrict:'AC',
		    require: '?ngModel',
		    controller: 'JqueryDatePickerController',
		    link: function(scope, element, attrs, ngModel, jqDpCtrl){

		    	function dateTimeChange(current_time,$input){
		    		//console.log(current_time, $input, scope.$eval(attrs.ngModel));
		    		this.hide();
		    	}

				var dateOptions = scope.$eval(attrs.dateConfigOptions) || {};
//				dateOptions.onChangeDateTime = dateTimeChange;
                dateOptions.minDate = attrs.minDate;
                dateOptions.maxDate = attrs.maxDate;

				scope.dateOptions = angular.extend(dateOptions, defaultConfig);
				//element.datetimepicker(scope.dateOptions);
				element.datepicker(scope.dateOptions);
                console.log(element.data());
                if(element.data().datepicker){
                    scope.$emit('elementCreated',true);
                }
		    }
		}
	}

    angular.module('smc').constant('jqMultiDatePickerDefaultConfig', {
     dateFormat:'dd-mm-yy',
     changeMonth: true,
     changeYear: true,
     yearRange: range,
    });


    angular.module('smc').directive('jqueryMultiDatePicker', JqueryMultiDatePicker);

    JqueryMultiDatePicker.$inject = ['jqMultiDatePickerDefaultConfig'];

    function JqueryMultiDatePicker(defaultConfig){

        return {
            restrict:'AC',
            require: '?ngModel',
            controller: 'JqueryDatePickerController',
            link: function(scope, element, attrs, ngModel, jqDpCtrl){

                function dateTimeChange(current_time,$input){
                    //console.log(current_time, $input, scope.$eval(attrs.ngModel));
                    this.hide();
                }

                var dateOptions = scope.$eval(attrs.dateConfigOptions) || {};
//              dateOptions.onChangeDateTime = dateTimeChange;
                dateOptions.minDate = attrs.minDate;
                dateOptions.maxDate = attrs.maxDate;

                scope.dateOptions = angular.extend(dateOptions, defaultConfig);
                //element.datetimepicker(scope.dateOptions);
                element.multiDatesPicker(scope.dateOptions);
                console.log(element.data());
            }
        }
    }
    
})();


 
angular.module('smc').directive('jqueryTimePicker',function (){
    return {
        restrict:'AC',
        replace: true,
        scope: {ngModel:'='},
        link: function(scope, element, attrs, ngModel){
            element.timepicki();
            element.bind('onChange', function () {
                scope.ngModel = element.dataTimepickiTim+element.dataTimepickiMini+element.dataTimepickiMeri;
                scope.$apply();
            });
        }
    }
});

angular.module('smc').directive('jqueryMonthPicker',function (){
    return {
        restrict: 'AC',
        rrequire: '?ngModel',
        link: function (scope, element, attrs) {

            element.MonthPicker({ Button: false,MinMonth: attrs.minMonth,MaxMonth : attrs.maxMonth });
        }
    };
});

angular.module('smc').directive('timePickerJquery',function (){
    return {
        restrict:'AC',
        require: '?ngModel',
        link: function(scope, element, attrs, ngModel){
            element.timepicker({ 
                'timeFormat': 'h:i a',
                'step': 15,
                'minTime': attrs.minTime,
                'maxTime':  attrs.maxTime,
                'disableTextInput': true 
            });
            element.bind('blur', function () {
                scope.$apply(function() {
                    ngModel.$setViewValue(element[0].value);
                });
            });
        }
    }
});

angular.module('smc').directive('customModalPopup', function(){
  return {
    restrict: 'A',
    scope: {
      popupId: '@'
    },
    link: function(scope,element) {
        element.bind('click', function () {
	    angular.element(".custom-modal-popup").css("display","none");
            var popup  = scope.popupId;
            var target =  angular.element("#"+popup);
            var overlay_elemet = angular.element("#custom_overlay");
            overlay_elemet.css('display', 'block');
            target.css('display', 'block');
        });
    }
  }
});


angular.module('smc').directive('customModalPopupClose', function () {
    return {
    restrict: 'A',
    scope: {
      popupId: '@',
      otherId: '@'
    },
    link: function(scope,element) {
        element.bind('click', function () {
            var popup  = scope.popupId;
            var other_id  = scope.otherId;
            var target =  angular.element("#"+popup);
            var other =  angular.element("#"+other_id);
            var overlay_elemet = angular.element("#custom_overlay");
            overlay_elemet.css('display', 'none');
            target.css('display', 'none');
            other.css('display', 'none');
        });
    }
  }
});

angular.module('smc').directive('customOnChange', function() {
  return {
    restrict: 'A',
    link: function (scope, element, attrs) {
      var onChangeHandler = scope.$eval(attrs.customOnChange);
      element.bind('change', onChangeHandler);
    }
  };
});

angular.module('smc').directive('validFile', function () {
return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ngModel) {
        var validFormats = ['jpg','jpeg','png'];
        elem.bind('change', function () {
            validImage(false);
            scope.$apply(function () {
                ngModel.$render();
            });
        });
        ngModel.$render = function () {
            ngModel.$setViewValue(elem.val());
        };
        function validImage(bool) {
            ngModel.$setValidity('extension', bool);
        }
        ngModel.$parsers.push(function(value) {
            var ext = value.substr(value.lastIndexOf('.')+1);
            if(ext=='') return;
            if(validFormats.indexOf(ext) == -1){
                return value;
            }
            validImage(true);
            return value;
        });
    }
  };
});

angular.module('smc').directive("dateFromToValidate", function () {
    return {
        restrict: 'A', // only activate on element attribute
        require: '?ngModel', // get a hold of NgModelController

        link: function (scope, elem, attrs, ngModel) {
            if (!ngModel) return; // do nothing if no ng-model

            // watch own value and re-validate on change
            scope.$watch(attrs.ngModel, function () {
                validate();
            });

            // observe the other value and re-validate on change
            attrs.$observe('dateFromToValidate', function (val) {
                validate();
            });

            var validate = function () {
                // values
                var dateTo = angular.isDefined(ngModel.$viewValue) === true && !_.isNull(ngModel.$viewValue) ? moment(ngModel.$viewValue).toDate() : null;
                var dateFrom = attrs.dateGreaterAndEqual !== "" ? moment(attrs.dateGreaterAndEqual.replace('"', '').replace('\\', '').replace('"', '')).toDate() : null;
                //passing date with braces around it causes and issue therfore we need to use replace

            };
        }
    }

});
angular.module('smc').directive('dateGreaterThan', function() {
    return {
        require: 'ngModel',
        link: function(scope, elm, attrs, ctrl) {
            var sc = scope;
            scope.$watch(attrs.ngModel, function() {
                var eqCtrl = scope.$eval(attrs.dateGreaterThan);
                //assuming pattern 'mm-dd-yyyy HH:MM:SS'
                var v1 = ctrl.$viewValue;
                var v2 = eqCtrl;

                if(v1 && v2) {
                    var ctrlDate = new Date(v1.substr(3,2) + '-' + v1.substr(0,2) + '-' + v1.substr(6,4));
                    var eqCtrlDate = new Date(v2.substr(3,2) + '-' + v2.substr(0,2) + '-' + v2.substr(6,4));
                    if (ctrlDate > eqCtrlDate) {
                        ctrl.$setValidity('dateGreaterThan', true);
                    } else {
                        ctrl.$setValidity('dateGreaterThan', false);
                    }
                }

            });
        }
    };
});


angular.module('smc').directive('image',function ($q){
     'use strict'

        var URL = window.URL || window.webkitURL;

        var getResizeArea = function () {
            var resizeAreaId = 'fileupload-resize-area';

            var resizeArea = document.getElementById(resizeAreaId);

            if (!resizeArea) {
                resizeArea = document.createElement('canvas');
                resizeArea.id = resizeAreaId;
                resizeArea.style.visibility = 'hidden';
                document.body.appendChild(resizeArea);
            }

            return resizeArea;
        }

        var resizeImage = function (origImage, options) {
            var maxHeight = options.resizeMaxHeight || 300;
            var maxWidth = options.resizeMaxWidth || 250;
            var quality = options.resizeQuality || 0.7;
            var type = options.resizeType || 'image/jpg';

            var canvas = getResizeArea();

            var height = origImage.height;
            var width = origImage.width;

            // calculate the width and height, constraining the proportions
            if (width > height) {
                if (width > maxWidth) {
                    height = Math.round(height *= maxWidth / width);
                    width = maxWidth;
                }
            } else {
                if (height > maxHeight) {
                    width = Math.round(width *= maxHeight / height);
                    height = maxHeight;
                }
            }

            canvas.width = width;
            canvas.height = height;

            //draw image on canvas
            var ctx = canvas.getContext("2d");
            ctx.drawImage(origImage, 0, 0, width, height);

            // get the data from canvas as 70% jpg (or specified type).
            return canvas.toDataURL(type, quality);
        };

        var createImage = function (url, callback) {
            var image = new Image();
            image.onload = function () {
                callback(image);
            };
            image.src = url;
        };

        var fileToDataURL = function (file) {
            var deferred = $q.defer();
            var reader = new FileReader();
            reader.onload = function (e) {
                deferred.resolve(e.target.result);
            };
            reader.readAsDataURL(file);
            return deferred.promise;
        };


        return {
            restrict: 'A',
            scope: {
                image: '=',
                resizeMaxHeight: '@?',
                resizeMaxWidth: '@?',
                resizeQuality: '@?',
                resizeType: '@?',
            },
            link: function postLink(scope, element, attrs, ctrl) {

                var doResizing = function (imageResult, callback) {
                    createImage(imageResult.url, function (image) {
                        var dataURL = resizeImage(image, scope);
                        imageResult.resized = {
                            dataURL: dataURL,
                            type: dataURL.match(/:(.+\/.+);/)[1],
                        };
                        callback(imageResult);
                    });
                };

                var applyScope = function (imageResult) {
                    scope.$apply(function () {
                        //console.log(imageResult);
                        if (attrs.multiple)
                            scope.image.push(imageResult);
                        else
                            scope.image = imageResult;
                    });
                };


                element.bind('change', function (evt) {
                    //when multiple always return an array of images
                    if (attrs.multiple)
                        scope.image = [];

                    var files = evt.target.files;
                    for (var i = 0; i < files.length; i++) {
                        //create a result object for each file in files
                        var imageResult = {
                            file: files[i],
                            url: URL.createObjectURL(files[i])
                        };

                        fileToDataURL(files[i]).then(function (dataURL) {
                            imageResult.dataURL = dataURL;
                        });

                        if (scope.resizeMaxHeight || scope.resizeMaxWidth) { //resize image
                            doResizing(imageResult, function (imageResult) {
                                applyScope(imageResult);
                            });
                        } else { //no resizing
                            applyScope(imageResult);
                        }
                    }
                });
            }
        };
});


(function (angular) {
    'use strict';

    function printDirective() {
        var printSection = document.getElementById('printSection');

        // if there is no printing section, create one
        if (!printSection) {
            printSection = document.createElement('div');
            printSection.id = 'printSection';
            document.body.appendChild(printSection);
        }

        function link(scope, element, attrs) {
            element.on('click', function () {
                var elemToPrint = document.getElementById(attrs.printElementId);
                if (elemToPrint) {
                    printElement(elemToPrint);
                    window.print();
                }
            });

            window.onafterprint = function () {
                // clean the print section before adding new content
                printSection.innerHTML = '';
            }
        }

        function printElement(elem) {
            // clones the element you want to print
            var domClone = elem.cloneNode(true);
            printSection.appendChild(domClone);
        }

        return {
            link: link,
            restrict: 'A'
        };
    }

    angular.module('smc').directive('ngPrint', [printDirective]);
}(window.angular));
