angular.module('smc').constant('mediationPatternConfig', { 

	Applicant:{
		register_name:{
			pattern_error:"Please enter valid applicant name"
		},
		nric:{
			pattern_error:"Please enter valid NRIC/passport no"
		},
        uen:{
            pattern_error:"Please enter valid UEN"
        },
		postal_code:{
			pattern_error:"Please enter valid postal code"
		},
		address:{
			pattern_error:"Please enter valid address"
		},
		telephone_number:{
			pattern_error:"Please enter valid telephone number"
		},
        mobile_number:{
			pattern_error:"Please enter valid mobile number"
		},
		fax_number:{
			pattern_error:"Please enter valid fax number"
		},
		authorised_representative:{
			pattern_error:"Please enter valid authorised representative name"
		},
		designation:{
			pattern_error:"Please enter valid designation"
		},
		email:{
			pattern_error:"Please enter valid email address"
		},
		name_of_payee:{
			pattern_error:"Please enter valid name of payee"
		},
		law_firm_name:{
			pattern_error:"Please enter valid law firm name"
		},
		name_of_lawyer:{
			pattern_error:"Please enter valid name of lawyer"
		},
		lawfirm_reference_number:{
			pattern_error:"Please enter valid law firm's file reference number"
		}
			},
	Respondent:{
		register_name:{
			pattern_error:"Please enter valid respondent name"
		},
		nric:{
			pattern_error:"Please enter valid NRIC/passport no"
		},
        uen:{
            pattern_error:"Please enter valid UEN"
        },
		address:{
			pattern_error:"Please enter valid address"
		},
		postal_code:{
			pattern_error:"Please enter valid postal code"
		},
		telephone_number:{
			pattern_error:"Please enter valid telephone number"
		},
        mobile_number:{
			pattern_error:"Please enter valid mobile number"
		},
		fax_number:{
			pattern_error:"Please enter valid fax number"
		},
		authorised_representative:{
			pattern_error:"Please enter valid authorised representative name"
		},
		designation:{
			pattern_error:"Please enter valid designation"
		},
		email:{
			pattern_error:"Please enter valid email address"
		},
		law_firm_name:{
			pattern_error:"Please enter valid law firm name"
		},
		ref_number:{
			pattern_error:"Please enter valid reference number"
		},
		name_of_lawyer:{
			pattern_error:"Please enter valid name of lawyer"
		},
		lawyer_reference_number:{
			pattern_error:"Please enter valid lawyer's reference number"
		}	
	},
	dispute_details:{
		distripute_details:{
			pattern_error:"Please enter valid distripute details"
		},
		quantum_claim:{
			pattern_error:"Please enter valid quantum claim"
		},
		quantum_counter_claim:{
			pattern_error:"Please enter valid quantum counter claim"
		},
		quantum_other:{
			pattern_error:"Please enter valid quantum other"
		},
		other_attributes:{
			pattern_error:"Please enter valid attributes"
		},
		suit_number:{
			pattern_error:"Please enter valid suit number"
		}
	},
	purpose_of_regulation:{
		principal_name:{
			pattern_error:"Please enter valid principal name"
		},
		postal_code:{
			pattern_error:"Please enter valid postal code"
		},
		phone_number:{
			pattern_error:"Please enter valid telephone number/mobile number"
		},
		fax_number:{
			pattern_error:"Please enter valid fax number"
		},
		email:{
			pattern_error:"Please enter valid email address"
		},
		principal_reference_number:{
			pattern_error:"Please enter valid principal's reference number"
		},
		owner_reference_number:{
			pattern_error:"Please enter valid owner's reference number"
		},
		name_of_owmer:{
			pattern_error:"Please enter valid name of owner"
		},
		contact_person_name:{
			pattern_error:"Please enter valid name of contact person"
		}
	},
	information_on_contract:{
		project_title:{
			pattern_error:"Please enter valid project title or reference"
		},
		contract_number:{
			pattern_error:"Please enter valid contract number"
		}
	},
	information_on_payment_details:{
		payment_claim_reference_number:{
			pattern_error:"Please enter valid payment claim reference number"
		},
		payment_claim_amount:{
			pattern_error:"Please enter valid payment claim amount"
		},
		payment_interest:{
			pattern_error:"Please enter valid late payment interest rate"
		},
		payment_response_reference_number:{
			pattern_error:"Please enter valid payment response reference number"
		},
		payment_response_amount:{
			pattern_error:"Please enter valid payment response amount"
		},
		amount_of_payment_made_by_the_respondent:{
			pattern_error:"Please enter valid amount of payment made by the respondent"
		},
		claimed_amount:{
			pattern_error:"Please enter valid claimed amount"
		}
	},
	submission:{
		name_of_person_authorised_by_the_claimant_to_submit:{
			pattern_error:"Please enter valid name of person authorised by the claimant to submit this application"
		},
		NRIC_passport_number:{
			pattern_error:"Please enter valid NRIC/passport Number"
		}
	},
	cheque_payment:{
		cheque_order_number:{
			pattern_error:"Please enter valid cheque order number"
		},
		amount_of_cheque:{
			pattern_error:"Please enter valid amount of cheque order"
		},
		name_of_the_bank:{
			pattern_error:"Please enter valid name of the bank"
		}
	},
	cashier_payment:{
		cashier_order_number:{
			pattern_error:"Please enter valid cashier's order number"
		},
		amount_of_cashier:{
			pattern_error:"Please enter valid amount of cashier's order"
		},
		name_of_the_bank:{
			pattern_error:"Please enter valid name of the bank"
		}
	},
	netbank_payment:{
		name_of_the_bank:{
			pattern_error:"Please enter valid name of the bank"
		},
		amount_of_paid:{
			pattern_error:"Please enter valid amount of paid"
		},
		transaction_reference_number:{
			pattern_error:"Please enter valid transaction reference number"
		}
	},
	response_amount_detail:{
		constituting_adjudication_response:{
			pattern_error:"Please enter valid constituting adjudication response"
		}
	},
	respond_submission:{
		name_of_person_authorised_by_the_respond_to_submit:{
			pattern_error:"Please enter valid name of person authorised by the respondent to submit this application"
		},
		NRIC_passport_number:{
			pattern_error:"Please enter valid NRIC/passport Number"
		}
	},
	smc_officer:{
		update_schedule:{
			venue:{
				pattern_error: "Please enter valid venue place"
			},
			numberOfAttendees:{
				pattern_error:"Please enter valid Number of Attendees"
			},
			cost:{
				pattern_error:"Please enter valid Cost"
			}
		}
	}

});
