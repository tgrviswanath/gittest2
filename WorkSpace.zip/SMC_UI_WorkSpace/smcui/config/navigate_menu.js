angular.module('smc').constant('navigateConfig', {
    navigation: {
        default: [{
            displayName: 'Home',
            url: ''
        }, {
            displayName: 'About Us',
            url: ''
        }, {
            displayName: 'Contact Us',
            url: ''
        }],
    },
    Adjudication: {
        "claimant": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.lawyercasesummary'
        }],
        "respondent": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.respondantcasesummary'
        }],
        "claimantLawyer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.lawyercasesummary'
        }],
        "respondentLawyer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.respondantcasesummary'
        }],
        "adjudicator": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.adjudicatorcaselist.torespond'
        }],
        "SMC Officer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.membercaselist.incomplete'
        }, {
            displayName: 'Code Table',
            url: 'smclayout.membershiplayout.codetable'
        }, {
            displayName: 'Courier Management',
            url: 'smclayout.membershiplayout.managecourier'
        },{
            displayName: 'Law Firm Management',
            url: 'smclayout.membershiplayout.lawFirmManagement'
        }, {
            displayName: 'Re-Assignment of Case(s)',
            url: 'smclayout.membershiplayout.reassign'
        }, {
            displayName: 'List of Adjudicator(s)',
            url: 'smclayout.membershiplayout.adjudicatorlist'
        }, {
            displayName: 'To-Do List',
            url: 'smclayout.membershiplayout.todolist'
        }, {
            displayName: 'List of Determinations',
            url: 'smclayout.membershiplayout.determinationlist'
        }, {
            displayName: 'Reports',
            url: 'smclayout.membershiplayout.generatereports.reports'
        },
        {
            displayName:'Arrange for Courier Service',
            url:'smclayout.membershiplayout.courierservicemanagement'
        },{
            displayName: 'Email Templates',
            url: 'smclayout.mediationlayout.emailTemplate'
        },{
            displayName: 'Collection Reports',
            url: 'smclayout.membershiplayout.collectionreports'
        },{
            displayName: 'Balance Payment Report',
            url: 'smclayout.membershiplayout.blncepaymentreports'
        }],
        "SMC Management": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'Adjudicator Pending Approval',
            url: 'smclayout.membershiplayout.pendingapproval'
        }, {
            displayName: 'Payment Pending Approval',
            url: 'smclayout.membershiplayout.paymentapproval'
        }, {
            displayName: 'Refund for Claimant Pending Approval',
            url: 'smclayout.membershiplayout.refundapproval'
        }, {
            displayName: 'Adjudicator Resignation Approval',
            url: 'smclayout.membershiplayout.resignationapproval'
        }, {
           displayName: 'Change of Payee’s Name',
            url: 'smclayout.membershiplayout.changepayee'
        }, {
            displayName: 'Case List',
            url: 'smclayout.membershiplayout.membercaselist.incomplete'
        }, {
            displayName: 'Case Load',
            url: 'smclayout.membershiplayout.caseload'
        }, {
            displayName: 'List of Adjudicator(s)',
            url: 'smclayout.membershiplayout.adjudicatorlist'
        }, {
            displayName: 'Code Table',
            url: 'smclayout.membershiplayout.codetable'
        }]
    },
    Mediation: {
        "applicant" : [
            {
                displayName: 'Dashboard',
                url: 'smclayout.membershiplayout.membersdashboard'  
            },
            {
                displayName: 'Case Summary',
                url: 'smclayout.mediationlayout.applicantcasesummary'
            }
        ],
        "applicantLawyer" : [
            {
                displayName: 'Dashboard',
                url: 'smclayout.membershiplayout.membersdashboard'  
            },
            {
                displayName: 'Case Summary',
                url: 'smclayout.mediationlayout.applicantcasesummary'
            }
        ],
        "respondent" : [
            {
                displayName: 'Dashboard',
                url: 'smclayout.membershiplayout.membersdashboard'  
            },
            {
                displayName: 'Case Summary',
                url: 'smclayout.mediationlayout.respondantcasesummaries'
            }
        ],
        "respondentLawyer" : [
            {
                displayName: 'Dashboard',
                url: 'smclayout.membershiplayout.membersdashboard'  
            },
            {
                displayName: 'Case Summary',
                url: 'smclayout.mediationlayout.respondantcasesummaries'
            }
        ],
        "SMC Officer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'List Of Cases',
            url: 'smclayout.mediationlayout.caselist.incomplete'
        }, {
            displayName: 'Add CPE Case',
            url: 'smclayout.cmsFormLayout.cpe'
        }, {
            displayName: 'Venue Management',
            url: 'smclayout.cmsFormLayout.venueManagement'
        }, {
            displayName: 'Email Templates',
            url: 'smclayout.mediationlayout.emailTemplate'
        }],
        "Associate Mediator" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "Principal Mediator" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "SDRP" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "CFP" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "Family Panel" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "Neutral Evaluator" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "SDRP" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "Neutral Evaluator" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }],
        "CFP" : [{
            displayName : 'Profile',
            url : 'smclayout.contactlayout.smcmemberprofilemenulist.profileinformation'
        }]

    },
    Training: { 
        "SMC Officer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'Training Master',
            url: 'smclayout.traininglayout.trainingmaster'
        }, {
            displayName: 'Schedule',
            url: 'smclayout.traininglayout.monthschedule'
        }, {
            displayName: 'List of Programs',
            url: 'smclayout.traininglayout.listofprograms'
        }, {
            displayName: 'To-Do List',
            url: 'smclayout.traininglayout.todolist'
        },{
            displayName: 'Code Table',
            url: 'smclayout.membershiplayout.codetable'
        }],
        "SMC Management": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'Program Management',
            url: 'smclayout.traininglayout.programManagement'
        }, {
            displayName: 'Trainer Resources Management',
            url: 'smclayout.traininglayout.pendingmembersappointment'
        }, {
            displayName: 'To-Do List',
            url: 'smclayout.traininglayout.todolist'
        } ],
        "Senior Associate Trainer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Pending Schedule Approval',
            url: 'smclayout.traininglayout.trainerscheduleapproval'
        }, {
            displayName: 'Training - Accept Terms & Conditions',
            url: 'smclayout.traininglayout.traineracceptterms'
        }],
        "Principal Trainer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Pending Schedule Approval',
            url: 'smclayout.traininglayout.trainerscheduleapproval'
        }, {
            displayName: 'Training - Accept Terms & Conditions',
            url: 'smclayout.traininglayout.traineracceptterms'
        }],
        "Associate Trainer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Pending Schedule Approval',
            url: 'smclayout.traininglayout.trainerscheduleapproval'
        }, {
            displayName: 'Training - Accept Terms & Conditions',
            url: 'smclayout.traininglayout.traineracceptterms'
        }],
        "Affiliate Trainer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Pending Schedule Approval',
            url: 'smclayout.traininglayout.trainerscheduleapproval'
        }, {
            displayName: 'Training - Accept Terms & Conditions',
            url: 'smclayout.traininglayout.traineracceptterms'
        }],
        "External Trainer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Pending Schedule Approval',
            url: 'smclayout.traininglayout.trainerscheduleapproval'
        }, {
            displayName: 'Training - Accept Terms & Conditions',
            url: 'smclayout.traininglayout.traineracceptterms'
        }],
        "Assessor": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.membersdashboard'
        }, {
            displayName: 'Pending Schedule Approval',
            url: 'smclayout.traininglayout.trainerscheduleapproval'
        }],
    },
    Admin: {
        "Super Admin": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'User Management',
            url: 'smclayout.membershiplayout.userlist'
        }, {
            displayName: 'Admin Reports',
            url: 'smclayout.membershiplayout.adminreports'
        }, {
            displayName: 'Public Calendar',
            url: 'smclayout.membershiplayout.publicCalendar'
        }, {
            displayName: 'Code Table',
            url: 'smclayout.membershiplayout.codetable'
        }],
        "SMC Admin": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        }, {
            displayName: 'Manage Access',
            url: 'smclayout.membershiplayout.userlist'
        }, {
            displayName: 'Public Calendar',
            url: 'smclayout.membershiplayout.publicCalendar'
        }, {
            displayName: 'Email Templates',
            url: 'smclayout.mediationlayout.emailTemplate'
        }, {
            displayName: 'Audit Trail Reports',
            url: ''
        }]
    },
    Contact: {
        "SMC Officer": [{
            displayName: 'Dashboard',
            url: 'smclayout.membershiplayout.memberdashboard'
        },
        {   displayName:'Continual Professional Development Requirement: SOP ',
            url:'smclayout.contactlayout.adjudicatorlist'
        },
        {
            displayName: 'Member Invite',
            url: 'smclayout.contactlayout.caselist.tobeinvited'
        },
        {
            displayName: 'Panel Management',
            url: 'smclayout.contactlayout.panelmanagement'
        },
        {
            displayName: 'Manage Other Members',
            url: 'smclayout.contactlayout.manageothermembers'
        },
        {
            displayName: 'SMC Member Management',
            url: 'smclayout.contactlayout.smcmembermanagement'
        },
        {
            displayName: 'SMC Non Member Management',
            url: 'smclayout.contactlayout.smcnonmembermanagement'
        },
        {
            displayName: 'Monthly Renewal Report',
            url: 'smclayout.contactlayout.monthlyrenewalreport'
        },
        {
            displayName: 'Complaint Management',
            url: 'smclayout.contactlayout.managecomplaints'
        },
        {
            displayName: 'Waiver Report',
            url: 'smclayout.contactlayout.waiverreport'
        },
        {
            displayName: 'Watch List',
            url: 'smclayout.contactlayout.watchlist'
        }, 
        {
            displayName: 'Add Watch List',
            url: 'smclayout.contactlayout.addwatchlist'
        }, 
        {
            displayName: 'User Id Update',
            url: 'smclayout.contactlayout.useridupdate'
        }, 
        {
            displayName: 'Code Table',
            url: 'smclayout.membershiplayout.codetable'
        },{
            displayName: 'Collection Reports',
            url: 'smclayout.contactlayout.collectionreports'
        },
        {
            displayName: 'Balance Payment Report',
            url: 'smclayout.contactlayout.balancepaymentreports'
        },
        {
            displayName: 'To-Do list',
            url: 'smclayout.contactlayout.todolist'
        },{
            displayName: 'Email Templates',
            url: 'smclayout.mediationlayout.emailTemplate'
        }
        ],
        'SMC Management' :[
            {
                displayName: 'List of Members for Status Update',
                url: 'smclayout.contactlayout.memberstatusupdate'
            },
            {
                displayName: 'List of Cases for Waivers',
                url: 'smclayout.contactlayout.waivercaseslist'
            },
            {
                displayName: 'List of Members for trainer promotion',
                url: 'smclayout.contactlayout.trainerpromotion'
            },
            {
                displayName: 'List of Cases for Renewal Invoice Cancellation',
                url: 'smclayout.contactlayout.approveinvoicecancellation'
            },
            {
                displayName: 'SMC Member Management',
                url: 'smclayout.contactlayout.smcmembermanagement'
            },
            {
                displayName: 'SMC Non Member Management',
                url: 'smclayout.contactlayout.smcnonmembermanagement'
            },
            {
                displayName: 'Complaint Management',
                url: 'smclayout.contactlayout.managecomplaints'
            },
            {
                displayName: 'Watch List',
                url: 'smclayout.contactlayout.watchlist'
            },
            {
                displayName: 'Add Watch List',
                url: 'smclayout.contactlayout.addwatchlist'
            },
            {
                displayName: 'Code Table',
                url: 'smclayout.membershiplayout.codetable'
            }
        ]
    },
    logoUrl: {
        Member: 'smclayout.membershiplayout.membersdashboard',
        Staff: 'smclayout.membershiplayout.memberdashboard'
    },
    BacktoCase: {
        claimant: {
            url: 'smclayout.membershiplayout.lawyercasesummary'
        },
        respondent: {
            url: 'smclayout.membershiplayout.respondantcasesummary'
        },
        claimantLawyer: {
            url: 'smclayout.membershiplayout.lawyercasesummary'
        },
        respondentLawyer: {
            url: 'smclayout.membershiplayout.respondantcasesummary'
        },
        adjudicator: {
            url: 'smclayout.membershiplayout.adjudicatorcaselist.inprogress'
        }
    }

});
