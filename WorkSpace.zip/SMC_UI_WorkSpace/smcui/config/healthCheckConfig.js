angular.module('smc').constant('healthCheckConfig', {
	Adjudication: {
		"AACaseStatusList" : 
			[
                {
                    "name": "Lodged",
                    "displayName": "AA Lodged"
                }, {
                    "name": 'Payment Dishonored',
                    "displayName": "*Payment Dishonored"
                }, {
                    "name": 'AA Served',
                    "displayName": "AA Served on Respondent"
                }, {
                    "name": 'Adjudicators Proposed',
                    "displayName": "Shortlist Adjudicators"
                }, {
                    "name": 'Shortlisted Adjudicators Approved',
                    "displayName": "Shortlisted List of Adjudicators Approved"
                }, {
                    "name": 'Shortlisted Adjudicators Invited',
                    "displayName": "Invite Approved Adjudicator"
                }, {
                    "name": 'Adjudicator Appointed',
                    "displayName": "Approved Adjudicator accepted/Adjudicator appointed"
                }, {
                    "name": 'Parties Notified of Adjudicator Appointed',
                    "displayName": "All Parties Notified of Appointment"
                }, {
                    "name": 'AA Served On Adjudicator Appointed',
                    "displayName": "AA Served on the Adjudicator."
                }, {
                    "name": 'Adjudicator Advised On Timeline',
                    "displayName": "Adjudicator advised on Timeline"
                }, {
                    "name": 'AR Lodged',
                    "displayName": "*AR Lodged by Respondent"
                }, {
                    "name": 'AR Served',
                    "displayName": "*AR Served on Claimant"
                }, {
                    "name": 'Draft Determination And Time Sheet Submitted',
                    "displayName": "Draft Det. And Timesheet Submitted"
                }, {
                    "name": 'AA Determined',
                    "displayName": "Adjudication Det. accepted by SMC"
                }, {
                    "name": 'Additional Deposit Paid / Deposit is Sufficient',
                    "displayName": "Additional Adj. Deposit Paid / Sufficient"
                }, {
                    "name": 'Determination Served on Parties',
                    "displayName": "Det. Served on all Parties"
                }, {
                    "name": 'AA Withdrawn',
                    "displayName": "*Adj. Application Withdrawn"
                }, {
                    "name": 'Ack of Withdrawal Sent to Parties and Adju',
                    "displayName": "*Ack. Of Withdrawn Send to Parties"
                }, {
                    "name": 'Memo Sent for approval',
                    "displayName": "Memo Sent to Mgt for Approval"
                }, {
                    "name": 'Memo Sent to Management And Approved',
                    "displayName": "Memo Approved"
                }, {
                    "name": 'Excess Money Refunded to Claimant',
                    "displayName": "Excess Money Refunded to Claimant"
                }, {
                    "name": 'Adjudicator Paid',
                    "displayName": "Adjudicator Paid"
                }, {
                    "name": 'AA Canceled',
                    "displayName": "Case Closed/Canceled"
                }
			],
		"ARACaseStatusList" : 
			[
                {
                    "name": "ARA Lodged",
                    "displayName": "ARA Lodged"
                }, {
                    "name": "ARA Payment Dishonored",
                    "displayName": "ARA Payment Dishonored"
                }, {
                    "name": "ARA Served on Claimant, Principal and/or Owner",
                    "displayName": "ARA Served"
                }, {
                    "name": "List of Proposed Review Adjudicator(s) Sent for Approval",
                    "displayName": "List of Adj. Proposed"
                }, {
                    "name": "List of Proposed Review Adjudicator(s) Approved",
                    "displayName": "List of Adj. Proposed Approved"
                }, {
                    "name": "Proposed Review Adjudicator(s) Contacted",
                    "displayName": "Proposed Adj. Contacted"
                }, {
                    "name": "Review Adjudicator(s) Appointed",
                    "displayName": "Review Adj. Appointed"
                }, {
                    "name": "Parties Notified of the Review Adjudicator(s) Appointed",
                    "displayName": "Parties Notified"
                }, {
                    "name": "ARA Served on the Review Adjudicator(s)",
                    "displayName": "ARA Served on the Review Adj."
                }, {
                    "name": "Review Adjudicator(s) Advised on Timeline",
                    "displayName": "Review Adj. Advised on Timeline"
                }, {
                    "name": "Draft Review Determination and Time Sheet(s) Submitted",
                    "displayName": "Draft Det. And Timesheet Submitted"
                }, {
                    "name": "Adjudication Review Application Determined",
                    "displayName": "Adj. Review Application Determined"
                }, {
                    "name": "Additional Deposit Paid / Deposit is Sufficient",
                    "displayName": "Adj. Deposit Paid / Sufficient"
                }, {
                    "name": "Review Determination Served on Parties",
                    "displayName": "Review Det. Served on Parties"
                }, {
                    "name": "Adjudication Review Application Withdrawn",
                    "displayName": "Adj. Review Application Withdrawn"
                }, {
                    "name": "Acknowledgement of Withdrawal Sent to Parties",
                    "displayName": "Ack. of Withdrawal Sent to Parties"
                }, {
                    "name": "Memo sent for approval",
                    "displayName": "Memo sent for Approval"
                }, {
                    "name": "Memo Sent to Management and Approved",
                    "displayName": "Memo Sent and Approved"
                }, {
                    "name": "Excess Refunded to Respondent",
                    "displayName": "Excess Money Refunded to Respondent"
                }, {
                    "name": "Review Adjudicator(s) Paid",
                    "displayName": "Review Adjudicator(s) Paid"
                }, {
                    "name": "ARA Cancelled",
                    "displayName": "ARA Cancelled"
                }
			]
	},
});

