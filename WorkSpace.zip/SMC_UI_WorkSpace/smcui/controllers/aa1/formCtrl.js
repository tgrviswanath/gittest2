(function() {
    'use strict';
    angular
        .module('smc')
        .controller('aa1formCtrl',aa1formCtrl);

    aa1formCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','navigateConfig','$window','$sce', 'NotifyFactory'];

    function aa1formCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,navigateConfig,$window,$sce, NotifyFactory){

    	var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	$scope.tabName = tab;
    	if (tab == 'submitformprocess'){
	    	if ($cookies.get('roleName') != 'claimant'  || $cookies.get('roleName') != 'claimantLawyer') {
	            $state.go('smclayout.membershiplayout.login');
	        }
	    }
	    if($cookies.get('roleName') == "adjudicator"){
	    	$scope.downloadButtonStatus = false;
	    } else {
	    	$scope.downloadButtonStatus = true;
	    }
    	var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches

    	//Error Messages
		$scope.pattern = patternConfig;
		//Default Values settings
		$scope.directFormSataus = true;
    	$scope.isPreviewClicked = false;
    	$scope.claiamentStatus = false;
    	$scope.claiamentServiceAddressStatus = true;
    	$scope.claiamentLawFormDetailStatus = true;
    	$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
    	$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
    	$scope.uenOrnric = "Enter the organisation’s UEN";
    	$scope.respondentIndivStatus = false;
		$scope.registeredRespondentName = "Enter the respondent’s registered name";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
		$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.interestRateOfLatePaymentStatus = false;
		$scope.onlineFormSubmissionStatus = true;
		$scope.onlineFileUploadStatus = false;
		$scope.claimentLegallyRepresentStatus = false;
		$scope.respondentLegallyRepresentStatus = true;
		$scope.claiamentLawyerServiceAddressStatus = true;

		//Form Related Default settings
		$scope.aa1_form1 = {};
		$scope.aa1_form1.claimantInfo = {};
		$scope.aa1_form1.claimantInfo.businessAddress = {};

		$scope.aa1_form1.claimantInfo.lawFirmDto = {};
		$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress = {};

		$scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails = [];
		$scope.aa1_form1.respondentInfo = {};
		$scope.aa1_form1.respondentInfo.businessAddress = {};

		$scope.aa1_form1.respondentInfo.lawFirmDto = {};
		$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress = {};
		$scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails = [];
		$scope.aa1_form1.regulationInfo = {};
		$scope.aa1_form1.regulationInfo.principalName = undefined;
		$scope.aa1_form1.contractInfo = {};
		$scope.aa1_form1.paymentInfo = {};
		$scope.aa1_form1.caseDto = {};


		$scope.aa1_form1.claimantInfo.caseMemberRoleType = "Organisation";
		$scope.aa1_form1.respondentInfo.caseMemberRoleType = "Organisation";
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.claimantLawFirmStatus = true;
		$scope.respondantLawFirmStatus = true;
		$scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress = false;
		$scope.aa1_form1.claimantInfo.isLegallyRepresented = "Yes";
		$scope.aa1_form1.respondentInfo.isLegallyRepresented = "No";
		$scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress = false;
		$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress = false;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.termsUploadPathStatus = false;
		$scope.paymentClaimUploadPathStatus = false;
		$scope.paymentResponseUploadPathStatus = false;
		$scope.intentionNoticeUploadPathStatus = false;
		$scope.otherDocUploadPathStatus = false;
		$scope.termsErrorStatus = false;
		$scope.paymentClaimErrorStatus = false;
		$scope.paymentResponseErrorStatus = false;
		$scope.intentionNoticeErrorStatus = false;
		$scope.otherDocErrorStatus = false;
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.isSubmitted = false;

		$rootScope.tempCaseNumber = null;

		$scope.toDateMinLimit = 0;



		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
				$rootScope.lawFirmList = data.results;
				// $scope.cliamentLegallyRepresentedClick();
				// $scope.respondentLegallyRepresentedClick();
			} else {
				$scope.lawFirmList = [];
			}
			
        });

        /*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
				$rootScope.lawFirmList = data.results;
				// $scope.cliamentLegallyRepresentedClick();
				// $scope.respondentLegallyRepresentedClick();
			} else {
				$scope.lawFirmList = [];
			}
			
        });

        //Get Contract Type List Service
        DataService.get('GetContractTypeList').then(function(data){
			$scope.contractTyoeList = data.results;
        });

        //Get Dispute Nature List Service
        DataService.get('GetDisputeNatureList').then(function(data){
			$scope.disputeNatureList = data.results;
        });

        //Get Mode of Document Submission type
        DataService.get('ModeOfDocumentSubmission').then(function(data){
			$scope.documentSubmissionType = data;
			if(!$rootScope.loginSession){
				$scope.submitdoctype = data.result.value;
				$scope.aa1_form1.caseDto.isOnline = data.result.value;
				$scope.onlineFormSubmissionClick();
			}			
        });

        //Get Purpose Regulation
        DataService.get('GetPurposeRegulation').then(function(data){
			$scope.regulationPurpose = data.result.value;
        });

        /* Login Form Submit process Session */
		if($rootScope.loginSession){
			$scope.directFormSataus = false;
			$scope.aa1_form1 = $rootScope.singleCaseObject;
			$scope.aa1_form1.claimantInfo.reEmail = $scope.aa1_form1.claimantInfo.email;
			// if($scope.aa1_form1.paymentInfo.claimAmount){
			// 		$scope.aa1_form1.paymentInfo.claimAmount= $scope.aa1_form1.paymentInfo.claimAmount+'.00'
			// 	}
			// 	if($scope.aa1_form1.paymentInfo.latePaymentInterestRate){
			// 		$scope.aa1_form1.paymentInfo.latePaymentInterestRate= $scope.aa1_form1.paymentInfo.latePaymentInterestRate+'.00'
			// 	}
			// 	if($scope.aa1_form1.paymentInfo.responseAmount){
			// 		$scope.aa1_form1.paymentInfo.responseAmount= $scope.aa1_form1.paymentInfo.responseAmount+'.00'
			// 	}
			// 	if($scope.aa1_form1.paymentInfo.paymentByRespondent){
			// 		$scope.aa1_form1.paymentInfo.paymentByRespondent= $scope.aa1_form1.paymentInfo.paymentByRespondent+'.00'
			// 	}
			// 	if($scope.aa1_form1.caseDto.claimAmount){
			// 		$scope.aa1_form1.caseDto.claimAmount= $scope.aa1_form1.caseDto.claimAmount+'.00'
			// 	}
			$rootScope.tempCaseNumber = $cookies.get('caseNumber');
			if($scope.aa1_form1.claimantInfo.caseMemberRoleType == 'Individual'){
				$scope.claiamentStatus = true;
				$scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
				$scope.uenOrnricLabel = "NRIC/Passport Number";
				$scope.uenOrnric = "Enter your NRIC / Passport No.";
			}
			if($scope.aa1_form1.respondentInfo.caseMemberRoleType == 'Individual'){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			}
			if($scope.aa1_form1.claimantInfo.isLegallyRepresented == 'Yes'){
				$scope.claiamentLawFormDetailStatus = true;
			}else{
				$scope.claiamentLawFormDetailStatus = false;
			}
			if($rootScope.singleCaseObject.claimantInfo.lawFirmDto){
				$scope.aa1_form1.claimantInfo.lawFirmDto.id = { 'id' : $rootScope.singleCaseObject.claimantInfo.lawFirmDto.id};
				DataService.get('GetLawFirmList').then(function(data){
					if(data.results){
						var lawVal = getValueById(data.results, "name", $rootScope.singleCaseObject.claimantInfo.lawFirmDto.name);
						if(lawVal.length < 1){
							$scope.aa1_form1.claimantInfo.lawFirmDto.id = {'id' : 0};
						}
					}
				});
			}
			if($rootScope.singleCaseObject.respondentInfo){
				if($rootScope.singleCaseObject.respondentInfo.lawFirmDto){
					$scope.aa1_form1.respondentInfo.lawFirmDto.id = { 'id' : $rootScope.singleCaseObject.respondentInfo.lawFirmDto.id};
					

					DataService.get('GetLawFirmList').then(function(data){
						if(data.results){
							var lawValRespondent = getValueById(data.results, "name", $rootScope.singleCaseObject.respondentInfo.lawFirmDto.name);
							if(lawValRespondent.length < 1){
								$scope.aa1_form1.respondentInfo.lawFirmDto.id = {'id' : 0};
							}
						}
					});
				}

				if($scope.aa1_form1.respondentInfo.email){
					$scope.aa1_form1.respondentInfo.reEmail = $scope.aa1_form1.respondentInfo.email;
				}
			}
			if($rootScope.singleCaseObject.contractInfo){
				if($rootScope.singleCaseObject.contractInfo.contractTypeDto){
					if($rootScope.singleCaseObject.contractInfo.contractTypeDto.type == "Construction"){
						$scope.natureOfDistributeStatus = true;
					}
				}
			}
			if($rootScope.singleCaseObject.paymentInfo){
				if($rootScope.singleCaseObject.paymentInfo.latePaymentInterest == true){
					$scope.aa1_form1.paymentInfo.latePaymentInterest = "yes";
					$scope.interestRateOfLatePaymentStatus = true;
				}
				if($rootScope.singleCaseObject.paymentInfo.latePaymentInterest == false){
					$scope.aa1_form1.paymentInfo.latePaymentInterest = "no";
				}

				var fromDate = $rootScope.singleCaseObject.paymentInfo.referencePeriodFrom;
				$scope.toDateMinLimit = fromDate;
				$( "#referencePeriodTo" ).datepicker( "option", "minDate",fromDate );
			}
			if($rootScope.singleCaseObject.caseDto){
				
				if($rootScope.singleCaseObject.caseDto.includeGst == true){
					$scope.aa1_form1.caseDto.includeGst = "Yes";
				}
				if($rootScope.singleCaseObject.caseDto.includeGst == false){
					$scope.aa1_form1.caseDto.includeGst = "No";
				}
				if($rootScope.singleCaseObject.caseDto.isOnline == true){
					$scope.aa1_form1.caseDto.isOnline = $scope.submitdoctype = "Online";
					$scope.onlineFormSubmissionStatus = true;

				} else {
					$scope.aa1_form1.caseDto.isOnline = $scope.submitdoctype = "Offline";
					$scope.onlineFormSubmissionStatus = false;
				}
				if($rootScope.singleCaseObject.caseDto.isOnline == false){
					$scope.aa1_form1.caseDto.isOnline = "Offline";
				}
			}
			if($rootScope.singleCaseObject.contractInfo){
				if($scope.aa1_form1.contractInfo.contractType != null){
					$scope.aa1_form1.contractInfo.contractType = JSON.stringify($rootScope.singleCaseObject.contractInfo.contractTypeDto);
				}
			}
			if($rootScope.singleCaseObject.supportingDocuments){
				loginSupportingDocumentLoad($rootScope.singleCaseObject.supportingDocuments);
			}
			
			if($scope.aa1_form1.respondentInfo.serviceAddress){
            	if($scope.aa1_form1.respondentInfo.serviceAddress.faxNumber){
	                $scope.aa1_form1.respondentInfo.serviceAddress.faxNumber = $scope.aa1_form1.respondentInfo.serviceAddress.faxNumber.substring(3);
	            }
	            if($scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber){
	                $scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber = $scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber.substring(2);
	            }
            }
            if($scope.aa1_form1.claimantInfo.serviceAddress){
            	if($scope.aa1_form1.claimantInfo.serviceAddress.faxNumber){
	                $scope.aa1_form1.claimantInfo.serviceAddress.faxNumber = $scope.aa1_form1.claimantInfo.serviceAddress.faxNumber.substring(3);
	            }
	            if($scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber){
	                $scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber = $scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber.substring(2);
	            }
            }

			if($scope.aa1_form1.respondentInfo.businessAddress.faxNumber){
                $scope.aa1_form1.respondentInfo.businessAddress.faxNumber = $scope.aa1_form1.respondentInfo.businessAddress.faxNumber.substring(3);
            }
            if($scope.aa1_form1.respondentInfo.businessAddress.phoneNumber){
                $scope.aa1_form1.respondentInfo.businessAddress.phoneNumber = $scope.aa1_form1.respondentInfo.businessAddress.phoneNumber.substring(2);
            }
            
            if($scope.aa1_form1.claimantInfo.businessAddress.faxNumber){
                $scope.aa1_form1.claimantInfo.businessAddress.faxNumber = $scope.aa1_form1.claimantInfo.businessAddress.faxNumber.substring(3);
            }
             if($scope.aa1_form1.claimantInfo.businessAddress.phoneNumber){
                $scope.aa1_form1.claimantInfo.businessAddress.phoneNumber = $scope.aa1_form1.claimantInfo.businessAddress.phoneNumber.substring(2);
            }
            
            if($scope.aa1_form1.respondentInfo.lawFirmDto){
                if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber){
                    $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                }
                if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
                    $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                }
                if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress){
                	 if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
                    	$scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                	}
                	if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
                   		 $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
               		}
                }
               
            } 
            if($scope.aa1_form1.claimantInfo.lawFirmDto){
            	if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber){
                    $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                }
                 if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber){
                    $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                }
                if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress){
                	if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber){
	                    $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
	                }
	                if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber){
	                    $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
	                }
                }
            }
            if($scope.aa1_form1.regulationInfo){
            	if($scope.aa1_form1.regulationInfo.ownerAddress){
            		if($scope.aa1_form1.regulationInfo.ownerAddress.faxNumber){
            			$scope.aa1_form1.regulationInfo.ownerAddress.faxNumber = $scope.aa1_form1.regulationInfo.ownerAddress.faxNumber.substring(3);
            		}
            		if($scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber){
            			$scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber = $scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber.substring(2);
            		}
            	}
            	if($scope.aa1_form1.regulationInfo.principalAddress){
            		if($scope.aa1_form1.regulationInfo.principalAddress.faxNumber){
            			$scope.aa1_form1.regulationInfo.principalAddress.faxNumber = $scope.aa1_form1.regulationInfo.principalAddress.faxNumber.substring(3);
            		}
            		if($scope.aa1_form1.regulationInfo.principalAddress.phoneNumber){
            			$scope.aa1_form1.regulationInfo.principalAddress.phoneNumber = $scope.aa1_form1.regulationInfo.principalAddress.phoneNumber.substring(2);
            		}
            	}
            }

			$scope.roleName = $cookies.get('roleName');
	    	$scope.navigateConfig = navigateConfig;
	    	$scope.backToForm = navigateConfig.BacktoCase[$scope.roleName].url;
		}else if(!$rootScope.loginSession && tab == 'submitformprocess'){
			$state.go('smclayout.membershiplayout.lawyercasesummary');
		}

		function loginSupportingDocumentLoad(documents){
			var documentsLen = documents.length;
			for(var i =0; i < documentsLen; i++){
				if(documents[i].name == "Relevant Contractual Terms and Conditions"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload1 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload1_name = fileName;
						$scope.termsUploadPath = documents[i].fileLocation;
						$scope.termsUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.termsUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Payment Claim"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload2 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload2_name = fileName;
						$scope.paymentClaimUploadPath = documents[i].fileLocation;
						$scope.paymentClaimUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.paymentClaimUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Payment Response Received"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload3 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload3_name = fileName;
						$scope.paymentResponseUploadPath = documents[i].fileLocation;
						$scope.paymentResponseUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.paymentResponseUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Notice of Intention to Apply for Adjudication"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload4 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload4_name = fileName;
						$scope.intentionNoticeUploadPath = documents[i].fileLocation;
						$scope.intentionNoticeUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.intentionNoticeUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Other Relevant Document(s)"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload5 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload5_name = fileName;
						$scope.otherDocUploadPath = documents[i].fileLocation;
						$scope.otherDocUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.aa1_form1.suport_upload5_ref_name = documents[i].documentDescription;
						$scope.otherDocUploadPathStatus = true;
					}
				}
			}
		}

        //Claimant Click Actions
		$scope.cliamentTypeClick = function(){
			$scope.aa1_form1.claimantInfo.applicantUidValue = undefined;
			$scope.aa1_form1.claimantInfo.gender = undefined;
			if($scope.aa1_form1.claimantInfo.caseMemberRoleType == "Individual"){
				$scope.claiamentStatus = true;
				$scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
				$scope.uenOrnricLabel = "NRIC/Passport Number";
				$scope.uenOrnric = "Enter your NRIC / Passport No.";
			} else {
				$scope.claiamentStatus = false;
				$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
				$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnric = "Enter the organisation’s UEN";
			}
		}
		$scope.cliamentServiceAddressClick = function(){

			if($scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress == false){
				$scope.claiamentServiceAddressStatus = true;
			} else {
				$scope.claiamentServiceAddressStatus = false;
			}
		}
		$scope.cliamentLegallyRepresentedClick = function(){

			if($scope.aa1_form1.claimantInfo.isLegallyRepresented == "Yes"){
				$scope.claiamentLawFormDetailStatus = true;
				$scope.claimentLegallyRepresentStatus = false;
			} else {
				$scope.claiamentLawFormDetailStatus = false;
				$scope.claimentLegallyRepresentStatus = true;
			}
		}
		$scope.cliamentLawyerServiceAddressClick = function(){

			if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress == false){
				$scope.claiamentLawyerServiceAddressStatus = true;
			} else {
				$scope.claiamentLawyerServiceAddressStatus = false;
			}
		}

		//Claimant Load Law firm details on selecting law firm and reset
		$scope.loadClaimantLawFirmDetails = function(data){
			console.log(data);
			if(data){
				if(data.name == "Others"){
					$scope.aa1_form1.claimantInfo.lawFirmDto.name = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = undefined;
					$scope.claimantLawFirmStatus = false;
				} else {
					$scope.claimantLawFirmStatus = true;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress = {};
					$scope.aa1_form1.claimantInfo.lawFirmDto.name = data.name;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
				}
			} else {
				$scope.claimantLawFirmStatus = true;
				$scope.aa1_form1.claimantInfo.lawFirmDto.name = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = undefined;
			}
		}



		//Respondent Click Actions
		$scope.respondentTypeClick = function(){
			$scope.aa1_form1.respondentInfo.applicantUidValue = undefined;
			$scope.aa1_form1.respondentInfo.gender = undefined;
			if($scope.aa1_form1.respondentInfo.caseMemberRoleType == "Individual"){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			} else {
				$scope.respondentIndivStatus = false;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
			}
		}

		$scope.respondentServiceAddressClick = function(){

			if($scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress == false){
				$scope.respondentServiceAddressStatus = true;
			} else {
				$scope.respondentServiceAddressStatus = false;
			}
		}

		$scope.respondentLegallyRepresentedClick = function(){

			if($scope.aa1_form1.respondentInfo.isLegallyRepresented == "Yes"){
				$scope.respondentLawFormDetailStatus = true;
				$scope.respondentLegallyRepresentStatus = false;
			} else if ($scope.aa1_form1.respondentInfo.isLegallyRepresented == "No"){
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = true;
			} else {
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = false;
			}
		}

		$scope.respondentLawyerServiceAddressClick = function(){

			if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress == false){
				$scope.respondentLawyerServiceAddressStatus = true;
			} else {
				$scope.respondentLawyerServiceAddressStatus = false;
			}
		}

		//Respondent Load Law firm details on selecting law firm and reset
		$scope.loadRespondantLawFirmDetails = function(data){
			if($scope.aa1_form1.respondentInfo.lawFirmDto == undefined){
				$scope.aa1_form1.respondentInfo.lawFirmDto = {}
			}
			if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress == undefined){
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress = {};
			}
			console.log(data);
		
			if(data){
				if(data.name == "Others"){
					$scope.aa1_form1.respondentInfo.lawFirmDto.name = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
					$scope.respondantLawFirmStatus = false;
				} else {
					$scope.aa1_form1.respondentInfo.lawFirmDto.name = data.name;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
					$scope.respondantLawFirmStatus = true;
				}
			} else {
				$scope.aa1_form1.respondentInfo.lawFirmDto.name = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
				$scope.respondantLawFirmStatus = true;
			}
		}



		$scope.contractTypeClick = function(){
			var contactTypes = JSON.parse($scope.aa1_form1.contractInfo.contractType);
			if(contactTypes.type == "Construction"){
				$scope.natureOfDistributeStatus = true;
			} else {
				$scope.aa1_form1.contractInfo.natureOfDispute = undefined;
				$scope.natureOfDistributeStatus = false;
			}
		}
		$scope.paymentInfoFromDateClick = function(){
			var fromDate = $scope.aa1_form1.paymentInfo.referencePeriodFrom;
			var toDate = $scope.aa1_form1.paymentInfo.referencePeriodTo;
			$scope.toDateMinLimit = fromDate;
			$( "#referencePeriodTo" ).datepicker( "option", "minDate",fromDate );
			if((new Date(fromDate)) > (new Date(toDate))){
				$scope.aa1_form1.paymentInfo.referencePeriodTo = undefined;
			}
		}
		$scope.interestRateOfLatePaymentClick = function(){

			if($scope.aa1_form1.paymentInfo.latePaymentInterest == "yes"){
				$scope.interestRateOfLatePaymentStatus = true;
			} else {
				$scope.interestRateOfLatePaymentStatus = false;
			}
		}

		$scope.onlineFormSubmissionClick = function(){
			if($scope.aa1_form1.caseDto.isOnline == "Online"){
				$scope.onlineFormSubmissionStatus = true;
			} else {
				$scope.onlineFormSubmissionStatus = false;
			}
		}


		/*Document Uploads*/

		$scope.termsUpload = function(event){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.termsUploadPathStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload1_name = fileName;
						angular.element("#suport_upload1_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload1_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								angular.element(".overlay").css("display","none");
								angular.element(".loading-container").css("display","none");
								$scope.onlineFileUploadStatus = false;
								$("#suport_upload1_name").removeClass("error");
								$("#suport_upload2_name").removeClass("error");
								$("#suport_upload4_name").removeClass("error");
								console.log(data);
								$scope.termsUploadPath = data.result;
								$scope.termsUploadPathStatus = true;
							});
						}
					} else {
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						angular.element("#suport_upload1_name").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					angular.element("#suport_upload1_name").addClass("error");
					$scope.termsErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.termsUploadRemove = function(){	
			$scope.aa1_form1.suport_upload1 = undefined;
			$scope.aa1_form1.suport_upload1_name = undefined;
			$scope.termsUploadPath = undefined;
			angular.element("#suport_upload1_name").val("");
			angular.element("#suport_upload1").val("");
			$scope.termsUploadPathStatus = false;
			if(!$scope.termsUploadPath && !$scope.paymentClaimUploadPath && !$scope.intentionNoticeUploadPath){
				$scope.onlineFileUploadStatus = true;
				$("#suport_upload1_name").addClass("error");
				$("#suport_upload2_name").addClass("error");
				$("#suport_upload4_name").addClass("error");
			}
		}

		$scope.paymentClaimUpload = function(event){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.paymentClaimErrorStatus = false;
				$scope.paymentClaimUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload2_name = fileName;
						angular.element("#suport_upload2_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload2_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								angular.element(".overlay").css("display","none");
								angular.element(".loading-container").css("display","none");
								$scope.paymentClaimUploadPath = data.result;
								$scope.paymentClaimUploadPathStatus = true;
								$scope.onlineFileUploadStatus = false;
								$("#suport_upload1_name").removeClass("error");
								$("#suport_upload2_name").removeClass("error");
								$("#suport_upload4_name").removeClass("error");
							});
						}
					} else {
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						angular.element("#suport_upload2_name").addClass("error");
						$scope.paymentClaimErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					angular.element("#suport_upload2_name").addClass("error");
					$scope.paymentClaimErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.paymentClaimUploadRemove = function(){
			$scope.aa1_form1.suport_upload2 = undefined;
			$scope.aa1_form1.suport_upload2_name = undefined;
			$scope.paymentClaimUploadPath = undefined;
			angular.element("#suport_upload2_name").val("");
			angular.element("#suport_upload2").val("");
			$scope.paymentClaimUploadPathStatus = false;
			if(!$scope.termsUploadPath && !$scope.paymentClaimUploadPath && !$scope.intentionNoticeUploadPath){
				$scope.onlineFileUploadStatus = true;
				$("#suport_upload1_name").addClass("error");
				$("#suport_upload2_name").addClass("error");
				$("#suport_upload4_name").addClass("error");
			}
		}

		$scope.paymentResponseUpload = function(event){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.paymentResponseErrorStatus = false;
				$scope.paymentResponseUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload3_name = fileName;
						angular.element("#suport_upload3_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload3_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								angular.element(".overlay").css("display","none");
								angular.element(".loading-container").css("display","none");
								console.log(data);
								$scope.paymentResponseUploadPath = data.result;
								$scope.paymentResponseUploadPathStatus = true;
							});
						}
					} else {
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						angular.element("#suport_upload3_name").addClass("error");
						$scope.paymentResponseErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					angular.element("#suport_upload3_name").addClass("error");
					$scope.paymentResponseErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.paymentResponseUploadRemove = function(){
			$scope.aa1_form1.suport_upload3 = undefined;
			$scope.aa1_form1.suport_upload3_name = undefined;
			$scope.paymentResponseUploadPath = undefined;
			angular.element("#suport_upload3_name").val("");
			angular.element("#suport_upload3").val("");
			$scope.paymentResponseUploadPathStatus = false;
		}

		$scope.intentionNoticeUpload = function(event){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.intentionNoticeErrorStatus = false;
				$scope.intentionNoticeUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload4_name = fileName;
						angular.element("#suport_upload4_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload4_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								angular.element(".overlay").css("display","none");
								angular.element(".loading-container").css("display","none");
								$scope.onlineFileUploadStatus = false;
								$("#suport_upload1_name").removeClass("error");
								$("#suport_upload2_name").removeClass("error");
								$("#suport_upload4_name").removeClass("error");
								console.log(data);
								$scope.intentionNoticeUploadPath = data.result;
								$scope.intentionNoticeUploadPathStatus = true;
							});
						}
					} else {
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						angular.element("#suport_upload4_name").addClass("error");
						$scope.intentionNoticeErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					angular.element("#suport_upload4_name").addClass("error");
					$scope.intentionNoticeErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.intentionNoticeUploadRemove = function(){
			$scope.aa1_form1.suport_upload4 = undefined;
			$scope.aa1_form1.suport_upload4_name = undefined;
			$scope.intentionNoticeUploadPath = undefined;
			angular.element("#suport_upload4_name").val("");
			angular.element("#suport_upload4").val("");
			$scope.intentionNoticeUploadPathStatus = false;
			if(!$scope.termsUploadPath && !$scope.paymentClaimUploadPath && !$scope.intentionNoticeUploadPath){
				$scope.onlineFileUploadStatus = true;
				$("#suport_upload1_name").addClass("error");
				$("#suport_upload2_name").addClass("error");
				$("#suport_upload4_name").addClass("error");
			}
		}

		$scope.otherDocUpload = function(event){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.otherDocErrorStatus = false;
				$scope.otherDocUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload5_name = fileName;
						angular.element("#suport_upload5_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload5_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								angular.element(".overlay").css("display","none");
								angular.element(".loading-container").css("display","none");
								$scope.otherDocUploadPath = data.result;
								$scope.otherDocUploadPathStatus = true;
							});
						}
					} else {
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						angular.element("#suport_upload5_name").addClass("error");
						$scope.otherDocErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					angular.element("#suport_upload5_name").addClass("error");
					$scope.otherDocErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.otherDocUploadRemove = function(){
			$scope.aa1_form1.suport_upload5 = undefined;
			$scope.aa1_form1.suport_upload5_name = undefined;
			$scope.otherDocUploadPath = undefined;
			angular.element("#suport_upload5_name").val("");
			angular.element("#suport_upload5").val("");
			$scope.otherDocUploadPathStatus = false;
		}

		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if(allowedExt[i] == ext){
					return true;
				}
			}
		}


		//Save AA1 FROM Service
		$scope.formAA1Save = function(form){

			//Validate Claimant Details are entered
			var claimentInvalid = angular.element("#msform .claimantSession .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#msform .claimantSession .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				angular.element(".overlay").css("display","block");
				angular.element(".loading-container").css("display","block");
				$scope.saveQuery = buildQurey();
				if($scope.saveQuery){
					DataService.post('SaveAAForm',$scope.saveQuery).then(function(data){
						console.log(data);
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						if(data.status == "SUCCESS"){
							$rootScope.tempCaseNumber = data.result;
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = false;
							$scope.onlineSaveStatus = true;
						}
	        		}).catch(function (error) {
	        			angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
			            NotifyFactory.log('error', error.errorMessage)
			        });
        		}
			}
		}

		$scope.backToForm = function(){
			$scope.onlineFormActiveStatus = true;
			$scope.onlineSubmitStatus = false;
			$scope.onlineSaveStatus = false;
		}

		//Form Preview
    	$scope.aa1FormPreview = function(newItem){
    		if($scope.aa1_form1.caseDto.isOnline == "Online"){
	    		if(!$scope.termsUploadPath && !$scope.paymentClaimUploadPath && !$scope.intentionNoticeUploadPath){
	    			$("#suport_upload1_name").addClass("error");
	    			$("#suport_upload2_name").addClass("error");
	    			$("#suport_upload4_name").addClass("error");
					$scope.onlineFileUploadStatus = true;
				}
			}
		   $scope.isPreviewClicked = false;
		   $scope.termsUploadPathStatus = false;
		   $scope.paymentClaimUploadPathStatus = false;
		   $scope.paymentResponseUploadPathStatus = false;
		   $scope.intentionNoticeUploadPathStatus = false;
		   $scope.otherDocUploadPathStatus = false;
		   //Validate Claimant Details are entered
			var claimentInvalid = angular.element("#msform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#msform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.isPreviewClicked = true; 
			}
		}
		$scope.aa1FormPreviewHide = function(newItem){
		   $scope.isPreviewClicked = false;
		   $scope.termsUploadPathStatus = true;
		   $scope.paymentClaimUploadPathStatus = true;
		   $scope.paymentResponseUploadPathStatus = true;
		   $scope.intentionNoticeUploadPathStatus = true;
		   $scope.otherDocUploadPathStatus = true;
		}

		$scope.confirmSubmit = function(){
			DataService.get('GetConfirmMessageAAform').then(function(data){
				$scope.displayMessage = data.result.displayMessage;
			});
			angular.element(".overlay").css("display","block");
			angular.element(".form-submitt-confirm").css("display","block");
		}

		$scope.cancelSubmit = function(){
			angular.element(".overlay").css("display","none");
			angular.element(".form-submitt-confirm").css("display","none");
		}

		$scope.formAA1Submit = function(form){
			angular.element(".form-submitt-confirm").css("display","none");
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");

			$scope.isSubmitted = true;
			//Validate Claimant Details are entered
			var claimentInvalid = angular.element("#msform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;
			var errorMsgCount = angular.element("#msform .help-block:visible").length;
			if(claimentInvalidCount > 0 || errorMsgCount > 0){
				angular.element("#msform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.submitQuery = buildQurey();
				if($scope.submitQuery){
					DataService.post('SubmitAAForm',$scope.submitQuery).then(function(data){
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						console.log(data);
						if(data.status == "SUCCESS"){
							$scope.isPreviewClicked = false;
							$rootScope.tempCaseNumber = data.result.tempCaseNumber;
							$scope.downloadUrl = smcConfig.services.DownloadAAForm.url + $rootScope.tempCaseNumber;
							$rootScope.saveResponseDetails = data.result;

							var timeOfSubmissionView = $rootScope.saveResponseDetails.timeOfSubmission;
							timeOfSubmissionView = timeOfSubmissionView.split(".");

							$scope.timeOfSubmission = timeOfSubmissionView[0];
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = true;
							$scope.onlineSaveStatus = false;
							$rootScope.callFuntion();
						} else {
							$scope.isPreviewClicked = true;
							$scope.isSubmitted = false;
							angular.element(".overlay").css("display","none");
							angular.element(".loading-container").css("display","none");
							NotifyFactory.log('error', data.errorMsg);
						}
	        		}).catch(function (error) {
	        			$scope.isPreviewClicked = true;
						$scope.isSubmitted = false;
	        			angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
			            NotifyFactory.log('error', error.errorMessage)
			        });
				}
				
			}
		}

		function buildQurey(){
			var claimantInfoQueryVar = claimantInfoQuery();
			var respondentInfoQueryVar = respondentInfoQuery();
			var regulationInfoQueryVar = regulationInfoQuery();
			var contractInfoQueryVar = contractInfoQuery();
			var paymentInfoQueryVar = paymentInfoQuery();
			if($scope.aa1_form1.caseDto.isOnline == "Online"){
				var supportingDocumentsQueryVar = supportingDocumentsQuery();
			} else {
				var supportingDocumentsQueryVar = null;
			}
			var caseDtoQueryVar = caseDtoQuery();
			var query = { 
				"tempCaseNumber":undefinedSetNull($rootScope.tempCaseNumber),
				"claimantInfo":claimantInfoQueryVar,
				"respondentInfo":respondentInfoQueryVar,
				"regulationInfo":regulationInfoQueryVar,
				"contractInfo":contractInfoQueryVar,
				"paymentInfo":paymentInfoQueryVar,
				"supportingDocuments":supportingDocumentsQueryVar,
				"caseDto": caseDtoQueryVar
			}
			return query;
		}
		function claimantInfoQuery(){
			var query = {};
			if($scope.aa1_form1.claimantInfo){
				var caseMemberRoleType = $scope.aa1_form1.claimantInfo.caseMemberRoleType;
				var applicantUidValue = $scope.aa1_form1.claimantInfo.applicantUidValue;
				var memberName = $scope.aa1_form1.claimantInfo.memberName;
				$rootScope.claimantName = $scope.aa1_form1.claimantInfo.memberName;
				var gender = $scope.aa1_form1.claimantInfo.gender;
				var email = $scope.aa1_form1.claimantInfo.email;
				var authRepresentative = $scope.aa1_form1.claimantInfo.authRepresentative;
				var authRepDesignation = $scope.aa1_form1.claimantInfo.authRepDesignation;
				var payeeName = $scope.aa1_form1.claimantInfo.payeeName;
				var isLegallyRepresented = $scope.aa1_form1.claimantInfo.isLegallyRepresented;
				var businessAddress = claimantBusinessAddressQuery();
				
				if(isLegallyRepresented == "Yes"){
					var lawFirmDto = claimantlawFirmDtoQuery();
					var serviceAddress = null; 
				} else{
					var lawFirmDto = null;
					var serviceAddress = claimantServiceAddressQuery();
				}
				var query = { 
					"caseMemberRoleType":undefinedSetNull(caseMemberRoleType),
					"applicantUidValue":undefinedSetNull(applicantUidValue),
				    "memberName":undefinedSetNull(memberName),
				    "gender":undefinedSetNull(gender),
				    "businessAddress":businessAddress,
					"serviceAddress":serviceAddress,
				    "email":undefinedSetNull(email),
				    "authRepresentative":undefinedSetNull(authRepresentative),
				    "authRepDesignation":undefinedSetNull(authRepDesignation),
				    "payeeName":undefinedSetNull(payeeName),
				    "isLegallyRepresented":undefinedSetNull(isLegallyRepresented),
				    "lawFirmDto":lawFirmDto
				};
			}
			return query;
		}
		
		function claimantBusinessAddressQuery(){
			var query = {};
			if($scope.aa1_form1.claimantInfo.businessAddress){
				var address1 = $scope.aa1_form1.claimantInfo.businessAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.businessAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.businessAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.businessAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.businessAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.businessAddress.faxNumber;
				}		

				var isLegallyRepresented = $scope.aa1_form1.claimantInfo.isLegallyRepresented;

				if($scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress;
				} else if (isLegallyRepresented == "Yes") {
					var isServiceAddress = null;
				} else {
					var isServiceAddress = false;
				}
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber),
			        "isServiceAddress":isServiceAddress
				};
			}
			return query;
		}
		function claimantServiceAddressQuery(){
			var query = null;
			var claimant_service_address_status = $scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress;
			if(!claimant_service_address_status && $scope.aa1_form1.claimantInfo.serviceAddress != undefined){
				var query = {};
				var address1 = $scope.aa1_form1.claimantInfo.serviceAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.serviceAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.serviceAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.serviceAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.serviceAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.serviceAddress.faxNumber;
				}
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber)
				};
			};
			return query;
		}
		function claimantlawFirmDtoQuery(){
			var query = {};
			if($scope.aa1_form1.claimantInfo.lawFirmDto){
				var respresentative_lawfirmId = $scope.aa1_form1.claimantInfo.lawFirmDto.id;
				respresentative_lawfirmId = respresentative_lawfirmId.id;
				var name = $scope.aa1_form1.claimantInfo.lawFirmDto.name;
				var businessAddress = claimantlawFirmBusinessAddressQuery();
				var serviceAddress = claimantlawFirmServiceAddressQuery();
				var lawyerDetails = claimantlawyersDetailsQuery();
				var referenceNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.referenceNumber;
				var query = { 
					"id":respresentative_lawfirmId,
			        "name":undefinedSetNull(name),
					"businessAddress":businessAddress,
			        "serviceAddress":serviceAddress,
			        "lawyerDetails":lawyerDetails,
					"referenceNumber":undefinedSetNull(referenceNumber)
				};
			}
			return query;
		}
		function claimantlawFirmBusinessAddressQuery(){
			var query = {};
			if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress){
				var isServiceAddress = false;
				var address1 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber;
				}
				
				if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress;
				}
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber),
			        "isServiceAddress":isServiceAddress
				};
			}
			return query;
		}
		function claimantlawFirmServiceAddressQuery(){
			var query = null;
			var claimant_lawyer_service_address_status = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress;
			if(!claimant_lawyer_service_address_status){
				var query = {};
				var address1 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber;
				}
				
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber)
				};
			}
			return query;
		}
		function claimantlawyersDetailsQuery(){
			var query = [];
			if($scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails){
				var respresentative_l2name = "";
				var respresentative_l3name = "";
				var respresentative_lname = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[0].lawyerName;
				var respresentative_lemail = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[0].email;
				if($scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[1]){
					var respresentative_l2name = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[1].lawyerName;
					var respresentative_l2email = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[1].email;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[2]){
					var respresentative_l3name = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[2].lawyerName;
					var respresentative_l3email = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[2].email;
				}
				if(respresentative_lname && respresentative_lemail){
					var lawyer1 = { 
			               "lawyerName":undefinedSetNull(respresentative_lname),
			               "email":undefinedSetNull(respresentative_lemail)
					};
					query.push(lawyer1);
				}
				if(respresentative_l2name && respresentative_l2email){
					var lawyer2 = {
						"lawyerName":undefinedSetNull(respresentative_l2name),
						"email":undefinedSetNull(respresentative_l2email)
					}
					query.push(lawyer2);
				}
				if(respresentative_l3name && respresentative_l3email){
					var lawyer3 = {
						"lawyerName":undefinedSetNull(respresentative_l3name),
						"email":undefinedSetNull(respresentative_l3email)
					}
					query.push(lawyer3);
				}
			}
			return query;
		}


		function respondentInfoQuery(){
			var query = {};
			if($scope.aa1_form1.respondentInfo){
				var caseMemberRoleType = $scope.aa1_form1.respondentInfo.caseMemberRoleType;
				var applicantUidValue = $scope.aa1_form1.respondentInfo.applicantUidValue;
				var memberName = $scope.aa1_form1.respondentInfo.memberName;
				var gender = $scope.aa1_form1.respondentInfo.gender;
				var email = $scope.aa1_form1.respondentInfo.email;
				var authRepresentative = $scope.aa1_form1.respondentInfo.authRepresentative;
				var authRepDesignation = $scope.aa1_form1.respondentInfo.authRepDesignation;
				var isLegallyRepresented = $scope.aa1_form1.respondentInfo.isLegallyRepresented;
				var businessAddress = respondentBusinessAddressQuery();
				
				
				if(isLegallyRepresented == "Yes"){ 
					var lawFirmDto = respondentlawFirmDtoQuery(); 
					var serviceAddress = null; 
				} else if(isLegallyRepresented == "No"){
					var serviceAddress = respondentServiceAddressQuery();
					var lawFirmDto = null;
				} else {var serviceAddress = null; var lawFirmDto = null;}
				var query = {
					"caseMemberRoleType":undefinedSetNull(caseMemberRoleType),
					"applicantUidValue":undefinedSetNull(applicantUidValue),
					"memberName":undefinedSetNull(memberName),
					"gender":undefinedSetNull(gender),
					"businessAddress":businessAddress,
					"serviceAddress":serviceAddress,
					"email":undefinedSetNull(email),
					"authRepresentative":undefinedSetNull(authRepresentative),
					"authRepDesignation":undefinedSetNull(authRepDesignation),
					"isLegallyRepresented":isLegallyRepresented,
					"lawFirmDto":lawFirmDto
				};
			}
			return query;
		}
		function respondentBusinessAddressQuery(){
			var query = {};
			if ($scope.aa1_form1.respondentInfo.businessAddress){
				var address1 = $scope.aa1_form1.respondentInfo.businessAddress.address1;
				var address2 = $scope.aa1_form1.respondentInfo.businessAddress.address2;
				var address3 = $scope.aa1_form1.respondentInfo.businessAddress.address3;
				var address4 = $scope.aa1_form1.respondentInfo.businessAddress.address4;
				var postalCode = $scope.aa1_form1.respondentInfo.businessAddress.postalCode;
				if($scope.aa1_form1.respondentInfo.businessAddress.phoneNumber){
					var phoneNumber =  '65'+$scope.aa1_form1.respondentInfo.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.respondentInfo.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.businessAddress.faxNumber;
				}
				var isServiceAddress = $scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress;
				if($scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress;
				} else {
					var isServiceAddress = false;
				}
				var query = {
					"address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
					"postalCode":undefinedSetNull(postalCode),
					"phoneNumber":undefinedSetNull(phoneNumber),
					"faxNumber":undefinedSetNull(faxNumber),
					"isServiceAddress":isServiceAddress
				};
			}
			return query;
		}
		function respondentServiceAddressQuery(){
			var query = null;
			if($scope.aa1_form1.respondentInfo.businessAddress){
				var isServiceAddress = $scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress;
				var isLegallyRepresented = $scope.aa1_form1.respondentInfo.isLegallyRepresented;
				if(!isServiceAddress && isLegallyRepresented == "No" && $scope.aa1_form1.respondentInfo.serviceAddress != undefined){
					var query = {};
					var address1 = $scope.aa1_form1.respondentInfo.serviceAddress.address1;
					var address2 = $scope.aa1_form1.respondentInfo.serviceAddress.address2;
					var address3 = $scope.aa1_form1.respondentInfo.serviceAddress.address3;
					var address4 = $scope.aa1_form1.respondentInfo.serviceAddress.address4;
					var postalCode = $scope.aa1_form1.respondentInfo.serviceAddress.postalCode;
					if($scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber){
						var phoneNumber = '65'+$scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber;
					}
					if($scope.aa1_form1.respondentInfo.serviceAddress.faxNumber){
						var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.serviceAddress.faxNumber;
					}
					
					var query = {
						"address1":undefinedSetNull(address1),
						"address2":undefinedSetNull(address2),
						"address3":undefinedSetNull(address3),
						"address4":undefinedSetNull(address4),
						"postalCode":undefinedSetNull(postalCode),
						"phoneNumber":undefinedSetNull(phoneNumber),
						"faxNumber":undefinedSetNull(faxNumber)
					};
				}
			}
			return query;
		}
		function respondentlawFirmDtoQuery(){
			var query = {};
			if($scope.aa1_form1.respondentInfo.lawFirmDto){
				if($scope.aa1_form1.respondentInfo.lawFirmDto.id){
					var lawerAddressId = $scope.aa1_form1.respondentInfo.lawFirmDto.id;
					lawerAddressId = lawerAddressId.id;
				} else {
					var lawerAddressId = undefined;
				}
				var name = $scope.aa1_form1.respondentInfo.lawFirmDto.name;
				var businessAddress = respondentlawFirmBusinessAddressQuery();
				var serviceAddress = respondentlawFirmServiceAddressQuery();
				var lawyerDetails = respondentlawyersDetailsQuery();
				var referenceNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.referenceNumber;
				var query = {
					"id":lawerAddressId,
					"name":undefinedSetNull(name),
					"businessAddress":businessAddress,
			        "serviceAddress":serviceAddress,
					"lawyerDetails":lawyerDetails,
					"referenceNumber":undefinedSetNull(referenceNumber)
				};
			}
			return query;
		}
		function respondentlawFirmBusinessAddressQuery(){
			if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress){
				var address1 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1;
				var address2 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2;
				var address3 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3;
				var address4 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4;
				var postalCode = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber;
				}
				
				var isServiceAddress = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
				} else {
					var isServiceAddress = false;
				}
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber),
			        "isServiceAddress":isServiceAddress
				};
			}
			return query;
		}
		function respondentlawFirmServiceAddressQuery(){
			var query = null;
			var isServiceAddress = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
			if(!isServiceAddress && $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress != undefined){
				var query = {};
				var address1 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address1;
				var address2 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address2;
				var address3 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address3;
				var address4 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address4;
				var postalCode = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.postalCode;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber;
				}
				
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber)
				};
			}
			return query;
		}

		function respondentlawyersDetailsQuery(){
			var query = [];
			if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails){
				var respondent_lname = "";
				var respondent_l2name = "";
				var respondent_l3name = "";
				if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[0]){
					var respondent_lname = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[0].lawyerName;
					var respondent_lemail = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[0].email;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[1]){
					var respondent_l2name = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[1].lawyerName;
					var respondent_l2email = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[1].email;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[2]){
					var respondent_l3name = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[2].lawyerName;
					var respondent_l3email = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[2].email;
				}
				if(respondent_lname && respondent_lemail){
					var lawyer1 = {
						"lawyerName":undefinedSetNull(respondent_lname),
						"email":undefinedSetNull(respondent_lemail)
					};
					query.push(lawyer1);
				}
				if(respondent_l2name && respondent_l2email){
					var lawyer2 = {
						"lawyerName":undefinedSetNull(respondent_l2name),
						"email":undefinedSetNull(respondent_l2email)
					}
					query.push(lawyer2);
				}
				if(respondent_l3name && respondent_l3email){
					var lawyer3 = {
						"lawyerName":undefinedSetNull(respondent_l3name),
						"email":undefinedSetNull(respondent_l3email)
					}
					query.push(lawyer3);
				}
			}
			return query;
		}


		function regulationInfoQuery(){
			var query = {};
			if($scope.aa1_form1.regulationInfo){
				var principalName = $scope.aa1_form1.regulationInfo.principalName;
				var principalContactPerson = $scope.aa1_form1.regulationInfo.principalContactPerson;
				var principalRefNumber = $scope.aa1_form1.regulationInfo.principalRefNumber;
				var principalAddress = principleServiceAddressQuery();
				var principalEmail = $scope.aa1_form1.regulationInfo.principalEmail;
				var ownerName = $scope.aa1_form1.regulationInfo.ownerName;
				var ownerContactPerson = $scope.aa1_form1.regulationInfo.ownerContactPerson;
				var ownerRefNumber = $scope.aa1_form1.regulationInfo.ownerRefNumber;
				var ownerAddress = ownerServiceAddressQuery();
				var ownerEmail = $scope.aa1_form1.regulationInfo.ownerEmail;
				var query = {
					"principalName":undefinedSetNull(principalName),
					"principalAddress":principalAddress,
					"principalContactPerson":undefinedSetNull(principalContactPerson),
					"principalRefNumber":undefinedSetNull(principalRefNumber),
					"principalEmail":undefinedSetNull(principalEmail),
					"ownerName":undefinedSetNull(ownerName),
					"ownerAddress":ownerAddress,
					"ownerContactPerson":undefinedSetNull(ownerContactPerson),
					"ownerRefNumber":undefinedSetNull(ownerRefNumber),
					"ownerEmail":undefinedSetNull(ownerEmail),
				};
			}
			return query;
		}
		function principleServiceAddressQuery(){
			var query = null;
			if($scope.aa1_form1.regulationInfo.principalAddress){
				var address1 = $scope.aa1_form1.regulationInfo.principalAddress.address1;
				var postalCode = $scope.aa1_form1.regulationInfo.principalAddress.postalCode;
				if($scope.aa1_form1.regulationInfo.principalAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.regulationInfo.principalAddress.phoneNumber;
				}
				if($scope.aa1_form1.regulationInfo.principalAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.regulationInfo.principalAddress.faxNumber;
				}
				
				var query = {
					"address1":undefinedSetNull(address1),
					"address2":"",
					"address3":"",
					"address4":"",
					"postalCode":undefinedSetNull(postalCode),
					"phoneNumber":undefinedSetNull(phoneNumber),
					"faxNumber":undefinedSetNull(faxNumber)
				};
			}
			return query;
		}
		function ownerServiceAddressQuery(){
			var query = null;
			if($scope.aa1_form1.regulationInfo.ownerAddress){
				var address1 = $scope.aa1_form1.regulationInfo.ownerAddress.address1;
				var postalCode = $scope.aa1_form1.regulationInfo.ownerAddress.postalCode;
				if($scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber;
				}
				if($scope.aa1_form1.regulationInfo.ownerAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.regulationInfo.ownerAddress.faxNumber;
				}
				
				var query = {
					"address1":undefinedSetNull(address1),
					"address2":"",
					"address3":"",
					"address4":"",
					"postalCode":undefinedSetNull(postalCode),
					"phoneNumber":undefinedSetNull(phoneNumber),
					"faxNumber":undefinedSetNull(faxNumber)
				};
			}
			return query;
		}

		function contractInfoQuery(){
			var query = {};
			if($scope.aa1_form1.contractInfo){
				var projectReference = $scope.aa1_form1.contractInfo.projectReference;
				var contractNumber = $scope.aa1_form1.contractInfo.contractNumber;
				if($scope.aa1_form1.contractInfo.contractType && $scope.aa1_form1.contractInfo.contractType != "null"){
					var contractType = JSON.parse($scope.aa1_form1.contractInfo.contractType);
					contractType = contractType.id;
				} else {
					var contractType = undefined;
				}
				
				var natureOfDispute = $scope.aa1_form1.contractInfo.natureOfDispute;
				var contractMadeOn = $scope.aa1_form1.contractInfo.contractMadeOn;
				var mainContractMadeOn = $scope.aa1_form1.contractInfo.mainContractMadeOn;
				var query = {
					"projectReference":undefinedSetNull(projectReference),
					"contractNumber":undefinedSetNull(contractNumber),
					"contractType":undefinedSetNull(contractType),
					"natureOfDispute":undefinedSetNull(natureOfDispute),
					"contractMadeOn":undefinedSetNull(contractMadeOn),
					"mainContractMadeOn":undefinedSetNull(mainContractMadeOn)
				};
			}
			return query;
		}
		function paymentInfoQuery(){
			var query = {}
			if($scope.aa1_form1.paymentInfo){
				var latePaymentInterest = false;
				var claimRefNumber = $scope.aa1_form1.paymentInfo.claimRefNumber;
				var referencePeriodFrom = $scope.aa1_form1.paymentInfo.referencePeriodFrom;
				var referencePeriodTo = $scope.aa1_form1.paymentInfo.referencePeriodTo;
				var paymentClaimedDate = $scope.aa1_form1.paymentInfo.paymentClaimedDate;
				var claimAmount = $scope.aa1_form1.paymentInfo.claimAmount;
				var latePaymentInterestOrg = $scope.aa1_form1.paymentInfo.latePaymentInterest;
				if(latePaymentInterestOrg ==  "yes"){latePaymentInterest = true;}
				if(latePaymentInterestOrg ==  "no"){latePaymentInterest = false;}
				var latePaymentInterestRate = $scope.aa1_form1.paymentInfo.latePaymentInterestRate;
				var referenceResponseNumber = $scope.aa1_form1.paymentInfo.referenceResponseNumber;
				var responseDueDate = $scope.aa1_form1.paymentInfo.responseDueDate;
				var paymentClaimClaimant = $scope.aa1_form1.paymentInfo.paymentClaimClaimant;
				var responseAmount = $scope.aa1_form1.paymentInfo.responseAmount;
				var paymentDueDate = $scope.aa1_form1.paymentInfo.paymentDueDate;
				var respondentPaymentDate = $scope.aa1_form1.paymentInfo.respondentPaymentDate;
				var paymentByRespondent = $scope.aa1_form1.paymentInfo.paymentByRespondent;
				var query = {
					"claimRefNumber":undefinedSetNull(claimRefNumber),
					"referencePeriodFrom":undefinedSetNull(referencePeriodFrom),
					"referencePeriodTo":undefinedSetNull(referencePeriodTo),
					"paymentClaimedDate":undefinedSetNull(paymentClaimedDate),
					"claimAmount":undefinedSetNull(claimAmount),
					"latePaymentInterest":latePaymentInterest,
					"latePaymentInterestRate":undefinedSetNull(latePaymentInterestRate),
					"referenceResponseNumber":undefinedSetNull(referenceResponseNumber),
					"responseDueDate":undefinedSetNull(responseDueDate),
					"paymentClaimClaimant":undefinedSetNull(paymentClaimClaimant),
					"responseAmount":undefinedSetNull(responseAmount),
					"paymentDueDate":undefinedSetNull(paymentDueDate),
					"respondentPaymentDate":undefinedSetNull(respondentPaymentDate),
					"paymentByRespondent":undefinedSetNull(paymentByRespondent)
				};
			}
			return query;
		}
		function supportingDocumentsQuery(){
			var query = [];
			var termsFilePath = $scope.termsUploadPath;
			var paymentClaimFilePath = $scope.paymentClaimUploadPath;
			var paymentResponseFilePath = $scope.paymentResponseUploadPath;
			var intentionNoticeFilePath = $scope.intentionNoticeUploadPath;
			var otherFilePath = $scope.otherDocUploadPath;
			if(termsFilePath){
				var filepath1 = {
					"name":"Relevant Contractual Terms and Conditions",
					"fileLocation":termsFilePath
				}
				query.push(filepath1);
			}
			if(paymentClaimFilePath){
				var filepath2 = {
					"name":"Payment Claim",
					"fileLocation":paymentClaimFilePath
				}
				query.push(filepath2);
			}
			if(paymentResponseFilePath){
				var filepath3 = {
					"name":"Payment Response Received",
					"fileLocation":paymentResponseFilePath
				}
				query.push(filepath3);
			}
			if(intentionNoticeFilePath){
				var filepath4 = {
					"name":"Notice of Intention to Apply for Adjudication",
					"fileLocation":intentionNoticeFilePath
				}
				query.push(filepath4);
			}
			if(otherFilePath){
				var filepath5 = {
					"name":"Other Relevant Document(s)",
					"documentDescription":$scope.aa1_form1.suport_upload5_ref_name,
					"fileLocation":otherFilePath
				}
				query.push(filepath5);
			}
			return query;
		}
		function caseDtoQuery(){
			var query = {};
			if($scope.aa1_form1.caseDto){
				var claimAmount = $scope.aa1_form1.caseDto.claimAmount;
				if($scope.aa1_form1.caseDto.includeGst == "Yes"){
					var includeGst = true;
				} else if($scope.aa1_form1.caseDto.includeGst == "No") {
					var includeGst = false;
				}
				var authPerson = $scope.aa1_form1.caseDto.authPerson;
				var authPersonRef = $scope.aa1_form1.caseDto.authPersonRef;
				var query = {
					"claimAmount":undefinedSetNull(claimAmount),
					"includeGst":includeGst,
					"isOnline":$scope.onlineFormSubmissionStatus,
					"authPerson":undefinedSetNull(authPerson),
					"authPersonRef":undefinedSetNull(authPersonRef)
				};
			}
			return query;
		}
		if($rootScope.caseNumber){
			var caseNo = $rootScope.caseNumber;
			$rootScope.pdfCaseNumber = caseNo;
		} else if($cookies.get('caseNumber')){
			var caseNo = $cookies.get('caseNumber');
			$rootScope.pdfCaseNumber = caseNo;
		}

		//Generate Download URL
		var generateDownloadUrl = smcConfig.services.DownloadAAForm.url;
		$rootScope.downloadUrl = generateDownloadUrl + "/" + $rootScope.pdfCaseNumber;
		
		$scope.openPrintPdf = function(){
			angular.element(".downloadLink").html(" ");
			var generatePdfUrl = smcConfig.services.DownloadAAForm.url;
            generatePdfUrl = generatePdfUrl + "/" + $rootScope.pdfCaseNumber;
			// Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="AAform.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element(".overlay").css("display","block");
				angular.element("#aa_pdf_view").css("display","block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
                    angular.element(".overlay").css("display","block");
				angular.element("#aa_pdf_view").css("display","block");
                }
            });
		}
		$scope.closePrintPdf = function(formId){
			angular.element(".overlay").css("display","none");
			angular.element("#"+formId).css("display","none");
		}

		$scope.openAuditTrialPopup=function(){
			angular.element('.audit-trial-modal').css("display","block");
			angular.element(".overlay").css("display","block");
			var query = {
						"caseNumber":$cookies.get('caseNumber'),
						"formName":"AAForm"				
						};
			DataService.post('AuditTrialData', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                	$scope.shownodataavailable=false;
                    $scope.auditTrialData=data.result.responseData;
                }
            }).catch(function (error) {
                $scope.shownodataavailable=true;
                NotifyFactory.log('error', error.errorMessage);
            });
		}
		
		$scope.closeAuditTrial=function () {
			angular.element('.audit-trial-modal').css("display","none");
			angular.element(".overlay").css("display","none");
		}

		function undefinedSetNull(val){
			if(val){
				return val;
			} else {
				var val = null;
				return val;
			}
			return val;
		}
		$scope.proceedToPayment = function(){
			/*if(animating) return false;
			animating = true;*/

			current_fs = $(".aa1-form-wizard1");
			next_fs = $(".aa1-form-wizard2");

			$rootScope.nextWisard(next_fs,current_fs);
		}

		$rootScope.nextWisard = function(next_fs,current_fs){
			//activate next step on progressbar using the index of next_fs
			$(".processbar-controller li").eq($("fieldset").index(current_fs)).removeClass("current").removeClass("error").addClass("active");
			$(".processbar-controller li").eq($("fieldset").index(next_fs)).addClass("current");
			
			//show the next fieldset
			next_fs.show(); 
			//hide the current fieldset with style
			current_fs.hide();
			current_fs.animate({opacity: 0}, {
				step: function(now, mx) {
					//as the opacity of current_fs reduces to 0 - stored in "now"
					//1. scale current_fs down to 80%
					scale = 1 - (1 - now) * 0.2;
					//2. bring next_fs from the right(50%)
					left = (now * 50)+"%";
					//3. increase opacity of next_fs to 1 as it moves in
					opacity = 1 - now;
					current_fs.css({'transform': 'scale('+scale+')'});
					next_fs.css({'left': left, 'opacity': opacity});
				}, 
				duration: 800, 
				complete: function(){
					current_fs.hide();
					animating = false;
				}, 
				//this comes from the custom easing plugin
				easing: 'easeInOutBack'
			});
		}
		$rootScope.previousWisard = function (current_fs,previous_fs){
			current_fs = $("."+current_fs);
			previous_fs = $("."+previous_fs);
			//de-activate current step on progressbar
			$(".processbar-controller li").eq($("fieldset").index(current_fs)).removeClass("current").removeClass("error");
			
			//show the previous fieldset
			previous_fs.show(); 
			//hide the current fieldset with style
			current_fs.hide();
			current_fs.animate({opacity: 0}, {
				step: function(now, mx) {
					//as the opacity of current_fs reduces to 0 - stored in "now"
					//1. scale previous_fs from 80% to 100%
					scale = 0.8 + (1 - now) * 0.2;
					//2. take current_fs to the right(50%) - from 0%
					left = ((1-now) * 50)+"%";
					//3. increase opacity of previous_fs to 1 as it moves in
					opacity = 1 - now;
					current_fs.css({'left': left});
					previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
				}, 
				duration: 800, 
				complete: function(){
					current_fs.hide();
				}, 
				//this comes from the custom easing plugin
				easing: 'easeInOutBack'
			});
		}
		
		function getValueById(obj, key, val){
            var objects = [];
            for (var i in obj) {
                if (!obj.hasOwnProperty(i)) continue;
                if (typeof obj[i] == 'object') {
                    objects = objects.concat(getValueById(obj[i], key, val));
                } else if (i == key && obj[key] == val) {
                    objects.push(obj);
                }
            }
            return objects;
        }
        $scope.hoverIn=function(){
        	
        	angular.element(".contract-type-tooltipContent").css("display","block");
        }
         $scope.hoverOut=function(){
        	
        	angular.element(".contract-type-tooltipContent").css("display","none");
        }
 	}
 })();