(function() {
    'use strict';
    angular
        .module('smc')
        .controller('aa1formCtrl',aa1formCtrl);

    aa1formCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig'];

    function aa1formCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig){
    	var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches

    	//Error Messages
		$scope.pattern = patternConfig;

		//Default Values settings
    	$scope.isPreviewClicked = false;
    	$scope.claiamentStatus = false;
    	$scope.claiamentServiceAddressStatus = true;
    	$scope.claiamentLawFormDetailStatus = true;
    	$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
    	$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
    	$scope.uenOrnric = "Enter the organisation’s UEN";
    	$scope.respondentIndivStatus = false;
		$scope.registeredRespondentName = "Enter the respondent’s registered name";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
		$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.interestRateOfLatePaymentStatus = false;
		$scope.onlineFormSubmissionStatus = true;
		$scope.claimentLegallyRepresentStatus = false;
		$scope.respondentLegallyRepresentStatus = true;
		$scope.claiamentLawyerServiceAddressStatus = true;
		$scope.aa1_form1 = {};
		$scope.aa1_form1.claimant = "Organisation";
		$scope.aa1_form1.respondent_type = "Organisation";
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.claimantLawFirmStatus = true;
		$scope.respondantLawFirmStatus = true;
		$scope.aa1_form1.claimant_service_address_status = false;
		$scope.aa1_form1.claimant_clegal = "Yes";
		$scope.aa1_form1.respresentative_legrepresn = "No";
		$scope.aa1_form1.repondent_service_address_status = false;
		$scope.aa1_form1.repondent_lawyer_service_address_status = false;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.termsUploadPathStatus = false;
		$scope.paymentClaimUploadPathStatus = false;
		$scope.paymentResponseUploadPathStatus = false;
		$scope.intentionNoticeUploadPathStatus = false;
		$scope.otherDocUploadPathStatus = false;
		$scope.termsErrorStatus = false;
		$scope.paymentClaimErrorStatus = false;
		$scope.paymentResponseErrorStatus = false;
		$scope.intentionNoticeErrorStatus = false;
		$scope.otherDocErrorStatus = false;
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.isSubmitted = false;

		$rootScope.tempCaseNumber = null;

		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
			} else {
				$scope.lawFirmList = [];
			}
        });

        //Get Contract Type List Service
        DataService.get('GetContractTypeList').then(function(data){
			$scope.contractTyoeList = data.results;
        });

        //Get Dispute Nature List Service
        DataService.get('GetDisputeNatureList').then(function(data){
			$scope.disputeNatureList = data.results;
        });

        //Get Mode of Document Submission type
        DataService.get('ModeOfDocumentSubmission').then(function(data){
			$scope.documentSubmissionType = data;
			$scope.submitdoctype = data.result.value;
			$scope.aa1_form1.suport_submitdoc = data.result.value;
			$scope.onlineFormSubmissionClick();
        });

        //Claimant Click Actions
		$scope.cliamentTypeClick = function(){
			$scope.aa1_form1.claimat_name = undefined;
			$scope.aa1_form1.claimant_uen = undefined;
			$scope.aa1_form1.claimant_gender = undefined;
			if($scope.aa1_form1.claimant == "Individual"){
				$scope.claiamentStatus = true;
				$scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
				$scope.uenOrnricLabel = "NRIC/Passport Number";
				$scope.uenOrnric = "Enter your NRIC / Passport No.";
			} else {
				$scope.claiamentStatus = false;
				$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
				$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnric = "Enter the organisation’s UEN";
			}
		}
		$scope.cliamentServiceAddressClick = function(){

			if($scope.aa1_form1.claimant_service_address_status == false){
				$scope.claiamentServiceAddressStatus = true;
			} else {
				$scope.claiamentServiceAddressStatus = false;
			}
		}
		$scope.cliamentLegallyRepresentedClick = function(){

			if($scope.aa1_form1.claimant_clegal == "Yes"){
				$scope.claiamentLawFormDetailStatus = true;
				$scope.claimentLegallyRepresentStatus = false;
			} else {
				$scope.claiamentLawFormDetailStatus = false;
				$scope.claimentLegallyRepresentStatus = true;
			}
		}
		$scope.cliamentLawyerServiceAddressClick = function(){

			if($scope.aa1_form1.claimant_lawyer_service_address_status == false){
				$scope.claiamentLawyerServiceAddressStatus = true;
			} else {
				$scope.claiamentLawyerServiceAddressStatus = false;
			}
		}

		//Claimant Load Law firm details on selecting law firm and reset
		$scope.loadClaimantLawFirmDetails = function(data){
			console.log(data);
			if(data){
				if(data.name == "Others"){
					$scope.aa1_form1.respresentative_lawdetail = undefined;
					$scope.aa1_form1.respresentative_addresslfirm = undefined;
					$scope.aa1_form1.respresentative_addresslfirm2 = undefined;
					$scope.aa1_form1.respresentative_addresslfirm3 = undefined;
					$scope.aa1_form1.respresentative_addresslfirm4 = undefined;
					$scope.aa1_form1.respresentative_lpc = undefined;
					$scope.aa1_form1.respresentative_ltelnum = undefined;
					$scope.aa1_form1.respresentative_lfaxnum = undefined;
					$scope.claimantLawFirmStatus = false;
				} else {
					$scope.claimantLawFirmStatus = true;
					$scope.aa1_form1.respresentative_lawdetail = data.name;
					$scope.aa1_form1.respresentative_addresslfirm = data.businessAddress.address1;
					$scope.aa1_form1.respresentative_addresslfirm2 = data.businessAddress.address2;
					$scope.aa1_form1.respresentative_addresslfirm3 = data.businessAddress.address3;
					$scope.aa1_form1.respresentative_addresslfirm4 = data.businessAddress.address4;
					$scope.aa1_form1.respresentative_lpc = data.businessAddress.postalCode;
					$scope.aa1_form1.respresentative_ltelnum = data.businessAddress.phoneNumber;
					$scope.aa1_form1.respresentative_lfaxnum = data.businessAddress.faxNumber;
				}
			} else {
				$scope.claimantLawFirmStatus = true;
				$scope.aa1_form1.respresentative_lawdetail = undefined;
				$scope.aa1_form1.respresentative_addresslfirm = undefined;
				$scope.aa1_form1.respresentative_addresslfirm2 = undefined;
				$scope.aa1_form1.respresentative_addresslfirm3 = undefined;
				$scope.aa1_form1.respresentative_addresslfirm4 = undefined;
				$scope.aa1_form1.respresentative_lpc = undefined;
				$scope.aa1_form1.respresentative_ltelnum = undefined;
				$scope.aa1_form1.respresentative_lfaxnum = undefined;
			}
		}



		//Respondent Click Actions
		$scope.respondentTypeClick = function(){
			$scope.aa1_form1.repondent_name = undefined;
			$scope.aa1_form1.repondent_passno = undefined;
			$scope.aa1_form1.repondent_gender = undefined;
			if($scope.aa1_form1.respondent_type == "Individual"){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			} else {
				$scope.respondentIndivStatus = false;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
			}
		}

		$scope.respondentServiceAddressClick = function(){

			if($scope.aa1_form1.repondent_service_address_status == false){
				$scope.respondentServiceAddressStatus = true;
			} else {
				$scope.respondentServiceAddressStatus = false;
			}
		}

		$scope.respondentLegallyRepresentedClick = function(){

			if($scope.aa1_form1.respresentative_legrepresn == "Yes"){
				$scope.respondentLawFormDetailStatus = true;
				$scope.respondentLegallyRepresentStatus = false;
			} else if ($scope.aa1_form1.respresentative_legrepresn == "No"){
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = true;
			} else {
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = false;
			}
		}

		$scope.respondentLawyerServiceAddressClick = function(){

			if($scope.aa1_form1.repondent_lawyer_service_address_status == false){
				$scope.respondentLawyerServiceAddressStatus = true;
			} else {
				$scope.respondentLawyerServiceAddressStatus = false;
			}
		}

		//Respondent Load Law firm details on selecting law firm and reset
		$scope.loadRespondantLawFirmDetails = function(data){
			console.log(data);
			if(data){
				if(data.name == "Others"){
					$scope.aa1_form1.respondant_lawdetail = undefined;
					$scope.aa1_form1.respondant_addresslfirm = undefined;
					$scope.aa1_form1.respondant_addresslfirm2 = undefined;
					$scope.aa1_form1.respondant_addresslfirm3 = undefined;
					$scope.aa1_form1.respondant_addresslfirm4 = undefined;
					$scope.aa1_form1.respondent_lpc = undefined;
					$scope.aa1_form1.respondent_ltelnum = undefined;
					$scope.aa1_form1.respondent_lfaxnum = undefined;
					$scope.respondantLawFirmStatus = false;
				} else {
					$scope.aa1_form1.respondant_lawdetail = data.name;
					$scope.aa1_form1.respondant_addresslfirm = data.businessAddress.address1;
					$scope.aa1_form1.respondant_addresslfirm2 = data.businessAddress.address2;
					$scope.aa1_form1.respondant_addresslfirm3 = data.businessAddress.address3;
					$scope.aa1_form1.respondant_addresslfirm4 = data.businessAddress.address4;
					$scope.aa1_form1.respondent_lpc = data.businessAddress.postalCode;
					$scope.aa1_form1.respondent_ltelnum = data.businessAddress.phoneNumber;
					$scope.aa1_form1.respondent_lfaxnum = data.businessAddress.faxNumber;
					$scope.respondantLawFirmStatus = true;
				}
			} else {
				$scope.aa1_form1.respondant_lawdetail = undefined;
				$scope.aa1_form1.respondant_addresslfirm = undefined;
				$scope.aa1_form1.respondant_addresslfirm2 = undefined;
				$scope.aa1_form1.respondant_addresslfirm3 = undefined;
				$scope.aa1_form1.respondant_addresslfirm4 = undefined;
				$scope.aa1_form1.respondent_lpc = undefined;
				$scope.aa1_form1.respondent_ltelnum = undefined;
				$scope.aa1_form1.respondent_lfaxnum = undefined;
				$scope.respondantLawFirmStatus = true;
			}
		}



		$scope.contractTypeClick = function(){
			var contactTypes = JSON.parse($scope.aa1_form1.regulation_rconttype);
			if(contactTypes.type == "Construction"){
				$scope.natureOfDistributeStatus = true;
			} else {
				$scope.aa1_form1.regulation_natdisp = undefined;
				$scope.natureOfDistributeStatus = false;
			}
		}
		$scope.interestRateOfLatePaymentClick = function(){

			if($scope.aa1_form1.payment_lateint == "yes"){
				$scope.interestRateOfLatePaymentStatus = true;
			} else {
				$scope.interestRateOfLatePaymentStatus = false;
			}
		}

		$scope.onlineFormSubmissionClick = function(){
			if($scope.aa1_form1.suport_submitdoc == "Online"){
				$scope.onlineFormSubmissionStatus = true;
			} else {
				$scope.onlineFormSubmissionStatus = false;
			}
		}


		/*Document Uploads*/

		$scope.termsUpload = function(event){

			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.termsUploadPathStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload1_name = fileName;
						angular.element("#suport_upload1_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload1_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.termsUploadPath = data.result;
								$scope.termsUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload1_name").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.termsUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload1_name").addClass("error");
					$scope.termsErrorStatus = true;
					$scope.termsUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.termsUploadRemove = function(){
			$scope.aa1_form1.suport_upload1 = undefined;
			$scope.aa1_form1.suport_upload1_name = undefined;
			$scope.termsUploadPath = undefined;
			angular.element("#suport_upload1_name").val("");
			angular.element("#suport_upload1").val("");
			$scope.termsUploadPathStatus = false;
		}

		$scope.paymentClaimUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.paymentClaimErrorStatus = false;
				$scope.paymentClaimUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload2_name = fileName;
						angular.element("#suport_upload2_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload2_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.paymentClaimUploadPath = data.result;
								$scope.paymentClaimUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload2_name").addClass("error");
						$scope.paymentClaimErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.paymentClaimUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload2_name").addClass("error");
					$scope.paymentClaimErrorStatus = true;
					$scope.paymentClaimUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.paymentClaimUploadRemove = function(){
			$scope.aa1_form1.suport_upload2 = undefined;
			$scope.aa1_form1.suport_upload2_name = undefined;
			$scope.paymentClaimUploadPath = undefined;
			angular.element("#suport_upload2_name").val("");
			angular.element("#suport_upload2").val("");
			$scope.paymentClaimUploadPathStatus = false;
		}

		$scope.paymentResponseUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.paymentResponseErrorStatus = false;
				$scope.paymentResponseUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload3_name = fileName;
						angular.element("#suport_upload3_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload3_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.paymentResponseUploadPath = data.result;
								$scope.paymentResponseUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload3_name").addClass("error");
						$scope.paymentResponseErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.paymentResponseUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload3_name").addClass("error");
					$scope.paymentResponseErrorStatus = true;
					$scope.paymentResponseUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.paymentResponseUploadRemove = function(){
			$scope.aa1_form1.suport_upload3 = undefined;
			$scope.aa1_form1.suport_upload3_name = undefined;
			$scope.paymentResponseUploadPath = undefined;
			angular.element("#suport_upload3_name").val("");
			angular.element("#suport_upload3").val("");
			$scope.paymentResponseUploadPathStatus = false;
		}

		$scope.intentionNoticeUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.intentionNoticeErrorStatus = false;
				$scope.intentionNoticeUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload4_name = fileName;
						angular.element("#suport_upload4_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload4_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.intentionNoticeUploadPath = data.result;
								$scope.intentionNoticeUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload4_name").addClass("error");
						$scope.intentionNoticeErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.intentionNoticeUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload4_name").addClass("error");
					$scope.intentionNoticeErrorStatus = true;
					$scope.intentionNoticeUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.intentionNoticeUploadRemove = function(){
			$scope.aa1_form1.suport_upload4 = undefined;
			$scope.aa1_form1.suport_upload4_name = undefined;
			$scope.intentionNoticeUploadPath = undefined;
			angular.element("#suport_upload4_name").val("");
			angular.element("#suport_upload4").val("");
			$scope.intentionNoticeUploadPathStatus = false;
		}

		$scope.otherDocUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.otherDocErrorStatus = false;
				$scope.otherDocUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload5_name = fileName;
						angular.element("#suport_upload5_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload5_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.otherDocUploadPath = data.result;
								$scope.otherDocUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload5_name").addClass("error");
						$scope.otherDocErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.otherDocUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload5_name").addClass("error");
					$scope.otherDocErrorStatus = true;
					$scope.otherDocUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.otherDocUploadRemove = function(){
			$scope.aa1_form1.suport_upload5 = undefined;
			$scope.aa1_form1.suport_upload5_name = undefined;
			$scope.otherDocUploadPath = undefined;
			angular.element("#suport_upload5_name").val("");
			angular.element("#suport_upload5").val("");
			$scope.otherDocUploadPathStatus = false;
		}

		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if(allowedExt[i] == ext){
					return true;
				}
			}
		}


		//Save AA1 FROM Service
		$scope.formAA1Save = function(form){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			//Validate Claimant Details are entered
			var claimentInvalid = angular.element("#msform .claimantSession .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#msform .claimantSession .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.saveQuery = buildQurey();
				if($scope.saveQuery){
					DataService.post('SaveAAForm',$scope.saveQuery).then(function(data){
						console.log(data);
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						if(data.status == "SUCCESS"){
							$rootScope.tempCaseNumber = data.result;
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = false;
							$scope.onlineSaveStatus = true;
						}
	        		});
        		}
			}

			//angular.element("#msform .ng-invalid").addClass("error");
		}

		$scope.backToForm = function(){
			$scope.onlineFormActiveStatus = true;
			$scope.onlineSubmitStatus = false;
			$scope.onlineSaveStatus = false;
		}

		//Form Preview
    	$scope.aa1FormPreview = function(newItem){
		   $scope.isPreviewClicked = false;
		   //Validate Claimant Details are entered
			var claimentInvalid = angular.element("#msform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#msform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.isPreviewClicked = true; 
			}
		}
		$scope.aa1FormPreviewHide = function(newItem){
		   $scope.isPreviewClicked = false;
		}

		$scope.confirmSubmit = function(){
			angular.element(".overlay").css("display","block");
			angular.element(".form-submitt-confirm").css("display","block");
		}

		$scope.cancelSubmit = function(){
			angular.element(".overlay").css("display","none");
			angular.element(".form-submitt-confirm").css("display","none");
		}

		$scope.formAA1Submit = function(form){
			angular.element(".form-submitt-confirm").css("display","none");
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");

			$scope.isSubmitted = true;
			//Validate Claimant Details are entered
			var claimentInvalid = angular.element("#msform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#msform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.submitQuery = buildQurey();
				if($scope.submitQuery){
					DataService.post('SubmitAAForm',$scope.submitQuery).then(function(data){
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						console.log(data);
						if(data.status == "SUCCESS"){
							$scope.isPreviewClicked = false;
							$rootScope.tempCaseNumber = data.result.tempCaseNumber;
							$rootScope.saveResponseDetails = data.result;
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = true;
							$scope.onlineSaveStatus = false;
							$rootScope.getDeposit();
						}
	        		});
				}
				
			}
		}

		function buildQurey(){
			var claimantInfoQueryVar = claimantInfoQuery();
			var respondentInfoQueryVar = respondentInfoQuery();
			var regulationInfoQueryVar = regulationInfoQuery();
			var contractInfoQueryVar = contractInfoQuery();
			var paymentInfoQueryVar = paymentInfoQuery();
			var supportingDocumentsQueryVar = supportingDocumentsQuery();
			var caseDtoQueryVar = caseDtoQuery();
			var query = { 
				"tempCaseNumber":undefinedSetNull($rootScope.tempCaseNumber),
				"claimantInfo":claimantInfoQueryVar,
				"respondentInfo":respondentInfoQueryVar,
				"regulationInfo":regulationInfoQueryVar,
				"contractInfo":contractInfoQueryVar,
				"paymentInfo":paymentInfoQueryVar,
				"supportingDocuments":supportingDocumentsQueryVar,
				"caseDto": caseDtoQueryVar
			}
			return query;
		}
		function claimantInfoQuery(){
			var claimant = $scope.aa1_form1.claimant;
			var claimant_uen = $scope.aa1_form1.claimant_uen;
			var claimat_name = $scope.aa1_form1.claimat_name;
			$rootScope.claimantName = $scope.aa1_form1.claimat_name;
			var claimant_gender = $scope.aa1_form1.claimant_gender;
			var claimant_cead = $scope.aa1_form1.claimant_cead;
			var claimant_cauthrep = $scope.aa1_form1.claimant_cauthrep;
			var claimant_cdauthrep = $scope.aa1_form1.claimant_cdauthrep;
			var claimant_cpname = $scope.aa1_form1.claimant_cpname;
			var claimant_clegal = $scope.aa1_form1.claimant_clegal;
			var claimantBusinessAddressQueryVar = claimantBusinessAddressQuery();
			var claimantServiceAddressQueryVar = claimantServiceAddressQuery();
			var claimantlawFirmDtoQueryVar = claimantlawFirmDtoQuery();
			if(claimant_clegal == "Yes"){ claimantServiceAddressQueryVar = {}; }
			var query = { 
				"caseMemberRoleType":undefinedSetNull(claimant),
				"applicantUidValue":undefinedSetNull(claimant_uen),
			    "memberName":undefinedSetNull(claimat_name),
			    "gender":undefinedSetNull(claimant_gender),
			    "businessAddress":claimantBusinessAddressQueryVar,
				"serviceAddress":claimantServiceAddressQueryVar,
			    "email":undefinedSetNull(claimant_cead),
			    "authRepresentative":undefinedSetNull(claimant_cauthrep),
			    "authRepDesignation":undefinedSetNull(claimant_cdauthrep),
			    "payeeName":undefinedSetNull(claimant_cpname),
			    "isLegallyRepresented":undefinedSetNull(claimant_clegal),
			    "lawFirmDto":claimantlawFirmDtoQueryVar
			};

			return query;
		}
		function claimantBusinessAddressQuery(){
			var claimant_cba = $scope.aa1_form1.claimant_cba;
			var claimant_cba2 = $scope.aa1_form1.claimant_cba2;
			var claimant_cba3 = $scope.aa1_form1.claimant_cba3;
			var claimant_cba4 = $scope.aa1_form1.claimant_cba4;
			var claimant_cpc1 = $scope.aa1_form1.claimant_cpc1;
			var claimant_cfaxnum = $scope.aa1_form1.claimant_cfaxnum;
			var claimant_ctelnum = $scope.aa1_form1.claimant_ctelnum;
			var claimant_service_address_status = $scope.aa1_form1.claimant_service_address_status;
			var query = { 
		        "address1":undefinedSetNull(claimant_cba),
				"address2":undefinedSetNull(claimant_cba2),
				"address3":undefinedSetNull(claimant_cba3),
				"address4":undefinedSetNull(claimant_cba4),
		        "postalCode":undefinedSetNull(claimant_cpc1),
		        "phoneNumber":undefinedSetNull(claimant_ctelnum),
		        "faxNumber":undefinedSetNull(claimant_cfaxnum),
		        "isServiceAddress":claimant_service_address_status
			};
			return query;
		}
		function claimantServiceAddressQuery(){
			var query = {};
			var claimant_service_address_status = $scope.aa1_form1.claimant_service_address_status;
			if(!claimant_service_address_status){
				var claimant_csa = $scope.aa1_form1.claimant_csa;
				var claimant_csa2 = $scope.aa1_form1.claimant_csa2;
				var claimant_csa3 = $scope.aa1_form1.claimant_csa3;
				var claimant_csa4 = $scope.aa1_form1.claimant_csa4;
				var claimant_cspc = $scope.aa1_form1.claimant_cspc;
				var claimant_cstelnum = $scope.aa1_form1.claimant_cstelnum;
				var claimant_csfaxnum = $scope.aa1_form1.claimant_csfaxnum;
				var query = { 
			        "address1":undefinedSetNull(claimant_csa),
					"address2":undefinedSetNull(claimant_csa2),
					"address3":undefinedSetNull(claimant_csa3),
					"address4":undefinedSetNull(claimant_csa4),
			        "postalCode":undefinedSetNull(claimant_cspc),
			        "phoneNumber":undefinedSetNull(claimant_cstelnum),
			        "faxNumber":undefinedSetNull(claimant_csfaxnum)
				};
			};
			return query;
		}
		function claimantlawFirmDtoQuery(){
			var respresentative_lawdetail = $scope.aa1_form1.respresentative_lawdetail;
			var claimantlawFirmBusinessAddressQueryVar = claimantlawFirmBusinessAddressQuery();
			var claimantlawFirmServiceAddressQueryVar = claimantlawFirmServiceAddressQuery();
			var claimantlawyersDetailsQueryVar = claimantlawyersDetailsQuery();
			var respresentative_lawfirm = $scope.aa1_form1.respresentative_lawfirm;
			var referenceNumber = $scope.aa1_form1.respresentative_lrefnum;
			if(respresentative_lawfirm){
				var respresentative_lawfirmId = respresentative_lawfirm.id;
			}
			var query = { 
				"id":respresentative_lawfirmId,
		        "name":undefinedSetNull(respresentative_lawdetail),
				"businessAddress":claimantlawFirmBusinessAddressQueryVar,
		        "serviceAddress":claimantlawFirmServiceAddressQueryVar,
		        "lawyerDetails":claimantlawyersDetailsQueryVar,
				"referenceNumber":undefinedSetNull(referenceNumber)
			};
			return query;
		}
		function claimantlawFirmBusinessAddressQuery(){
			var respresentative_addresslfirm = $scope.aa1_form1.respresentative_addresslfirm;
			var respresentative_addresslfirm2 = $scope.aa1_form1.respresentative_addresslfirm2;
			var respresentative_addresslfirm3 = $scope.aa1_form1.respresentative_addresslfirm3;
			var respresentative_addresslfirm4 = $scope.aa1_form1.respresentative_addresslfirm4;
			var respresentative_lpc = $scope.aa1_form1.respresentative_lpc;
			var respresentative_ltelnum = $scope.aa1_form1.respresentative_ltelnum;
			var respresentative_lfaxnum = $scope.aa1_form1.respresentative_lfaxnum;
			var claimant_lawyer_service_address_status = $scope.aa1_form1.claimant_lawyer_service_address_status;
			var query = { 
		        "address1":undefinedSetNull(respresentative_addresslfirm),
				"address2":undefinedSetNull(respresentative_addresslfirm2),
				"address3":undefinedSetNull(respresentative_addresslfirm3),
				"address4":undefinedSetNull(respresentative_addresslfirm4),
		        "postalCode":undefinedSetNull(respresentative_lpc),
		        "phoneNumber":undefinedSetNull(respresentative_ltelnum),
		        "faxNumber":undefinedSetNull(respresentative_lfaxnum),
		        "isServiceAddress":undefinedSetNull(claimant_lawyer_service_address_status)
			};
			return query;
		}
		function claimantlawFirmServiceAddressQuery(){
			var query = {};
			var claimant_lawyer_service_address_status = $scope.aa1_form1.claimant_lawyer_service_address_status;
			if(!claimant_lawyer_service_address_status){
				var claimant_lawyer_csa = $scope.aa1_form1.claimant_lawyer_csa;
				var claimant_lawyer_csa2 = $scope.aa1_form1.claimant_lawyer_csa2;
				var claimant_lawyer_csa3 = $scope.aa1_form1.claimant_lawyer_csa3;
				var claimant_lawyer_csa4 = $scope.aa1_form1.claimant_lawyer_csa4;
				var claimant_lawyer_cpc2 = $scope.aa1_form1.claimant_lawyer_cpc2;
				var claimant_lawyer_ctelnum = $scope.aa1_form1.claimant_lawyer_ctelnum;
				var claimant_lawyer_cfaxnum = $scope.aa1_form1.claimant_lawyer_cfaxnum;
				var query = { 
			        "address1":undefinedSetNull(claimant_lawyer_csa),
					"address2":undefinedSetNull(claimant_lawyer_csa2),
					"address3":undefinedSetNull(claimant_lawyer_csa3),
					"address4":undefinedSetNull(claimant_lawyer_csa4),
			        "postalCode":undefinedSetNull(claimant_lawyer_cpc2),
			        "phoneNumber":undefinedSetNull(claimant_lawyer_ctelnum),
			        "faxNumber":undefinedSetNull(claimant_lawyer_cfaxnum)
				};
			}
			return query;
		}
		function claimantlawyersDetailsQuery(){
			var query = [];
			var respresentative_lname = $scope.aa1_form1.respresentative_lname;
			var respresentative_lemail = $scope.aa1_form1.respresentative_lemail;
			var respresentative_l2name = $scope.aa1_form1.respresentative_l2name;
			var respresentative_l2email = $scope.aa1_form1.respresentative_l2email;
			var respresentative_l3name = $scope.aa1_form1.respresentative_l3name;
			var respresentative_l3email = $scope.aa1_form1.respresentative_l3email;
			if(respresentative_lname){
				var lawyer1 = { 
		               "lawyerName":undefinedSetNull(respresentative_lname),
		               "email":undefinedSetNull(respresentative_lemail)
				};
				query.push(lawyer1);
			}
			if(respresentative_l2name){
				var lawyer2 = {
					"lawyerName":undefinedSetNull(respresentative_l2name),
					"email":undefinedSetNull(respresentative_l2email)
				}
				query.push(lawyer2);
			}
			if(respresentative_l3name){
				var lawyer3 = {
					"lawyerName":undefinedSetNull(respresentative_l3name),
					"email":undefinedSetNull(respresentative_l3email)
				}
				query.push(lawyer3);
			}
			return query;
		}


		function respondentInfoQuery(){
			var respondent_type = $scope.aa1_form1.respondent_type;
			var repondent_passno = $scope.aa1_form1.repondent_passno;
			var repondent_name = $scope.aa1_form1.repondent_name;
			var repondent_gender = $scope.aa1_form1.repondent_gender;
			var repondent_email = $scope.aa1_form1.repondent_email;
			var respresentative_name = $scope.aa1_form1.respresentative_name;
			var respresentative_designati = $scope.aa1_form1.respresentative_designati;
			var respresentative_legrepresn = $scope.aa1_form1.respresentative_legrepresn;
			var respondentBusinessAddressQueryVar = respondentBusinessAddressQuery();
			var respondentServiceAddressQueryVar = respondentServiceAddressQuery();
			var respondentlawFirmDtoQueryVar = respondentlawFirmDtoQuery();
			var query = {
				"caseMemberRoleType":undefinedSetNull(respondent_type),
				"applicantUidValue":undefinedSetNull(repondent_passno),
				"memberName":undefinedSetNull(repondent_name),
				"gender":undefinedSetNull(repondent_gender),
				"businessAddress":respondentBusinessAddressQueryVar,
				"serviceAddress":respondentServiceAddressQueryVar,
				"email":undefinedSetNull(repondent_email),
				"authRepresentative":undefinedSetNull(respresentative_name),
				"authRepDesignation":undefinedSetNull(respresentative_designati),
				"payeeName":"",
				"isLegallyRepresented":respresentative_legrepresn,
				"lawFirmDto":respondentlawFirmDtoQueryVar
			};
			return query;
		}
		function respondentBusinessAddressQuery(){
			var repondent_address = $scope.aa1_form1.repondent_address;
			var repondent_address2 = $scope.aa1_form1.repondent_address2;
			var repondent_address3 = $scope.aa1_form1.repondent_address3;
			var repondent_address4 = $scope.aa1_form1.repondent_address4;
			var respondent_business_postal = $scope.aa1_form1.respondent_business_postal;
			var repondent_mobile = $scope.aa1_form1.repondent_mobile;
			var repondent_fax = $scope.aa1_form1.repondent_fax;
			var repondent_service_address_status = $scope.aa1_form1.repondent_service_address_status;
			var query = {
				"address1":undefinedSetNull(repondent_address),
				"address2":undefinedSetNull(repondent_address2),
				"address3":undefinedSetNull(repondent_address3),
				"address4":undefinedSetNull(repondent_address4),
				"postalCode":undefinedSetNull(respondent_business_postal),
				"phoneNumber":undefinedSetNull(repondent_mobile),
				"faxNumber":undefinedSetNull(repondent_fax),
				"isServiceAddress":repondent_service_address_status
			};
			return query;
		}
		function respondentServiceAddressQuery(){
			var query = {};
			var respresentative_legrepresn = $scope.aa1_form1.respresentative_legrepresn;
			var repondent_service_address_status = $scope.aa1_form1.repondent_service_address_status;
			if(!repondent_service_address_status && respresentative_legrepresn == "No"){
				var repondent_service_address = $scope.aa1_form1.repondent_service_address;
				var repondent_service_address2 = $scope.aa1_form1.repondent_service_address2;
				var repondent_service_address3 = $scope.aa1_form1.repondent_service_address3;
				var repondent_service_address4 = $scope.aa1_form1.repondent_service_address4;
				var respondent_service_postal = $scope.aa1_form1.respondent_service_postal;
				var repondent_service_mobile = $scope.aa1_form1.repondent_service_mobile;
				var repondent_service_fax = $scope.aa1_form1.repondent_service_fax;
				var query = {
					"address1":undefinedSetNull(repondent_service_address),
					"address2":undefinedSetNull(repondent_service_address2),
					"address3":undefinedSetNull(repondent_service_address3),
					"address4":undefinedSetNull(repondent_service_address4),
					"postalCode":undefinedSetNull(respondent_service_postal),
					"phoneNumber":undefinedSetNull(repondent_service_mobile),
					"faxNumber":undefinedSetNull(repondent_service_fax)
				};
			}
			return query;
		}
		function respondentlawFirmDtoQuery(){
			var respondant_lawdetail = $scope.aa1_form1.respondant_lawdetail;
			var respondentlawFirmBusinessAddressQueryVar = respondentlawFirmBusinessAddressQuery();
			var respondentlawFirmServiceAddressQueryVar = respondentlawFirmServiceAddressQuery();
			var respondentlawyersDetailsQueryVar = respondentlawyersDetailsQuery();
			var referenceNumber = $scope.aa1_form1.respondent_lrefnum;
			var query = {
				"id":null,
				"name":undefinedSetNull(respondant_lawdetail),
				"businessAddress":respondentlawFirmBusinessAddressQueryVar,
		        "serviceAddress":respondentlawFirmServiceAddressQueryVar,
				"lawyerDetails":respondentlawyersDetailsQueryVar,
				"referenceNumber":undefinedSetNull(referenceNumber)
			};
			return query;
		}
		function respondentlawFirmBusinessAddressQuery(){
			var respondant_addresslfirm = $scope.aa1_form1.respondant_addresslfirm;
			var respondant_addresslfirm2 = $scope.aa1_form1.respondant_addresslfirm2;
			var respondant_addresslfirm3 = $scope.aa1_form1.respondant_addresslfirm3;
			var respondant_addresslfirm4 = $scope.aa1_form1.respondant_addresslfirm4;
			var respondent_lpc = $scope.aa1_form1.respondent_lpc;
			var respondent_ltelnum = $scope.aa1_form1.respondent_ltelnum;
			var respondent_lfaxnum = $scope.aa1_form1.respondent_lfaxnum;
			var repondent_lawyer_service_address_status = $scope.aa1_form1.repondent_lawyer_service_address_status;
			var query = { 
		        "address1":undefinedSetNull(respondant_addresslfirm),
				"address2":undefinedSetNull(respondant_addresslfirm2),
				"address3":undefinedSetNull(respondant_addresslfirm3),
				"address4":undefinedSetNull(respondant_addresslfirm4),
		        "postalCode":undefinedSetNull(respondent_lpc),
		        "phoneNumber":undefinedSetNull(respondent_ltelnum),
		        "faxNumber":undefinedSetNull(respondent_lfaxnum),
		        "isServiceAddress":repondent_lawyer_service_address_status
			};
			return query;
		}
		function respondentlawFirmServiceAddressQuery(){
			var query = {};
			var repondent_lawyer_service_address_status = $scope.aa1_form1.repondent_lawyer_service_address_status;
			if(!repondent_lawyer_service_address_status){
				var repondent_lawyer_service_address = $scope.aa1_form1.repondent_lawyer_service_address;
				var repondent_lawyer_service_address2 = $scope.aa1_form1.repondent_lawyer_service_address2;
				var repondent_lawyer_service_address3 = $scope.aa1_form1.repondent_lawyer_service_address3;
				var repondent_lawyer_service_address4 = $scope.aa1_form1.repondent_lawyer_service_address4;
				var respondent_lawyer_service_postal = $scope.aa1_form1.respondent_lawyer_service_postal;
				var repondent_lawyer_mobile = $scope.aa1_form1.repondent_lawyer_mobile;
				var repondent_lawyer_fax = $scope.aa1_form1.repondent_lawyer_fax;
				var query = { 
			        "address1":undefinedSetNull(repondent_lawyer_service_address),
					"address2":undefinedSetNull(repondent_lawyer_service_address2),
					"address3":undefinedSetNull(repondent_lawyer_service_address3),
					"address4":undefinedSetNull(repondent_lawyer_service_address4),
			        "postalCode":undefinedSetNull(respondent_lawyer_service_postal),
			        "phoneNumber":undefinedSetNull(repondent_lawyer_mobile),
			        "faxNumber":undefinedSetNull(repondent_lawyer_fax)
				};
			}
			return query;
		}

		function respondentlawyersDetailsQuery(){
			var query = [];
			var respondent_lname = $scope.aa1_form1.respondent_lname;
			var respondent_lemail = $scope.aa1_form1.respondent_lemail;
			var respondent_l2name = $scope.aa1_form1.respondent_l2name;
			var respondent_l2email = $scope.aa1_form1.respondent_l2email;
			var respondent_l3name = $scope.aa1_form1.respondent_l3name;
			var respondent_l3email = $scope.aa1_form1.respondent_l3email;
			if(respondent_lname){
				var lawyer1 = {
					"lawyerName":undefinedSetNull(respondent_lname),
					"email":undefinedSetNull(respondent_lemail)
				};
				query.push(lawyer1);
			}
			if(respondent_l2name){
				var lawyer2 = {
					"lawyerName":undefinedSetNull(respondent_l2name),
					"email":undefinedSetNull(respondent_l2email)
				}
				query.push(lawyer2);
			}
			if(respondent_l3name){
				var lawyer3 = {
					"lawyerName":undefinedSetNull(respondent_l3name),
					"email":undefinedSetNull(respondent_l3email)
				}
				query.push(lawyer3);
			}
			return query;
		}


		function regulationInfoQuery(){
			var regulation_pname = $scope.aa1_form1.regulation_pname;
			var regulation_rcp = $scope.aa1_form1.regulation_rcp;
			var regulation_rrefnum = $scope.aa1_form1.regulation_rrefnum;
			var regulation_rownername = $scope.aa1_form1.regulation_rownername;
			var regulation_rocname = $scope.aa1_form1.regulation_rocname;
			var regulation_rorefnum = $scope.aa1_form1.regulation_rorefnum;
			var principleServiceAddressQueryVar = principleServiceAddressQuery();
			var ownerServiceAddressQueryVar = ownerServiceAddressQuery();
			var query = {
				"principalName":undefinedSetNull(regulation_pname),
				"principalServiceAddress":principleServiceAddressQueryVar,
				"principalContactPerson":undefinedSetNull(regulation_rcp),
				"principalRefNumber":undefinedSetNull(regulation_rrefnum),
				"ownerName":undefinedSetNull(regulation_rownername),
				"ownerServiceAddress":ownerServiceAddressQueryVar,
				"ownerContactPerson":undefinedSetNull(regulation_rocname),
				"ownerRefNumber":undefinedSetNull(regulation_rorefnum)
			};
			return query;
		}
		function principleServiceAddressQuery(){
			var regulation_rsa = $scope.aa1_form1.regulation_rsa;
			var regulation_rpc = $scope.aa1_form1.regulation_rpc;
			var regulation_rtelnum = $scope.aa1_form1.regulation_rtelnum;
			var regulation_rfaxnum = $scope.aa1_form1.regulation_rfaxnum;
			var query = {
				"address1":undefinedSetNull(regulation_rsa),
				"address2":"",
				"address3":"",
				"address4":"",
				"postalCode":undefinedSetNull(regulation_rpc),
				"phoneNumber":undefinedSetNull(regulation_rtelnum),
				"faxNumber":undefinedSetNull(regulation_rfaxnum)
			};
			return query;
		}
		function ownerServiceAddressQuery(){
			var regulation_rosa = $scope.aa1_form1.regulation_rosa;
			var regulation_ropc = $scope.aa1_form1.regulation_ropc;
			var regulation_rotelnum = $scope.aa1_form1.regulation_rotelnum;
			var regulation_rofaxnum = $scope.aa1_form1.regulation_rofaxnum;
			var query = {
				"address1":undefinedSetNull(regulation_rosa),
				"address2":"",
				"address3":"",
				"address4":"",
				"postalCode":undefinedSetNull(regulation_ropc),
				"phoneNumber":undefinedSetNull(regulation_rotelnum),
				"faxNumber":undefinedSetNull(regulation_rofaxnum)
			};
			return query;
		}

		function contractInfoQuery(){
			var regulation_rprojtitle = $scope.aa1_form1.regulation_rprojtitle;
			var regulation_rcontnum = $scope.aa1_form1.regulation_rcontnum;
			if($scope.aa1_form1.regulation_rconttype){
				var contactTypes = JSON.parse($scope.aa1_form1.regulation_rconttype);
				var regulation_rconttype = contactTypes.id;
			} else {
				var regulation_rconttype = undefined;
			}
			
			var regulation_natdisp = $scope.aa1_form1.regulation_natdisp;
			var regulation_cmade = $scope.aa1_form1.regulation_cmade;
			var regulation_mcmade = $scope.aa1_form1.regulation_mcmade;
			var query = {
				"projectReference":undefinedSetNull(regulation_rprojtitle),
				"contractNumber":undefinedSetNull(regulation_rcontnum),
				"contractType":undefinedSetNull(regulation_rconttype),
				"natureOfDispute":undefinedSetNull(regulation_natdisp),
				"contractMadeOn":undefinedSetNull(regulation_cmade),
				"mainContractMadeOn":undefinedSetNull(regulation_mcmade)
			};
			return query;
		}
		function paymentInfoQuery(){
			var payment_crefnum = $scope.aa1_form1.payment_crefnum;
			var payment_refperFrom = $scope.aa1_form1.payment_refperFrom;
			var payment_refperTo = $scope.aa1_form1.payment_refperTo;
			var payment_dpc = $scope.aa1_form1.payment_dpc;
			var payment_payclaimamt = $scope.aa1_form1.payment_payclaimamt;
			var payment_lateint = $scope.aa1_form1.payment_lateint;
			if(payment_lateint ==  "yes"){payment_lateint = true;}
			if(payment_lateint ==  "no"){payment_lateint = false;}
			var payment_lateintrate = $scope.aa1_form1.payment_lateintrate;
			var payment_resrefnum = $scope.aa1_form1.payment_resrefnum;
			var payment_duepayres = $scope.aa1_form1.payment_duepayres;
			var payment_dspr = $scope.aa1_form1.payment_dspr;
			var payment_payresamt = $scope.aa1_form1.payment_payresamt;
			var payment_duepaymade = $scope.aa1_form1.payment_duepaymade;
			var payment_paymaderesp = $scope.aa1_form1.payment_paymaderesp;
			var payment_amtpayresp = $scope.aa1_form1.payment_amtpayresp;
			var query = {
				"claimRefNumber":undefinedSetNull(payment_crefnum),
				"referencePeriodFrom":undefinedSetNull(payment_refperFrom),
				"referencePeriodTo":undefinedSetNull(payment_refperTo),
				"paymentClaimedDate":undefinedSetNull(payment_dpc),
				"claimAmount":undefinedSetNull(payment_payclaimamt),
				"latePaymentInterest":payment_lateint,
				"latePaymentInterestRate":undefinedSetNull(payment_lateintrate),
				"referenceResponseNumber":undefinedSetNull(payment_resrefnum),
				"responseDueDate":undefinedSetNull(payment_duepayres),
				"paymentClaimClaimant":undefinedSetNull(payment_dspr),
				"responseAmount":undefinedSetNull(payment_payresamt),
				"paymentDueDate":undefinedSetNull(payment_duepaymade),
				"respondentPaymentDate":undefinedSetNull(payment_paymaderesp),
				"paymentByRespondent":undefinedSetNull(payment_amtpayresp)
			};
			return query;
		}
		function supportingDocumentsQuery(){
			var query = [];
			var termsFilePath = $scope.termsUploadPath;
			var paymentClaimFilePath = $scope.paymentClaimUploadPath;
			var paymentResponseFilePath = $scope.paymentResponseUploadPath;
			var intentionNoticeFilePath = $scope.intentionNoticeUploadPath;
			var otherFilePath = $scope.otherDocUploadPath;
			if(termsFilePath){
				var filepath1 = {
					"name":"Relevant Contractual Terms and Conditions",
					"fileLocation":termsFilePath
				}
				query.push(filepath1);
			}
			if(paymentClaimFilePath){
				var filepath2 = {
					"name":"Payment Claim",
					"fileLocation":paymentClaimFilePath
				}
				query.push(filepath2);
			}
			if(paymentResponseFilePath){
				var filepath3 = {
					"name":"Payment Response Received",
					"fileLocation":paymentResponseFilePath
				}
				query.push(filepath3);
			}
			if(intentionNoticeFilePath){
				var filepath4 = {
					"name":"Notice of Intention to Apply for Adjudication",
					"fileLocation":intentionNoticeFilePath
				}
				query.push(filepath4);
			}
			if(otherFilePath){
				var filepath5 = {
					"name":"Other Relevant Document(s)",
					"fileLocation":otherFilePath
				}
				query.push(filepath5);
			}
			return query;
		}
		function caseDtoQuery(){
			var payment_claimamt = $scope.aa1_form1.payment_claimamt;
			if($scope.aa1_form1.payment_gst == "Yes"){
				var payment_gst = true;
			} else {
				var payment_gst = false;
			}
			var submitApp_name = $scope.aa1_form1.submitApp_name;
			var submitApp_nric = $scope.aa1_form1.submitApp_nric;
			var query = {
				"claimAmount":undefinedSetNull(payment_claimamt),
				"includeGst":undefinedSetNull(payment_gst),
				"isOnline":$scope.onlineFormSubmissionStatus,
				"authPerson":undefinedSetNull(submitApp_name),
				"authPersonRef":undefinedSetNull(submitApp_nric)
			};
			return query;
		}


		function undefinedSetNull(val){
			if(val){
				return val;
			} else {
				var val = null;
				return val;
			}
			return val;
		}
		$scope.proceedToPayment = function(){
			/*if(animating) return false;
			animating = true;*/

			current_fs = $(".aa1-form-wizard1");
			next_fs = $(".aa1-form-wizard2");

			$rootScope.nextWisard(next_fs,current_fs);
		}

		$rootScope.nextWisard = function(next_fs,current_fs){
			//activate next step on progressbar using the index of next_fs
			$(".processbar-controller li").eq($("fieldset").index(current_fs)).removeClass("current").removeClass("error").addClass("active");
			$(".processbar-controller li").eq($("fieldset").index(next_fs)).addClass("current");
			
			//show the next fieldset
			next_fs.show(); 
			//hide the current fieldset with style
			current_fs.hide();
			current_fs.animate({opacity: 0}, {
				step: function(now, mx) {
					//as the opacity of current_fs reduces to 0 - stored in "now"
					//1. scale current_fs down to 80%
					scale = 1 - (1 - now) * 0.2;
					//2. bring next_fs from the right(50%)
					left = (now * 50)+"%";
					//3. increase opacity of next_fs to 1 as it moves in
					opacity = 1 - now;
					current_fs.css({'transform': 'scale('+scale+')'});
					next_fs.css({'left': left, 'opacity': opacity});
				}, 
				duration: 800, 
				complete: function(){
					current_fs.hide();
					animating = false;
				}, 
				//this comes from the custom easing plugin
				easing: 'easeInOutBack'
			});
		}
		$rootScope.previousWisard = function (current_fs,previous_fs){
			current_fs = $("."+current_fs);
			previous_fs = $("."+previous_fs);
			//de-activate current step on progressbar
			$(".processbar-controller li").eq($("fieldset").index(current_fs)).removeClass("current").removeClass("error");
			
			//show the previous fieldset
			previous_fs.show(); 
			//hide the current fieldset with style
			current_fs.hide();
			current_fs.animate({opacity: 0}, {
				step: function(now, mx) {
					//as the opacity of current_fs reduces to 0 - stored in "now"
					//1. scale previous_fs from 80% to 100%
					scale = 0.8 + (1 - now) * 0.2;
					//2. take current_fs to the right(50%) - from 0%
					left = ((1-now) * 50)+"%";
					//3. increase opacity of previous_fs to 1 as it moves in
					opacity = 1 - now;
					current_fs.css({'left': left});
					previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
				}, 
				duration: 800, 
				complete: function(){
					current_fs.hide();
				}, 
				//this comes from the custom easing plugin
				easing: 'easeInOutBack'
			});
		}
 	}
 })();