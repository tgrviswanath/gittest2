(function() {
    'use strict';
    angular
        .module('smc')
        .controller('paymentCtrl',paymentCtrl);

    paymentCtrl.$inject = ['$rootScope','$scope','$interval','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$sce'];

    function paymentCtrl($rootScope,$scope,$interval,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$sce){
		
		var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	if (tab == 'paymentprocess'){
	    	if ($cookies.get('roleName') != 'claimant'  || $cookies.get('roleName') != 'claimantLawyer') {
	            $state.go('smclayout.membershiplayout.lawyercasesummary');
	        }
	    }


		var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches
		
		$scope.summary_templatefile = 'views/aa1/payment.html';
		$scope.fail_templatefile = 'views/aa1/paymentfail.html'
		$scope.success_templatefile = 'views/aa1/paymentsuccess.html'
		$scope.pattern = patternConfig;
		$scope.payment_summary = true;
		$scope.payment_method = 'CHEQUE';
		$scope.payment_failed = false;
		$scope.payment_success = false;
		$scope.ifcheque = true;
		$scope.ifcashier = false;
		$scope.ifnetbank = false;
		$scope.service_charge = false;
		$scope.attachcopyStatus = false;
		$scope.attach_copy_name = '';
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.lawyerId = $cookies.get('lawyerId');
		$scope.caseNumber = $cookies.get('caseNumber');
		$scope.loagedStatus = false;
		$scope.onemorecheck = false;
		$scope.applicationFee = '';
		$scope.paidAmount = '';
		$scope.totalAmount = '';
		$scope.pendingAmount = '';
		$scope.creditPayment={};
		// for e-Net
		var minYear = new Date().getFullYear();
		var maxYear = minYear+30;
		var minMonth = 1;
		var maxMonth = 12;
		$scope.yearList = [];
        for (var expYear = minYear; expYear < maxYear; expYear++) {
            $scope.yearList.push(expYear);
        }
        $scope.monthList = [];
        for (var expMonth = minMonth; expMonth <= maxMonth; expMonth++) {
        	if(expMonth<=9){
        		$scope.monthList.push('0'+expMonth);
        	}else{
        		$scope.monthList.push(expMonth);
        	}
        }


		$rootScope.callFuntion = function(){
			getDeposit();
		}
		
		getDeposit();
		// get deposit amount
		
		
		function getDeposit(){
			if($rootScope.tempCaseNumber){
				var serviceGetDepositAmountUrl = smcConfig.services.GetDepositeAmount.url;
				serviceGetDepositAmountUrl = serviceGetDepositAmountUrl + "/" + $rootScope.tempCaseNumber;
				$http.get(serviceGetDepositAmountUrl).then(function(data){
	        		console.log("data",data)
	        		$scope.filingFee=data.data.result.filingFee;
	        		$scope.gstOnFilingFee=data.data.result.gstOnFilingFee;
	        		$scope.applicationFee = data.data.result.applicationFee;
	        		$scope.depositAmount = data.data.result.depositAmount;
	        		$scope.totalAmount = data.data.result.totalAmount;
	        		$rootScope.tempCaseNumber = data.data.result.tempCaseNumber;
	        		$scope.paidAmount = data.data.result.paidAmount;
	        		$scope.pendingAmount = data.data.result.pendingAmount;
	        		$scope.getBankDetails();
	        	});
	        }
		}
		
		$scope.modifyClaimantName=function(){	
			$scope.claimant = {};		
			$scope.claimant.updatePartyName = $rootScope.claimantName;
			 angular.element(".custom-model-popup").css("display","block");
			 angular.element(".overlay").css("display","block");
					
		}

		$scope.submitModify=function(formData){
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
			var query={
				"caseNumber":$rootScope.tempCaseNumber,
				"partyName":formData.updatePartyName
			}
			 DataService.post('ModifyPartyName', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                       $rootScope.claimantName = formData.updatePartyName;
					   angular.element(".overlay").css("display","none");
					   angular.element(".custom-model-popup").css("display","none");
					   angular.element(".loading-container").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
                });
		}

		$scope.closeModify=function(){
			$scope.claimant = {};
			$scope.claimant.updatePartyName = $scope.claimantName;
			angular.element(".overlay").css("display","none");
			angular.element(".custom-model-popup").css("display","none");
		}
		

		$scope.getBankDetails = function(){
			DataService.get('GetBankDetails').then(function(data){
				$scope.accountName = data.result.accountName;
				$scope.accountNumber = data.result.accountNumber;
				$scope.bankName = data.result.bankName;
			});
		}

		// check_method function for which method choose to payment filed
		$scope.check_method = function(method){
			if(method == 'CHEQUE'){
				$scope.ifcheque = true;
				$scope.ifcashier = false;
				$scope.ifnetbank = false;
				$scope.ifeNets=false;
				$scope.service_charge = false;
			}else if (method == "CASHIERS_ORDER"){
				$scope.ifcheque = false;
				$scope.ifcashier = true;
				$scope.ifnetbank = false;
				$scope.ifeNets=false;
				$scope.service_charge = false;
			}else if(method=="INTERNET_BANKING"){
				$scope.ifcheque = false;
				$scope.ifcashier = false;
				$scope.ifnetbank = true;
				$scope.ifeNets=false;
				$scope.service_charge = false;
				angular.element(".overlay").css("display","block");
			    angular.element(".internet-bank-popup").css("display","block");          
			}else{
				$scope.ifcheque = false;
				$scope.ifcashier = false;
				$scope.ifnetbank = false;
				$scope.service_charge = true;
				$scope.ifeNets=true;
				$scope.eNetsData = {};
				$scope.eNetsData.amount = $scope.totalAmount;
				$scope.paymentOptions = ['Yes','No'];
				$scope.confirmFullAmount = 'Yes';
		        
			}
		}

		// upload document copy
		$scope.attachcopy = function(event){
			$scope.creditPayment.document={};
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
		
			if(fileName){
				$scope.attachcopyStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						angular.element("#attach_copy").val(fileName);
						if(fileName){
							angular.element("#attach_copy").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								$scope.creditPayment.document={"name":fileName,"fileLocation":data.result};
								$scope.attachcopyStatus = true;
							});
						}
					} else {
						angular.element("#attach_copy").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.attachcopyErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#attach_copy").addClass("error");
					$scope.termsErrorStatus = true;
					$scope.attachcopyErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}

		//remove document copy
		$scope.attachcopyRemove = function(){
			$scope.attach_copy_name = undefined;
			$scope.creditPayment.attach_copy = undefined;
			$scope.attachcopyPath = undefined;
			angular.element("#attach_copy").val("");
			angular.element("#attach_copy").val("");
			$scope.attachcopyStatus = false;
		}

		// get e-net amount
		$scope.geteNetAmount = function(confirmation){
			if(confirmation == 'Yes'){
				$scope.eNetsData.amount = $scope.totalAmount;
			}else{
				$scope.eNetsData.amount = $scope.applicationFee;
			}
		}

		// convert card number
		$scope.convertCardNo = function(){
			var numberLen = $scope.eNetsData.referenceNumber.length;
			if(numberLen == 4 || numberLen == 9 || numberLen == 14){
				$scope.eNetsData.referenceNumber = $scope.eNetsData.referenceNumber + '-';
			}
			if(numberLen == 19){
				$scope.hideSubmitBtn = false;
			}else{
				$scope.hideSubmitBtn = true;
			}
		}

		// process to payment
		$scope.addpayment = function(method,payment){
			if(method != 'ENETS'){
				var amountStatus = checkAmountisValid(payment);
			}else{
				var amountStatus = true;
			}
			if (amountStatus){
				angular.element(".overlay").css("display","block");
				angular.element(".loading-container").css("display","block");
				/*if(animating) return false;
				animating = true;*/
				current_fs = $(".aa1-form-wizard2");
				next_fs = $(".aa1-form-wizard3");
				console.log("payment",payment);
				var paymentRequests = buildPaymentQuery(method,payment);
				var query = {
					"tempCaseNumber":$rootScope.tempCaseNumber,
					"loginId" : $rootScope.saveResponseDetails ? $rootScope.saveResponseDetails.loginId : $cookies.get('memberId'),
					"paymentRequests": paymentRequests
				}
				console.log('query',query)
				DataService.post('PaymentSubmit',query).then(function(data){
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					if(data.status == "SUCCESS"){
						$scope.payment_summary = false;
						$scope.payment_success = true;
						$scope.paymentResponse = data.result;

						if(data.result.caseNumber){
							$scope.loagedStatus = true;
						}
						$scope.paymethod = method;
						if($rootScope.paymentStatus == undefined){
							$rootScope.nextWisard(next_fs,current_fs);
						}
					}else{
						$scope.theTime = 10;
						$scope.payment_summary = false;
						$scope.payment_failed = true;
						$interval(function () {
						    $scope.theTime = $scope.theTime-1;
						    if($scope.theTime == 0){
						        $scope.payment_summary = true;
								$scope.payment_failed = false;
						        $scope.theTime = undefined;
						        $scope.ifcheque = true;
								$scope.ifcashier = false;
								$scope.ifnetbank = false;
								$scope.ifeNets=false;
						    }
						},1000);
						if($rootScope.paymentStatus == undefined){
							$(".processbar-controller li").eq($("fieldset").index(current_fs)).addClass("error");
						}
					}
	    		})
	    		.catch(function(error){
	    			angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
	    			$scope.theTime = 10;
	    			$scope.payment_summary = false;
	    			$scope.payment_failed = true;
		            console.log(error);
		            $interval(function () {
					    $scope.theTime = $scope.theTime-1;
					    if($scope.theTime == 0){
					        $scope.payment_summary = true;
							$scope.payment_failed = false;
					        $scope.theTime = undefined;
					        $scope.ifcheque = true;
							$scope.ifcashier = false;
							$scope.ifnetbank = false;
							$scope.ifeNets=false;
					    }
					},1000);
					if($rootScope.paymentStatus == false ){
							$(".processbar-controller li").eq($("fieldset").index(current_fs)).addClass("error");
						}
		        });
		    }
		}

		// upload document validation by exetension
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if($scope.fileUploadTypes[i] == ext){
					return true;
				}
			}
		}

		// after payment success return to case details
		$scope.returnToAdmin = function(){
			if($scope.caseNumber == $rootScope.tempCaseNumber){
				$state.go('smclayout.membershiplayout.lawyercasesummary');
			}
		}

		// add one more check 
		$scope.addonemorecheck = function(){
			if($scope.onemorecheck == false){
				$scope.onemorecheck = true;
			}else{
				$scope.onemorecheck = false;
			}
		}

		$scope.cancelNetBank=function(){
			angular.element(".overlay").css("display","none");
			angular.element(".internet-bank-popup").css("display","none");   
		}

		// check submit amount is valid or not
		function checkAmountisValid(payment){
			if(parseInt($scope.paidAmount) ==0){
				if($scope.onemorecheck){
					var validAmount = parseInt(payment.amount) + parseInt(payment.amount1);
					if(payment.referencenumber != payment.referencenumber1){
						if(parseInt(validAmount)< parseInt($scope.totalAmount)){
							NotifyFactory.log('error','You have to pay minimum amount of Total fees.')
						}else{
							return true;
						}
					}else{
						NotifyFactory.log('error','Cheque order should be not same')
					}
				}else{
					if(parseInt(payment.amount)< parseInt($scope.applicationFee)){
						NotifyFactory.log('error','You have to pay minimum amount of Application fees.')
					}else{
						return true;
					}
				}
			}else if(parseInt($scope.paidAmount) !=0){
				if(parseInt(payment.amount)<parseInt($scope.pendingAmount)){
					NotifyFactory.log('error','Minimum amount is Pending Amount')
				}else{
					return true
				}
			}
		}

		$scope.downloadPdfFile = function(data,type){
			angular.element(".downloadLink").html(" ");
			var query = {};
			query.caseNumber = data.tempCaseNumber;
			query.loginId = $rootScope.saveResponseDetails ? $rootScope.saveResponseDetails.loginId : $cookies.get('memberId');
			if(type == 'invoice'){
				var generateInvoice = smcConfig.services.PaymentGenerateInvoice.url;
				query.financeIdentifier = data.invoiceNumber;
				$scope.downLoadTitle = 'Invoice for '+data.tempCaseNumber;
			}else if(type == 'receipt'){
				query.financeIdentifier = data.receiptNumber;
				var generateInvoice = smcConfig.services.PaymentGenerateReceipt.url;
				$scope.downLoadTitle = 'Receipt for '+data.tempCaseNumber;
			}else if(type == 'proforma'){
				query.financeIdentifier = data.proFormaNumber;
				var generateInvoice = smcConfig.services.PaymentGenerateProforma.url;
				$scope.downLoadTitle = 'Proforma for '+data.tempCaseNumber;
			}else if(type =='proformaRec'){
				query.financeIdentifier = data.proFormaReceiptNumber;
				var generateInvoice = smcConfig.services.PaymentGenerateReceipt.url;
				$scope.downLoadTitle = 'Proforma for '+data.tempCaseNumber;
			}
			// Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.post(generateInvoice, query, {
                responseType: 'arraybuffer'
            })
            .success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="invoice.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element(".overlay").css("display","block");
                angular.element("#invoice_document_view").css("display","block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                    angular.element(".overlay").css("display","block");
                angular.element("#invoice_document_view").css("display","block");
                }
            });
		}

		// build payment query
		function buildPaymentQuery(method,payment){
			var query = [];
			if(method=="INTERNET_BANKING"){
				query=[{
					"paymentMode":method,
					"referenceNumber":payment.referenceNumber, 
					"amount":payment.amount, 
					"dateOfOrder":payment.dateOfOrder, 
					"bankName":payment.bankName,
					"payerName" : payment.payerName,
					"document":payment.document
				}]
			}else if(method == "ENETS"){
				var selectedMonth = String(payment.month);
				var selectedYear = String(payment.year).substring(2);
				var expiry = selectedMonth + selectedYear;
				query=[{
					"paymentMode":method,
					"referenceNumber":payment.referenceNumber.split('-').join(""), 
					"amount":payment.amount, 
					"dateOfOrder":payment.dateOfOrder, 
					"bankName":payment.bankName,
					"payerName" : payment.payerName,
					"cardHolderName":payment.cardHolderName,
				    "cardCVV":payment.cardCVV,
				    "cardExpiry": expiry
				}] 
			}else{
				var cheque1 = {
					"paymentMode":method,
					"referenceNumber":payment.referencenumber, 
					"amount":payment.amount, 
					"dateOfOrder":payment.paymentdate, 
					"bankName":payment.bankname,
					"payerName" : payment.payerName
				}
				query.push(cheque1);
				if($scope.onemorecheck == true){
					var cheque2 = {
						"paymentMode":method,
						"referenceNumber":payment.referencenumber1, 
						"amount":payment.amount1, 
						"dateOfOrder":payment.paymentdate1, 
						"bankName":payment.bankname1,
						"payerName" : payment.payerName1
					}
					query.push(cheque2);
				}
			}
			
				
			return query
		}


	}
}
)();