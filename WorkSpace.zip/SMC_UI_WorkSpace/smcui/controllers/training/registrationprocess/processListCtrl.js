(function () {
    'use strict';
    angular
        .module('smc')
        .controller('processListCtrl', processListCtrl);

    processListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', 'navigateConfig'];

    function processListCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, navigateConfig) {
        window.onbeforeunload = setPrimaryCookies;
        if($cookies.getObject('setRefreshPages') && $state.current.name.indexOf('registerationProcess') != -1){
            $scope.processPages = $cookies.getObject('setRefreshPages');
            $cookies.remove('setRefreshPages');
        }else{
            $scope.processPages = [];
        }
        
        // to receive filter program list
        $scope.$on('currentRegisterProcess', function(event, currentPageDetails) { 
            var findIndex = -1;
            for(var page in $scope.processPages){
                if($scope.processPages[page].name == currentPageDetails.name){
                    findIndex = page;
                    break;
                }
            }
            if(findIndex == -1){
                $scope.processPages.push(currentPageDetails);
            }else{
                $scope.processPages.splice(findIndex+1,$scope.processPages.length-findIndex-1)
            }
        });

        function setPrimaryCookies(){
            if($scope.processPages.length >1 && $state.current.name.indexOf('registerationProcess') != -1){
                $cookies.putObject('setRefreshPages',$scope.processPages)
           }
        }
    }
})();
