(function() {
    'use strict';
    angular
        .module('smc')
        .controller('publishedProgramsCtrl',publishedProgramsCtrl);

    publishedProgramsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','TrainingCommonFunctions'];

    function publishedProgramsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,TrainingCommonFunctions){
        $scope.shownodataavailable = false;
        $scope.pattern = TrainingConfig;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'publishedPrograms'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.reverseSort = false;
        $scope.dataLength = 10;
        $scope.selectedProgramsToRegister = [];
        $scope.max_pagenumber = '';
    	get_published_program_list($scope.pagenumber);//call to published program list function
        $cookies.put('currentTab','publishedPrograms');
        var pageDetails = {
            'name' : 'Events', 'url' : $state.current.name
        }
        $scope.$emit('currentRegisterProcess', pageDetails);
    	// get caseload case list
    	function get_published_program_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null,
                "loginId":1
    		}
    		GetPublishedPrograms(query)
    	}

        function GetPublishedPrograms(query){
            DataService.post('GetPublishedProgramListinEvent',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.PublishedProgramList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.PublishedProgramList.length == 0){
                        $scope.shownodataavailable = true;
                    }
                }else{
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function(pageNo){
           get_published_program_list(pageNo);
        } 

        $scope.addProgramToRegister = function(programId){
           var findIndex = $scope.selectedProgramsToRegister.indexOf(programId);
           if(findIndex == -1){
                $scope.selectedProgramsToRegister.push(programId)
           }else{
                $scope.selectedProgramsToRegister.splice(findIndex,1)
           }
        }

    }
})();