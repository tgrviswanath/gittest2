(function() {
    'use strict';
    angular
        .module('smc')
        .controller('viewProgramCtrl',viewProgramCtrl);

    viewProgramCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','TrainingCommonFunctions'];

    function viewProgramCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,TrainingCommonFunctions){
        
    	get_view_program_details();//call to published program list function
        
    	// get view program details
    	function get_view_program_details(pageNumber){
            var getRegisterProgramDetailUrl = smcConfig.services.PreviewProgram.url + $state.params.programId;
            $http.get(getRegisterProgramDetailUrl).then(function(data){
                $scope.viewProgramData = data.data.result;
                var pageDetails = {
                    'name' : $scope.viewProgramData.programName, 'url' : "smclayout.contactlayout.registerationProcess.viewprogram({'programId' :"+ $state.params.programId+"})"
                }
                $scope.$emit('currentRegisterProcess', pageDetails);                
            });
    	}

    }
})();