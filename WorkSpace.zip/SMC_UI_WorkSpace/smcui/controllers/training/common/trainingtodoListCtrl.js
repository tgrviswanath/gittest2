(function() {
    'use strict';
    angular
        .module('smc')
        .controller('trainingtodolistCtrl',trainingtodolistCtrl);

    trainingtodolistCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function trainingtodolistCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory){
        if (($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management') || $cookies.get('moduleName') != 'Training') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.pattern = TrainingConfig;
        $scope.roleName = $cookies.get('roleName');
        $scope.userName = $cookies.get('userName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'toDoList'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.reverseSort = false;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $scope.updateDetailsModel = 'views/training/trainingpopupviews/officer/approvedprogramlist/updatedetails.html';
        $scope.approveScheduleModel = 'views/training/trainingpopupviews/manager/approveschedulepopup.html';
    	get_todo_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','toDoList');
        $scope.currentTab = 'toDoList';
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to reload case list function from outside
        $rootScope.reLoadCaseList = function(){
          get_todo_list(0)
        }
        get_all_training_officer();
        // get case officers
        function get_all_training_officer(){
            var query = {
                 "moduleName":"Training", 
                 "roleName":"Training Officer"
            }
            DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.trainig_officers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        

    	// get caseload case list
    	function get_todo_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex":$scope.pagenumber,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
    		}
            if($cookies.get('roleName') == 'SMC Officer'){
                var serviceUrl = 'GetTriningToDoListOfficer';
                query.smcOfficerId = null
            }else{
                var serviceUrl = 'GetTriningToDoListManager';
                query.loginId = null
            }
            getToDoCases(serviceUrl,query);
    	}

        function getToDoCases(serviceUrl,query){
            DataService.post(serviceUrl,query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.toDoList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.toDoList.length == 0){
                        $scope.shownodataavailable = true;
                    }
                }else{
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function(pageNo){
           get_todo_list(pageNo);
        } 

        //search case
        $scope.getProg = function(filterDetails){
            var query = {};
            if($cookies.get('roleName') == 'SMC Officer'){
                var serviceUrl = 'GetTriningToDoListOfficer';
                query.smcOfficerId = filterDetails.trainingOfficerId
            }else{
                var serviceUrl = 'GetTriningToDoListManager';
                query.loginId = filterDetails.trainingOfficerId
            }
            getToDoCases(serviceUrl,query)
        }

        //reset users list
        $scope.resetcases = function(){
            $scope.filter = undefined;
            get_todo_list(0);
        }

        $scope.goToAction = function(actionCase){
            switch(actionCase.actionName){
                case "Update Details" : 
                    $rootScope.openUpdateDetails(actionCase)
                    break;
                case "Approve Schedule" : 
                    $rootScope.openEditSchedule(actionCase.scheduleId)
                    break;
                default :
                    NotifyFactory.log('error','Unknown action detected')
            }
        }
    }
})();