angular.module('smc').service('TrainingCommonFunctions', function () {
    
    this.undefinedSetNull = function(val){
        if(val){
            return val;
        } else {
            var val = null;
            return val;
        }
        return val;
    }

    this.undefinedSetFalse = function(val){
        if(val != undefined){
            return val;
        } else {
            var val = false;
            return val;
        }
        return val;
    }
});