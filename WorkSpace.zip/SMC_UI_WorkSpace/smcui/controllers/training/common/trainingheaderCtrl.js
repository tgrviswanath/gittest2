(function() {
    'use strict';
    angular
        .module('smc')
        .controller('trainingheaderCtrl',trainingheaderCtrl);

    trainingheaderCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','navigateConfig'];

    function trainingheaderCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,navigateConfig){
  		$scope.userRole = $cookies.get('roleName');
        $scope.passwordStatus = $cookies.get('systemPassword')
        $scope.userRole = $scope.userRole.split(' ').join('_');
        $scope.logoUrl = navigateConfig.logo[$scope.userRole][0].url;
        $scope.menues = navigateConfig.training[$scope.userRole];
        $scope.usermenu = navigateConfig.user_action[$scope.userRole];
        $scope.userRole = $scope.userRole.split('_').join(' ');
        $scope.userName = $cookies.get('userName');
        $scope.logout= function(){
            var role = $cookies.get('roleName')
            role = role.split(' ').join('_');
            $cookies.put('memberId',null);
            $cookies.put('smcOfficerStatus',null);
            $cookies.put('smcManagerStatus',null);
            $cookies.put('adjudicatorStatus',null);
            $cookies.put('userName',null);
            $cookies.put('caseNumber',null);
            $cookies.put('userMail',null);
            $cookies.put('Password',null);
            $cookies.put('roleName',null);
            $state.go(navigateConfig.logout[role].url);
        }
  	}
})();