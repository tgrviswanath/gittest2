angular.module('smc').constant('TrainingConfig', { 
	patternmsgs : {
		program_category:{
			pattern_error:"Please select category type"
		},
		program_name:{
			pattern_error:"Please select program name"
		},
		others:{
			pattern_error:"Please enter valid program name"
		},
		event_name:{
			pattern_error:"Please enter valid event name"
		},
		program_fees_amount:{
			pattern_error:"Please enter valid fees amount"
		},
		SILE_CPD_Points:{
			pattern_error:"Please enter valid SILE CPD Points"
		},
		CEA_CPDCore_hours:{
			pattern_error:"Please enter valid CEA CPD Core hours"
		},
		program_dietry_requirement:{
			pattern_error:"Please select dietry requirement"
		},
		program_short_description:{
			pattern_error:"Please enter valid short description"
		},
		program_long_description:{
			pattern_error:"Please enter valid long description"
		},
		no_trainers:{
			pattern_error:"Please enter valid no of trainers"
		},
		no_coachers:{
			pattern_error:"Please enter valid no of coaches"
		},
		no_assesscers:{
			pattern_error:"Please enter valid no of assessors"
		},
		min_partiespants:{
			pattern_error:"Please enter valid Min participants"
		},
		max_partiespants:{
			pattern_error:"Please enter valid Max participants"
		},
		update_venue_name : {
			pattern_error : "Please enter valid venue details"
		},
		person_name : {
			pattern_error : "Please enter valid name"
		},
		email_id : {
			pattern_error : "Please enter valid email id"
		},
		phone_number : {
			pattern_error : "Please enter valid phone number"
		}
	},
	servicesuccessmsgs : {
		officer : {
			master_program : {
				check_unique_program_success : {
					notify_message : "Entered program name does not exist. Proceed with this program name"
				},
				check_unique_program_error : {
					notify_message : "Entered program name already exist. Please enter new program name"
				},
				add_program : {
					notify_message : "Program master added successfully"
				},
				update_program : {
					notify_message : "Program master updated successfully"
				}
			},
			schedule : {
				add_schedule  : {
					notify_message : "Schedule added successfully"
				},
				update_schedule : {
					notify_message : "Schedule updated successfully"
				},
				request_to_approval : {
					notify_message : "Request sent to management successfully"
				},
				delete_program : {
					notify_message : "Program deleted successfully"
				},
				less_coach_hours : {
					notify_message : "Start session time should be less than end session"
				},
				save_time_session : {
					notify_message : "Session saved successfully"
				},
				submit_time_session : {
					notify_message : "Session submitted successfully"
				},
				appoint_coach : {
					notify_message : "Coaches appointed successfully"
				}
			},
		},
		trainer : {
			pending_schedule : {
				submit_availablity :{
					notify_message : "Schedule availablity submitted successfully"
				}
			},
			accept_terms : {
				accepted_success : {
					notify_message : "Terms and conditions accepted successfully"
				}
			}
		},
		manager : {

		},
		training_popup : {
			officer : {
				approved_programs : {
					update_program_details : {
						less_prog_hour : {
							notify_message : "Start time should be less than end time"
						},
						same_prog_hour : {
							notify_message : "Start time and end time should not be same"
						},
						update_success : {
							notify_message : "Program details updated successfully"
						}
					},
					pulish_program : {
						publish_success :{
							notify_message : "Program published successfully"
						}
					}
				}
			},
			manager : {
				approve_schedule : {
					approved_schedule : {
						notify_message : "Program(s) approved successfully"
					},
					request_change : {
						notify_message : "Program(s) requested for changes submitted successfully"
					},
					delete_program : {
						notify_message : "Program deleted successfully"
					}
				}
			}
		}
	}
});
