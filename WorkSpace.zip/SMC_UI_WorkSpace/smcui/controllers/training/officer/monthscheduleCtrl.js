
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('monthscheduleCtrl',monthscheduleCtrl);

    monthscheduleCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','TrainingCommonFunctions'];

    function monthscheduleCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,TrainingCommonFunctions){
    	
        
        $scope.shownodataavailable=false;
        $scope.Schedule = {};
        $scope.ifEarlyBird = [];
        $scope.$on('diffdays', function(event, caselist,index) { 
            $scope.ifEarlyBird[index] = caselist; 
         });
        $scope.pattern=TrainingConfig;
        var trainingSuccessMsg = $scope.pattern.servicesuccessmsgs.officer.schedule;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'monthlySchedule'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber') );
        }else{
            $scope.pagenumber = 0;
        }
        getScheduleList($scope.pagenumber);
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $cookies.put('currentTab','monthlySchedule');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status

        //Default Date set
        $scope.minFromDate = "1";
        $scope.maxFromDate = "";
        $scope.minToDate = "1";
        $scope.maxToDate = "";

        function getScheduleList(pageNumber){
             if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
            var query={ 
                    "pageIndex":$scope.pagenumber,
                    "dataLength":$scope.dataLength,
                    "sortingColumn":null,
                    "sortDirection":null,
                    "OrganizationName":null,
                    "scheduleProgramName":null,
                    "dateCreated":null,
                    "scheduleStatus":null 
            };
            DataService.post('ViewScheduleTrainingProgramList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.shownodataavailable = false;
                    $scope.scheduleData = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalPages
                }else{
                    $scope.shownodataavailable=true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.resetScheduleList = function(){
            $scope.filter={};
            getScheduleList();
        }

        $scope.filterScheduleList = function(ScheduleData){
            console.log(ScheduleData);
            var query={ 
                    "pageIndex":0,
                    "dataLength":10,
                    "sortingColumn":null,
                    "sortDirection":null,
                    "OrganizationName":null,
                    "scheduleProgramName":ScheduleData.scheduleProgramName,
                    "dateCreated":null,
                    "scheduleStatus":ScheduleData.scheduleStatus 
            };
            DataService.post('ViewScheduleTrainingProgramList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.shownodataavailable = false;
                    $scope.scheduleData = data.result.responseData;
                    console.log($scope.scheduleData);
                    $scope.max_pagenumber = data.result.totalPages;
                }else{
                    $scope.shownodataavailable=true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function(pageNo){
           getScheduleList(pageNo);
        } 

        $scope.addonemoreschedule = function(action){
            $scope.addScedule.push(true);
            var toDate = '';
            var fromDate = '';
            if(action == 'update'){
                var firstValue = {
                    minimumParticipants : 12,
                    maximumParticipants : 24
                }
                $scope.updateScheduleData.trainingProgramResponseDTOs[$scope.addScedule.length-1]=firstValue
            }else{
                var fromDate = $scope.Schedule.startDate;
                var toDate = $scope.Schedule.endDate;
                var firstValue = {
                    minParticipants : 12,
                    maxParticipants : 24
                }
                $scope.Schedule.trainingPrograms[$scope.addScedule.length-1]=firstValue;
                $scope.minFromDate = fromDate;
                $scope.maxFromDate = toDate;
                $scope.minToDate = fromDate;
                $scope.maxToDate = toDate;
            }
        }

        $scope.removeone = function(index){
            $scope.addScedule.splice(index,1);
            $scope.Schedule.trainingPrograms.splice(index,1);
        }

        $scope.removeUpdateOne = function(index,action,sched_id,prog_id){
            if(action == 'Delete'){
                openToConfirmDelete(sched_id,prog_id);
                $scope.addScedule.splice(index,1);
            }else{
                var sched_id = $scope.updateScheduleData.id;
                var prog_id = $scope.updateScheduleData.trainingProgramResponseDTOs[index].id;
                $scope.addScedule.splice(index,1);
                $scope.updateScheduleData.trainingProgramResponseDTOs.splice(index,1);
            }
        }
        
        $scope.openAddSchedule = function(){
            $("input.datepicker1").multiDatesPicker('resetDates');
            $("input.datepicker1").datepicker('option',"minDate",1);
            $("input.datepicker1").datepicker('option',"maxDate",null);
            $("input.datepicker").datepicker('option',"minDate",1);
            $("input.datepicker").datepicker('option',"maxDate",null);
            $scope.minFromDate = "1";
            $scope.maxFromDate = "";
            $scope.minToDate = "1";
            $scope.maxToDate = "";
            $scope.Schedule = {};
            $scope.Schedule.trainingPrograms = [];
            $scope.Schedule.trainingPrograms = [];
            $scope.ifEarlyBird = [];
            $scope.addScedule = [true];
            $scope.toDateMinLimit = 0;
            var firstValue = {
                minParticipants : 12,
                maxParticipants : 24
            }
            $scope.Schedule.trainingPrograms.push(firstValue)
            $scope.addScedule = [true];
            angular.element(".overlay").css("display","block");
            angular.element(".add-schedule-modal").css("display","block");
            scheduleLoad();
            categoryLoad();
        }
          
        $scope.closeAddSchedule = function(){ 
            angular.element(".overlay").css("display","none");
            angular.element(".add-schedule-modal").css("display","none");
        }

        function scheduleLoad (){
            DataService.get('GetScheduleNameList').then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.scheduleList = data.results;
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function categoryLoad(){
            DataService.get('GetCategoryList').then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.categoryList = data.results;
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.openEditSchedule = function(scheduleData){            
            editSchedule(scheduleData.id)
        }

        function editSchedule(scheduleId){
             $scope.addScedule = [];
            var GetSingleScheduleUrl = smcConfig.services.GetSingleSchedule.url;
            GetSingleScheduleUrl = GetSingleScheduleUrl +  scheduleId;
            $http.get(GetSingleScheduleUrl).then(function(data){
                $scope.updateScheduleData=data.data.result;
                if($scope.updateScheduleData.scheduleName == 'Schedule'){
                    $scope.minFromDate = $scope.updateScheduleData.startDate;
                    $scope.maxFromDate = $scope.updateScheduleData.endDate;
                    $scope.minToDate = $scope.updateScheduleData.startDate;
                    $scope.maxToDate = $scope.updateScheduleData.endDate;
                    for(var schedule1 in $scope.updateScheduleData.trainingProgramResponseDTOs){
                        var fromDate = $scope.updateScheduleData.trainingProgramResponseDTOs[schedule1].fromDate;
                        $('[name="selectedUPDateRange'+schedule1+'"]').datepicker('option',"minDate",fromDate)
                    }
                }else{
                    if($scope.updateScheduleData.trainingProgramResponseDTOs.length != 0){
                        $scope.minFromDate = "1";
                        $scope.maxFromDate = "";
                        $scope.minToDate = $scope.updateScheduleData.trainingProgramResponseDTOs[0].fromDate;
                        $scope.maxToDate = "";
                        $('[name="selectedUPDateRange0"]').datepicker('option',"minDate",$scope.updateScheduleData.trainingProgramResponseDTOs[0].fromDate);
                    }
                }
                if($scope.updateScheduleData.scheduleName == 'Event'){
                  DataService.get('GetEventList').then(function(resonse){
                      $scope.eventlist=resonse.results;
                  });
                }else{
                    for (var prog in $scope.updateScheduleData.trainingProgramResponseDTOs){
                        if($scope.updateScheduleData.trainingProgramResponseDTOs[prog].programName == 'Events'){
                            DataService.get('GetEventList').then(function(resonse){
                              $scope.eventlist=resonse.results;
                          });
                        }
                    }
                }
                    for(var schedule in $scope.updateScheduleData.trainingProgramResponseDTOs){
                        $scope.addScedule.push(true);
                        categoryNameList($scope.updateScheduleData.trainingProgramResponseDTOs[schedule].categoryId,schedule);
                    }

                    scheduleLoad();
                    categoryLoad();
                    angular.element(".overlay").css("display","block");
                    angular.element(".update-train-schedule-modal").css("display","block");
            }).catch(function (error) {
                $scope.addScedule = undefined;
                NotifyFactory.log('error', error.data.errorMessage)
            });
        }

        $scope.closeEditSchedule = function(){ 
            angular.element(".overlay").css("display","none");
            angular.element(".update-train-schedule-modal").css("display","none");
        }

        $scope.openViewSchedule = function(scheduleData){
            getManagerList();
            var GetSingleScheduleUrl = smcConfig.services.GetSingleSchedule.url;
            GetSingleScheduleUrl = GetSingleScheduleUrl +  scheduleData.id;
            $http.get(GetSingleScheduleUrl).then(function(data){
                $scope.updateScheduleData=data.data.result;
            });
            scheduleLoad();
            categoryLoad();
            angular.element(".overlay").css("display","block");
            angular.element(".view-train-schedule-modal").css("display","block");
        }

        $scope.closeViewSchedule = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".view-train-schedule-modal").css("display","none");
        }
        $scope.programval = [];
        $scope.categoryNameList = function(catid,index){
            categoryNameList(catid,index);
        }

        function categoryNameList(catid,index){
            var GetProgramNameListUrl = smcConfig.services.GetProgramNameList.url;
            GetProgramNameListUrl = GetProgramNameListUrl +  catid;
            $http.get(GetProgramNameListUrl).then(function(resonse){
                $scope.programval[index]=resonse.data.results;
            });
        }

        $scope.eventNameList = function(progid,index){
            if(progid == 18 || progid == 9 || progid == 3){
                DataService.get('GetEventList').then(function(resonse){
                    $scope.eventlist=resonse.results;
                });
            }else if(index == 0){
                $scope.Schedule.trainingPrograms[index].eventName = '';
            }
        }

        $scope.chkscheduleType = function(sched_Id){
            $scope.addScedule = [true];
            $scope.Schedule.trainingPrograms = undefined;
            $scope.Schedule.trainingPrograms = [];
            var firstValue = {
                minParticipants : 12,
                maxParticipants : 24
            }
            $scope.Schedule.trainingPrograms.push(firstValue)
            
            $scope.Schedule.startDate = '';
            $scope.Schedule.endDate = '';
            $('[name="selectedDateRange0"]').multiDatesPicker('resetDates');
            $('input.datepicker').datepicker('option',"minDate",1);
            $('input.datepicker').datepicker('option',"maxDate",null);
            $('input.datepicker1').datepicker('option',"minDate",1);
            $('input.datepicker1').datepicker('option',"maxDate",null);
             $scope.minFromDate = "1";
            $scope.maxFromDate = "";
            $scope.minToDate = "1";
            $scope.maxToDate = "";

        }

        $scope.changeDateRange = function(index,fromDate){
            $scope.Schedule.trainingPrograms[index].dateRange = '';
            $('[name="selectedDateRange'+index+'"]').multiDatesPicker('resetDates');
            $('[name="selectedDateRange'+index+'"]').datepicker('option',"minDate",fromDate)
        }

        $scope.changeUpDateRange = function(index,fromDate){
            $scope.updateScheduleData.trainingProgramResponseDTOs[index].dateRange = '';
            $('[name="selectedUPDateRange'+index+'"]').multiDatesPicker('resetDates');
            $('[name="selectedUPDateRange'+index+'"]').datepicker('option',"minDate",fromDate)
            $scope.minToDate = fromDate;
        }

        $scope.addNewSchedule = function(schedule){
            var trainingProgramsVar = buildTrainingProgramsVarQuery(schedule.trainingPrograms,'create');
            var query = {
                "organizationName": schedule.organizationName,
                "scheduleNameId": schedule.scheduleNameId,
                "smcOfficerId": $cookies.get('memberId'),
                "startDate" : TrainingCommonFunctions.undefinedSetNull(schedule.startDate),
                "endDate" : TrainingCommonFunctions.undefinedSetNull(schedule.endDate),
                "trainingPrograms": trainingProgramsVar 
            }
            DataService.post('AddTrainingSchedule',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.add_schedule.notify_message);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".add-schedule-modal").css("display","none");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        function buildTrainingProgramsVarQuery(trainingPrograms,action){
            var programsSchedule = []
            for(var data in trainingPrograms){
                var rangeDates = [];
                if(trainingPrograms[data].programStatus != 'Approved'){
                    var query = {
                        "categoryId": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].categoryId),
                        "programNameId": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].programNameId),
                        "eventId": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].eventId),
                        "fromDate": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].fromDate),
                        "dateRange": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].dateRange),
                        "earlyBidEndDate": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].earlyBidEndDate),
                        "billingOrgName": TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].billingOrgName),
                        "isDiscountAppilicable":TrainingCommonFunctions.undefinedSetFalse(trainingPrograms[data].isDiscountApplicable)
                    }
                    if(action == 'create'){
                        query.numOfTrainers = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].numOfTrainers);
                        query.numOfCoaches = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].numOfCoaches);
                        query.numOfAssessors = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].numOfAssessors);
                        query.minParticipants = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].minParticipants);
                        query.maxParticipants = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].maxParticipants);
                    }else{
                        query.id = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].id)
                        query.numOfTrainers = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].numberOfTrainers);
                        query.numOfCoaches = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].numberOfCoaches);
                        query.numOfAssessors = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].numberOfAssessors);
                        query.minParticipants = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].minimumParticipants);
                        query.maxParticipants = TrainingCommonFunctions.undefinedSetNull(trainingPrograms[data].maximumParticipants);
                    }
                    programsSchedule.push(query)
                }
            }
            return programsSchedule;
        }

        $scope.paymentInfoFromDateClick = function(){
            var fromDate = $scope.Schedule.startDate;
            var toDate = $scope.Schedule.endDate;
            var dateSplit = fromDate.split('-');
            if(dateSplit[1]=='01'||dateSplit[1]=='03'||dateSplit[1]=='05'||dateSplit[1]=='07'||dateSplit[1]=='08'||dateSplit[1]=='10'||dateSplit[1]=='12'){
                if(dateSplit[0]=="31"){
                    dateSplit[0] = 1;
                    dateSplit[1] = parseInt(dateSplit[1])+1;
                }else{
                    dateSplit[0] = parseInt(dateSplit[0])+1;
                }
            }else if(dateSplit[1]=='02'){
                if(dateSplit[0]=='28'){
                    dateSplit[0] = 1;
                    dateSplit[1] = parseInt(dateSplit[1])+1;
                }else{
                    dateSplit[0] = parseInt(dateSplit[0])+1;
                }
            }else{
                if(dateSplit[0]=='30'){
                    dateSplit[0] = 1;
                    dateSplit[1] = parseInt(dateSplit[1])+1;
                }else{
                    dateSplit[0] = parseInt(dateSplit[0])+1;
                }
            }
            
            var from2 = dateSplit.join('-'); 
            $scope.toDateMinLimit = from2;
            
            $("input.datepicker").datepicker( "option", "minDate",fromDate);
            $("input.datepicker1").datepicker( "option", "minDate",fromDate);
            $( "#schedulePeriodTo" ).datepicker( "option", "minDate",from2);
            $scope.Schedule.endDate = undefined;
        }

        $scope.paymentUpdateInfoFromDateClick = function(){
            var fromDate = $scope.updateScheduleData.startDate;
            var toDate = $scope.updateScheduleData.endDate;
            var dateSplit = fromDate.split('-');
            if(dateSplit[1]=='01'||dateSplit[1]=='03'||dateSplit[1]=='05'||dateSplit[1]=='07'||dateSplit[1]=='08'||dateSplit[1]=='10'||dateSplit[1]=='12'){
                if(dateSplit[0]=="31"){
                    dateSplit[0] = 1;
                    dateSplit[1] = parseInt(dateSplit[1])+1;
                }else{
                    dateSplit[0] = parseInt(dateSplit[0])+1;
                }
            }else if(dateSplit[1]=='02'){
                if(dateSplit[0]=='28'){
                    dateSplit[0] = 1;
                    dateSplit[1] = parseInt(dateSplit[1])+1;
                }else{
                    dateSplit[0] = parseInt(dateSplit[0])+1;
                }
            }else{
                if(dateSplit[0]=='30'){
                    dateSplit[0] = 1;
                    dateSplit[1] = parseInt(dateSplit[1])+1;
                }else{
                    dateSplit[0] = parseInt(dateSplit[0])+1;
                }
            }
            
            var from2 = dateSplit.join('-'); 
            $scope.toDateMinLimit = from2;
            $("input.datepicker").datepicker( "option", "minDate",fromDate);
             $("input.datepicker1").datepicker( "option", "minDate",fromDate);
            $("#schedulePeriodTo" ).datepicker( "option", "minDate",from2);
            $scope.updateScheduleData.endDate = undefined;
        }

        $scope.paymentInfoToDateClick = function(){
            var toDate = $scope.Schedule.endDate;
            $("input.datepicker1").datepicker( "option", "maxDate",toDate);
            $("input.datepicker").datepicker( "option", "maxDate",toDate);
            $("#schedulePeriodFrom" ).datepicker( "option", "maxDate",null);
            $("#schedulePeriodTo" ).datepicker( "option", "maxDate",null);
        }

        $scope.updateSchedule = function(updateData,action){
            var trainingProgramsVar = buildTrainingProgramsVarQuery(updateData.trainingProgramResponseDTOs,'update');
            var query = {
                "id" : updateData.id,
                "organizationName": updateData.organizationName,
                "scheduleNameId": findId(updateData.scheduleName),
                "startDate" : TrainingCommonFunctions.undefinedSetNull(updateData.startDate),
                "endDate" : TrainingCommonFunctions.undefinedSetNull(updateData.endDate),
                "smcOfficerId": $cookies.get('memberId'),
                "trainingPrograms": trainingProgramsVar 
            }
            var seviceUrl = action+'TrainingSchedule';
            DataService.post(seviceUrl,query).then(function (data) {
                if(action == 'Update'){
                    NotifyFactory.log('success', trainingSuccessMsg.update_schedule.notify_message);
                }else if(action == 'Resubmit'){
                    requestScheduleToManager (updateData)
                }
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".update-train-schedule-modal").css("display","none");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }
        function findId(name){
            if(name == 'Schedule'){
                return 1;
            }else if(name == 'Adhoc Program'){
                return 2;
            }else{
                return 3;
            }
        }
        $scope.openToApproval = function(scheduleId){
            $scope.approvalData = {};
            $scope.approvalData.id = scheduleId;
            getManagerList();
            angular.element(".overlay").css("display","block");
            angular.element(".approval-request-schedule").css("display","block");
        }

        $scope.cancelapproval = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".approval-request-schedule").css("display","none");
        }

        function getManagerList(){
            var query = {
                "moduleName":"Training", 
                "roleName":"SMC Management"
            }
             DataService.post('GetMemberList',query).then(function (data) {
                $scope.Managers = data.results;
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.requestSchedule = function(scheduledata){
            requestScheduleToManager (scheduledata)
        }

        function requestScheduleToManager (scheduledata){
            var query = {
                "scheduleId":scheduledata.id, 
                "smcOfficerId":$cookies.get('memberId'), 
                "smcManagerId":scheduledata.smcManagerId
            }
            DataService.post('TrainingScheduleRequest',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.request_to_approval.notify_message);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".approval-request-schedule").css("display","none");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.openContactMemberModel = function(shed_id,inviteType,scheduleType){
            if(inviteType == 'trainer'){
                $scope.prog_id = shed_id;
                $scope.scheduleType = scheduleType;
                $scope.inviteType = inviteType;
                $scope.tabMemberType = 'principalTrainer';
                findRoleFilterId($scope.tabMemberType.replace(/([a-z](?=[A-Z]))/g, '$1 '),$scope.tabMemberType);
                angular.element(".overlay").css("display","block");
                angular.element(".contact-members-model").css("display","block");
            }else if(inviteType == 'coach'){
                getProgramDatelist(shed_id);
            }else{
                var query = {
                    "memberList" : [],
                    "scheduleId" : shed_id,
                    "smcOfficerId" : $cookies.get('memberId')
                }
                sendContactRequest(query,'Assessor')
            }
        }

        $scope.closeContactCoaches = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".set-coaches-time-schedule").css("display","none");
        }

        $scope.goOtherTab = function(diffMemberType){
            $scope.tabMemberType = diffMemberType;
            findRoleFilterId(diffMemberType.replace(/([a-z](?=[A-Z]))/g, '$1 '),diffMemberType);
        }

        $scope.closeContactTrainers = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".contact-members-model").css("display","none");
        }

        function findRoleFilterId(memType,diffMemberType){
            var id = '';
            DataService.get('GetMembersRoleWithId').then(function (data) {
                for(var role in data.results){
                    if(memType.charAt(0).toUpperCase() + memType.slice(1) == data.results[role].name){
                        id= data.results[role].id;
                        getMembersTypeList(id,diffMemberType,0);
                    }
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }
        $scope.memberlistOfIds = [];
        function getMembersTypeList(memberType,tab,pageNumber){
            $scope.tabDataLength = 10;
            if(pageNumber){
                $scope.tabPageNumber = pageNumber;
            }else{
                $scope.tabPageNumber = 0;
            }
            $scope.tabMemberId= memberType;
            $scope.memberTab = tab;
            if(tab == 'affiliateTrainer'){
                var findTab = 'affiliatedTrainers'
            }else{
                var findTab = tab+'s';
            }
            var query = {
                "pageIndex":$scope.tabPageNumber,
               "dataLength":$scope.tabDataLength,
               "sortingColumn":null,
               "sortDirection":null,
               "roleFilterId":memberType
            }
            DataService.post('GetMembersList',query).then(function (data) {
                $scope.membersList = data.result[findTab].responseData;
                $scope.max_tabPageNumber = data.result[findTab].totalPages;
                for(var type in $scope.membersList){
                    if($scope.memberlistOfIds.indexOf($scope.membersList[type].id) == -1){
                        $scope.memberlistOfIds.push($scope.membersList[type].id)
                    }
                    $scope.membersList[type].isAvalible = 'Yes'
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage);
                $scope.membersList = [];
            });
        }

        $scope.goToPageNumberTab = function(memId,memTab,pageNo){
            getMembersTypeList(memId,memTab,pageNo)
        }

        $scope.changeMemberValue = function(isAvalible,memId){
            if(isAvalible == 'No'){
                for(var id in $scope.memberlistOfIds){
                    if($scope.memberlistOfIds[id] == memId){
                        $scope.memberlistOfIds.splice(id,1);
                    }
                }
            }else{
                $scope.memberlistOfIds.push(memId);
            }
        }

        

       $scope.submitContact = function(memberlistOfIds,programId,contactMemberType){
            var query = {
                "memberList" : memberlistOfIds,
                "scheduleId" : programId,
                "smcOfficerId" : $cookies.get('memberId')
            }
            console.log('query',query);
            sendContactRequest(query,contactMemberType)
        }

        function sendContactRequest(query,contactMemberType){
            var ContactType = 'Contact'+contactMemberType;
            var successMsg =  contactMemberType+'(s) contacted successfully'
            DataService.post(ContactType,query).then(function (data) {
                NotifyFactory.log('success',successMsg);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".contact-members-model").css("display","none");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        function openToConfirmDelete(scheduleId,progid){
            $scope.sched_id = scheduleId;
            $scope.progid = progid;
            angular.element(".overlay").css("display","block");
            angular.element(".update-train-schedule-modal").css("display","none");
            angular.element(".confirm-delete-schedule").css("display","block");
        }

        $scope.closedeleteconfirmmodel = function(){
            $scope.addScedule.push(true)
             angular.element(".overlay").css("display","block");
             angular.element(".update-train-schedule-modal").css("display","block");
            angular.element(".confirm-delete-schedule").css("display","none");
        }

        $scope.submitscheduledelete = function(sched_id,prog_id){
            var query = {
                "scheduleId":sched_id, "programIdList":[prog_id]
            }
            DataService.post('TrainingDeleteSchedule',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.delete_program.notify_message);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".confirm-delete-schedule").css("display","none");
                if($scope.addScedule.length != 0){
                    editSchedule(sched_id)
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

       
        $scope.programMembersListIds = [];
        $scope.openViewMemberStatus = function(scheduleId,memberType,status,scheduleType){
            $scope.scheduleType = scheduleType;
            $scope.programMembersListIds = [];
            if(memberType == 'Assessor'){
                getAvailableMemberList(scheduleId,memberType,null);
            }else{
                findRoleFilterIdForStatus(scheduleId,memberType,'principalTrainer'.replace(/([a-z](?=[A-Z]))/g, '$1 '))
            }
            $scope.memberStatus = status;
            $scope.memberType = memberType;
            var findStatus = 'Minimum '+memberType+'s Confirmed'
            $scope.getMinimumNo = $scope.memberStatus.indexOf(findStatus);
        }

        function findRoleFilterIdForStatus(scheduleId,memberType,memType){
            var id = '';
            DataService.get('GetMembersRoleWithId').then(function (data) {
                for(var role in data.results){
                    if(memType.charAt(0).toUpperCase() + memType.slice(1) == data.results[role].name){
                        id= data.results[role].id;
                        getAvailableMemberList(scheduleId,memberType,id);
                    }
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.goOtherTabStatus = function(scheduleId,memtype){
            findRoleFilterIdForStatus(scheduleId,'Trainer',memtype.replace(/([a-z](?=[A-Z]))/g, '$1 '))
        }
        
        function getAvailableMemberList(scheduleId,memberType,roleFilterId){
            $scope.statusScheduleId = scheduleId;
            var query = {
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "roleFilterId":roleFilterId,
                "isResponded":true,
                "scheduleId":scheduleId
            }
            var checkStatus = 'View'+memberType+'Status';
            DataService.post(checkStatus,query).then(function (data) {
                if(data.status='SUCCESS'){
                    $scope.memberListOfAvailablity = [];
                    $scope.programList = [];
                    for(var datas in data.results){
                        var query = {};
                        query.scheduleId = scheduleId;
                        query.programId = data.results[datas].programId;
                        query.programName = data.results[datas].programName;
                        query.respondMembers = data.results[datas].respondedMember;
                        query.notRespondNames = [];
                        for(var name in data.results[datas].notRespondedMember){
                            query.notRespondNames.push(data.results[datas].notRespondedMember[name].memberName)
                        }
                        query.respondIds = [];
                        for(var member in query.respondMembers){
                            query.respondMembers[member].isAvalible = 'Yes';
                            query.respondIds.push(query.respondMembers[member].memberId);
                        }
                        if(memberType == 'Trainer'){
                            var findVal = -1;
                            for(var prog1 in $scope.programMembersListIds){
                                if(query.programId == $scope.programMembersListIds[prog1].programId){
                                    findVal = prog1;
                                }
                            }
                            if(findVal == -1){
                                $scope.programMembersListIds.push({'programId':query.programId,'memberList':query.respondIds})
                            }else{
                                if($scope.programMembersListIds[findVal].memberList.length == 0 && query.respondIds.length != 0){
                                    $scope.programMembersListIds[findVal].memberList = query.respondIds;
                                }
                            }
                        }
                        console.log('$scope.programMembersListIds',$scope.programMembersListIds)
                        $scope.memberListOfAvailablity.push(query)
                        $scope.programList.push(data.results[datas].programName);
                    }
                    $scope.selectedProgram = $scope.memberListOfAvailablity[0].programName;
                    $scope.availableMembers = $scope.memberListOfAvailablity[0].respondMembers;
                    $scope.nonAvailableMembers = $scope.memberListOfAvailablity[0].notRespondNames;
                    console.log($scope.memberListOfAvailablity)
                    getManagerList();
                    angular.element(".overlay").css("display","block");
                    angular.element(".view-trainer-status").css("display","block");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".overlay").css("display","block");
                angular.element(".view-trainer-status").css("display","block");
            });
        }

         $scope.getAvailableMembers = function(programName){
            for(var program in $scope.memberListOfAvailablity){
                if($scope.memberListOfAvailablity[program].programName== programName){
                    $scope.availableMembers = $scope.memberListOfAvailablity[program].respondMembers;
                    $scope.nonAvailableMembers = $scope.memberListOfAvailablity[program].notRespondNames;
                }
            }
         }

         // $scope.changeAvalaibleValue = function(member,programName,index){
         //    for(var program in $scope.memberListOfAvailablity){
         //        if($scope.memberListOfAvailablity[program].programName== programName){
         //            $scope.memberListOfAvailablity[program].respondMembers[index].isAvalible = member.isAvalible;
         //        }
         //    }
         // }

        $scope.closeTrainersStatus = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".view-trainer-status").css("display","none"); 
        }


        $scope.submitMembersToManager = function(trainerList,managerId,memberType){
            if(memberType != 'Trainer'){
                var memberList = getMembetIds(trainerList);
            }else{
                var memberList = $scope.programMembersListIds;
            }
            
            var query = {
                    "programMembersList": memberList,
                    "smcOfficerId":parseInt($cookies.get('memberId')),
                    "scheduleId":trainerList[0].scheduleId,
                    "smcManagerId":managerId
            }
            console.log(query);
            var seviceUrl = 'Send'+memberType+'ListToManager'
            var requestSuccessMessage = memberType + 'list approval request sent successfully'
            DataService.post(seviceUrl,query).then(function (data) {
                NotifyFactory.log('success',requestSuccessMessage);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".view-trainer-status").css("display","none"); 
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        function getMembetIds(list){
            var memList = [];
            for(var mem in list){
                var query = {};
                query.memberList = [];
                for(var prog in list[mem].respondMembers){
                    if(list[mem].respondMembers[prog].isAvalible == 'Yes'){
                        query.memberList.push(list[mem].respondMembers[prog].memberId);
                    }
                }
                if(query.memberList.length != 0){
                    query.programId = list[mem].programId;
                    memList.push(query);
                }
            }
            return memList;
        }

        function getProgramDatelist(scheduleId){
            getProgramList(scheduleId)
        }

        function getProgramList(scheduleId){
            var query = {
                "scheduleId":scheduleId,
                "programId":null,
                "smcOfficerId":$cookies.get('memberId')
            }
            DataService.post('ViewTimeSessionCoachByOfficer',query).then(function (data) {
                $scope.programScheduleId = data.result.scheduleId;
                $scope.programDatesList = data.result.programList;
                $scope.programnameList = [];
                var chkSession = 0;
                for(var dates in $scope.programDatesList){
                    $scope.programnameList.push({"programName":$scope.programDatesList[dates].programName,"programId":$scope.programDatesList[dates].programId});
                    $scope.programDatesList[dates].programDates.sessions = {};
                    for(var date1 in $scope.programDatesList[dates].programDates){
                        if(date1 != 'sessions'){
                            $scope.programDatesList[dates].programDates.sessions[date1] = [];
                            if(!$scope.programDatesList[dates].programDates[date1].dateSession){
                                $scope.programDatesList[dates].programDates.sessions[date1].push(true);
                                $scope.programDatesList[dates].programDates[date1].dateSession =[];
                                chkSession = 1;
                            }else{
                                for(var session in $scope.programDatesList[dates].programDates[date1].dateSession){
                                    $scope.programDatesList[dates].programDates.sessions[date1].push(true);
                                }
                            }
                        }
                    }
                }
                if(chkSession == 1){
                    $scope.disabledSubmitSession = true;
                }else{
                    $scope.disabledSubmitSession = false;
                }
                $scope.selectedPrograms = $scope.programDatesList[0].programId;
                $scope.availableDates = $scope.programDatesList[0].programDates;
                angular.element(".overlay").css("display","block");
                angular.element(".set-coaches-time-schedule").css("display","block");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.chkToSubmitSession = function(){
            var chkSession = 0;
            for(var dates in $scope.programDatesList){
                for(var date1 in $scope.programDatesList[dates].programDates){
                    if(date1 != 'sessions'){
                        if(!$scope.programDatesList[dates].programDates[date1].dateSession){
                            chkSession = 1;
                        }else{
                            if($scope.programDatesList[dates].programDates[date1].dateSession.length != 0){
                                for(var session in $scope.programDatesList[dates].programDates[date1].dateSession){
                                    if(!$scope.programDatesList[dates].programDates[date1].dateSession[session].sessionStart || !$scope.programDatesList[dates].programDates[date1].dateSession[session].sessionEnd){
                                        chkSession = 1;
                                    }
                                }
                            }else{
                                chkSession = 1;
                            }
                        }
                    }
                }
            }
            if(chkSession == 1){
                $scope.disabledSubmitSession = true;
            }else{
                $scope.disabledSubmitSession = false;
            }
        }

        $scope.getAvailableDates = function(selectDateProg){
            for(var program in $scope.programDatesList){
                if($scope.programDatesList[program].programId== selectDateProg){
                    $scope.availableDates = $scope.programDatesList[program].programDates;
                }
            }
        }

        $scope.toChkValidHourCoach = function(startTime,endTime){
            if(startTime && endTime){
                var startSplit = startTime.split(' ');
                var Start_Sched = startSplit[1];
                var Start_Hour = startSplit[0].split(':')[0];
                var Start_Minits = startSplit[0].split(':')[1];
                var endSplit = endTime.split(' ');
                var End_Sched = endSplit[1];
                var End_Hour = endSplit[0].split(':')[0];
                var End_Minits = endSplit[0].split(':')[1];
                if(Start_Sched == End_Sched){
                    if(Start_Hour == '12'){
                        if(End_Hour == '12'){
                            if(Start_Minits == End_Minits){
                                $scope.disabledSubmitSession = true;
                                NotifyFactory.log('error',trainingSuccessMsg.less_coach_hours.notify_message)
                            }else if(Start_Minits > End_Minits){
                                $scope.disabledSubmitSession = true;
                                NotifyFactory.log('error',trainingSuccessMsg.less_coach_hours.notify_message)
                            }else{
                                $scope.disabledSubmitSession = false;
                            }
                        }else{
                            $scope.disabledSubmitSession = false;
                        }
                    }else if(Start_Hour == End_Hour){
                        if(Start_Minits == End_Minits){
                            $scope.disabledSubmitSession = true;
                            NotifyFactory.log('error',trainingSuccessMsg.less_coach_hours.notify_message)
                        }else if(Start_Minits > End_Minits){
                            $scope.disabledSubmitSession = true;
                            NotifyFactory.log('error',trainingSuccessMsg.less_coach_hours.notify_message)
                        }else{
                            $scope.disabledSubmitSession = false;
                        }
                    }else if(Start_Hour > End_Hour){
                        $scope.disabledSubmitSession = true;
                        NotifyFactory.log('error',trainingSuccessMsg.less_coach_hours.notify_message)
                    }else{
                        $scope.disabledSubmitSession = false;
                    }
                }else if(Start_Sched == 'pm'){
                    $scope.disabledSubmitSession = true;
                    NotifyFactory.log('error',trainingSuccessMsg.less_coach_hours.notify_message)
                }else{
                    $scope.disabledSubmitSession = false;
                }
            }
        }

        $scope.actionOfTimeSession = function(datesArray,selectedId,programScheduleId,action){
            if(action == 'Save'){
                saveTimeSession(datesArray,selectedId,programScheduleId);
            }else{
                submitTimeSession(datesArray,programScheduleId);
            }
           console.log(datesArray)
        }

        function saveTimeSession(datesArray,selectedId,programScheduleId){
            var selectedArray;
            for(var prog in datesArray){
                if(datesArray[prog].programId == selectedId){
                    selectedArray = datesArray[prog];
                }
            }
            delete selectedArray['sessions'];
            var query = {
                "scheduleId":programScheduleId,
                "smcOfficerId":$cookies.get('memberId'),
                "programList" : [selectedArray]
            }
            DataService.post('SaveTimeSessionOfficer',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.save_time_session.notify_message);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".set-coaches-time-schedule").css("display","none"); 
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.addonemoresession = function(index,sessionArray){
            sessionArray[index].push(true);
        }

        $scope.removeonemoresession = function(parentIndex,index,sessionArray){
            sessionArray.sessions[parentIndex].splice(index,1);
            sessionArray[parentIndex].dateSession.splice(index,1);
        }

        function submitTimeSession(datesArray,programScheduleId){
            var query = {
                "scheduleId":programScheduleId,
                "smcOfficerId":$cookies.get('memberId'),
                "programList" : datesArray
            }
            DataService.post('SubmitTimeSessionOfficer',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.submit_time_session.notify_message);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".set-coaches-time-schedule").css("display","none"); 
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.viewManagerStatus = function(scheduleId,memberType,memberStatus){
            $scope.memberStatus = memberStatus;
            $scope.memberType= memberType;
            $scope.managerThoughts = {};
            $scope.managerThoughts.scheduleId = scheduleId;
            $scope.managerThoughts.memberType = memberType;
            var query = {
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "programId":null,
               "roleFilterId":null,
               "smcOfficerId":$cookies.get('memberId'),
               "scheduleId":scheduleId
            }

            var serviceUrl = 'View'+memberType+'ProgramStatusByOfficer'
            DataService.post(serviceUrl,query).then(function (data) {
              if(data.status == 'SUCCESS'){
                $scope.programTrainerDeatils = data.result.responseData[0];
                $scope.managerThoughts.auditTrail = data.result.responseData[0].auditTrailSection;
                $scope.managerThoughts.comment = data.result.responseData[0].comment;
                $scope.managerThoughts.smcManagerId = data.result.responseData[0].smcManagerId;
                $scope.requestSchedId = $scope.programTrainerDeatils.scheduleId;
                $scope.programData = $scope.programTrainerDeatils.programList
                $scope.programNameList =  [];
                for(var prog in $scope.programData){
                  $scope.programNameList.push($scope.programData[prog].programName);
                  for(var mem in $scope.programData[prog].memberList){
                    $scope.programData[prog].memberList[mem].isAvalible = 'Yes';
                  }
                }
                $scope.currentTabType = 'Principal Trainer';
                if(memberType == 'Trainer'){
                  $scope.approveMemberDeatils =[];
                  for(var val1 in $scope.programData[0].memberList){
                    if($scope.programData[0].memberList[val1].memberRole == $scope.currentTabType){
                      $scope.approveMemberDeatils.push($scope.programData[0].memberList[val1]);
                    }
                  }
                }else{
                  $scope.approveMemberDeatils = $scope.programData[0].memberList;
                }
                $scope.selectedProgram = $scope.programNameList[0];
                angular.element(".overlay").css("display","block");
                angular.element(".manager-trainer-view-program").css("display","block");
              }
            }).catch(function (error) {
                  NotifyFactory.log('error',error,errorMsg)  
              });
        }

        $scope.getAvailableMembersStatus = function(programName,memType,currentTabType){
              for(var program in $scope.programData){
                  if($scope.programData[program].programName== programName){
                    if(memType == 'Assessor'){
                      $scope.approveMemberDeatils = $scope.programData[program].memberList;
                    }else{
                      $scope.approveMemberDeatils = [];
                      for(var val2 in $scope.programData[program].memberList){
                        if($scope.programData[program].memberList[val2].memberRole == currentTabType){
                          $scope.approveMemberDeatils.push($scope.programData[program].memberList[val2]);
                        }
                      }
                    }
                  }
              }
           }

           $scope.closeTrainersProgram = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".manager-trainer-view-program").css("display","none");
          }

           $scope.goOtherTabTrainerApproval = function (currentTabType,programName){
              $scope.currentTabType = currentTabType;
              for(var program in $scope.programData){
                  if($scope.programData[program].programName== programName){
                    $scope.approveMemberDeatils = [];
                    for(var val2 in $scope.programData[program].memberList){
                      if($scope.programData[program].memberList[val2].memberRole == currentTabType){
                        $scope.approveMemberDeatils.push($scope.programData[program].memberList[val2]);
                      }
                    }
                  }
              }
           }

           $scope.resubmitMembersToManager = function(programData,managerThoughts){
                var query = {
                    "programMembersList": getArrangeProgramMembersList(programData),
                    "smcOfficerId":parseInt($cookies.get('memberId')),
                    "scheduleId":managerThoughts.scheduleId,
                    "smcManagerId":managerThoughts.smcManagerId
                }
                console.log(query);
                var seviceUrl = 'Send'+managerThoughts.memberType+'ListToManager'
                var requestSuccessMessage = managerThoughts.memberType + 'list approval request sent successfully'
                DataService.post(seviceUrl,query).then(function (data) {
                    NotifyFactory.log('success',requestSuccessMessage);
                    getScheduleList();
                    angular.element(".overlay").css("display","none");
                    angular.element(".manager-trainer-view-program").css("display","none"); 
                })
                .catch(function(error){
                    NotifyFactory.log('error',error.errorMessage)
                });
           }

          function getArrangeProgramMembersList(list){
             var memList = [];
            for(var mem in list){
              var query = {};
              query.programId = list[mem].programId;
              query.memberList = [];
              for(var mem1 in list[mem].memberList){
                if(list[mem].memberList[mem1].isAvalible == 'Yes'){
                  query.memberList.push(list[mem].memberList[mem1].id)
                }
              }
              if(query.memberList.length != 0){
                memList.push(query);
              }
            }
            return memList;
          }

        $scope.openViewContactedCoachStatus = function(schedId,status){
            var query = {
                "scheduleId":schedId,
                "programId":null,
                "smcOfficerId": $cookies.get('memberId')
            }
            DataService.post('ViewContactCoachStatus',query).then(function (data) {
                if(data.stuatus = 'SUCCESS'){
                    $scope.coachesStatusList = data.result;
                    $scope.availableCoachMembers = $scope.coachesStatusList.programList[0].programDates;
                    $scope.coachProgramNameList = [];
                    $scope.coachNotRespondedMember = [];
                    var chkRespond = 0;
                    for(var prog in $scope.coachesStatusList.programList){
                        $scope.coachProgramNameList.push({'programId' : $scope.coachesStatusList.programList[prog].programId,'programName' : $scope.coachesStatusList.programList[prog].programName})
                        for(var datelist in $scope.coachesStatusList.programList[prog].programDates){
                            for(var session in $scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList){
                                if($scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList[session].respondedMember){
                                    for (var responded in $scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList[session].respondedMember){
                                        $scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList[session].respondedMember[responded].isAvalible = 'Yes';
                                    }
                                    chkRespond = 1;
                                }
                            }
                        }
                    }
                    if(chkRespond == 0){
                        $scope.coachAppointBtnDisbld = true;
                    }else{
                        $scope.coachAppointBtnDisbld = false;
                    }
                    if($scope.coachesStatusList.notRespondedMember){
                       for(var prog1 in $scope.coachesStatusList.notRespondedMember){
                            $scope.coachNotRespondedMember.push($scope.coachesStatusList.notRespondedMember[prog1].memberName)
                        } 
                    }else{
                       $scope.coachNotRespondedMember.push('--All coaches are responded--'); 
                    }
                    $scope.selectedCoachProgram = $scope.coachProgramNameList[0].programId;
                    angular.element(".overlay").css("display","block");
                    angular.element(".officer-viewcoach-status").css("display","block");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.closeCoachesStatus = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".officer-viewcoach-status").css("display","none");
        }

        $scope.getAvailableCoachPrograms = function(selectedProgram){
            for(var prog in $scope.coachesStatusList.programList){
                if($scope.coachesStatusList.programList[prog].programId == selectedProgram){
                    $scope.availableCoachMembers = $scope.coachesStatusList.programList[prog].programDates;
                }
            }
        }

        $scope.chkAppointBtnEnabled = function(){
            var chkRespond = 0;
            for(var prog in $scope.coachesStatusList.programList){
                for(var datelist in $scope.coachesStatusList.programList[prog].programDates){
                    for(var session in $scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList){
                        if($scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList[session].respondedMember){
                            for (var responded in $scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList[session].respondedMember){
                                if($scope.coachesStatusList.programList[prog].programDates[datelist].dateSessionList[session].respondedMember[responded].isAvalible == 'Yes'){
                                    chkRespond = 1;
                                }
                            }
                        }
                    }
                }
            }
            if(chkRespond == 1){
                $scope.coachAppointBtnDisbld = false;
            }else{
                $scope.coachAppointBtnDisbld = true;
            }
        }

        $scope.appointAvailableCoaches = function(programListData){
            var coachesavailablePrograms = buildAvailableCoachesQuery(programListData.programList);
            var query = {
                "smcOfficerId": $cookies.get('memberId'),
                "scheduleId" : programListData.scheduleId,
                "programList" : coachesavailablePrograms
            }
            DataService.post('AppointedContactCoaches',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.appoint_coach.notify_message);
                getScheduleList();
                angular.element(".overlay").css("display","none");
                angular.element(".officer-viewcoach-status").css("display","none"); 
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        function buildAvailableCoachesQuery(listOfPrograms){
            var progQuery = [];
            for (var prog in listOfPrograms){
                var programData = {};
                programData.programId = listOfPrograms[prog].programId;
                programData.programDates = [];
                for(var progDate in listOfPrograms[prog].programDates){
                    var progDateQuery = {};
                    progDateQuery.programDate = listOfPrograms[prog].programDates[progDate].programDate;
                    progDateQuery.sessionList = [];
                    for(var session in listOfPrograms[prog].programDates[progDate].dateSessionList){
                        var sessionQuery = {};
                        sessionQuery.sessionId = listOfPrograms[prog].programDates[progDate].dateSessionList[session].id;
                        sessionQuery.coachList = [];
                        for(var coach in listOfPrograms[prog].programDates[progDate].dateSessionList[session].respondedMember){
                            var coachQuery = {};
                            coachQuery.memberId = listOfPrograms[prog].programDates[progDate].dateSessionList[session].respondedMember[coach].memberId;
                            if(listOfPrograms[prog].programDates[progDate].dateSessionList[session].respondedMember[coach].isAvalible == 'Yes'){
                                coachQuery.isShortlisted = true;
                            }else{
                                coachQuery.isShortlisted = false;
                            }
                            sessionQuery.coachList.push(coachQuery);
                        }
                        progDateQuery.sessionList.push(sessionQuery);
                    }
                    programData.programDates.push(progDateQuery);
                }
                progQuery.push(programData);
            }
            return progQuery;
        }

    }
})();	