(function() {
    'use strict';
    angular
        .module('smc')
        .controller('approvedProgramsCtrl',approvedProgramsCtrl);

    approvedProgramsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','TrainingCommonFunctions'];

    function approvedProgramsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,TrainingCommonFunctions){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Training') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.pattern = TrainingConfig;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'approvedPrograms'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.updateDetailsModel = 'views/training/trainingpopupviews/officer/approvedprogramlist/updatedetails.html'
        $scope.healthChkModel = 'views/training/trainingpopupviews/officer/approvedprogramlist/healthcheck.html';
        $scope.previewProgModel = 'views/training/trainingpopupviews/officer/approvedprogramlist/previewProgram.html';
        $scope.publishProgModel = 'views/training/trainingpopupviews/officer/approvedprogramlist/publishProgram.html';
        $scope.reverseSort = false;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_approved_program_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','approvedPrograms');
        $scope.currentTab = 'toDoList';
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        $rootScope.reLoadCaseList = function(){
            get_approved_program_list($scope.pagenumber);
        }
    	// get caseload case list
    	function get_approved_program_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex":$scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null,
                "smcOfficerId":$cookies.get('memberId'),
                "scheduleName":null,
                "programName":null,
                "trainingCategoryId":null,
                "dateFrom":null,
                "dateRange":null,
                "programIdStatus":null
    		}
    		GetApprovedPrograms(query)
    	}

        function GetApprovedPrograms(query){
            DataService.post('GetApprovedProgramList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.approvedPrograms = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.approvedPrograms.length == 0){
                        $scope.shownodataavailable = true;
                    }else{
                        for(var prog in $scope.approvedPrograms){
                            if((!$scope.approvedPrograms[prog].isProgramDetailsUpdated) || (($scope.approvedPrograms[prog].isProgramDetailsUpdated && !$scope.approvedPrograms[prog].isProgramPublished) &&($scope.approvedPrograms[prog].categoryType=='Local Public Workshops' ||  $scope.approvedPrograms[prog].categoryType=='Assessments'))){
                                $scope.approvedPrograms[prog].showMenu = true;
                            }else{
                                $scope.approvedPrograms[prog].showMenu = false;
                            }
                        }
                    }
                }else{
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        // get category types for filter dropdown
        DataService.get('GetCategoryList').then(function (data) {
            if(data.status == 'SUCCESS'){
                $scope.categoryList = data.results;
            }
        }).catch(function (error) {
            NotifyFactory.log('error', error.errorMessage);
        });

        $scope.goToPageNumber = function(pageNo){
           get_approved_program_list(pageNo);
        } 

        //search case
        $scope.getProg = function(filterDetails){
            var query = {
                "scheduleName": TrainingCommonFunctions.undefinedSetNull(filterDetails.scheduleName),
                "programName": TrainingCommonFunctions.undefinedSetNull(filterDetails.programName),
                "trainingCategoryId": TrainingCommonFunctions.undefinedSetNull(filterDetails.categoryId),
                "dateFrom": TrainingCommonFunctions.undefinedSetNull(filterDetails.dateFrom),
                "dateRange": TrainingCommonFunctions.undefinedSetNull(filterDetails.dateRange),
                "programIdStatus": TrainingCommonFunctions.undefinedSetNull(filterDetails.programIdStatus) 
            }
            GetApprovedPrograms(query)
        }

        //reset users list
        $scope.resetcases = function(){
            $scope.filter = undefined;
            get_approved_program_list(0);
        }

        $scope.filterFromDateClick = function(){
            var fromDate = $scope.filter.fromDate;
            $scope.fromMinDate = fromDate;
            $( "#filterToDate" ).datepicker( "option", "minDate",fromDate );
            $scope.filter.dateRange = undefined;
        }
    }
})();