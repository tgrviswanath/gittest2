/*This Controller for SMC Management to get changes payee name requests from SMC officers
So, SMC Manager Will Check it And Approve Or Amand And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('trainingmasterCtrl',trainingmasterCtrl);

    trainingmasterCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','TrainingCommonFunctions'];

    function trainingmasterCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,TrainingCommonFunctions){
    	$scope.programForm={};
        $scope.addNewForm={};
        $scope.update={};
        $scope.addNew={};
        categoryLoad();
        $scope.shownodataavailable=false;
        $scope.dietRequirements=false;
        $scope.events=false;
        $scope.others=false;
        $scope.success=false;
        $scope.addMasterModel = 'views/training/trainingpopupviews/officer/masterprogram/addmasterprog.html'
        $scope.updateMasterModel = 'views/training/trainingpopupviews/officer/masterprogram/updatemasterprog.html'
        $scope.pattern=TrainingConfig;
        var trainingSuccessMsg = $scope.pattern.servicesuccessmsgs.officer.master_program;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'trainMaster'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber') );
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $cookies.put('currentTab','trainMaster');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        getProgramList($scope.pagenumber);
        function getProgramList(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
            var query={ "pageIndex":$scope.pagenumber,
                    "dataLength":$scope.dataLength,
                    "sortingColumn":null,
                    "sortDirection":null, 
                    "categoryId":null, 
                    "programNameId":null, 
                    "eventName":null 
            };
            DataService.post('ProgramMasterDatasList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.trainingData = data.result.responseData;
                    $scope.shownodataavailable=false;
                    $scope.max_pagenumber = data.result.totalPages;
                }else{
                    $scope.shownodataavailable=true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }
         $scope.filterTrainingMaster = function(filterMaster){
            var query={ 
                    "pageIndex":0,
                    "dataLength":10,
                    "sortingColumn":null,
                    "sortDirection":null, 
                    "categoryId":filterMaster.categoryId, 
                    "programNameId":filterMaster.programNameId, 
                    "eventName":filterMaster.eventName 
            };

            DataService.post('ProgramMasterDatasList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.trainingData = data.result.responseData;
                    $scope.shownodataavailable=false;
                    $scope.max_pagenumber = data.result.totalpages;
                }else{
                    console.log("else1");
                    $scope.shownodataavailable=true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    console.log("catch");
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function(pageNo){
           getProgramList(pageNo);
        } 

        $scope.openUpdateProgram = function(trainingData){
            angular.element(".overlay").css("display","block");
            angular.element(".update-program-modal").css("display","block");
            $scope.wrongDigitsPoints = false;
            $scope.wrongDigitsHours = false;
            $scope.updateData=angular.copy(trainingData);
            $scope.updateData.silePoint = $scope.updateData.silePoint.split('.')[0];
            $scope.updateData.ceaCoreHours = $scope.updateData.ceaCoreHours.split('.')[0];
            $scope.updateData.dietaryRequirement = $scope.updateData.dietaryRequirement?'Yes':'No';
        }
         $scope.resetTrainingMaster = function(){
             getProgramList();
             $scope.filter={};
             $scope.eventList = '';
        }
        $scope.checkAvailability = function(catid,programName){
            if(catid && programName){
                if(programName != 'Others'){
                    var query={
                        "categoryTypeId":catid,
                        "programName":programName
                    };
                    DataService.post('CheckAvailabilityProgram',query).then(function (data) {
                    if(data.result=='Available' ){
                        $scope.success=true;
                        NotifyFactory.log('error',trainingSuccessMsg.check_unique_program_error.notify_message);
                    }else{
                        $scope.success=false;
                        NotifyFactory.log('success',trainingSuccessMsg.check_unique_program_success.notify_message);
                    }
                    })
                    .catch(function(error){
                        NotifyFactory.log('error',error.errorMessage)
                    });
                }else{
                    $scope.success=true;
                }
            }
        }

        $scope.updateProgram = function(updateprogram){
            var query = {
                    "id" : TrainingCommonFunctions.undefinedSetNull(updateprogram.id),
                    "smcOfficerId": TrainingCommonFunctions.undefinedSetNull(parseInt($cookies.get('memberId'))),
                    "fees":TrainingCommonFunctions.undefinedSetNull(updateprogram.fees), 
                    "silePoint": TrainingCommonFunctions.undefinedSetNull(updateprogram.silePoint), 
                    "ceaCoreHours": TrainingCommonFunctions.undefinedSetNull(updateprogram.ceaCoreHours),
                    "dietaryRequirement": TrainingCommonFunctions.undefinedSetNull((updateprogram.dietaryRequirement == 'Yes')?true:false), 
                    "shortDescription": TrainingCommonFunctions.undefinedSetNull(updateprogram.shortDescription), 
                    "longDescription": TrainingCommonFunctions.undefinedSetNull(updateprogram.longDescription) 
            } 
            DataService.post('UpdateProgramMasterDetail',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.update_program.notify_message);
                getProgramList();
                angular.element(".overlay").css("display","none");
                angular.element(".update-program-modal").css("display","none");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.closeUpdateProgram = function(){ 
            angular.element(".overlay").css("display","none");
            angular.element(".update-program-modal").css("display","none");
            $scope.programForm.update={};
        }

        $scope.openAddProgram = function(id){
            angular.element(".overlay").css("display","block");
            angular.element(".add-program-modal").css("display","block");
            $scope.addNew = {};
            $scope.programval = [];
            categoryLoad();
            $scope.wrongDigitsPoints = false;
            $scope.wrongDigitsHours = false;
        }

        function categoryLoad() {
            DataService.get('GetCategoryList').then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.categoryList = data.results;
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.wrongDigitsPoints = false;
        $scope.wrongDigitsHours = false;

        $scope.chkPointHourValue = function (hourValue){
            chkPointHours(hourValue,'wrongDigitsHours')
        }

        $scope.chkPointValue = function (pointValue){
            chkPointHours(pointValue,'wrongDigitsPoints')
        }

        function chkPointHours(pointData,modelValue){
            if(pointData){
                var value = pointData.indexOf('.');
                if(value != -1){
                    if(pointData[value+1]!='5'){
                        $scope[modelValue] = true;
                    }
                    else {
                        $scope[modelValue] = false;
                    }
                }else {
                    $scope[modelValue] = false;
                }
            }
            if(!$scope.wrongDigitsPoints && !$scope.wrongDigitsHours){
                $scope.success=false;
            }else{
                 $scope.success=true;
            }
        }

        $scope.categoryNameList = function(catid){
            if(catid != 4&& catid != ''){
                getProgramListbyCatId(catid);
            }
            $scope.addNew.programName = ''
        }

        $scope.categoryNameListinFilter = function(catid){
            if(catid != ''){
                getProgramListbyCatId(catid);
            }else{
                $scope.filter = {};
                $scope.eventList = '';
            }
            $scope.filter.programNameId = ''
        }

        function getProgramListbyCatId(catid){
            var GetProgramNameListUrl = smcConfig.services.GetProgramNameList.url;
            GetProgramNameListUrl = GetProgramNameListUrl +  catid;
            $http.get(GetProgramNameListUrl).then(function(resonse){
                $scope.programval=resonse.data.results;
            });
        }


        $scope.addNewProgram = function(newprogram){
            var query = {
                "smcOfficerId":TrainingCommonFunctions.undefinedSetNull(parseInt($cookies.get('memberId'))),
                "categoryId":TrainingCommonFunctions.undefinedSetNull(newprogram.categoryId),
                "eventName":TrainingCommonFunctions.undefinedSetNull(newprogram.eventName),
                "fees":TrainingCommonFunctions.undefinedSetNull(newprogram.fees),
                "silePoint":TrainingCommonFunctions.undefinedSetNull(newprogram.silePoint),
                "ceaCoreHours":TrainingCommonFunctions.undefinedSetNull(newprogram.ceaCoreHours),
                "dietaryRequirement":TrainingCommonFunctions.undefinedSetNull((newprogram.dietaryRequirement == 'Yes') ? true:false),
                "shortDescription":TrainingCommonFunctions.undefinedSetNull(newprogram.shortDescription),
                "longDescription":TrainingCommonFunctions.undefinedSetNull(newprogram.longDescription)
            }
            if(newprogram.programName == 'Others'){
                query.programName = newprogram.others
            }else{
                query.programName = newprogram.programName
            }
            DataService.post('AddProgramMasterDetails',query).then(function (data) {
                NotifyFactory.log('success',trainingSuccessMsg.add_program.notify_message);
                getProgramList();
                angular.element(".overlay").css("display","none");
                angular.element(".add-program-modal").css("display","none");
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.closeAddProgram = function(){ 
            angular.element(".overlay").css("display","none");
            angular.element(".add-program-modal").css("display","none");
            $scope.programForm.addNew={};
        }
        $scope.eventList = '';
        $scope.eventNameList = function(progid){
            if(progid == 18 || progid == 9){
                DataService.get('GetEventList').then(function(resonse){
                    $scope.eventList=resonse.results;
                });
            }else{
                $scope.eventList = '';
                $scope.filter.eventName = '';
            }
        }
    }
})();	