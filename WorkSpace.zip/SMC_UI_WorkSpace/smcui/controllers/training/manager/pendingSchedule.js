   (function() {
       'use strict';
       angular
           .module('smc')
           .controller('trainScheduleApprovalCtrl', trainScheduleApprovalCtrl);
       trainScheduleApprovalCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','$window','$sce'];

       function trainScheduleApprovalCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,$window,$sce) {
         if ($cookies.get('roleName') != 'SMC Management' && $cookies.get('moduleName') != 'Training' ) {
              $state.go('smclayout.membershiplayout.memberlogin');
          }
          $scope.roleName = $cookies.get('roleName');
          $scope.userName = $cookies.get('userName');
          $scope.shownodataavailable = false;
          if($cookies.get('pageNumber')&& $cookies.get('currentTab') == 'trainScheduleApproval'){
              $scope.pagenumber = parseInt($cookies.get('pageNumber'));
          }else{
              $scope.pagenumber = 0;
          }
          $scope.dataLength = 10;
          $scope.approveScheduleModel = 'views/training/trainingpopupviews/manager/approveschedulepopup.html';
          $scope.pattern=TrainingConfig;
          $scope.max_pagenumber = '';
          get_pending_caselist($scope.pagenumber);
          $cookies.put('currentTab','trainScheduleApproval');
          $scope.$emit('activeTab',$cookies.get('currentTab'));

        // get pending case list
        function get_pending_caselist(pageNumber){
              if(pageNumber){
                  $scope.pagenumber = pageNumber;
              }else{
                  $scope.pagenumber = 0;
              }
              $cookies.put('pageNumber',$scope.pagenumber) 
              var sorting = [[0,0], [1,0]];
          var query = { 
                  "pageIndex":$scope.pagenumber, 
                  "dataLength":$scope.dataLength, 
                  "sortingColumn":null, 
                  "sortDirection":null, 
                  "organizationName":null, 
                  "scheduleProgramName":null, 
                  "dateSent":null, 
                  "smcManagerName":null, 
                  "smcManagerId":$cookies.get('memberId')
              }
          DataService.post('GetTrainingApprovalList',query).then(function (data) {
            if(data.status == 'SUCCESS'){
              $scope.pendingApprovalData = data.result.responseData;
              $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
              var value= Math.round($scope.max_pagenumber);
              if(value < $scope.max_pagenumber){
                  $scope.max_pagenumber = value+1;
              }else{
                  $scope.max_pagenumber = value;
              }
            }else{
                      $scope.shownodataavailable = true;
            }
          }).catch(function (error) {
                  if(error.errorCode == 100){
                      $scope.shownodataavailable = true;
                  }
            });
        }

        $rootScope.reLoadCaseList = function(){
          get_pending_caselist(0)
        }

          $scope.goToPageNumber = function(pageNo){
             get_pending_caselist(pageNo);
          }
       }
   })();