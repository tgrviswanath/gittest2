   (function() {
       'use strict';
       angular
           .module('smc')
           .controller('trainersApprovalCtrl', trainersApprovalCtrl);
       trainersApprovalCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','$window','$sce','TrainingCommonFunctions'];

       function trainersApprovalCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,$window,$sce,TrainingCommonFunctions) {
         if ($cookies.get('roleName') != 'SMC Management' && $cookies.get('moduleName') != 'Training' ) {
              $state.go('smclayout.membershiplayout.memberlogin');
          }
          $scope.roleName = $cookies.get('roleName');
          $scope.userName = $cookies.get('userName');
          $scope.shownodataavailable = false;
          $scope.pattern = TrainingConfig;
          if($cookies.get('pageNumber')&& $cookies.get('currentTab') == 'pendingTrainersApproval'){
              $scope.pagenumber = parseInt($cookies.get('pageNumber'));
          }else{
              $scope.pagenumber = 0;
          }
          $scope.dataLength = 10;
          $scope.max_pagenumber = '';
          get_pending_trainerlist($scope.pagenumber);
          $cookies.put('currentTab','pendingTrainersApproval');
          $scope.$emit('activeTab',$cookies.get('currentTab'));

          $scope.getMemberList = function(memberType){
            if(memberType == 'Trainer'){
              get_pending_trainerlist(0);
            }else if(memberType == 'Assessor'){
              get_pending_assessorslist(0);
            }
          }
          // get pending approval assessors list
          function get_pending_assessorslist(pageNumber){
            if(pageNumber){
                  $scope.pagenumber = pageNumber;
              }else{
                  $scope.pagenumber = 0;
              }
              $cookies.put('pageNumber',$scope.pagenumber) 
              var sorting = [[0,0], [1,0]];
          var query = { 
                  "pageIndex":$scope.pagenumber, 
                  "dataLength":$scope.dataLength, 
                  "sortingColumn":null, 
                  "sortDirection":null, 
                  "smcManagerId":$cookies.get('memberId')
              }
              getDifferMemberList(query,'Assessors')
          }


        // get pending approval trainers list
        function get_pending_trainerlist(pageNumber){
              if(pageNumber){
                  $scope.pagenumber = pageNumber;
              }else{
                  $scope.pagenumber = 0;
              }
              $cookies.put('pageNumber',$scope.pagenumber) 
              var sorting = [[0,0], [1,0]];
          var query = { 
                  "pageIndex":$scope.pagenumber, 
                  "dataLength":$scope.dataLength, 
                  "sortingColumn":null, 
                  "sortDirection":null, 
                  "smcManagerId":$cookies.get('memberId')
              }
              getDifferMemberList(query,'Trainers')
        }
        function getDifferMemberList(query,memberType){
          var serviceUrl = 'GetTraining'+memberType+'ApprovalList'
          DataService.post(serviceUrl,query).then(function (data) {
            if(data.status == 'SUCCESS'){
              $scope['pending'+memberType+'Data'] = data.result.responseData;
              $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
              var value= Math.round($scope.max_pagenumber);
              if(value < $scope.max_pagenumber){
                  $scope.max_pagenumber = value+1;
              }else{
                  $scope.max_pagenumber = value;
              }
              $scope.shownodataavailable = false;
            }else{
                      $scope.shownodataavailable = true;
            }
          }).catch(function (error) {
              $scope['pending'+memberType+'Data'] = '';
              $scope.shownodataavailable = true;
            });
        }

          $scope.goToPageNumber = function(pageNo,memType){
            if(memType == 'Trainer'){
             get_pending_trainerlist(pageNo);
            }else{
              get_pending_assessorslist(pageNo);
            }
          }

          $scope.openContactMembers = function(scheduleId,memberType){
            $scope.memberType= memberType;
            $scope.managerThoughts = {};
            var query = {
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "scheduleId":scheduleId,
                "programId":null,
                "roleFilterId":null,
                "smcManagerId":$cookies.get('memberId')
            }
            var serviceUrl = 'View'+memberType+'ProgramByManager'
            DataService.post(serviceUrl,query).then(function (data) {
              if(data.status == 'SUCCESS'){
                $scope.programTrainerDeatils = data.result.responseData[0];
                $scope.requestSchedId = $scope.programTrainerDeatils.scheduleId;
                $scope.programData = $scope.programTrainerDeatils.programList
                $scope.programNameList =  [];
                for(var prog in $scope.programData){
                  $scope.programNameList.push($scope.programData[prog].programName);
                  for(var mem in $scope.programData[prog].memberList){
                    $scope.programData[prog].memberList[mem].isAvalible = 'Yes';
                  }
                }
                $scope.currentTabType = 'Principal Trainer';
                if(memberType == 'Trainer'){
                  $scope.approveMemberDeatils =[];
                  for(var val1 in $scope.programData[0].memberList){
                    if($scope.programData[0].memberList[val1].memberRole == $scope.currentTabType){
                      $scope.approveMemberDeatils.push($scope.programData[0].memberList[val1]);
                    }
                  }
                }else{
                  $scope.approveMemberDeatils = $scope.programData[0].memberList;
                }
                $scope.selectedProgram = $scope.programNameList[0];
                angular.element(".overlay").css("display","block");
                angular.element(".manager-trainer-view-program").css("display","block");
              }
            }).catch(function (error) {
                  NotifyFactory.log('error',error,errorMsg)  
              });
          }

           $scope.getAvailableMembers = function(programName,memType,currentTabType){
              for(var program in $scope.programData){
                  if($scope.programData[program].programName== programName){
                    if(memType == 'Assessor'){
                      $scope.approveMemberDeatils = $scope.programData[program].memberList;
                    }else{
                      $scope.approveMemberDeatils = [];
                      for(var val2 in $scope.programData[program].memberList){
                        if($scope.programData[program].memberList[val2].memberRole == currentTabType){
                          $scope.approveMemberDeatils.push($scope.programData[program].memberList[val2]);
                        }
                      }
                    }
                  }
              }
           }

           $scope.goOtherTabTrainerApproval = function (currentTabType,programName){
              $scope.currentTabType = currentTabType;
              for(var program in $scope.programData){
                  if($scope.programData[program].programName== programName){
                    $scope.approveMemberDeatils = [];
                    for(var val2 in $scope.programData[program].memberList){
                      if($scope.programData[program].memberList[val2].memberRole == currentTabType){
                        $scope.approveMemberDeatils.push($scope.programData[program].memberList[val2]);
                      }
                    }
                  }
              }
           }

          $scope.closeTrainersProgram = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".manager-trainer-view-program").css("display","none");
          }

          $scope.submitMembers = function(status,programData,memberType,managerThoughts){
            var query = {
              "scheduleId":TrainingCommonFunctions.undefinedSetNull($scope.requestSchedId),
              "smcManagerId":$cookies.get('memberId'),
              "comment":TrainingCommonFunctions.undefinedSetNull(managerThoughts.comments),
              "auditTrailSection":TrainingCommonFunctions.undefinedSetNull(managerThoughts.auditTrail),
              "programMembersList":getMembetIds(programData),
              "smcManagerStatus":status
            }
            if(status == 'Approved'){
              var successmsg = memberType+'(s) approved successfully'
            }else{
              var successmsg = memberType+'(s) to amend request sent successfully'
            }
            console.log('query',query)
            var serviceUrl = 'submit'+memberType+'ByManger'
            DataService.post(serviceUrl,query).then(function (data) {
                NotifyFactory.log('success',successmsg);
                if(memberType == 'Trainer'){
                  get_pending_trainerlist($cookies.get('pagenumber'));
                }else{
                  get_pending_assessorslist($cookies.get('pagenumber'));
                }
                angular.element(".overlay").css("display","none");
                angular.element(".manager-trainer-view-program").css("display","none"); 
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage)
            });
          }

          function getMembetIds(list){
            var memList = [];
            for(var mem in list){
              var query = {};
              query.programId = list[mem].programId;
              query.memberList = [];
              for(var mem1 in list[mem].memberList){
                if(list[mem].memberList[mem1].isAvalible == 'Yes'){
                  query.memberList.push(list[mem].memberList[mem1].id)
                }
              }
              if(query.memberList.length != 0){
                memList.push(query);
              }
            }
            return memList;
        }
         
       }
   })();