(function() {
       'use strict';
       angular
           .module('smc')
           .controller('trainerAcceptTermsCtrl', trainerAcceptTermsCtrl);
       trainerAcceptTermsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','$window','$sce'];

       function trainerAcceptTermsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,$window,$sce) {
          $scope.roleName = $cookies.get('roleName');
          $scope.userName = $cookies.get('userName');
          $scope.shownodataavailable = false;
          if($cookies.get('pageNumber')&& $cookies.get('currentTab') == 'trainerAcceptTerms'){
              $scope.pagenumber = parseInt($cookies.get('pageNumber'));
          }else{
              $scope.pagenumber = 0;
          }
          $scope.dataLength = 10;
          $scope.max_pagenumber = '';
          var trainingConfig = TrainingConfig;
          var trainingSuccessMsg = trainingConfig.servicesuccessmsgs.trainer.accept_terms;
          get_terms_schedule_list($scope.pagenumber);
          $cookies.put('currentTab','trainerAcceptTerms');
          $scope.$emit('activeTab',$cookies.get('currentTab'));

        // get pending case list
        function get_terms_schedule_list(pageNumber){
              if(pageNumber){
                  $scope.pagenumber = pageNumber;
              }else{
                  $scope.pagenumber = 0;
              }
              $cookies.put('pageNumber',$scope.pagenumber) 
              var sorting = [[0,0], [1,0]];
          var query = { 
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "memberId":$cookies.get('memberId')
              }
          DataService.post('GetTrainerTermsConditionBySchedule',query).then(function (data) {
            if(data.status == 'SUCCESS'){
              $scope.termsScheduleData = [];
              for(var schedule in data.result.responseData[0].schedule){
                $scope.termsScheduleData.push(data.result.responseData[0].schedule[schedule])
              }
              for(var adhoc in data.result.responseData[0].adhocProgram){
                $scope.termsScheduleData.push(data.result.responseData[0].adhocProgram[adhoc])
              }
              $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
              var value= Math.round($scope.max_pagenumber);
              if(value < $scope.max_pagenumber){
                  $scope.max_pagenumber = value+1;
              }else{
                  $scope.max_pagenumber = value;
              }
            }else{
                      $scope.shownodataavailable = true;
            }
          }).catch(function (error) {
                  if(error.errorCode == 100){
                      $scope.shownodataavailable = true;
                  }
            });
        }

          $scope.goToPageNumber = function(pageNo){
             get_pending_caselist(pageNo);
          }

          $scope.viewAcceptTerms = function(prog_id){
            $scope.prog_id = prog_id;
          }

          $scope.acceptSchedule = function(programid){
            var query = {
              "memberId":$cookies.get('memberId'),
              "programId":programid,
              "isAccepted":true
            }
            DataService.post('TrainingAcceptedTerms',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',trainingSuccessMsg.accepted_success.notify_message);
                    get_terms_schedule_list($cookies.get('pageNumber'))
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
          }

   }
})();