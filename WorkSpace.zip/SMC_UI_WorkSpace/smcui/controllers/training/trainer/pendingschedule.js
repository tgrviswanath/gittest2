(function() {
       'use strict';
       angular
           .module('smc')
           .controller('trainerSchedulePendingCtrl', trainerSchedulePendingCtrl);
       trainerSchedulePendingCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','TrainingConfig','httpPostFactory','smcConfig','NotifyFactory','$window','$sce'];

       function trainerSchedulePendingCtrl($rootScope,$scope,$state,$cookies,DataService,$http,TrainingConfig,httpPostFactory,smcConfig,NotifyFactory,$window,$sce) {
          $scope.roleName = $cookies.get('roleName');
          $scope.userName = $cookies.get('userName');
          $scope.shownodataavailable = false;
          var trainingConfig = TrainingConfig;
          var trainingSuccessMsg = trainingConfig.servicesuccessmsgs.trainer.pending_schedule;
          if($cookies.get('pageNumber')&& $cookies.get('currentTab') == 'trainerPendingSchedule'){
              $scope.pagenumber = parseInt($cookies.get('pageNumber'));
          }else{
              $scope.pagenumber = 0;
          }
          $scope.dataLength = 10;
          $scope.max_pagenumber = '';
          get_pending_caselist($scope.pagenumber);
          $cookies.put('currentTab','trainerPendingSchedule');
          $scope.$emit('activeTab',$cookies.get('currentTab'));

        // get pending case list
        function get_pending_caselist(pageNumber){
              if(pageNumber){
                  $scope.pagenumber = pageNumber;
              }else{
                  $scope.pagenumber = 0;
              }
              $cookies.put('pageNumber',$scope.pagenumber) 
              var sorting = [[0,0], [1,0]];
            var query = { 
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "memberId":$cookies.get('memberId')
              }
          DataService.post('GetTrainerPendingList',query).then(function (data) {
            if(data.status == 'SUCCESS'){
              $scope.pendingScheduleData = data.result.responseData;
              $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
              var value= Math.round($scope.max_pagenumber);
              if(value < $scope.max_pagenumber){
                  $scope.max_pagenumber = value+1;
              }else{
                  $scope.max_pagenumber = value;
              }
            }else{
                      $scope.shownodataavailable = true;
            }
          }).catch(function (error) {
              $scope.shownodataavailable = true;
          });
        }

          $scope.goToPageNumber = function(pageNo){
             get_pending_caselist(pageNo);
          }

          $scope.openProgramSchedule = function(scheduleId){
            var query = {
              "memberId":$cookies.get('memberId'),
              "scheduleId": scheduleId
            }
            if($scope.roleName.indexOf('Trainer')!= -1){
              var serviceUrl = 'ViewTrainerProgramById';
            }else if($scope.roleName.indexOf('Assessor')!= -1){
              var serviceUrl = 'ViewAssessorProgramById';
            }else if($scope.roleName.indexOf('Coach')!= -1){
              var serviceUrl = 'ViewCoachProgramById';
            }
             openMemberProgramSchedule(serviceUrl,query)
          }

          function openMemberProgramSchedule(serviceUrl,query){
            DataService.post(serviceUrl,query).then(function (data) {
              if(data.status == 'SUCCESS'){
                $scope.programDeatils = data.result;
                $scope.programNameList = [];
                if($scope.roleName.indexOf('Coach')!= -1){
                  for(var prog in $scope.programDeatils.programList){
                    $scope.programNameList.push({"programName":$scope.programDeatils.programList[prog].programName,"programId":$scope.programDeatils.programList[prog].programId});
                    for(var date in $scope.programDeatils.programList[prog].programDates){
                      for(var session in $scope.programDeatils.programList[prog].programDates[date].dateSession){
                        $scope.programDeatils.programList[prog].programDates[date].dateSession[session].isAvalible = 'Yes';
                      }
                    }
                  }
                  $scope.selectedPrograms = $scope.programDeatils.programList[0].programId;
                  $scope.programDates = $scope.programDeatils.programList[0].programDates;
                  $scope.openModetTypeId= '#viewCoachDetails';
                }else{
                  for(var type in $scope.programDeatils.programList){
                    $scope.programDeatils.programList[type].isAvalible = 'Yes'
                  }
                  $scope.openModetTypeId= '#viewDetails';
                }
              }
            }).catch(function (error) {
                  NotifyFactory.log('error',error.errorMessage)  
              });
          }

          $scope.getAvailableDatesByProg = function(selectDateProg){
            for(var program in $scope.programDeatils.programList){
                if($scope.programDeatils.programList[program].programId== selectDateProg){
                    $scope.programDates = $scope.programDeatils.programList[program].programDates;
                }
            }
        }

          $scope.submitAvailablity = function(programData){
            var programList = [];
            for(var prog in programData.programList){
              if(programData.programList[prog].isAvalible == 'Yes'){
                programList.push(programData.programList[prog].programId)
              }
            }
            var query = {
              "memberId":$cookies.get('memberId'),
              "scheduleId":programData.scheduleId,
              "isAvailable":true,
              "programList":programList
            }
            if($scope.roleName.indexOf('Trainer')!= -1){
              var serviceUrl = 'TrainerSubmitAvalaibility';
            }else if($scope.roleName.indexOf('Assessor')!= -1){
              var serviceUrl = 'AssessorSubmitAvalaibility';
            }
            submitMemberavailablityRequest(serviceUrl,query);
          }

          function submitMemberavailablityRequest(serviceUrl,query){
            DataService.post(serviceUrl,query).then(function (data) {
              if(data.status == 'SUCCESS'){
                NotifyFactory.log('success',trainingSuccessMsg.submit_availablity.notify_message) ;
                get_pending_caselist($cookies.get('pageNumber'));
              }
            }).catch(function (error) {
                  NotifyFactory.log('error',error,errorMsg)  
            });
          }

          $scope.submitCoachAvailablity = function(programData){
            var programList = buildCoachQuery(programData);
            var query = {
              "scheduleId" : programData.scheduleId,
              "memberId" : $cookies.get('memberId'),
              "programList" : programList
            }
            console.log(query);
            var serviceUrl = 'CoachSubmitAvalaibility';
            submitMemberavailablityRequest(serviceUrl,query)
          }

          function buildCoachQuery(programData){
            var programList = [];
            for(var prog in programData.programList){
              var dateQuery = {};
              dateQuery.programId = programData.programList[prog].programId;
              dateQuery.programDates = [];
              for(var date in programData.programList[prog].programDates){
                var sessionQuery = {};
                sessionQuery.programDate = programData.programList[prog].programDates[date].programDate;
                sessionQuery.sessionList = [];
                for(var session in programData.programList[prog].programDates[date].dateSession){
                  var singleSession = {};
                  singleSession.sessionId = programData.programList[prog].programDates[date].dateSession[session].id;
                  if(programData.programList[prog].programDates[date].dateSession[session].isAvalible == 'Yes'){
                    singleSession.isAvailable = true;
                  }else{
                    singleSession.isAvailable = false;
                  }
                  sessionQuery.sessionList.push(singleSession);
                }
                dateQuery.programDates.push(sessionQuery);
              }
              programList.push(dateQuery);
            }
            return programList;
          }
   }
})();