/*This Controller for Admin dashboard actions*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adminDashboardCtrl',adminDashboardCtrl);

    adminDashboardCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adminDashboardCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if( $cookies.get('roleName') == "null"){
    		$state.go('smclayout.membershiplayout.memberlogin');
    	}
    	if($cookies.get('roleName') == 'Super Admin'){
            $scope.urlList = { 
                "admin" : [
                    {
                        "label" : "User Management",
                        "url" : "smclayout.membershiplayout.userlist"
                    },
                    {
                        "label" : "Admin Reports",
                        "url" : "smclayout.membershiplayout.adminreports"
                    },
                    {
                        "label" : "Public Calendar",
                        "url" : "smclayout.membershiplayout.publicCalendar"
                    },
                    {
                        "label" : "Code Table",
                        "url" : "smclayout.membershiplayout.codetable"
                    }
                ]
            };
    	}
        if($cookies.get('roleName') == 'SMC Admin'){
            $scope.urlList = { 
                "admin" : [
                    {
                        "label" : "Manage Access",
                        "url" : "smclayout.membershiplayout.userlist"
                    },
                    {
                        "label" : "Public Calendar",
                        "url" : "smclayout.membershiplayout.publicCalendar"
                    }
                ]
            };
    	}
    	
    }
})();	