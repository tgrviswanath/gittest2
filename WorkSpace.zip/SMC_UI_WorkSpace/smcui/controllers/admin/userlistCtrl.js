(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adminUsersListCtrl',adminUsersListCtrl);

    adminUsersListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adminUsersListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('roleName') != "Super Admin" && $cookies.get('roleName') != "SMC Admin") {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'userList'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $scope.ifassigned = false;
    	get_user_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','userList');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to conflicted case list function from outside
        $rootScope.getuserlist = function(){
            get_user_list($cookies.get('pageNumber'));
        } 
        $scope.permisson_status = {};

    	// get rejected case list
    	function get_user_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex": parseInt($scope.pagenumber), 
                 "dataLength":$scope.dataLength, 
                 "sortingColumn": null, 
                 "sortDirection":null, 
                 "name":null, "email":null, 
                 "organisation":null, 
                 "status":null, 
                 "createdDate":null, 
                 "modifiedDate":null,
                 "createdBy":null
    		}
    		DataService.post('AdminGetUserList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.user_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.user_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    

        $scope.goToPageNumber = function(pageNo){
           get_user_list(pageNo);
        } 

        //to open add a user model
        $scope.addUser = function (){
            $scope.userData = {};
            angular.element(".overlay").css("display","block");
            angular.element(".admin-add-user").css("display","block");
        }

        //search user for admin
            $scope.getUser = function(filterDetails){
                var query = {
                "name":filterDetails.userName, 
                "email":filterDetails.userEmail, 
                "organisation":'SMC', 
                "status":filterDetails.userStatus, 
                "createdDate":filterDetails.createdDate, 
                "modifiedDate":filterDetails.modifiedDate
                }
                DataService.post('AdminGetUserList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.user_List = data.result.responseData
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
                }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                });
            }

            //reset users list
            $scope.resetusercases = function(){
                $scope.filter = undefined;
                get_user_list(0);
            }


        //to close add a user model
        $scope.closeaddusermodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".admin-add-user").css("display","none");
        }

        // submit add user 
        $scope.submitAddUser = function(userData){
            console.log('data',userData);
            var query = {
                "name":userData.userName, 
                "applicantUidValue":userData.applicantUidValue, 
                "organizerType":'SMC', 
                "address":{ 
                    "address1":userData.address1, 
                    "address2":undefinedSetNull(userData.address2), 
                    "address3":undefinedSetNull(userData.address3), 
                    "address4":undefinedSetNull(userData.address4), 
                    "postalCode":userData.postalCode
                }, 
                "email":userData.email, 
                "designation":userData.designation,
                "createdBy":$cookies.get('memberId')
            }
            DataService.post('AdminAddaUser',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','User added successfully');
                    get_user_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".admin-add-user").css("display","none");
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
	        });
        }

        //view a single user details
        $scope.viewUser = function(userId){
            var query = {
                "userId" : userId
            }
            DataService.post('GetaSingleUserDetails',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   $scope.userDetails = data.result;
                    if($scope.userDetails.isRoleAssigned == 'No'){
                        NotifyFactory.log('error','User role not assigned')
                    }else{
                        angular.element(".overlay").css("display","block");
                        angular.element(".admin-modify-user").css("display","block");
                    }
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //to close modify a user model
        $scope.closemodifyusermodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".admin-modify-user").css("display","none");
        }

        //update user status
        $scope.updateuserstatus = function(modifyData){
            var query = {
                "userId": modifyData.userId, 
                "userStatus": modifyData.staffStatus, 
                "modifiedBy": $cookies.get('memberId')
            }
            var successMsg = 'User status updated as '+modifyData.staffStatus;
            DataService.post('AdminUserStatusUpdate',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success',successMsg);
                    get_user_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".admin-modify-user").css("display","none");
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
	        });
        }

        $scope.maprole = {};
        //open assign role in SMC Admin 
        $scope.openMapRole = function(userId,userName){
            $scope.userId = userId;
            $scope.user_name = userName;
            $scope.maprole = {};
            $scope.ifassigned = false;
            $rootScope.submitRoleAccess = undefined;
            get_Modules_Roles();
            angular.element(".overlay").css("display","block");
            angular.element(".admin-map-role").css("display","block");
        }

        //open update or view assigned role for a user in SMC Admin 
        $scope.openUpdateMapRole = function(userId,userName){
            $scope.userId = userId;
            $scope.user_name = userName;
            var query = { 
                "userId" : userId
            }
            DataService.post('GetAssignedRoles',query).then(function (data) {
                var modules = ['adjudication','mediation','admin','training','contact']
    			if(data.status == 'SUCCESS'){
                    $scope.ifassigned = true;
    				$scope.maprole = data.result;
                    $rootScope.submitAccessess = []
                    for(var mod in modules){
                        if($scope.maprole[modules[mod]]){
                            getAssignedAccess(modules[mod],$scope.maprole[modules[mod]].roleName,$scope.maprole.userId)
                        }
                    }                
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
	        });
            get_Modules_Roles();
            angular.element(".overlay").css("display","block");
            angular.element(".admin-map-role").css("display","block");
        } 

        //get assigned access
        function getAssignedAccess(module,role,userId){
            var query = {
                "userId":userId, 
                "moduleName":module, 
                "roleName":role
            }
            DataService.post('GetAssignedAccess',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    var query = {
                        "module" : module,
                        "role" : role,
                        "accesses" : data.results,
                        "isAssigned" : true
                    }
                    $rootScope.submitAccessess.push(query);
                }
            }).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
            });
        }
        //close map role in SMC Admin
        $scope.closemaprole =function() {
            angular.element(".overlay").css("display","none");
            angular.element(".admin-map-role").css("display","none");
        }

       $scope.removeAccess = function(moduleName){
            $scope.maprole[moduleName] = undefined;
            for (var access in $rootScope.submitAccessess){
                if(moduleName == $rootScope.submitAccessess[access].module){
                    $rootScope.submitAccessess[access].isAssigned = false;
                }
            }
       }

        //get modules and role
        function get_Modules_Roles(){
            DataService.get('AdminGetModulesRoles').then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.modules = data.results
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
	        });
        }

        $rootScope.accessRights = [];

        $scope.userRights = function(moduleName,roleName,modelopenstatus){
            
            $scope.viewrole = roleName;
            $scope.viewModule = moduleName;
            var query = {
                "moduleName":moduleName, 
                "roleName":roleName
            }
            DataService.post('AdminGetRoleRights',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.user_rights = data.results;
                    if($rootScope.submitAccessess.length == 0 || $rootScope.submitAccessess == undefined){
                        $scope.permisson_check_status = [];
                        $rootScope.accessRights = [];
                        $scope.permisson_status = {};
                        for(var rights in $scope.user_rights){
                            $scope.permisson_status[$scope.user_rights[rights]] = 'Yes'
                            var access = {
                                "accessName":$scope.user_rights[rights], 
                                "accessValue":"Y"
                            }
                            $rootScope.accessRights.push(access);
                        }
                    }else{
                        var alreadyChanged = false;
                        var changedIndex = '';
                        for(var module in $rootScope.submitAccessess){
                            if($rootScope.submitAccessess[module].module == $scope.viewModule.toLowerCase()){
                                if($rootScope.submitAccessess[module].role == $scope.viewrole){
                                    alreadyChanged = true;
                                    changedIndex = module;
                                    break;
                                }
                            }
                        }
                        if(alreadyChanged){
                            for(var rights in $scope.user_rights){
                                for(var subaccess in $rootScope.submitAccessess[changedIndex].accesses){
                                    var a= 0;
                                    if($scope.user_rights[rights] == $rootScope.submitAccessess[changedIndex].accesses[subaccess].accessName){
                                        if($rootScope.submitAccessess[changedIndex].accesses[subaccess].accessValue == 'Y'){
                                            var a= 1;
                                        }
                                       break;
                                    }
                                }
                                if(a == 1){
                                    $scope.permisson_status[$scope.user_rights[rights]] = 'Yes'
                                }else{
                                    $scope.permisson_status[$scope.user_rights[rights]] = 'No'
                                }
                            }
                            $rootScope.accessRights = $rootScope.submitAccessess[changedIndex].accesses;
                        }else{
                            $scope.permisson_check_status = [];
                            $rootScope.accessRights = [];
                            $scope.permisson_status = {};
                            for(var rights in $scope.user_rights){
                                $scope.permisson_status[$scope.user_rights[rights]] = 'Yes'
                                var access = {
                                    "accessName":$scope.user_rights[rights], 
                                    "accessValue":"Y"
                                }
                                $rootScope.accessRights.push(access);
                            }
                        }
                    }
                    if(modelopenstatus){
                        angular.element(".overlay").css("display","block");
                        angular.element(".admin-map-role").css("display","none");
                        angular.element(".users-role-rights").css("display","block");
                    }
                }
            }).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.closerightsmodel = function(){
            angular.element(".admin-map-role").css("display","block");
            angular.element(".users-role-rights").css("display","none");
        }

        $scope.changeValue = function(value,rights,viewModule,arrayRights){
            if(value){
                $scope.permisson_status[rights] = 'Yes'
                var access = {
                    "accessName":rights, 
                    "accessValue":"Y"
                }
                arrayRights.push(access);
                console.log('accessRights',$rootScope.accessRights)
            }else{
                $scope.permisson_status[rights] = 'No'
                for(var access in arrayRights){
                    if(arrayRights[access].accessName == rights){
                       arrayRights.splice(access,1)
                    }
                }
                console.log('accessRights',$rootScope.accessRights)
            }
        }
        $rootScope.submitAccessess = [];

        $scope.submituserrightsstatus = function(accesses,role,module){
            $scope.newModule = module;
            $scope.newRole = role;
            if($rootScope.submitAccessess.length == 0 || $rootScope.submitAccessess == undefined){
               var query = {
                    "module" :  $scope.newModule.toLowerCase(),
                    "role" : $scope.newRole,
                    "accesses" : accesses,
                    "isAssigned" : true
                }
                $rootScope.submitAccessess.push(query);
            }else{
                var ifSame = true;
                var moduleIndex = '';
                for(var module in $rootScope.submitAccessess){
                    if($rootScope.submitAccessess[module].module == $scope.newModule){
                       ifSame = false;
                       moduleIndex = module;
                       break;
                    }
                }
                if(ifSame){
                    var query = {
                        "module" :  $scope.newModule.toLowerCase(),
                        "role" : $scope.newRole,
                        "accesses" : accesses,
                        "isAssigned" : true
                    }
                    $rootScope.submitAccessess.push(query);
                }else{
                    $rootScope.submitAccessess.splice(moduleIndex,1);
                    var query = {
                        "module" :  $scope.newModule.toLowerCase(),
                        "role" : $scope.newRole,
                        "accesses" : accesses,
                        "isAssigned" : true
                    }
                    $rootScope.submitAccessess.push(query);
                }
            }
            console.log('submitAccessess',$rootScope.submitAccessess)
            angular.element(".admin-map-role").css("display","block");
            angular.element(".users-role-rights").css("display","none");
        }

        $scope.maprole = {};

        $scope.submitmapRole = function(userId){
            if($rootScope.submitAccessess.length != 0){
                var query = {
                    "userId":userId, 
                    "assignedBy":$cookies.get('memberId')
                }
                for(var mod in $rootScope.submitAccessess){
                    query[$rootScope.submitAccessess[mod].module] = {
                        "roleName":$rootScope.submitAccessess[mod].role, 
                        "isAssigned" : $rootScope.submitAccessess[mod].isAssigned, 
                        "accessRights": $rootScope.submitAccessess[mod].accesses
                    }
                }
                console.log('query',query)
                DataService.post('AdminSubmitMapRoles',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success','Roles assigned successfully');
                        get_user_list($cookies.get('pageNumber'));
                        angular.element(".overlay").css("display","none");
                       angular.element(".assign-save-confirmation").css("display","none");
                    }
                }).catch(function (error) {
                   NotifyFactory.log('error',error.errorMessage)
                });
            }
            else{
                NotifyFactory.log('error','No role assigned');
            }
        }

        $scope.submitupdatemapRole = function(userId){
            if($rootScope.submitAccessess.length != 0){
                var query = {
                    "userId":userId, 
                    "assignedBy":$cookies.get('memberId'), 
                }
                for(var mod in $rootScope.submitAccessess){
                    query[$rootScope.submitAccessess[mod].module.toLowerCase()] = {
                        "roleName":$rootScope.submitAccessess[mod].role, 
                        "isAssigned" :$rootScope.submitAccessess[mod].isAssigned, 
                        "accessRights": $rootScope.submitAccessess[mod].accesses
                    }
                }
                console.log('query',query)
                DataService.post('AdminSubmitUpdateMapRoles',query).then(function (data) {
        			if(data.status == 'SUCCESS'){
        				NotifyFactory.log('success','Roles updated successfully');
                        get_user_list($cookies.get('pageNumber'));
                        angular.element(".overlay").css("display","none");
                        angular.element(".assign-save-confirmation").css("display","none");
        			}
        		}).catch(function (error) {
                   NotifyFactory.log('error',error.errorMessage)
    	        });
            }
            else{
                NotifyFactory.log('error','No role assigned');
            }
        }

        $scope.askConfirmation = function (userId){
            $scope.userId = userId;
             angular.element(".overlay").css("display","block");
              angular.element(".admin-map-role").css("display","none");
            angular.element(".assign-save-confirmation").css("display","block");
        }
        $scope.closeassignconfirmmodel = function(){
            angular.element(".overlay").css("display","block");
            angular.element(".assign-save-confirmation").css("display","none");
              angular.element(".admin-map-role").css("display","block");
            
        }
        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


