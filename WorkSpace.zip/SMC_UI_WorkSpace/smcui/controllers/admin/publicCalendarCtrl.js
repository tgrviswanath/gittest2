(function() {
    'use strict';
    angular
        .module('smc')
        .controller('publicCalendarCtrl',publicCalendarCtrl);

    publicCalendarCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$compile'];

    function publicCalendarCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$compile){
        if ($cookies.get('roleName') != "Super Admin" && $cookies.get('roleName') != "SMC Admin") {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }

        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'userList'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	
        $rootScope.eventSources = [];
        getPublicEventList();

        $rootScope.events = [];
        $rootScope.calEventsExt = {
                                color: '#f00',
                                textColor: 'yellow',
                                events: []
                              };
        function getPublicEventList(){
          $rootScope.events = [];
          $rootScope.calEventsExt = {
                                color: '#f00',
                                textColor: 'yellow',
                                events: []
                              };
          DataService.get('AdminGetEvents').then(function (data) {
            
            if(data.status == 'SUCCESS'){
              $scope.getEvents = data.results;
              for(var event in $scope.getEvents){
                var date = $scope.getEvents[event].date;
                var splitdates = date.split('-');
                $scope.getEvents[event].date = splitdates[2]+'-'+splitdates[1]+'-'+splitdates[0];
                $scope.getEvents[event].title = $scope.getEvents[event].leaveType;
              }
              for(var event in $scope.getEvents){
                if($scope.getEvents[event].leaveType == 'Full Day'){
                  $rootScope.events.push($scope.getEvents[event]);
                  console.log($rootScope.events);
                }else{
                  $rootScope.calEventsExt.events.push($scope.getEvents[event]);
                  console.log($rootScope.calEventsExt);
                }
              }
            }
          }).catch(function (error) {
                NotifyFactory.log('error',error.data.errorMsg)
            });
        }
        var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();

    
    
    /* event source that calls a function on every view switch */
    $rootScope.eventsF = function (start, end, timezone, callback) {
      var s = new Date(start).getTime() / 1000;
      var e = new Date(end).getTime() / 1000;
      var m = new Date(start).getMonth();
      var events = [{title: 'Feed Me ' + m,start: s + (50000),end: s + (100000),allDay: false, className: ['customFeed']}];
      callback(events);
    };

    /* alert on eventClick */
    $scope.dayClick = function( date, jsEvent, view){
        var dateDis = moment(date).format('DD-MM-YYYY');
        $scope.clickedDate = dateDis;
        $scope.event = {};
        angular.element(".overlay").css("display","block");
        angular.element(".add-event-date").css("display","block");
        
    };

    $scope.closeaddeventmodel = function(){
      angular.element(".overlay").css("display","none");
      angular.element(".add-event-date").css("display","none");
    }
    /* alert on eventClick */
    $scope.alertOnEventClick = function( date, jsEvent, view){
        $scope.modifyevent = date;
        angular.element(".overlay").css("display","block");
        angular.element(".modify-event-date").css("display","block");
    };
    /* alert on Drop */
     $scope.alertOnDrop = function(event, delta, revertFunc, jsEvent, ui, view){
       $scope.alertMessage = ('Event Droped to make dayDelta ' + delta);
       console.log ($scope.alertMessage);
    };
    /* alert on Resize */
    $scope.alertOnResize = function(event, delta, revertFunc, jsEvent, ui, view ){
       $scope.alertMessage = ('Event Resized to make dayDelta ' + delta);
    };
    /* add and removes an event source of choice */
    $scope.addRemoveEventSource = function(sources,source) {
      var canAdd = 0;
      angular.forEach(sources,function(value, key){
        if(sources[key] === source){
          sources.splice(key,1);
          canAdd = 1;
        }
      });
      if(canAdd === 0){
        sources.push(source);
      }
    };
    /* add custom event*/
    $scope.addEvent = function() {
      $rootScope.events.push({
        title: 'Open Sesame',
        start: new Date(y, m, 28),
        end: new Date(y, m, 29),
        className: ['openSesame']
      });
    };
    /* remove event */
    $scope.remove = function(index) {
      $rootScope.events.splice(index,1);
    };
    /* Change View */
    $scope.changeView = function(view,calendar) {
      uiCalendarConfig.calendars[calendar].fullCalendar('changeView',view);
    };
    /* Change View */
    $scope.renderCalender = function(calendar) {
      if(uiCalendarConfig.calendars[calendar]){
        uiCalendarConfig.calendars[calendar].fullCalendar('render');
      }
    };
     /* Render Tooltip */
    $scope.eventRender = function( event, element, view ) { 
        element.attr({'tooltip': event.title,
                     'tooltip-append-to-body': true});
        $compile(element)($scope);
    };
    /* config object */
    $scope.uiConfig = {
      calendar:{
        height: 450,
        editable: true,
        header:{
          left: 'title',
          center: '',
          right: 'today prev,next'
        },
        eventClick: $scope.alertOnEventClick,
        eventDrop: $scope.alertOnDrop,
        eventResize: $scope.alertOnResize,
        eventRender: $scope.eventRender,
        dayClick: $scope.dayClick
      }
    };


    $scope.submitAddEvent = function(event,date){
      var query = {
        "addedBy":$cookies.get('memberId'), 
        "calendarDates":[ 
            { 
              "date":date, 
              "leaveType" : event.leaveType, 
              "eventAction": event.eventAction 
            }
        ]
      }
      DataService.post('AdminAddEvents',query).then(function (data) {
        if(data.status == 'SUCCESS'){
          NotifyFactory.log('success','Event added successfully');
          getPublicEventList();
          location.reload();
          angular.element(".overlay").css("display","none");
          angular.element(".add-event-date").css("display","none");
        }
      }).catch(function (error) {
            NotifyFactory.log('error',error.errorMessage)
        });
    }

    $scope.confirmremoveeventmodel = function(id){
      var RemoveEventUrl = smcConfig.services.RemoveEvent.url;
      RemoveEventUrl = RemoveEventUrl + id;
      $http.get(RemoveEventUrl).then(function(data){
            NotifyFactory.log('success','Event removed successfully');
            getPublicEventList();
            location.reload();
            angular.element(".overlay").css("display","none");
            angular.element(".confirmation-delete-event-date").css("display","none");
        });
    }

    $scope.removeEventmodel = function(id){
      $scope.eventId = id;
      angular.element(".overlay").css("display","block");
      angular.element(".modify-event-date").css("display","none");
      angular.element(".confirmation-delete-event-date").css("display","block");
    }

    $scope.closeconfirmmodel = function(){
      angular.element(".overlay").css("display","none");
      angular.element(".confirmation-delete-event-date").css("display","none");
    }

    $scope.closemodifyeventmodel = function(){
      angular.element(".overlay").css("display","none");
      angular.element(".modify-event-date").css("display","none");
    }

    $scope.submitUpdateEvent = function(modifyData){
      var date = modifyData.date;
      var splitdates = date.split('-');
      modifyData.date = splitdates[2]+'-'+splitdates[1]+'-'+splitdates[0];
      var query = {
        "addedBy":$cookies.get('memberId'), 
        "calendarDates":[ 
            { 
              "date":modifyData.date, 
              "leaveType" : modifyData.leaveType, 
              "eventAction": modifyData.eventAction 
            }
        ]
      }
      DataService.post('AdminUpdateEvents',query).then(function (data) {
        if(data.status == 'SUCCESS'){
          NotifyFactory.log('success','Event added successfully');
          getPublicEventList();
          location.reload();
          angular.element(".overlay").css("display","none");
          angular.element(".modify-event-date").css("display","none");
        }
      }).catch(function (error) {
            NotifyFactory.log('error',error.errorMessage)
        });
    }

    /* event sources array*/
    $rootScope.eventSources = [$rootScope.calEventsExt, $rootScope.eventsF, $rootScope.events];

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


