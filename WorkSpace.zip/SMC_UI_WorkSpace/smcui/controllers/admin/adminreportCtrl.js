   (function() {
       'use strict';
       angular
           .module('smc')
           .controller('adminReportsCtrl', adminReportsCtrl);
       adminReportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

       function adminReportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory) {
         
              if ($cookies.get('roleName') != "Super Admin" && $cookies.get('roleName') != "SMC Admin") {
                 $state.go('smclayout.membershiplayout.memberlogin');
              }
             $scope.shownodataavailable = false;
              $scope.roleName = $cookies.get('roleName');
              if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'adminReportList'){
                  $scope.pagenumber = parseInt($cookies.get('pageNumber'));
              }else{
                  $scope.pagenumber = 0;
              }
              $scope.dataLength = 10;
              $scope.max_pagenumber = '';
              get_report_list($scope.pagenumber);//call to conflicted case list function
              $cookies.put('currentTab','adminReportList');
              $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
            // get rejected case list
              function get_report_list(pageNumber){
                  if(pageNumber){
                      $scope.pagenumber = pageNumber;
                  }else{
                      $scope.pagenumber = 0;
                  }
                  $cookies.put('pageNumber',$scope.pagenumber)
                var query = {
                        "pageIndex": parseInt($scope.pagenumber), 
                        "dataLength":$scope.dataLength, 
                        "sortingColumn": null, 
                        "sortDirection":null, 
                        "name":null, 
                        "status":null, 
                        "module":null, 
                        "role":null, 
                        "createdDate":null
                }
                adminGetAll_Reports(query);
              }

              function adminGetAll_Reports(query){
                  DataService.post('AdminGetReportList',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        $scope.report_List = data.result.responseData;
                        $scope.shownodataavailable = false;
                        $scope.max_pagenumber = data.result.totalPages;
                        if($scope.report_List.length == 0){
                            $scope.shownodataavailable = true;
                        }
                    }else{
                              $scope.shownodataavailable = true;
                    }
                  }).catch(function (error) {
                          if(error.errorCode == 100){
                              $scope.shownodataavailable = true;
                          }
                    });
              }
          

              $scope.goToPageNumber = function(pageNo){
                if(!$scope.filter){
                 get_report_list(pageNo);
                }else{
                  $cookies.put('pageNumber',pageNo);
                  $scope.pagenumber = pageNo;
                  var query = {
                    "pageIndex": parseInt(pageNo), 
                    "dataLength":$scope.dataLength, 
                    "name":undefinedSetNull($scope.filter.userName), 
                    "organisation":undefinedSetNull($scope.filter.organization), 
                    "status":undefinedSetNull($scope.filter.userStatus), 
                    "createdDate":undefinedSetNull($scope.filter.createdDate),
                    "module":undefinedSetNull($scope.filter.module), 
                    "role":undefinedSetNull($scope.filter.role),  
                    }
                    adminGetAll_Reports(query)
                }
              } 

              //search user for admin
            $scope.getReports = function(filterDetails){
                $cookies.put('pageNumber',0)
                var query = {
                "pageIndex": parseInt(0), 
                "dataLength":$scope.dataLength, 
                "name":undefinedSetNull(filterDetails.userName), 
                "organisation":undefinedSetNull(filterDetails.organization), 
                "status":undefinedSetNull(filterDetails.userStatus), 
                "createdDate":undefinedSetNull(filterDetails.createdDate),
                "module":undefinedSetNull(filterDetails.module), 
                "role":undefinedSetNull(filterDetails.role),  
                }
                adminGetAll_Reports(query)
            }

              //reset users list
            $scope.resetreports = function(){
                $scope.filter = undefined;
                $scope.roles = [];
                get_report_list(0);
            }


              getModuleList();
               function getModuleList(){
                  DataService.get('GetAllModules').then(function (data) {
                    if(data.status == 'SUCCESS'){
                        $scope.module_List = data.results;
                    }
                  }).catch(function (error) {
                       NotifyFactory.log('error',error.errorMsg)   
                  });
               }

               $scope.getRoles = function(moduleName){
                  var GetRolesFromModuleUrl = smcConfig.services.GetRolesFromModule.url;
                  GetRolesFromModuleUrl = GetRolesFromModuleUrl + moduleName;
                  $http.get(GetRolesFromModuleUrl).then(function(data){
                        console.log("data",data)
                        $scope.roles = data.data.results;
                      });
               }

               function undefinedSetNull(val){
                    if(val){
                        return val;
                    } else {
                        var val = null;
                        return val;
                    }
                    return val;
                }
       }
   })();