(function () {
    'use strict';
    angular
        .module('smc')
        .controller('profileCtrl', profileCtrl);

    profileCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function profileCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {

        var memberprofile = smcConfig.services.ViewMemberProfileDetails.url;
        var member_login_id = $cookies.get('memberId');
        var memberprofileurl = memberprofile + member_login_id;
        $http.get(memberprofileurl).then(function (response) {
            $scope.profiledata = response.result;
            console.log($scope.profiledata);
        });
        var fileInput = $('.upload-file');
        var maxSize = fileInput.data('max-size');
        $scope.single = function (image) {
            console.log("enterd");
            var formData = new FormData();
            formData.append('image', image, image.name);
            if (fileInput.get(0).files.length) {
                var fileSize = fileInput.get(0).files[0].size; // in bytes
                if (fileSize > maxSize) {
                    alert('file size is more then' + maxSize + ' bytes');
                    return false;
                } else {
                    alert('file size is correct- ' + fileSize + ' bytes');
                }
            } else {
                alert('choose file, please');
                return false;
            }
            // $http.post('upload', formData, {
            //     headers: {
            //         'Content-Type': false
            //     },
            //     transformRequest: angular.identity
            // }).success(function (result) {
            //     $scope.uploadedImgSrc = result.src;
            //     $scope.sizeInBytes = result.size;
            // });
        };

    }
})();
