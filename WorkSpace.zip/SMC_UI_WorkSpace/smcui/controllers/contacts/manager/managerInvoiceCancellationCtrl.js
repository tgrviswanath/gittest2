(function() {
    'use strict';
    angular
        .module('smc')
        .controller('managerInvoiceCancellationCtrl',managerInvoiceCancellationCtrl);

    managerInvoiceCancellationCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function managerInvoiceCancellationCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('moduleName') != 'Contact' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getinvoicelist($scope.pagenumber);//call function
        $scope.shownodataavailable = false;
        
    	
    	function getinvoicelist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
                "loginId": $cookies.get('memberId'),
    			"pageIndex":$scope.pagenumber, 
    			"dataLength":$scope.dataLength, 
    			"sortingColumn":null, 
    			"sortDirection":null, 
    		}
    		DataService.post('GetCancellationInvoiceListByManager',query).then(function (data) {
    			 $scope.invoiceList = data.result.responseData;
                 $scope.max_pagenumber = data.result.totalPages;
                 if($scope.memberships.length == 0){
                    $scope.shownodataavailable = true;
                }
    		})
    		.catch(function(error){
    			console.log('errorlist',error)
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getinvoicelist(pageNo);
        }

        $scope.actionOnInvoice = function (membershipId,actionType){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId": $cookies.get('memberId'),
                "status": undefinedSetNull(actionType),
                "membershipId": undefinedSetNull(membershipId)
            }
            if(actionType == 'APPROVED'){
                var successMessage = 'Invoice cancellation approved successfully';
            }else{
                var successMessage = 'Invoice cancellation rejected successfully';
            }
            DataService.post('ActionCancellationInvoiceListByManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',successMessage);
                    getinvoicelist($cookies.get('pageNumber'));
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".overlay").css("display","none");
            });
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();