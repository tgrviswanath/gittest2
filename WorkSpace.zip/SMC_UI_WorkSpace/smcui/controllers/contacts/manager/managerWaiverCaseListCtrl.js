(function() {
    'use strict';
    angular
        .module('smc')
        .controller('managerWaiverCaseListCtrl',managerWaiverCaseListCtrl);

    managerWaiverCaseListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function managerWaiverCaseListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('moduleName') != 'Contact' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_waiver_case_list($scope.pagenumber);//call function
        $scope.shownodataavailable = false;
        
    	
    	function get_waiver_case_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
    			"loginId": $cookies.get('memberId'),
                "waiverStatus": true,
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null
    		}
    		DataService.post('GetWaiverListByManager',query).then(function (data) {
    			 $scope.waiverCaseList = data.result.responseData;
                 $scope.remarkData = {};
                 $scope.max_pagenumber = data.result.totalPages;
                 if($scope.waiverCaseList.length == 0){
                    $scope.shownodataavailable = true;
                }
    		})
    		.catch(function(error){
    			console.log('errorlist',error)
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           get_waiver_case_list(pageNo);
        }

        $scope.actionOnWaiverReport = function (remarkData,waiverData,actionType){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = buildActionQuery(remarkData,waiverData,actionType);
            if(actionType == 'Approve'){
                var successMessage = 'Waivers request approved successfully';
            }else{
                var successMessage = 'Waivers requested for change successfully';
            }
            DataService.post('GetWaiverListByManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',successMessage);
                    get_waiver_case_list($cookies.get('pageNumber'));
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".overlay").css("display","none");
            });
        }

        function buildActionQuery(remarkData,waiverData,actionType){
            var memberIdList = [];
            for(var member in waiverData){
                memberIdList.push(waiverData[member].memberId)
            }
            var query = {
                "loginId": $cookies.get('memberId'),
                "membershipRenewalWaiverIds" : memberIdList,
                "renewalRemarkId": undefinedSetNull(remarkData.renewalRemarkId),
                "approverRemarks": undefinedSetNull(remarkData.approverRemarks), 
                "approvalStatus": undefinedSetNull(actionType)        
            }
            return query;
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();