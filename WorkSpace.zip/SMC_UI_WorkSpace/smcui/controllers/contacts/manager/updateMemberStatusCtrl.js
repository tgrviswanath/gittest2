(function() {
    'use strict';
    angular
        .module('smc')
        .controller('updateMemberStatusCtrl',updateMemberStatusCtrl);

    updateMemberStatusCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function updateMemberStatusCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('moduleName') != 'Contact' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getmembershiplist($scope.pagenumber);//call function
        $scope.shownodataavailable = false;
        $scope.fullStatus = ['Active','Struck Off','Suspended','Canceled'];
        
    	
    	function getmembershiplist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
    			"pageIndex":$scope.pagenumber, 
    			"dataLength":$scope.dataLength, 
    			"sortingColumn":null, 
    			"sortDirection":null, 
    		}
    		DataService.post('GetUpdateMemberStatusList',query).then(function (data) {
    			 $scope.memberships = data.result.responseData;
                 $scope.max_pagenumber = data.result.totalPages;
                 if($scope.memberships.length == 0){
                    $scope.shownodataavailable = true;
                }
    		})
    		.catch(function(error){
    			console.log('errorlist',error)
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getmembershiplist(pageNo);
        }

        $scope.openViewData = function (membershipData){
            $scope.changeData = membershipData;
            $scope.currentStatus = [];
            $scope.minDateLimit = $scope.changeData.suspendedFrom;
            getComplaints($scope.changeData.smcMemberId,$scope.changeData.memberRoleId);
            for(var status in $scope.fullStatus){
                if($scope.fullStatus[status] != $scope.changeData.oldMemberStatus){
                    $scope.currentStatus.push($scope.fullStatus[status]);
                }
            }
            angular.element(".overlay").css("display","block");
            angular.element(".membership-change-status").css("display","block");
        }

        function getComplaints(memberId,roleId){
            var query = {
                "loginId": $cookies.get('memberId'),
                "memberRoleId": memberId,
                "memberId": roleId
            }
            DataService.post('GetComplaintsByManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.complaints = data.results;
                }
            });
        }

        $scope.suspendFromDateClick = function(){
            var fromDate = $scope.changeData.suspendedFrom;
            $scope.minDateLimit = fromDate;
            $scope.changeData.suspendedTo = '';
            $( "#suspendPeriodTo" ).datepicker( "option", "minDate",fromDate );
        }
        
        $scope.closeChange = function(){
            $scope.changeData = {};
            angular.element(".membership-change-status").css("display","none");
            angular.element(".overlay").css("display","none");
        }

        $scope.actionChangeStatus = function(approvalData,status){
            var query = {
                "loginId": $cookies.get('memberId'),
                "membershipStatusHistoryId":undefinedSetNull(approvalData.id),
                "memberStatus": undefinedSetNull(approvalData.newMemberStatus),
                "complaintNumber": undefinedSetNull(approvalData.complaintNumber),
                "suspendedFrom": undefinedSetNull(approvalData.suspendedFrom),
                "suspendedTo": undefinedSetNull(approvalData.suspendedTo),
            }
            if(status == 'Approve'){
                query.isApproved = true;
                var successMessage = 'Member status change request approved successfully';
            }else{
                query.isApproved = false;
                var successMessage = 'Member status change request rejected successfully';
            }
            changeActionService(query,successMessage);
        }

        function changeActionService(query,successMessage){
            angular.element(".membership-change-status").css("display","none");
            angular.element(".loading-container").css("display","block");
            DataService.post('ChangeActionStatusManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',successMessage)
                    getmembershiplist($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {  
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".membership-change-status").css("display","block");
            });
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();