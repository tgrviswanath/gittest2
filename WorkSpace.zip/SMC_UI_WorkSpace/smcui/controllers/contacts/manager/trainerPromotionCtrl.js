(function() {
    'use strict';
    angular
        .module('smc')
        .controller('trainerPromotionCtrl',trainerPromotionCtrl);

    trainerPromotionCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function trainerPromotionCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('moduleName') != 'Contact' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
       
        $scope.pagenumber = 0;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getPromoteTrainerList($scope.pagenumber);//call function
        $scope.shownodataavailable = false;

        DataService.get('GetTrainerCategoryMasterData').then(function (response) {
            $scope.trainerCategoryList = response.results;                
        }).catch(function (error) {
            NotifyFactory.log('error',error.errorMessage);
        });
        
    	
    	function getPromoteTrainerList(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
                "loginId": $cookies.get('memberId'),
    			"pageIndex":$scope.pagenumber, 
    			"dataLength":$scope.dataLength, 
    			"sortingColumn":null, 
    			"sortDirection":null, 
    		}
    		DataService.post('GetPromoteTrainerListByManager',query).then(function (data) {
    			 $scope.promoteList = data.result.responseData;
                 $scope.max_pagenumber = data.result.totalPages;
                 if($scope.promoteList.length == 0){
                    $scope.shownodataavailable = true;
                }
    		})
    		.catch(function(error){
    			console.log('errorlist',error)
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getmembershiplist(pageNo);
        }

        $scope.openViewData = function (promoteData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "memberId": promoteData.memberId
            }
            DataService.post('GetPromoteTrainerDetails',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.promoteData = data.result;
                    $scope.promoteData.memberId = promoteData.memberId;
                    $scope.promoteTrainerCategoryList = [];
                    var findCategory = -1;
                    for(var cat in $scope.trainerCategoryList){
                        if($scope.trainerCategoryList[cat].name.toUpperCase().split(' ').join('_') == $scope.promoteTrainerData.category){
                            $scope.promoteData.newRole = $scope.trainerCategoryList[cat];
                        }
                    }
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
            });
            angular.element(".overlay").css("display","block");
            angular.element(".manager-view-promote-details").css("display","block");
        }

        $scope.cancelviewData = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".manager-view-promote-details").css("display","none");
        }

        $scope.actionOnPromote = function(approveData,actionType){
            angular.element(".manager-view-promote-details").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = buildPromoteQuery(approveData,actionType);
            if(actionType == 'APPROVED'){
                var successMessage = 'Promote trainer request approved successfully';
            }else{
                var successMessage = 'Promote trainer request rejected successfully';
            }
            DataService.post('ActionPromoteTrainerByManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',successMessage);
                    getPromoteTrainerList($cookies.get('pageNumber'))
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".manager-view-promote-details").css("display","block");
            });
        }

        function buildPromoteQuery(approveData,actionType){
            var query = {
                "loginId": $cookies.get('memberId'),
                "memberId": undefinedSetNull(approveData.memberId),
                "promotionId": undefinedSetNull(approveData.memberPromotionId),
                "status": undefinedSetNull(actionType)
            }
            return query;
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();