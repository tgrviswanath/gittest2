(function() {
    'use strict';
    angular
        .module('smc')
        .controller('mediatorCalendarCtrl',mediatorCalendarCtrl);

    mediatorCalendarCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$compile'];

    function mediatorCalendarCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$compile){
        
        $cookies.put('currentTab', 'mediatorCalandar');
        $rootScope.currentTab=$cookies.get('currentTab')
    	
        $rootScope.mediatorDates = [];
        getMediatorDateList();

        $rootScope.events = [];
        $rootScope.calEventsExt = {
                                color: '#f00',
                                textColor: 'yellow',
                                events: []
                              };
        function getMediatorDateList(){
          $rootScope.events = [];
          $rootScope.calEventsExt = {
                                color: '#f00',
                                textColor: 'yellow',
                                events: []
                              };
          var query = {
            "loginId": $cookies.get('memberId')
          }         
          DataService.post('GetMediatorCalanderData',query).then(function (data) {
            
            if(data.status == 'SUCCESS'){
                if(data.result.mediationDates){
                  $scope.mediationDates = data.result.mediationDates.split(',');
                  for(var dates in $scope.mediationDates){
                    var date = $scope.mediationDates[dates];
                    var splitdates = date.split('-');
                    $scope.mediationDates[dates] = {};
                    $scope.mediationDates[dates].date = splitdates[2]+'-'+splitdates[1]+'-'+splitdates[0];
                    $scope.mediationDates[dates].title = 'Mediation';
                  }
                  console.log($scope.mediationDates)
                  for(var module in $scope.mediationDates){
                    $rootScope.events.push($scope.mediationDates[module]);
                    console.log($rootScope.events);
                  }
                }
                if(data.result.training){
                  $scope.trainingDates = data.result.training.split(',');
                  for(var dates in $scope.trainingDates){
                    var date = $scope.trainingDates[dates];
                    var splitdates = date.split('-');
                    $scope.trainingDates[dates] = {};
                    $scope.trainingDates[dates].date = splitdates[2]+'-'+splitdates[1]+'-'+splitdates[0];
                    $scope.trainingDates[dates].title = 'Training';
                  }
                  for(var module in $scope.trainingDates){
                    $rootScope.calEventsExt.events.push($scope.trainingDates[module]);
                    console.log($rootScope.calEventsExt);
                  }
                }   
            }
          }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }
        var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();


    
    /* event source that calls a function on every view switch */
    $rootScope.eventsF = function (start, end, timezone, callback) {
      var s = new Date(start).getTime() / 1000;
      var e = new Date(end).getTime() / 1000;
      var m = new Date(start).getMonth();
      var events = [{title: 'Feed Me ' + m,start: s + (50000),end: s + (100000),allDay: false, className: ['customFeed']}];
      callback(events);
    };

    /* alert on eventClick */
    $scope.dayClick = function( date, jsEvent, view){
        var dateDis = moment(date).format('DD-MM-YYYY');
        $scope.clickedDate = dateDis;
        $scope.event = {};
    };
    /* alert on eventClick */
    $scope.alertOnEventClick = function( date, jsEvent, view){
        $scope.modifyevent = date;
    };

    /* alert on Drop */
     $scope.alertOnDrop = function(event, delta, revertFunc, jsEvent, ui, view){
       $scope.alertMessage = ('Event Droped to make dayDelta ' + delta);
       console.log ($scope.alertMessage);
    };
    /* alert on Resize */
    $scope.alertOnResize = function(event, delta, revertFunc, jsEvent, ui, view ){
       $scope.alertMessage = ('Event Resized to make dayDelta ' + delta);
    };
    /* add and removes an event source of choice */
    $scope.addRemoveEventSource = function(sources,source) {
      var canAdd = 0;
      angular.forEach(sources,function(value, key){
        if(sources[key] === source){
          sources.splice(key,1);
          canAdd = 1;
        }
      });
      if(canAdd === 0){
        sources.push(source);
      }
    };
    /* add custom event*/
    $scope.addEvent = function() {
      $rootScope.events.push({
        title: 'Open Sesame',
        start: new Date(y, m, 28),
        end: new Date(y, m, 29),
        className: ['openSesame']
      });
    };
    /* remove event */
    $scope.remove = function(index) {
      $rootScope.events.splice(index,1);
    };
    /* Change View */
    $scope.changeView = function(view,calendar) {
      uiCalendarConfig.calendars[calendar].fullCalendar('changeView',view);
    };
    /* Change View */
    $scope.renderCalender = function(calendar) {
      if(uiCalendarConfig.calendars[calendar]){
        uiCalendarConfig.calendars[calendar].fullCalendar('render');
      }
    };
     /* Render Tooltip */
    $scope.eventRender = function( event, element, view ) { 
        element.attr({'tooltip': event.title,
                     'tooltip-append-to-body': true});
        $compile(element)($scope);
    };
    /* config object */
    $scope.uiConfig = {
      calendar:{
        height: 450,
        editable: true,
        header:{
          left: 'title',
          center: '',
          right: 'today prev,next'
        },
        eventClick: $scope.alertOnEventClick,
        eventDrop: $scope.alertOnDrop,
        eventResize: $scope.alertOnResize,
        eventRender: $scope.eventRender,
        dayClick: $scope.dayClick
      }
    };

    /* event sources array*/
    $rootScope.mediatorDates = [$rootScope.calEventsExt, $rootScope.eventsF, $rootScope.events];

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


