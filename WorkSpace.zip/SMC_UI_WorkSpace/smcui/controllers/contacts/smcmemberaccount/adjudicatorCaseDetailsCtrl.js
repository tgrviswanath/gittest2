(function () {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorCaseDetailsCtrl', adjudicatorCaseDetailsCtrl);

    adjudicatorCaseDetailsCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function adjudicatorCaseDetailsCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'adjudicatorCaseDetails');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.adjudicatorCasesummarydata;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'adjudicatorCaseDetails') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
            console.log("pageno in if" + $scope.pagenumber);
        } else {
            $scope.pagenumber = 0;
        }


        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_adjudication_caselist($scope.pagenumber);

        function get_adjudication_caselist(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "memberId": $cookies.get('memberId')
            }
            getAlladjudicationCases(query);

        }

        function getAlladjudicationCases(query) {
            DataService.post('GetAdjudicationCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.AdjudicationCasesByadjudicator = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
                get_adjudication_caselist(pageNo);
            }
   
   

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
