(function () {
    'use strict';
    angular
        .module('smc')
        .controller('memberSpecialisationCtrl', memberSpecialisationCtrl);

    memberSpecialisationCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function memberSpecialisationCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $cookies.put('currentTab', 'memberSpecialisation');
        $rootScope.currentTab = $cookies.get('currentTab');
        $scope.specData = {};
        $scope.specData.specialization = [];

        get_specialisation_list();
        getFullSpecList();

        function get_specialisation_list() {
            var query = {
                "loginId": $cookies.get('memberId')
            }
            DataService.post('GetSpecDataByMember', query).then(function (data) {
                if(data.status == 'SUCCESS') {
                    $scope.specData = data.result; 
                    if(isEmpty($scope.specData)){
                        $scope.specData.specialization = [];
                    }
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function getFullSpecList(){
            /*To get specialization List */
            DataService.get('GetSpecialisationList').then(function (response) {
                $scope.specList = response.results;
                $scope.specList.push({'specialisationName' : 'Others'})
            })
        }

        $scope.pushSpec = function(spec){
            var specIndex = $scope.specData.specialization.indexOf(spec);
            if(specIndex == -1){
                $scope.specData.specialization.push(spec)
            }else{
                $scope.specData.specialization.splice(specIndex,1)
            }
        }

        $scope.updateSpecialization = function(specData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "specialization": undefinedSetNull(specData.specialization),
                "newSpecialization": undefinedSetNull(specData.newSpecialization),
                "remarks": undefinedSetNull(specData.remarks)
            }
            DataService.post('UpdateSpecDataByMember', query).then(function (data) {
                if(data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Specialisation updated successfully");
                    getFullSpecList();
                    get_specialisation_list();
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        function isEmpty(obj) {
            for(var key in obj) {
                if(obj.hasOwnProperty(key))
                    return false;
            }
            return true;
        }
    }
})();
