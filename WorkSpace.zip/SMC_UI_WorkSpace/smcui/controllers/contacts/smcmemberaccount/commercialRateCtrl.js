(function () {
    'use strict';
    angular
        .module('smc')
        .controller('commercialRateCtrl', commercialRateCtrl);

    commercialRateCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function commercialRateCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {

        $cookies.put('currentTab', 'commercialRate');
        $rootScope.currentTab=$cookies.get('currentTab')
        
        getCommercialRateData();

        function getCommercialRateData(){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId" : $cookies.get('memberId')
            }
            DataService.post('GetCommercialRatesByMember',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.commercialRatesData = data.result;
                    for(var rate in $scope.commercialRatesData){
                        if(rate != 'lastDateForCancellation' && rate != 'cancellationPercentageOfMediationFee' && rate != 'id' && rate != 'memberId' && rate != 'memberName'){
                            $scope.commercialRatesData[rate] = $scope.commercialRatesData[rate] + '.00'
                        }
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
            });
        }

        $scope.updateCommercialRates = function(rateData){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = buildRateQuery(rateData);
            DataService.post('UpdateCommercialRatesByMember',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Commercial rates updated successfully');
                    getCommercialRateData();
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
            });
        }

        function buildRateQuery(rateData){
            var returnQuery = {
                "loginId": $cookies.get('memberId'),
                "readingTimeHourFee":undefinedSetNull(rateData.readingTimeHourFee),
                "readingTimeFlatFee":undefinedSetNull(rateData.readingTimeFlatFee),
                "mediatorFeePerHour":undefinedSetNull(rateData.mediatorFeePerHour),
                "mediatorOtherFee": undefinedSetNull(rateData.mediatorOtherFee),
                "overTimeRatePerHour": undefinedSetNull(rateData.overTimeRatePerHour),
                "cancellationFlatFee":undefinedSetNull(rateData.cancellationFlatFee),
                "cancellationPercentageOfMediationFee": undefinedSetNull(rateData.cancellationPercentageOfMediationFee),
                "lastDateForCancellation": undefinedSetNull(rateData.lastDateForCancellation)
            }

            return returnQuery;
        }

        $scope.checkPercentage = function(percentage){
            if(parseInt(percentage)>100){
                $scope.showPercentageError = true;
            }else{
                $scope.showPercentageError = false;
            }
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();
