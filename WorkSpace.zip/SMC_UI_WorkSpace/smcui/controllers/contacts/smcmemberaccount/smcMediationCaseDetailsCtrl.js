(function () {
    'use strict';
    angular
        .module('smc')
        .controller('smcMediationCaseDetailsCtrl', smcMediationCaseDetailsCtrl);

    smcMediationCaseDetailsCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function smcMediationCaseDetailsCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'smcMediationCaseDetails');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.adjudicatorCasesummarydata;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'smcMediationCaseDetails') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }


        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_mediation_case_list($scope.pagenumber);

        function get_mediation_case_list(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "loginId": $cookies.get('memberId')
            }
            getMediationCaseList(query);

        }

        function getMediationCaseList(query) {
            DataService.post('GetSMCMediationCaseListByMember', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.mediationCaseList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
                get_mediation_case_list(pageNo);
            }
   
   

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
