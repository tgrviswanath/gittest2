(function () {
    'use strict';
    angular
        .module('smc')
        .controller('contactAdjudicationlistCtrl', contactAdjudicationlistCtrl);

    contactAdjudicationlistCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function contactAdjudicationlistCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {
        $scope.shownodataavailable = false;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';


        if ($cookies.get('pageNumber')) {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
            console.log("pageno in if" + $scope.pagenumber);
        } else {
            $scope.pagenumber = 0;
        }


        get_adjudicator_list($scope.pagenumber);
        $scope.goToPageNumber = function (pageNo) {
                get_adjudicator_list($scope.pagenumber);

            }
            /*To Get Adjudicator List */
        function get_adjudicator_list(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var dataFradjudicator = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
            }
            get_adjudicators_list(dataFradjudicator);

            function get_adjudicators_list(dataFradjudicator) {
                DataService.post('ToGetAdjudicatorsList', dataFradjudicator).then(function (adjudicatorsData) {
                    if (adjudicatorsData.status == 'SUCCESS') {
                        $scope.listOfadjudicators = adjudicatorsData.result.responseData;
                    }
                });
            }

        }
        $scope.redirectToSOP = function (name, id) {


            $rootScope.$broadcast('nameOfAdjudicator', {
                message: name
            });

            $rootScope.$broadcast('idOfAdjudicator',{
                idOfAdjudicator:id
            });
            // $scope.$emit('nameOfAdjudicator', $scope.nameofadjudicator);
            $state.go('smclayout.contactlayout.continualprofessionaldevelopmentrequirementsop',{'id':id});
             
        }

    }
})();
