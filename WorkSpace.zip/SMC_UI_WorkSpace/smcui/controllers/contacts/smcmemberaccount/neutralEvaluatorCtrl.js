(function () {
    'use strict';
    angular
        .module('smc')
        .controller('neutralEvaluatorCtrl', neutralEvaluatorCtrl);

    neutralEvaluatorCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function neutralEvaluatorCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
         $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'NECaseList');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.lastContactedDate = '';
        $scope.suitRoleList = ['Plaintiff','Defendant','Third Party','Others']
        
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'NECaseList') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }

        DataService.get('MemberGetNECaseResultList').then(function (response) {
            $scope.resultData = response.results;                
        }).catch(function (error) {
            NotifyFactory.log('error',error.errorMessage);
        });

        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_NE_case_list($scope.pagenumber);

        function get_NE_case_list(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "loginId": $cookies.get('memberId')
            }
            getNEList(query);
        }

        function getNEList(query) {
            DataService.post('ContactGetNeCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.NECaseList = data.result.responseData;
                    for(var caseData in $scope.NECaseList){
                        $scope.NECaseList[caseData].respondNameList = [];
                        $scope.NECaseList[caseData].suitNoList = [];
                        $scope.NECaseList[caseData].respondUENList = [];
                        $scope.NECaseList[caseData].respondNRICList = [];
                        for(var respond in $scope.NECaseList[caseData].respondentDTO){
                            if($scope.NECaseList[caseData].respondentDTO[respond].respondentName){
                                $scope.NECaseList[caseData].respondNameList.push($scope.NECaseList[caseData].respondentDTO[respond].respondentName)
                                if($scope.NECaseList[caseData].respondentDTO[respond].respondentNRIC){
                                    $scope.NECaseList[caseData].respondNRICList.push($scope.NECaseList[caseData].respondentDTO[respond].respondentNRIC)
                                }
                                if($scope.NECaseList[caseData].respondentDTO[respond].respondentUEN){
                                    $scope.NECaseList[caseData].respondUENList.push($scope.NECaseList[caseData].respondentDTO[respond].respondentUEN)
                                }
                            }
                        }
                        for(var suit in $scope.NECaseList[caseData].suitDTO){
                            if($scope.NECaseList[caseData].suitDTO[suit].suitNumber){
                                $scope.NECaseList[caseData].suitNoList.push($scope.NECaseList[caseData].suitDTO[suit].suitNumber);
                            }
                        }
                    }
                    $scope.lastContactedDate = data.result.lastContactedDate;
                    $scope.updaedContactedDate = data.result.lastContactedDate;
                    $scope.totalNoOfCases=data.result.totalNumberOfCases;
                    $scope.membershipPeriod=data.result.membershipPeriodFrom +' to '+data.result.membershipPeriodTo;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_NE_case_list(pageNo);
        }
   
        $scope.openAddNECase=function(action,NEData){
            if(action == 'Add'){
                $scope.NECaseData = {};
                $scope.NECaseData.respondentDTO = [{}];
                $scope.NECaseData.suitDTO = [{}];
            }else{
                $scope.NECaseData = angular.copy(NEData);
            }
            $scope.popupTitle = action;
            angular.element(".overlay").css("display","block");
            angular.element(".member-add-necase").css("display","block");
        }

        $scope.addRespondent = function(){
            $scope.NECaseData.respondentDTO.push({})
        }

        $scope.addSuit = function(){
            $scope.NECaseData.suitDTO.push({})
        }

        $scope.removeSuit = function(suitIndex){
            $scope.NECaseData.suitDTO.splice(suitIndex,1)
        }

        $scope.removeRespondent = function(respondentIndex){
            $scope.NECaseData.respondentDTO.splice(respondentIndex,1)
        }

        $scope.closeAddNECasePopup=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".member-add-necase").css("display","none");
        }
        $scope.saveNECase=function(caseData,action){
            var query = buildQuery(caseData);
            if(action == 'Add'){
                var seviceUrl = 'ContactAddNeCase';
                var successMessage = 'NE case added successfully';
            }else{
                var seviceUrl = 'ContactOfficerUpdateNECaseList';
                var successMessage = 'NE case updated successfully'
                query.id = caseData.id;
                query.respondentId = caseData.respondentId,
                query.lastContactedDate = null;
            }
            actionOfCase(seviceUrl,successMessage,query)
        }
        function actionOfCase(seviceUrl,successMessage,query){
            DataService.post(seviceUrl, query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    get_NE_case_list($scope.pagenumber);
                    NotifyFactory.log('success', successMessage);
                    angular.element(".overlay").css("display","none");
                    angular.element(".member-add-necase").css("display","none");
                } 
            }).catch(function (error) {
               NotifyFactory.log('error', error.errorMessage);
            });
        }
        function buildQuery(caseData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "applicantName": undefinedSetNull(caseData.applicantName),
                "applicantNRIC": undefinedSetNull(caseData.applicantNRIC),
                "applicantUEN": undefinedSetNull(caseData.applicantUEN),
                "respondentDTO":buildRespondentQuery(caseData.respondentDTO),
                "suitDTO":buildSuitQuery(caseData.suitDTO),
                "appointmentDate": undefinedSetNull(caseData.appointmentDate),
                "caseNumber": undefinedSetNull(caseData.caseNumber),
                "result": undefinedSetNull(caseData.result)  
            }
            return query;
        }
        function buildRespondentQuery(respondentData){
            var respondQuery = [];
            for(var respond in respondentData){
                var query = {
                    "respondentName": undefinedSetNull(respondentData[respond].respondentName),
                    "respondentNRIC": undefinedSetNull(respondentData[respond].respondentNRIC),
                    "respondentUEN": undefinedSetNull(respondentData[respond].respondentUEN)
                }
                respondQuery.push(query);
            }
            return respondQuery
        }
        function buildSuitQuery(suitData){
            var suitQuery = [];
            for(var suit in suitData){
                var query = {
                    "suitNumber": undefinedSetNull(suitData[suit].suitNumber),
                    "partyName": undefinedSetNull(suitData[suit].partyName),
                    "suitRole": undefinedSetNull(suitData[suit].suitRole != 'Others' ? suitData[suit].suitRole : suitData[suit].otherSuitRole)
                }
                suitQuery.push(query);
            }
            return suitQuery
        }
        $scope.openDeleteConfirm=function(caseNumber){
            $scope.caseNumber=caseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".member-delete-ne-case").css("display","block");
        }
        $scope.cancelDeleteNeCase=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".member-delete-ne-case").css("display","none");
        }
        $scope.DeleteNECase=function(caseNumber){
             var query={
                "loginId": $cookies.get('memberId'),
                "caseNumber": caseNumber
            }
            DataService.post('ContactDeleteNeCase', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    get_NE_case_list($scope.pagenumber);
                    NotifyFactory.log('success', 'NE case deleted successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".member-delete-ne-case").css("display","none");
                } 
            }).catch(function (error) {
               NotifyFactory.log('error', error.errorMessage);
            });
        }
       
        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();