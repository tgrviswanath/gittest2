(function () {
    'use strict';
    angular
        .module('smc')
        .controller('mediatorexpertiseCtrl', mediatorexpertiseCtrl);

    mediatorexpertiseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function mediatorexpertiseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {

        $cookies.put('currentTab', 'mediatorExpertise');
        $rootScope.currentTab=$cookies.get('currentTab')

        // initial values
        $scope.confirmOptions = ['Yes','No'];
        $scope.selectedLangs = [];

        //Get Language List Service
        DataService.get('GetLanguageList').then(function(data){
            $scope.languageList = data.results;
        });

        //Get nature of occupation list
        DataService.get('GetNatureOfOccupationList').then(function(data){
            $scope.occupationList = data.results;
        });

        //Get professional background list
        DataService.get('GetProfessionalBackgroundList').then(function(data){
            $scope.backgroundList = data.results;
        });
        
        getMediatorExpertise();

        function getMediatorExpertise(){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId" : $cookies.get('memberId')
            }
            DataService.post('GetMediatorExpertiseByMember',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.mediatorExpertiseData = data.result;
                    getLanguages($scope.mediatorExpertiseData.languages);
                    var occupationId = findOccupationIdByName($scope.mediatorExpertiseData.natureOfOccupation);
                    var backgroundId = findBackgroundIdByName($scope.mediatorExpertiseData.professionalBackgrounds);
                    $scope.mediatorExpertiseData.natureOfOccupationId = occupationId;
                    $scope.mediatorExpertiseData.professionalBackgroundId = backgroundId;
                    if(!$scope.mediatorExpertiseData.imicertification){
                        $scope.mediatorExpertiseData.imicertification = 'No';
                    }
                    if(!$scope.mediatorExpertiseData.similevel1){
                        $scope.mediatorExpertiseData.similevel1 = 'No';
                    }
                    if(!$scope.mediatorExpertiseData.similevel2){
                        $scope.mediatorExpertiseData.similevel2 = 'No';
                    }
                    if(!$scope.mediatorExpertiseData.similevel3){
                        $scope.mediatorExpertiseData.similevel3 = 'No';
                    }
                    if(!$scope.mediatorExpertiseData.simicertified){
                        $scope.mediatorExpertiseData.simicertified = 'No';
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
            });
        }

        function getLanguages(languageArray){
            $scope.selectedLangs = [];
            for(var selectedLanguage in languageArray){
                for(var language in $scope.languageList){
                    if(languageArray[selectedLanguage] == $scope.languageList[language].languageName){
                        $scope.selectedLangs.push($scope.languageList[language].id)
                    }
                }
            }
        }

        function findOccupationIdByName(occupationName){
            var occupationId = '';
            for(var occupation in $scope.occupationList){
                if(occupationName == $scope.occupationList[occupation].name){
                    occupationId = $scope.occupationList[occupation].id;
                    break;
                }
            }
            return occupationId;
        }

        function findBackgroundIdByName(backgroundName){
            var backgroundId = '';
            for(var background in $scope.backgroundList){
                if(backgroundName == $scope.backgroundList[background].name){
                    backgroundId = $scope.backgroundList[background].id;
                    break;
                }
            }
            return backgroundId;
        }

        $scope.pushLangs = function(lang){
            var index = $scope.selectedLangs.indexOf(lang);
            if(index != -1){
                $scope.selectedLangs.splice(index,1)
            }else{
                $scope.selectedLangs.push(lang);
            }
        }  

        $scope.updateMediatorExpertise = function(expertiseData){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = buildQuery(expertiseData);
            DataService.post('UpdateMediatorExpertiseByMember',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Mediator expertise details updated successfully');
                    getMediatorExpertise();
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
            });
        }      

        function buildQuery(expertiseData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "qualification":undefinedSetNull(expertiseData.qualification),
                "natureOfOccupationId":undefinedSetNull(expertiseData.natureOfOccupationId),
                "newNatureOfOccupation":undefinedSetNull(expertiseData.newNatureOfOccupation),
                "affiliations": undefinedSetNull(expertiseData.affiliations),
                "professionalBackgroundId":undefinedSetNull(expertiseData.professionalBackgroundId),
                "newProfessionalBackgrounds":undefinedSetNull(expertiseData.newProfessionalBackgrounds),
                "adrTraining": undefinedSetNull(expertiseData.adrTraining),
                "areaOfExpertise": undefinedSetNull(expertiseData.areaOfExpertise),
                "areaOfMediation": undefinedSetNull(expertiseData.areaOfMediation),
                "languageIds": $scope.selectedLangs.length != 0 ? $scope.selectedLangs : null
            }
            return query;
        }
           
        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();
