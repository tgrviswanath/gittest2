(function () {
    'use strict';
    angular
        .module('smc')
        .controller('timesheetCtrl', timesheetCtrl);

    timesheetCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function timesheetCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'timesheet');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.timesheetButton='Add';
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'timesheet') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_timesheet_list($scope.pagenumber);

        function get_timesheet_list(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "loginId": $cookies.get('memberId')
            }
            getTimesheetList(query);

        }

        function getTimesheetList(query) {
            DataService.post('GetMemberTimesheet', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.timesheetList = data.result.responseData;
                    $scope.totalNoOfTimesheet=data.result.totalData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
               
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
                get_timesheet_list(pageNo);
            }
   
        $scope.openAddTimesheet=function(){
            $scope.addTimesheet={};
            $scope.timesheetButton='Add';
            angular.element(".overlay").css("display","block");
            angular.element(".add-timesheet-popup").css("display","block");
        }

        $scope.closeUpdateAddTimesheetPopup=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-timesheet-popup").css("display","none");
        }

        $scope.setMinTime=function(minTime){
            $scope.addTimesheet.toTime=null;
            $('#toTime').timepicker('option', 'minTime', minTime);
        }
        $scope.addTimesheetToList=function(addTimesheet){
            if($scope.timesheetButton=='Add'){
                var url='AddMemberTimesheet';
                 var query={
                    "loginId": $cookies.get('memberId'),
                    "caseNumber": addTimesheet.caseNumber,
                    "workDate": addTimesheet.workDate ,
                    "fromTime": addTimesheet.fromTime,
                    "toTime":  addTimesheet.toTime,
                    "remarks": addTimesheet.remarks
                }
            }else{
                var url='UpdateMemberTimesheet';
                 var query={
                    "loginId": $cookies.get('memberId'),
                    "caseNumber": addTimesheet.caseNumber,
                    "workDate": addTimesheet.workDate ,
                    "fromTime": addTimesheet.fromTime,
                    "toTime":  addTimesheet.toTime,
                    "timeSheetId": $scope.timesheetId,
                    "remarks": addTimesheet.remarks
                }
            }
            DataService.post(url, query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    get_timesheet_list($scope.pagenumber);
                    NotifyFactory.log('success', 'Timesheet added successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".add-timesheet-popup").css("display","none");
                } 
            }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
            });
        }
        $scope.openDeleteConfirm=function(id){
            $scope.timesheetId=id;
            angular.element(".overlay").css("display","block");
            angular.element(".form-submitt-confirm").css("display","block");
        }
        $scope.canceldelete=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".form-submitt-confirm").css("display","none");
        }
        $scope.editTimesheet=function(id){
            $scope.timesheetButton='Update';
            $scope.timesheetId=id;
            var viewTimeheetDetails = smcConfig.services.EditMemberTimesheet.url;
            viewTimeheetDetails=viewTimeheetDetails+id;
            $http.get(viewTimeheetDetails).then(function (response) {
            if (response.data.status == 'SUCCESS') {

                $scope.viewTimesheetData = response.data.result;
                $scope.addTimesheet=$scope.viewTimesheetData;
                angular.element(".overlay").css("display","block");
                angular.element(".add-timesheet-popup").css("display","block");
            }

        })
            
        }
        $scope.deleteTimesheet=function(){
            var query={
                "loginId": $cookies.get('memberId'),
                "timeSheetId":$scope.timesheetId
            }
            DataService.post('DeleteMemberTimesheet', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    get_timesheet_list($scope.pagenumber);
                    NotifyFactory.log('success', 'Timesheet deleted successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".form-submitt-confirm").css("display","none");

                } 
            }).catch(function (error) {
               
            });
        }
        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
