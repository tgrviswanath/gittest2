(function () {
    'use strict';
    angular
        .module('smc')
        .controller('continualprofessionaldevelopmentrequirementCtrl', continualprofessionaldevelopmentrequirementCtrl);

    continualprofessionaldevelopmentrequirementCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$sce'
    ];

    function continualprofessionaldevelopmentrequirementCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory, $sce) {
        $scope.roleName = $cookies.get('roleName');
        $scope.selectedRow = null;
        $scope.reverseSort = false;
        $scope.memberId;
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.attachcopyStatus_err = false;
        $scope.attachcopyStatusNew = false;
        $scope.profileattachcopyStatus = false;
        $scope.attachcopyStatusFrErr = false;
        $scope.makeEditDisable = false;
        $scope.btnDisabled = true;
        $scope.fileUploadTypes = ["pdf", "doc"];
        $scope.cvlocation;
        $scope.cvlocationnew;
        $scope.nameOfSeminar;
        $rootScope.adjudicatorName;
        $scope.adjName;
        $rootScope.adjudicatorId;
        $scope.adjId;
        $scope.delete_modal_path = 'views/contacts/smcmemberaccount/confirm-delete-professional-modal.html'
        $scope.view_modal_path = 'views/contacts/smcmemberaccount/view-member-professional-requirement-modal.html'
        $cookies.put('currentTab', 'continualprofessionaldevelopmentrequirement');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.adjudicatorCasesummarydata;

        $rootScope.$on('nameOfAdjudicator', function (event, args) {
            $rootScope.adjudicatorName = args.message;

        });
        $rootScope.$on('idOfAdjudicator', function (event, val) {
            $rootScope.adjudicatorId = val.idOfAdjudicator;
        })
        $scope.adjName = $rootScope.adjudicatorName;
        $scope.adjId = $rootScope.adjudicatorId;

        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'continualprofessionaldevelopmentrequirement') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
            console.log("pageno in if" + $scope.pagenumber);
        } else {
            $scope.pagenumber = 0;
        }

        $scope.setClickedRow = function (index, name, id) { //function that sets the value of selectedRow to current index

            $scope.memberId = id;
            $scope.selectedAdjudicatorName = name;

            $scope.selectedRow = index;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        /*uplaod cv */
        $scope.uploadFile = function (file, index) {
                console.log("uploading documents");
                var file = file;
                console.log(file);
                if (file.size < 5242881) {
                    if (validateUploadFileExtention(file.name)) {
                        $rootScope.supprtDocumentName = file.name;
                        $rootScope.documentUrl = file.url;
                        console.log("url" + $rootScope.documentUrl);
                        $scope.fileName = $rootScope.supprtDocumentName.split('.')[0];
                        var fd = new FormData();
                        fd.append('file', file);
                        httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                            console.log(data);
                            $rootScope.supportFilePath = data.result;

                            $scope.cvlocation = $rootScope.supportFilePath;
                            $scope.attachcopyStatus = true;
                        });

                    } else {

                        $scope.attachcopyStatus_err = true;
                        $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();

                    }

                } else {
                    NotifyFactory.log('error', "Please select below 5MB file");
                }

            }
            // if we want remove upload file
        $scope.attachcopyRemove = function () {
            $rootScope.supprtDocumentName = undefined;
            $rootScope.supportFilePath = undefined;
            $scope.attachcopyStatus = false;
            $scope.attachcopyStatusFrErr = false;
            $scope.attachcopyStatus_err = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        /*eof cv uplaod */
        /* to get seminar program list */

        var seminarPgmList = smcConfig.services.GetSeminarProgramList.url;
        $http.get(seminarPgmList).then(function (response) {
                if (response.data.status == 'SUCCESS') {
                    $scope.seminarPgmLists = response.data.results;
                } else {
                    NotifyFactory.log('error', "error");
                }

            })
            /*eof to get seminar program list */

        get_member_professional_requirement($scope.pagenumber);


        function get_member_professional_requirement(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "memberId": $cookies.get('memberId')
            }
            get_member_professional_requirement_Details(query);

        }

        function get_member_professional_requirement_Details(query) {
            DataService.post('GetMemberProfessionalRequirementDetails', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.professionalReqData = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                $scope.shownodataavailable = true;
            });
        }
        $scope.goToPageNumber = function (pageNo) {
                get_member_professional_requirement(pageNo);
        }
         // check valid file by exetension
        function validateUploadFileExtention(val) {
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            console.log("ext" + ext);
            for (var i = 0; i < allowedExt.length; i++) {
                if ($scope.fileUploadTypes[i] == ext) {
                    return true;
                }

            }
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }

        }

        $scope.addProfessionalRequirement = function (professionalDevelopment) {

            $scope.roleName = $cookies.get('roleName');

            if ($scope.attachcopyStatus_err) {
                return;
            }
            console.log("others" + $scope.othersPgm);
            var finalName;
            if ($scope.seminarProgram != 'Others') {

                finalName = $scope.seminarProgram;
                console.log("insie final  name" + finalName);
                add(professionalDevelopment);
            } else if (($scope.seminarProgram == 'Others')) {
                if (!$scope.othersPgm) {
                    NotifyFactory.log('error', "Please Specify The Program Name");
                } else if ($scope.othersPgm) {
                    finalName = $scope.othersPgm;
                    console.log("insie final  name others" + finalName);
                    add(professionalDevelopment);
                }
            }


            function add(professionalDevelopment) {
                var newData = {
                    "seminarProgram": professionalDevelopment.seminarProgram,
                    "seminarProgramDate": professionalDevelopment.dateofSeminar,
                    "description": professionalDevelopment.description,
                    "document": {
                        "name": $rootScope.supprtDocumentName,
                        "fileLocation": $scope.cvlocation
                    },
                    "memberLoginId": $cookies.get('memberId')
                }

                DataService.post('AddMemberProfessionalRequirementByAdudicator', newData).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        get_member_professional_requirement($scope.pagenumber);
                        $scope.professionalDevelopment=null;
                        $rootScope.supprtDocumentName = '';
                        $scope.cvlocation = '';
                        $scope.attachcopyStatus = false;
                        NotifyFactory.log('success', "SOP Seminar Details is added successfully");
                    } else {
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        console.log(error);
                        NotifyFactory.log('error', error.errorMessage);
                    }
                });
            }
        }
        
        $scope.tableSorting = function (sortVal) {
                $scope.orderByField = sortVal;
                if (sortVal == $scope.sortValue) {
                    if ($scope.reverseSort) {
                        $scope.reverseSort = false;
                    } else {
                        $scope.reverseSort = true;
                    }
                } else {
                    $scope.reverseSort = false;
                    $scope.sortValue = sortVal;
                }
            }
            //to open update payee name modal
        $scope.deleteModal = function (id) {
            $rootScope.caseId = id;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-payee-name").css("display", "block");
            /*Delete data*/
            $scope.deleteData = function (id) {

                    var deleteData = smcConfig.services.DeleteMemberProfessionalRequirement.url;
                    var urlForDelete = deleteData + $rootScope.caseId;
                    $http.get(urlForDelete).then(function (response) {
                        if (response.data.status == 'SUCCESS') {
                            $scope.closepayeepop();
                            NotifyFactory.log('success', "Data deleted successfully");

                            get_member_professional_requirement($scope.pagenumber);
                        } else {
                            NotifyFactory.log('error', "error");
                        }

                    })
                }
                /*eof Delete */
        }
        $scope.closepayeepop = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-payee-name").css("display", "none");
        }
        $scope.closepayeepop_sop = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-payee-name-for-sop").css("display", "none");
        }
        $scope.ViewMemberRequirementModal = function (id, location) {
            $rootScope.reqId = id;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-payee-name-for-sop").css("display", "block");
            var viewData = smcConfig.services.ViewMemberProfessionalRequirementDetail.url;
            var urlForView = viewData + $rootScope.reqId;
            $http.get(urlForView).then(function (response) {
                if (response.data.status == 'SUCCESS') {
                    $scope.professionalReqModaldata = response.data.result;
                    $scope.cvlocationnew = response.data.result.document.fileLocation;
                    $scope.professionalReqModaldata.supprtDocumentName = response.data.result.document.name;
                    $scope.readOnlyfileds = true;
                } else {
                    NotifyFactory.log('error', "error");
                }
            })
        }
        $scope.editRequirement = function (id) {

                // UpdateMemberProfessionalRequirement
                $scope.readOnlyfileds = false;
                $scope.makeEditDisable = true;
                $scope.btnDisabled = false;
            }
            /*uplaod cv */
        $scope.uploadFileinmodel = function (file, index) {
            console.log("uploading documents");
            var file = file;
            console.log(file);
            if (file.size < 5242881) {
                if (validateUploadFileExtention(file.name)) {
                    console.log("this is valid one");
                    $scope.professionalReqModaldata.supprtDocumentName = file.name;
                    console.log("this is doc name" + $scope.professionalReqModaldata.supprtDocumentName);
                    $rootScope.documentUrl = file.url;
                    console.log("url" + $rootScope.documentUrl);
                    $scope.fileName = $scope.professionalReqModaldata.supprtDocumentName.split('.')[0];
                    var fd = new FormData();
                    fd.append('file', file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                        console.log(data);
                        // $rootScope.supportFilePath = data.result;
                        $rootScope.supportFilePathNew = data.result;
                        console.log("supprt filepath" + $rootScope.supportFilePathNew);

                        $scope.cvlocationnew = $rootScope.supportFilePathNew;
                        console.log("New cv location" + $scope.cvlocationnew);
                        $scope.attachcopyStatusNew = true;
                        $scope.btnDisabled = false;
                    });
                } else {
                    $scope.attachcopyStatusFrErr = true;
                    $scope.btnDisabled = true;
                    $scope.attachcopyStatusNew = true;
                    $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                }

            } else {
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        $scope.submitEditedRequirement = function (reqId) {
            console.log("edit data of id" + reqId);
            console.log("others" + $scope.professionalReqModaldata.othersPgm);
            var finalName;
            if ($scope.professionalReqModaldata.seminarProgram != 'Others') {

                finalName = $scope.professionalReqModaldata.seminarProgram;
                console.log("insie final  name" + finalName);
                submit();
            } else if ($scope.professionalReqModaldata.seminarProgram == 'Others') {
                if (!$scope.professionalReqModaldata.othersPgm) {
                    NotifyFactory.log('error', "Please Specify The Program Name");
                } else if ($scope.professionalReqModaldata.othersPgm) {
                    finalName = $scope.professionalReqModaldata.othersPgm;
                    console.log("insie final  name others" + finalName);
                    submit();
                }
            }

            function submit() {
                console.log("checking id" + reqId);
                var newData = {
                    "id": reqId,
                    "seminarProgram": finalName,
                    "seminarProgramDate": $scope.professionalReqModaldata.seminarProgramDate,
                    "description": $scope.professionalReqModaldata.description,
                    "document": {
                        "name": $scope.professionalReqModaldata.supprtDocumentName,
                        "fileLocation": $scope.cvlocationnew
                    },
                    "memberLoginId": $cookies.get('memberId')
                }
                DataService.post('UpdateMemberProfessionalRequirement', newData).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        $scope.attachcopyStatusNew = false;
                        angular.element(".overlay").css("display", "none");
                        angular.element(".update-payee-name-for-sop").css("display", "none");
                        NotifyFactory.log('success', "Member Professional Requirement Detail is Updated Successfully");
                        get_member_professional_requirement($scope.pagenumber);
                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        NotifyFactory.log('error',error.errorMessage);
                    }
                });
            }

          
        }
    }
})();
