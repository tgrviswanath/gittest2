(function () {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorCaseCtrl', adjudicatorCaseCtrl);

    adjudicatorCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function adjudicatorCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'adjudicatorCasesummary');
        $rootScope.currentTab=$cookies.get('currentTab')
        $scope.adjudicatorCasesummarydata;

        if ($cookies.get('pageNumber')) {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_declined_caselist($scope.pagenumber);

        function get_declined_caselist(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var declinedData = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "memberId": $cookies.get('memberId')
            }
            getAlldeclienedCases(declinedData);

        }

        function getAlldeclienedCases(declinedData) {
            DataService.post('GetDecliendAdjudicationCases', declinedData).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.declinedAdjudicationCases = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
                get_declined_caselist(pageNo);
            }
            /*To get Adjudicator Case Summary */
        var adjudicatorCasesummary = smcConfig.services.GetAdjudicatorCaseSummary.url;
        var member_login_id = $cookies.get('memberId');
        var adjudicatorCasesummaryUrl = adjudicatorCasesummary + member_login_id;

        $http.get(adjudicatorCasesummaryUrl).then(function (response) {
            if (response.data.status == 'SUCCESS') {
                $scope.adjudicatorCasesummarydata = response.data.result;

            }

        })
        $scope.updateDates = function () {


            /*updateing unavailability dates */
            console.log("frm date" + $scope.adjudicatorCasesummarydata.unavailabilityFromDate);
            var query = {
                "fromDate": undefinedSetNull($scope.adjudicatorCasesummarydata.unavailabilityFromDate),
                "toDate": undefinedSetNull($scope.adjudicatorCasesummarydata.unavailabilityToDate),
                "memberLoginId": $cookies.get('memberId')
            }
            updateunavailabilityDates(query);

            function updateunavailabilityDates(query) {
                DataService.post('ToUpdatemembersUnavailabilityDate', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "The dates are updated");

                    } else {

                        NotifyFactory.log('error', "error");
                    }
                }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                    if (error.errorCode == 100) {
                        console.log(error);
                    }
                });
            }
            console.log("query" + query);
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }
    }
})();
