(function () {
    'use strict';
    angular
        .module('smc')
        .controller('mediatorCaseSummaryCtrl', mediatorCaseSummaryCtrl);

    mediatorCaseSummaryCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function mediatorCaseSummaryCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {

        $cookies.put('currentTab', 'mediatorCaseSummary');
        $rootScope.currentTab=$cookies.get('currentTab')
        
        getMediatorCaseSummary();

        function getMediatorCaseSummary(){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId" : $cookies.get('memberId')
            }
            DataService.post('GetMediatorCaseSummaryByMember',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.mediatorCaseSummaryData = data.result;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
            });
        }
    }
})();
