(function () {
    'use strict';
    angular
        .module('smc')
        .controller('trainingSummaryCtrl', trainingSummaryCtrl);

    trainingSummaryCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function trainingSummaryCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
  
        $cookies.put('currentTab', 'trainingSummary');
        $rootScope.currentTab = $cookies.get('currentTab')
    
        var loginId=$cookies.get('memberId');
        var ContactGetTrainingSummaryUrl = smcConfig.services.ContactGetTrainingSummary.url;
        ContactGetTrainingSummaryUrl=ContactGetTrainingSummaryUrl+loginId;
        $http.get(ContactGetTrainingSummaryUrl).then(function(data){
            $scope.categories = data.data.result;
        }).catch(function (error) {
            NotifyFactory.log('error',error.errorMessage)
        });
    }
})();
