(function () {
    'use strict';
    angular
        .module('smc')
        .controller('sdrpCasesCtrl', sdrpCasesCtrl);

    sdrpCasesCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function sdrpCasesCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'sdrpCases');
        $rootScope.currentTab = $cookies.get('currentTab')
        
        
        var getSDRPResultDetails = smcConfig.services.ContactGetSDRPResultDetails.url;
        $http.get(getSDRPResultDetails).then(function (response) {
            if (response.data.status == 'SUCCESS') {
                    $scope.resultData=response.data.results;
                }
        })
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'sdrpCases') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_sdrp_case_list($scope.pagenumber);

        function get_sdrp_case_list(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "loginId": $cookies.get('memberId')
            }
            getSdrpList(query);

        }

        function getSdrpList(query) {
            DataService.post('ContactGetSdrpCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.sdrpList = data.result.responseData;
                    $scope.totalNoOfCases=data.result.totalNumberOfCases;
                    $scope.membershipPeriod=data.result.membershipPeriodFrom +' to '+data.result.membershipPeriodTo;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
               
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
                get_sdrp_case_list(pageNo);
            }
   
        $scope.openAddCase=function(){
            $scope.addSdrpCase={};
            angular.element(".overlay").css("display","block");
            angular.element(".add-sdrp-popup").css("display","block");
        }

        $scope.closeUpdateAddSdrpPopup=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-sdrp-popup").css("display","none");
        }
        $scope.addSdrpCaseToList=function(addSdrp){
            var query={
                "loginId": $cookies.get('memberId'),
                "applicantName":addSdrp.applicantName,
                "applicantNRIC": addSdrp.applicantNRIC,
                "applicantUEN": addSdrp.applicantUEN,
                "respondentName": addSdrp.respondentName,
                "respondentNRIC": addSdrp.respondentNRIC,
                "respondentUEN": addSdrp.respondentUEN,
                "appointmentDate":addSdrp.appointmentDate,
                "caseNumber": addSdrp.caseNumber,
                "result": addSdrp.result
            }
            DataService.post('ContactAddSdrpCase', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    get_sdrp_case_list($scope.pagenumber);
                    NotifyFactory.log('success', 'Case added successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".add-sdrp-popup").css("display","none");

                } 
            }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
            });
        }
        $scope.openDeleteConfirm=function(caseNumber){
            $scope.caseNumber=caseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".form-submitt-confirm").css("display","block");
        }
        $scope.canceldelete=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".form-submitt-confirm").css("display","none");
        }
        $scope.deleteCase=function(){
             var query={
                "loginId": $cookies.get('memberId'),
                "caseNumber":  $scope.caseNumber
            }
            DataService.post('ContactDeleteSdrpCase', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    get_sdrp_case_list($scope.pagenumber);
                    NotifyFactory.log('success', 'Case deleted successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".form-submitt-confirm").css("display","none");

                } 
            }).catch(function (error) {
               
            });
        }
        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
