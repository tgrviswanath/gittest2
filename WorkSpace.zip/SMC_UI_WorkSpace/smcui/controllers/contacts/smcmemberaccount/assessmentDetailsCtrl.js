(function () {
    'use strict';
    angular
        .module('smc')
        .controller('assessmentDetailsCtrl', assessmentDetailsCtrl);

    assessmentDetailsCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function assessmentDetailsCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'assessmentDetails');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.adjudicatorCasesummarydata;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'assessmentDetails') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }


        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_assessment_case_list($scope.pagenumber);

        function get_assessment_case_list(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "loginId": $cookies.get('memberId')
            }
            getAssessmentCaseList(query);

        }

        function getAssessmentCaseList(query) {
            DataService.post('ContactGetAssessmentDetails', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.assessmentList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
                get_assessment_case_list(pageNo);
            }
   
   

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
