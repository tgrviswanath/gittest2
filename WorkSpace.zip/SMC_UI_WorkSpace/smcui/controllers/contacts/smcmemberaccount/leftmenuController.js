(function () {
    'use strict';
    angular
        .module('smc')
        .controller('leftmenuController', leftmenuController);

    leftmenuController.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function leftmenuController($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {
        var query = {
            "name": "Professional_Requirement",
            "moduleId": $cookies.get('moduleId')
        }
        $scope.roleName = $cookies.get('roleName');
        $scope.moduleName=$cookies.get('moduleName');
        DataService.post('CodeInfo', query).then(function (data) {
            if (data.status == 'SUCCESS') {
                if (data.result == 'No') {
                    console.log("inside no");
                    $scope.showSOP = false;
                } else {
                    $scope.showSOP = true;
                }

            } else {

                NotifyFactory.log('error', "error");
            }
        }).catch(function (error) {
            if (error.errorCode == 100) {
                console.log(error);
                NotifyFactory.log('error', "error");
            }
        });


console.log("role name"+$cookies.get('roleName'));

    }
})();
