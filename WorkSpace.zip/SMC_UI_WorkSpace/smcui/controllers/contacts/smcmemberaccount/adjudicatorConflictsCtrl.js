(function () {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorConflictsCtrl', adjudicatorConflictsCtrl);

    adjudicatorConflictsCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function adjudicatorConflictsCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        var partyIdentifiersArray;
        var uidTypeArray;
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $scope.update_payeename_modal_path = 'views/contacts/smcmemberaccount/confirm-delete-modal.html'
        $cookies.put('currentTab', 'adjudicatorConflictDetails');
        $rootScope.currentTab = $cookies.get('currentTab')
        $scope.adjudicatorCasesummarydata;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'adjudicatorConflictDetails') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
            console.log("pageno in if" + $scope.pagenumber);
        } else {
            $scope.pagenumber = 0;
        }


        $scope.dataLength = 10;
        $scope.max_pagenumber = '';


        /*To get Party Identifier List */


        var adjudicatorCasesummary = smcConfig.services.GetPartyIdentifierList.url;
        $http.get(adjudicatorCasesummary).then(function (response) {
            if (response.data.status == 'SUCCESS') {
                $scope.partyIdentifiers = response.data.results;
                partyIdentifiersArray = response.data.results;
            }

        })


        $scope.allIncludingReference = true;
        $scope.chkIdType = function () {
            if ($scope.partyIdentifier == 'Principal' || $scope.partyIdentifier == 'Owner') {
                $scope.ReferenceOnly = true;
                $scope.allIncludingReference = false;
            } else {
                $scope.ReferenceOnly = false;
                $scope.allIncludingReference = true;
            }

        }

        /*eof To get Party Identifier List */

        /*ID Type */
        var adjudicatorIdTypes = smcConfig.services.GetApplicantUIDsList.url;
        $http.get(adjudicatorIdTypes).then(function (response) {
                if (response.data.status == 'SUCCESS') {
                    $scope.idTypes = response.data.results;
                    uidTypeArray = response.data.results;

                }

            })
            // $scope.idTypes = ["NRIC/Passport Number", "UEN", "Reference Number"]
            /*eof ID Type */



        get_adjudicator_conflict_details($scope.pagenumber);

        function get_adjudicator_conflict_details(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "memberId": $cookies.get('memberId')
            }
            getAlladjudicatiorConflictCases(query);

        }

        function getAlladjudicatiorConflictCases(query) {
            DataService.post('GetAdjudicatorConflictDetails', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.adjudicatorConflictscasesdata = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });

        }
        $scope.goToPageNumber = function (pageNo) {
            get_adjudicator_conflict_details(pageNo);
        }



        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        /*add conflict */
        $scope.addConflict = function () {
                console.log("partyIdentifier" + $scope.partyIdentifier);
                var idOfIdentifier;
                for (var i = 0; i < partyIdentifiersArray.length; i++) {
                    if (partyIdentifiersArray[i].name == $scope.partyIdentifier) {
                        idOfIdentifier = partyIdentifiersArray[i].id;
                    }
                }
                var uid;
                for (var i = 0; i < uidTypeArray.length; i++) {
                    if (uidTypeArray[i].name == $scope.memberUIDType) {
                        uid = uidTypeArray[i].id;
                    }
                    // else if(uidTypeArray[i].name == 'Reference Number'){
                    //     uid=uidTypeArray[i].id;
                    // }
                }
                var addData = {
                    "partyIdentiferId": idOfIdentifier,
                    "name": $scope.name,
                    "email": $scope.email,
                    "memberUIDTypeId": uid,
                    "memberUIDValue": $scope.memberUIDValue,
                    "memberLoginId": $cookies.get('memberId')
                }
                console.log("addData" + JSON.stringify(addData));
                add_conflict_by_adjudicator(addData);

                function add_conflict_by_adjudicator(addData) {
                    DataService.post('AddConflictDetailByAdjudicator', addData).then(function (data) {
                        if (data.status == 'SUCCESS') {
                            get_adjudicator_conflict_details($scope.pagenumber);
                            NotifyFactory.log('success', "conflict details added successfully");
                            $scope.name = '';
                            $scope.email = '';
                            $scope.partyIdentifier = '';
                            $scope.memberUIDType = '';
                            $scope.memberUIDValue = '';
                        }
                    }).catch(function (error) {
                        if (error.errorCode == 100) {
                             NotifyFactory.log('error', error.errorMessage);
                        }
                    });
                }

            }
            /*eof add conflict */



        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }


        //to open update payee name modal
        $scope.deleteModal = function (id) {
            $rootScope.caseId = id;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-payee-name").css("display", "block");
            /*Delete data*/
            $scope.deleteData = function (id) {

                    var deleteData = smcConfig.services.DeleteConflictDetail.url;
                    var urlForDelete = deleteData + $rootScope.caseId;
                    $http.get(urlForDelete).then(function (response) {
                        if (response.data.status == 'SUCCESS') {
                            $scope.closepayeepop();
                            NotifyFactory.log('success', "Data deleted successfully");

                            get_adjudicator_conflict_details($scope.pagenumber);
                        } else {
                            NotifyFactory.log('error', "error");
                        }

                    })
                }
                /*eof Delete */

        }


        $scope.closepayeepop = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-payee-name").css("display", "none");
        }

    }
})();
