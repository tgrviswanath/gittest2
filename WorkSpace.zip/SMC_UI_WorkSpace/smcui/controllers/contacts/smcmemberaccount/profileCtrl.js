(function () {
    'use strict';
    angular
        .module('smc')
        .controller('profileCtrl', profileCtrl);

    profileCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function profileCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {
        $scope.image = {
            src: "images/nophoto.jpg"
        };

        $cookies.put('currentTab', 'profile');
        $rootScope.currentTab = $cookies.get('currentTab');
        $scope.attachcopyStatuserr=false;
        $scope.regEx = "/^[0-9]{10,10}$/";
        $scope.languagearray = [];
        $scope.attachcopyStatus = false;
        $scope.profileattachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf", "doc"];
        $scope.profilImageType = ["jpg", "jpeg", "png"];
        $scope.membershipid;
        $scope.cvlocation;
        $scope.staticImage = true;
        $scope.genders = [{'name':'Male','value':'M'},{'name':'Female','value':'F'}];
        $scope.nationalities = ['Singaporean','PR','Foreigner'];
        $scope.countries = ['Singapore' , 'India'];
        $scope.confirmOptions = ["Yes", "No"];

        /*To get Organisation List */
        DataService.get('GetOrganizationList').then(function (response) {
            $scope.organisations = response.results;
        })
        //Get Salutation Type List Service
        DataService.get('GetSalutationList').then(function(data){
            $scope.salutations = data.results;
        });
        //Get Language List Service
        DataService.get('GetLanguageList').then(function(data){
            $scope.languageList = data.results;
        });

        viewProfile();

        function viewProfile() {
            var memberprofile = smcConfig.services.ViewMemberProfileDetails.url;
            var member_login_id = $cookies.get('memberId');
            var memberprofileurl = memberprofile + member_login_id;
            $http.get(memberprofileurl).then(function (response) {
                $scope.profiledata = response.data.result;
                if(response.data.result.languages.length != 0){
                    $scope.selectedLangs = response.data.result.languages;
                }
                if($scope.profiledata.cvFileLocation){
                    var url = $scope.profiledata.cvFileLocation;
                    var array = url.split('\\');
                    var lastsegment = array[array.length - 1];
                    $scope.attachcopyStatus = true;
                    $scope.supprtDocumentName = array[array.length - 1];
                    console.log("lastsegment" + lastsegment);
                    console.log("location od resume" + $scope.supprtDocumentName);
                }       
                $scope.loading = true;
                viewProfilepic();
                $scope.membershipid = response.data.result.membershipId;
            });
        }
        
        /*view profile picture */
        function viewProfilepic() {
            var viewmemberprofile = smcConfig.services.GetMemberProfile.url;
            var member_login_id = $cookies.get('memberId');
            var viewmemberprofileurl = viewmemberprofile + member_login_id;
            $scope.loading = true;
            $http({
                method: 'GET',
                url: viewmemberprofileurl,
                responseType: 'arraybuffer'
            }).then(function (response) {
                $scope.loading = false;
                $scope.staticImage = false;
                console.log(response);
                var str = _arrayBufferToBase64(response.data);
                $scope.img = str;
                // str is base64 encoded.
            }, function (response) {
                $scope.staticImage = true;
                $scope.loading = false;
            });

            function _arrayBufferToBase64(buffer) {
                var binary = '';
                var bytes = new Uint8Array(buffer);
                var len = bytes.byteLength;
                for (var i = 0; i < len; i++) {
                    binary += String.fromCharCode(bytes[i]);
                }
                return window.btoa(binary);
            }
        }


        /*uplaod cv */
        $scope.uploadFile = function (file, index) {
            var file = file;
            console.log(file);
            if (file.size < 5242881) {
                if (validateUploadFileExtention(file.name)) {
                    $scope.supprtDocumentName = file.name;

                    $rootScope.documentUrl = file.url;
                    console.log("url" + $rootScope.documentUrl);
                    $scope.fileName = $scope.supprtDocumentName.split('.')[0];
                    var fd = new FormData();
                    fd.append('file', file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                        console.log(data);
                        $rootScope.supportFilePath = data.result;

                        $scope.cvlocation = $rootScope.supportFilePath;
                        $scope.attachcopyStatus = true;
                    });
                } else {
                    $scope.attachcopyStatuserr = true;
                    $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                }
            } else {
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        /*uplaod profile pic */
        $scope.uploadImage = function (file, index) {
            // console.log("memberId"+$cookies.get('memberId'));
            $scope.img = "";
            var file = file;
            console.log("profile file" + file);
            console.log("membership id" + $scope.profiledata.membershipId);
            if (file.size < 5242881) {
                if (validateProfileimage(file.name)) {
                    $rootScope.profilePicName = file.name;
                    $rootScope.documentUrl = file.url;
                    console.log("url" + $rootScope.documentUrl);
                    $scope.fileName = $rootScope.profilePicName.split('.')[0];
                    var fd = new FormData();
                    console.log("fd", fd);
                    fd.append('multipartFile', file);
                    fd.append('membershipId',  $scope.profiledata.membershipId);
                    httpPostFactory(smcConfig.services.MemberProfilePicture.url, fd, function (data) {
                        console.log(data);
                        $rootScope.supportFilePath = data.result;
                        viewProfilepic();
                    });

                } else {
                    $scope.profileattachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.profilImageType.toString();
                }
            } else {
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }
            /*eof uplaod profile pic */
        function validateProfileimage(val) {
            var allowedExtensions = $scope.profilImageType;
            var extension = val.split('.').pop();
            console.log("extension" + extension);
            for (var i = 0; i < allowedExtensions.length; i++) {
                if ($scope.profilImageType[i] == extension) {
                    return true;
                }
            }
        }
        // check valid file by exetension
        function validateUploadFileExtention(val) {
            var allowedExt = $scope.fileUploadTypes;
            var ext = val.split('.').pop();
            console.log("ext" + ext);
            for (var i = 0; i < allowedExt.length; i++) {
                if ($scope.fileUploadTypes[i] == ext) {
                    return true;
                }
            }
        }
        // if we want remove upload file
        $scope.attachcopyRemove = function () {
            $rootScope.supprtDocumentName = undefined;
            $rootScope.supportFilePath = undefined;
            $scope.attachcopyStatus = false;
            $scope.attachcopyStatuserr=false;
            $scope.profileattachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        $scope.Update = function () {
            if ($scope.profileattachcopyStatus||$scope.attachcopyStatuserr) {
                return;
            }
            console.log("this is the resume path" + undefinedSetNull($scope.cvlocation));
            console.log("inside of update function");
            console.log("memberid" + undefinedSetNull($scope.profiledata.professionalBackground));
            if ($scope.registered == true) {
                console.log("registered");
            }
            var formData = {
                "loginId" : $cookies.get('memberId'),
                "membershipId": undefinedSetNull($scope.profiledata.membershipId),
                "name": undefinedSetNull($scope.profiledata.name),
                "email": undefinedSetNull($scope.profiledata.email),
                "vehicleRegNum": undefinedSetNull($scope.profiledata.vehicleRegNum),
                "isGSTRegistered": undefinedSetFalse($scope.profiledata.isGSTRegistered),
                "address": {
                    "address1": undefinedSetNull($scope.profiledata.address.address1),
                    "address2": undefinedSetNull($scope.profiledata.address.address2),
                    "address3": undefinedSetNull($scope.profiledata.address.address3),
                    "address4": undefinedSetNull($scope.profiledata.address.address4),
                    "postalCode": undefinedSetNull($scope.profiledata.address.postalCode),
                    "phoneNumber": undefinedSetNull($scope.profiledata.address.phoneNumber),
                    "faxNumber": undefinedSetNull($scope.profiledata.address.faxNumber),
                    "isServiceAddress": null,
                    "countryCode": null,
                    "mobileNumber": undefinedSetNull($scope.profiledata.address.mobileNumber),
                    "country": undefinedSetNull($scope.profiledata.address.country)
                },
                "salutation": undefinedSetNull($scope.profiledata.salutation),
                "nationality": undefinedSetNull($scope.profiledata.nationality),
                "memberUIDType": null,
                "memberUIDValue": null,
                "gender": undefinedSetNull($scope.profiledata.gender),
                "qualification": undefinedSetNull($scope.profiledata.qualification),
                "designation": undefinedSetNull($scope.profiledata.designation),
                "organisation": undefinedSetNull($scope.profiledata.organisation),
                "payeeName": null,
                "professionalBackground": undefinedSetNull($scope.profiledata.professionalBackground),
                "experience": undefinedSetNull($scope.profiledata.experience),
                "isPDPAConsentClause": undefinedSetNull($scope.profiledata.isPDPAConsentClause),
                "dob": undefinedSetNull($scope.profiledata.dob),
                "gstRegistrationNum": undefinedSetNull($scope.profiledata.gstRegistrationNum),
                "languages": undefinedSetNull($scope.selectedLangs),
                "cvFileLocation": undefinedSetNull($scope.cvlocation),
                "caacMember": undefinedSetNull($scope.profiledata.caacMember),
                "boardOfDirectors": undefinedSetNull($scope.profiledata.boardOfDirectors)
            }

            console.log("formData" + JSON.stringify(formData));

            if ($scope.registered == true) {

                if ($scope.profiledata.gstRegistrationNum) {
                    updatePost();
                } else {
                    NotifyFactory.log('error', "Please enter gstRegistrationNum");
                }

            } else {
                updatePost();
            }

            function updatePost() {
                DataService.post('MemberProfileUpdate', formData).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        viewProfile();
                        NotifyFactory.log('success', "Member profile is updated successfully");

                    } else {

                        NotifyFactory.log('error', "error");
                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        console.log(error);
                        NotifyFactory.log('error', "error");
                    }
                });
            }
        }
        $scope.selectedLangs = [];
        $scope.pushLangs = function(lang){
            var index = $scope.selectedLangs.indexOf(lang);
            if(index != -1){
                $scope.selectedLangs.splice(index,1)
            }else{
                $scope.selectedLangs.push(lang);
            }
            
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        function undefinedSetFalse(val){
            if (val) {
                return val;
            } else {
                var val = false;
                return val;
            }
            return val;
        }
    }
})();
