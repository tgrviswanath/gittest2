(function () {
    'use strict';
    angular
        .module('smc')
        .controller('nonSMCCaseDetailsCtrl', nonSMCCaseDetailsCtrl);

    nonSMCCaseDetailsCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function nonSMCCaseDetailsCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.confirmOptions = [{'name':'Yes','value':true},{'name':'No','value':false}];
        $cookies.put('currentTab', 'nonSMCCaseDetails');
        $rootScope.currentTab = $cookies.get('currentTab')
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'nonSMCCaseDetails') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }


        $scope.dataLength = 10;
        $scope.max_pagenumber = '';

        get_nonsmc_caselist($scope.pagenumber);

        //Get status of mediated list Service
        DataService.get('GetStatusOfMediatedList').then(function(data){
            $scope.statusList = data.results;
            $scope.statusList.push({'name' : 'Others'})
        });

        //Get mediated case list
        DataService.get('GetMediatedCaseList').then(function(data){
            $scope.mediatedCaseList = data.results;
            $scope.mediatedCaseList.push({'name' : 'Others'})
        });

        //Get mediation subject list
        DataService.get('GetMediationSubjectList').then(function(data){
            $scope.subjectList = data.results;
            $scope.subjectList.push({'name' : 'Others'})
        });

        function get_nonsmc_caselist(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,  
                "loginId": $cookies.get('memberId')
            }
            getNonSmcCaseList(query);

        }

        function getNonSmcCaseList(query) {
            DataService.post('GetNonSMCCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.nonSmcCaseList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }


                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_nonsmc_caselist(pageNo);
        }

        $scope.openAddCase = function(){
            $scope.addCaseData = {};
            angular.element(".overlay").css("display","block");
            angular.element(".member-add-non-case").css("display","block");
        }

        $scope.closeAddCasePopup = function(){
            angular.element(".member-add-non-case").css("display","none");
            angular.element(".overlay").css("display","none");
        }

        $scope.checkValidHours = function(hour){
            if(parseInt(hour)>24){
                $scope.showInvalidHour = true;
            }else{
                $scope.showInvalidHour = false;
            }
        }

        $scope.addNonSmcCase = function(caseData){
            var query = buildQuery(caseData);
            DataService.post('AddNonSmcCaseByMember', query).then(function (data) {
                if(data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Case added successfully");
                    get_nonsmc_caselist($scope.pagenumber);
                    angular.element(".member-add-non-case").css("display", "none");
                    angular.element(".overlay").css("display", "none");
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    NotifyFactory.log('error', error.errorMessage);
                }
            });
        }

        function buildQuery(caseData){
            var caseQuery = {
                "loginId": $cookies.get('memberId'),
                "mediationDate": undefinedSetNull(caseData.mediationDate),
                "caseNumber": undefinedSetNull(caseData.caseNumber),
                "durationOfMediation": undefinedSetNull(caseData.durationOfMediation),
                "statusOfMediatedCase": undefinedSetNull(caseData.statusOfMediatedCase),
                "newStatusOfMediatedCase": undefinedSetNull(caseData.newStatusOfMediatedCase),
                "caseMediatedAt": undefinedSetNull(caseData.caseMediatedAt),
                "newCaseMediatedAt": undefinedSetNull(caseData.newCaseMediatedAt),
                "subjectMatterOfMediation": undefinedSetNull(caseData.subjectMatterOfMediation),
                "newSubjectMatterOfMediation": undefinedSetNull(caseData.newSubjectMatterOfMediation),
                "fullScaleMediation": undefinedSetNull(caseData.fullScaleMediation),
                "supportingDocument":  caseData.supportingDocument
            }
            return caseQuery;
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file){
            $scope.addCaseData.supportingDocument={};
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        $scope.addCaseData.supportingDocument.name = file.name;
                        $scope.addCaseData.supportingDocument.fileLocation = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }
        // check valid file by exetension
        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;
            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.fileUploadTypes[i] == ext){
                    return true;
                }
            }
        }

        // if we want remove upload file
        $scope.attachcopyRemove = function(){
            $scope.addCaseData.supportingDocument={};
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        $scope.openDeleteCaseData = function(caseDataId){
            $scope.caseDataId = caseDataId;
            angular.element(".overlay").css("display","block");
            angular.element(".form-submitt-confirm").css("display","block");
        }

        $scope.cancelDeleteCase = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".form-submitt-confirm").css("display","none");
        }

        $scope.DeleteCaseData = function(caseDataId){
            var query = {
                "loginId": $cookies.get('memberId'),
                "id":caseDataId
            }
            DataService.post('DeleteNonSmcCaseByMember', query).then(function (data) {
                if(data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Case deleted successfully");
                    get_nonsmc_caselist($scope.pagenumber);
                    angular.element(".form-submitt-confirm").css("display", "none");
                    angular.element(".overlay").css("display", "none");
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    NotifyFactory.log('error', error.errorMessage);
                }
            });
        }
   
   

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
