(function () {
    'use strict';
    angular
        .module('smc')
        .controller('mediatorRegisterCtrl', mediatorRegisterCtrl);

    mediatorRegisterCtrl.$inject = ['$rootScope', '$scope','$interval', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function mediatorRegisterCtrl($rootScope, $scope,$interval, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {
        $scope.languagesArray=[];  
        $scope.memberParticipantId=null;       

       if($cookies.get('memberId')==null){
            var currentUrl = window.location.href.split('/');
            var token = currentUrl[currentUrl.length - 1];
            var memberDetailsFromToken = smcConfig.services.MemberDetailsFromToken.url;
            var memberdetailsUrl = memberDetailsFromToken + token;
            $http.get(memberdetailsUrl).then(function (memberdetails) {
                $scope.memberdetails = memberdetails.data;
                $scope.memberParticipantId=memberdetails.data.result.id;
                $scope.memberRoleName=memberdetails.data.result.memberRoleName;
            });
       }
        
        //Get Salutation Type List Service        
        DataService.get('GetSalutationList').then(function(data){            
            $scope.salutations = data.results;   
        });        
        //Get Language List Service       
        DataService.get('GetLanguageList').then(function(data){            
            $scope.languageList = data.results;       
         });
        $scope.goToPayment=function(){
            var participantId=null;
            var memberRoleName=null;
            var phoneNumber=null;
            var mobileNumber=null;
            var faxNumber=null;

            if($scope.memberParticipantId){
                participantId = $scope.memberParticipantId;
            }else{
                participantId = $state.params.participantId;
            }  
            if($scope.memberRoleName){
                memberRoleName=$scope.memberRoleName;
            }else{
                 memberRoleName=$state.params.memberRoleName;
            }     
            if($scope.mediatorRegFormData.mediatorRegForm_phoneNumber){
               phoneNumber = '+65'+$scope.mediatorRegFormData.mediatorRegForm_phoneNumber; 
            }
            if($scope.mediatorRegFormData.mediatorRegForm_mobileNumber){
               mobileNumber='+65'+$scope.mediatorRegFormData.mediatorRegForm_mobileNumber;
            }
            if($scope.mediatorRegFormData.faxNumber){
                faxNumber='65'+$scope.mediatorRegFormData.faxNumber;
            }
            var query={
                "mediatorMemberRole":memberRoleName,
                "name":$scope.mediatorRegFormData.mediator_register_name,
                "email":$scope.mediatorRegFormData.email,
                "vehicleRegNum":$scope.mediatorRegFormData.vehicleRegNum,
                "professionalAffiliations":$scope.mediatorRegFormData.professionalAffiliations,
                "adrRelatedTraining":$scope.mediatorRegFormData.adrRelatedTraining,
                "salutation" :$scope.mediatorRegFormData.salutation,
                "gender":$scope.mediatorRegFormData.gender,
                "qualification":$scope.mediatorRegFormData.qualification,
                "designation":$scope.mediatorRegFormData.designation,
                "organisation":$scope.mediatorRegFormData.organisation,
                "dob":$scope.mediatorRegFormData.dob,
                "address":{
                    "address1":$scope.mediatorRegFormData.address1,
                    "address2":$scope.mediatorRegFormData.address2,
                    "address3":$scope.mediatorRegFormData.address3,
                    "address4":$scope.mediatorRegFormData.address4,
                    "postalCode":$scope.mediatorRegFormData.postalCode,
                    "phoneNumber":phoneNumber,
                    "faxNumber" :faxNumber,
                    "isServiceAddress" :null,
                    "countryCode": null,
                    "mobileNumber":mobileNumber,
                    "country" : "Singapore"
                },
                "nationality": "Singaporean",
                "memberUIDValue": $scope.mediatorRegFormData.memberUIDValue,
                "participantId":participantId,
                "languages":$scope.languagesArray,
                "undischargedBankrupt":$scope.mediatorRegFormData.undischargedBankrupt,
                "convictedCriminalOffence":$scope.mediatorRegFormData.convictedCriminalOffence,
                "declareInfo":$scope.mediatorRegFormData.declareInfo
            }

             
            console.log(query);
            
            DataService.post('MediatorRegistration', query).then(function (data) { 
                $scope.mediatorRegisterData=data.result;
                $scope.loginId=$scope.mediatorRegisterData.loginId;
                $scope.smcMemberId=$scope.mediatorRegisterData.smcMemberId;
                $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$scope.loginId, 'smcMemberId': $scope.smcMemberId,'memberRoleName':memberRoleName}); 
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.pushLangs=function(lang){
           var index= $scope.languagesArray.indexOf(lang);
           if(index!=-1){
                $scope.languagesArray.splice(index,1);
           }else{
                $scope.languagesArray.push(lang);
           }
        }

    }
})();
