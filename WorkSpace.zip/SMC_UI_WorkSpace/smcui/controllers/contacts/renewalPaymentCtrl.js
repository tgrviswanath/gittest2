
(function () {
    'use strict';
    angular
        .module('smc')
        .controller('renewalPaymentCtrl', renewalPaymentCtrl);

    renewalPaymentCtrl.$inject = ['$rootScope', '$scope','$interval', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function renewalPaymentCtrl($rootScope, $scope,$interval, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {
        var chequeValue="CHEQUE";
        var enetsValue="ENETS";
        $scope.fail_templatefile = 'views/contacts/smcmemberaccount/mediator-payment-fail.html';
        $scope.success_templatefile = 'views/contacts/smcmemberaccount/mediator-payment-success.html';
        $scope.ChequePayment=true;
        $scope.payment_summary = true;
        $scope.paymentMethod = chequeValue;
        getPaymentDetails();
        $scope.selectedMemberToPayment = $rootScope.selectedMemberToPayment;
        
        function getPaymentDetails(){
            var query={
                "loginId": $cookies.get('memberId'),
                "allRenewalStatus" : false,
                "roleIds" : $scope.selectedMemberToPayment  
            }
            DataService.post('GetMemberRenewalPaymentDetails', query).then(function (data) {
                if(data.status=="SUCCESS"){
                    $scope.mediatorRegisterPaymentDetail=data.result;     
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        $scope.check_method=function(payment_method){
            $scope.paymentMethod=payment_method;
            if(payment_method==chequeValue){
                $scope.ChequePayment=true;
                $scope.eNetsPayment=false;
            }else{
                $scope.eNetsPayment=true;
                $scope.ChequePayment=false;
            }
        }
        $scope.makePayment=function(paymentData,paymentMethod){
            var query={
                "loginId": $cookies.get('memberId'),
                "allRenewalStatus" : false,
                "roleIds" : $scope.selectedMemberToPayment ,
                "paymentMode":paymentMethod,
                "paymentType":"RENEWAL_FEE",
                "referenceNumber": paymentData.referenceNumber,
                "amount": paymentData.amount,
                "bankName": paymentData.bankName,
                "payerName": paymentData.payerName,
                "dateOfOrder": paymentData.dateOfOrder,
                "document": null
            }
         
            DataService.post('MakeMemberRenewalPayment', query).then(function (data) {
                if(data.status=="SUCCESS"){
                     $scope.mediatorRegisterPaymentSuccess=data.result;
                    $scope.payment_summary = false;
                    $scope.payment_success = true;
                   
                }else{
                    $scope.theTime = 10;
                    $interval(function () {
                        $scope.theTime = $scope.theTime-1;
                        if($scope.theTime == 0){
                            $scope.theTime = undefined;
                            $scope.ChequePayment=false;
                            $scope.eNetsPayment=false;
                            $scope.payment_summary = false;
                            $scope.payment_success = true;
                        }
                    },1000);
                }
            }).catch(function (error) {
                        $scope.theTime = 10;
                        $scope.payment_summary = false;
                        $scope.payment_failed = true;
                    $interval(function () {
                        $scope.theTime = $scope.theTime-1;
                        if($scope.theTime == 0){
                            $scope.payment_summary = true;
                            $scope.payment_failed = false;   
                            $scope.theTime = undefined;
                            $scope.ChequePayment=true;
                            $scope.eNetsPayment=false;  
                        }
                    },1000);
                NotifyFactory.log('error', error.errorMessage);
            });
        }
    }
})();
