(function () {
    'use strict';
    angular
        .module('smc')
        .controller('cfpPaymentCtrl', cfpPaymentCtrl);

    cfpPaymentCtrl.$inject = ['$rootScope', '$scope','$interval', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function cfpPaymentCtrl($rootScope, $scope,$interval, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {
        var chequeValue="CHEQUE";
        var enetsValue="ENETS";
        $scope.fail_templatefile = 'views/contacts/smcmemberaccount/mediator-payment-fail.html';
        $scope.success_templatefile = 'views/contacts/smcmemberaccount/mediator-payment-success.html';
        $scope.ChequePayment=true;
        $scope.payment_summary = true;
        $scope.paymentData={};
        $scope.payment_method = chequeValue;
         $scope.eNetsData={};
            // for e-Net
        var minYear = new Date().getFullYear();
        var maxYear = minYear+30;
        var minMonth = 1;
        var maxMonth = 12;
        $scope.yearList = [];
        for (var expYear = minYear; expYear < maxYear; expYear++) {
            $scope.yearList.push(expYear);
        }
        $scope.monthList = [];
        for (var expMonth = minMonth; expMonth <= maxMonth; expMonth++) {
            if(expMonth<=9){
                $scope.monthList.push('0'+expMonth);
            }else{
                $scope.monthList.push(expMonth);
            }
        }

        getPaymentDetails();
         DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
            $scope.roledetails = newdata.results;
            for(var i=0;i<$scope.roledetails.length;i++){
                if($scope.roledetails[i].name==$cookies.get('roleName')){
                    $scope.resourceId=$scope.roledetails[i].id;
                }
            }
        });
        $scope.check_method=function(payment_method){
            $scope.paymentMethod=payment_method;
            if(payment_method==chequeValue){
                $scope.ChequePayment=true;
                $scope.eNetsPayment=false;
            }else{
                $scope.eNetsPayment=true;
                $scope.ChequePayment=false;
            }
        }
        function getPaymentDetails(){
            var query={
                "loginId":$cookies.get('memberId'),
                "memberRole": $cookies.get('roleName')
            }
            DataService.post('GetMediatorRegisterPaymentDetail', query).then(function (data) {
                if(data.status=="SUCCESS"){
                    $scope.mediatorRegisterPaymentDetail=data.result;  
                      $scope.eNetsData.amount=data.result.totalAmount;   
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
          $scope.convertCardNo = function(){
            var numberLen = $scope.eNetsData.referenceNumber.length;
            if(numberLen == 4 || numberLen == 9 || numberLen == 14){
                $scope.eNetsData.referenceNumber = $scope.eNetsData.referenceNumber + '-';
            }
            if(numberLen == 19){
                $scope.hideSubmitBtn = false;
            }else{
                $scope.hideSubmitBtn = true;
            }
        }
         $scope.addpayment=function(method,payment){
                var selectedMonth = String(payment.month);
                var selectedYear = String(payment.year).substring(2);
                var expiry = selectedMonth + selectedYear;
                var query={
                    "paymentMode":method,
                    "referenceNumber":payment.referenceNumber.split('-').join(""), 
                    "amount":payment.amount, 
                    "dateOfOrder":payment.dateOfOrder, 
                    "bankName":payment.bankName,
                    "payerName" : payment.payerName,
                    "cardHolderName":payment.cardHolderName,
                    "cardCVV":payment.cardCVV,
                    "cardExpiry": expiry,
                    "loginId":$cookies.get('memberId'),
                    "memberId":$state.params.participantId,
                    "resourceId":$scope.resourceId
               
                }
                    DataService.post('MakeMediatorPayment', query).then(function (data) {
                        if(data.status=="SUCCESS"){
                             $scope.mediatorRegisterPaymentSuccess=data.result;
                            $scope.payment_summary = false;
                            $scope.payment_success = true;
                           
                        }else{
                            $scope.theTime = 10;
                            $interval(function () {
                                $scope.theTime = $scope.theTime-1;
                                if($scope.theTime == 0){
                                    $scope.theTime = undefined;
                                    $scope.ChequePayment=false;
                                    $scope.eNetsPayment=false;
                                    $scope.payment_summary = false;
                                    $scope.payment_success = true;
                                }
                            },1000);
                        }
                    }).catch(function (error) {
                                $scope.theTime = 10;
                                $scope.payment_summary = false;
                                $scope.payment_failed = true;
                            $interval(function () {
                                $scope.theTime = $scope.theTime-1;
                                if($scope.theTime == 0){
                                    $scope.payment_summary = true;
                                    $scope.payment_failed = false;   
                                    $scope.theTime = undefined;
                                    $scope.ChequePayment=true;
                                    $scope.eNetsPayment=false;  
                                }
                            },1000);
                        NotifyFactory.log('error', error.errorMessage);
                    });
        }
        $scope.makePayment=function(paymentData){
            var query={
                "loginId":$cookies.get('memberId'),
                "memberId":$state.params.participantId,
                "resourceId":$scope.resourceId,
                "paymentMode":$scope.payment_method,
                "paymentType":"MEMBERSHIP_FEE",
                "referenceNumber":paymentData.referenceNumber,
                "amount":paymentData.paymentFormAmount,
                "bankName":paymentData.bankName,
                "payerName":paymentData.payerName,
                "dateOfOrder":paymentData.chequePaymentdate
            }
            
            DataService.post('MakeMediatorPayment', query).then(function (data) {
                if(data.status=="SUCCESS"){
                    $scope.payment_summary = false;
                    $scope.payment_success = true;
                    $scope.mediatorRegisterPaymentSuccess=data.result;
                }else{
                    $scope.theTime = 10;
                    $interval(function () {
                        $scope.theTime = $scope.theTime-1;
                        if($scope.theTime == 0){
                            $scope.theTime = undefined;
                            $scope.ChequePayment=false;
                            $scope.eNetsPayment=false;
                            $scope.payment_summary = false;
                            $scope.payment_success = true;
                        }
                    },1000);
                }
            }).catch(function (error) {
                        $scope.theTime = 10;
                        $scope.payment_summary = false;
                        $scope.payment_failed = true;
                    $interval(function () {
                        $scope.theTime = $scope.theTime-1;
                        if($scope.theTime == 0){
                            $scope.payment_summary = true;
                            $scope.payment_failed = false;   
                            $scope.theTime = undefined;
                            $scope.ChequePayment=true;
                            $scope.eNetsPayment=false;  
                        }
                    },1000);
                NotifyFactory.log('error', error.errorMessage);
            });
        }

    }
})();
