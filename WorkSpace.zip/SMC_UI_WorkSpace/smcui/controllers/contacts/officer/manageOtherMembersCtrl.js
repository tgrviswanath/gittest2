(function() {
    'use strict';
    angular
        .module('smc')
        .controller('manageOtherMembersCtrl',manageOtherMembersCtrl);

    manageOtherMembersCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function manageOtherMembersCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'manageOtherMembers'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.pagenumber = 0;
        $scope.submitButton='Save';
        $scope.popupHead='Add new member';
        $scope.memberId=null;
        $scope.max_pagenumber = '';
        $scope.filter={};
        $cookies.put('currentTab','manageOtherMembers');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status

        DataService.get('GetSalutationList').then(function(data){
            $scope.salutationList = data.results;
        });
        var ContactGetOtherCetegoryMembersUrl = smcConfig.services.ContactGetOtherCetegoryMembers.url;
        $http.get(ContactGetOtherCetegoryMembersUrl).then(function (data) {
           $scope.otherMembers=data.data.results;
            $scope.filter.memberTypeId=$scope.otherMembers[0].id;
            getmemberList(0);
            for(var i=0;i<$scope.otherMembers.length;i++){
                if($scope.otherMembers[i].name=='Neutral Evaluator'){
                    $scope.neutralEvaluatorId=$scope.otherMembers[i].id;
                }
                if($scope.otherMembers[i].name=='CAAC Member'){
                    $scope.caacMemberId=$scope.otherMembers[i].id;
                }
                if($scope.otherMembers[i].name=='Board Member'){
                    $scope.boardMemberId=$scope.otherMembers[i].id;
                }
            }
        })
        .catch(function (error) {
            NotifyFactory.log('error', error.data.errorMessage);
        });
        $scope.shownodataavailable = true;        
        function getmemberList(pageNumber){
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
                var sorting = [
                    [0, 0],
                    [1, 0]
                ];
            var query={
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "name":null,
                "memberTypeId": $scope.filter.memberTypeId,
                "memberStatus":null,
                "gender":null,
                "dateOfBirthFrom":null,
                "dateOfBirthTo":null
            }
            getAllMemberList(query);

        }
        $scope.resetMemberlist=function(){
            $scope.filter=null; 
            getmemberList(0);
        }
        $scope.getAllMemberDataList=function(filterData){
            var query={
                "pageIndex":0,
                "dataLength":10,
                "sortingColumn":null,
                "sortDirection":null,
                "name":filterData.name,
                "memberTypeId": filterData.memberTypeId,
                "memberStatus":filterData.memberStatus,
                "gender":filterData.gender,
                "dateOfBirthFrom":null,
                "dateOfBirthTo":null
            }
            getAllMemberList(query);
        }
        function getAllMemberList(query){

            DataService.post('ContactOtherCategoryMembersList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.otherMemberList=data.result.responseData;

                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.otherMemberList.length>0){
                        $scope.shownodataavailable=false;
                    }
                }
            }).catch(function (error) {
                if(error.errorMessage=='Member Type Not Found'){
                     NotifyFactory.log('error','Please choose a Member Type');
                }else{
                    NotifyFactory.log('error', error.errorMessage);
                }
                 $scope.shownodataavailable=true;
            });
        }
        

        $scope.addOtherMember=function(){
            var phoneNumber=null;
            var faxNumber=null;
            var mobileNumber=null;
            var url='';

            if($scope.otherMember.address.phoneNumber){
                phoneNumber='+65'+$scope.otherMember.address.phoneNumber;
            }
            if($scope.otherMember.address.faxNumber){
                 faxNumber='+65'+$scope.otherMember.address.faxNumber;
            }
            if($scope.otherMember.address.mobileNumber){
                mobileNumber='+65'+$scope.otherMember.address.mobileNumber;
            }
            if($scope.submitButton=='Update'){
                url='ContactUpdateOtherCetegoryMembers';
            }else{
                url='ContactSaveOtherCetegoryMembers';
            }
            var memberTypeId=$scope.otherMember.roleId;
            var query={
                "loginId" :$cookies.get('memberId'),
                "memberRoleId":$scope.otherMember.roleId,
                "memberId":$scope.memberId,
                "name": $scope.otherMember.name,
                "email": $scope.otherMember.email,
                "vehicleRegNum": $scope.otherMember.vehicleRegNum,
                "experience":$scope.otherMember.experience,
                "salutation": $scope.otherMember.salutation,
                "personalAssistantName":$scope.otherMember.personalAssistantName,
                "gender": $scope.otherMember.gender,
                "startDate":$scope.otherMember.startDate,
                "endDate":$scope.otherMember.endDate,
                "address": {
                  "address1": $scope.otherMember.address.address1,
                  "address2": $scope.otherMember.address.address2,
                  "address3": $scope.otherMember.address.address3,
                  "address4": $scope.otherMember.address.address4,
                  "postalCode": $scope.otherMember.address.postalCode,
                  "phoneNumber": phoneNumber,
                  "faxNumber": faxNumber,
                  "isServiceAddress": null,
                  "countryCode": null,
                  "mobileNumber": mobileNumber,
                  "country": "Singapore"
                },
                "nationality": "Singaporean",
                "memberUIDValue": $scope.otherMember.memberUIDValue,
                "qualification": null,
                "designation": $scope.otherMember.designation,
                "organisation": $scope.otherMember.organisation,
                "dob": null,
                "languages": null
            }

            DataService.post(url,query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   $scope.otherMember=null;
                   if($scope.submitButton=='Update'){
                        NotifyFactory.log('success', 'Member Updated successfully');
                    }else{
                        NotifyFactory.log('success', 'Member Added successfully');
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".add-other-member").css("display","none");
                    $scope.filter.memberTypeId=memberTypeId;
                    getAllMemberList($scope.filter);

                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        
        $scope.changeMinDate=function(){
            var fromDate = $scope.otherMember.startDate;         
            $scope.toDateLimit = fromDate;               
            $( "#termEndDate" ).datepicker( "option", "minDate",fromDate );      
        }
        $scope.changeFilterMinDate=function(){
            var fromDate = $scope.filter.dateFrom;         
            $scope.toDateFilterLimit = fromDate;               
            $( "#toDateFilter" ).datepicker( "option", "minDate",fromDate);      
        }
        $scope.addMember=function(){
            $scope.submitButton='Save';
            angular.element(".overlay").css("display","block");
            angular.element(".add-other-member").css("display","block");
        }
        $scope.closeAddMember=function(){
            $scope.otherMember=null;
            angular.element(".overlay").css("display","none");
            angular.element(".add-other-member").css("display","none");
        }
        $scope.openMemberEdit=function(id){
            $scope.submitButton='Update';
            $scope.popupHead='Edit member';
            $scope.memberId=id;
            angular.element(".overlay").css("display","block");
            angular.element(".add-other-member").css("display","block");
            var ContactViewMemberDetailUrl = smcConfig.services.ViewMembershipProfileDetails.url+id;
            $http.get(ContactViewMemberDetailUrl).then(function (data) {
               $scope.otherMember=data.data.result;
               for(var i=0;i<$scope.otherMembers.length;i++){
                    if($scope.otherMember.memberTypeList[0]==$scope.otherMembers[i].name){
                        $scope.otherMember.roleId=$scope.otherMembers[i].id;
                    }
                    if($scope.otherMember.memberTypeList[0]=='Board Member'){
                        $scope.otherMember.startDate=$scope.otherMember.memberships[0].membershipPeriodFrom;
                        $scope.otherMember.endDate=$scope.otherMember.memberships[0].membershipPeriodTo;
                    }

                }
                if($scope.otherMember.address.mobileNumber){
                    $scope.otherMember.address.mobileNumber= $scope.otherMember.address.mobileNumber.substring(3);
                }
                 if($scope.otherMember.address.phoneNumber){
                    $scope.otherMember.address.phoneNumber= $scope.otherMember.address.phoneNumber.substring(3);
                } if($scope.otherMember.address.faxNumber){
                    $scope.otherMember.address.faxNumber= $scope.otherMember.address.faxNumber.substring(3);
                }
                   
            })
            .catch(function (error) {
                NotifyFactory.log('error', error.data.errorMessage);
            });
        }
        
    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();