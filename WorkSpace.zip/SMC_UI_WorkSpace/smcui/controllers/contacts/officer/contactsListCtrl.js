(function () {
    'use strict';
    angular
        .module('smc')
        .controller('contactsListCtrl', contactsListCtrl);

    contactsListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function contactsListCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
          if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('moduleName') != 'Contact') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        $scope.userRole = $cookies.get('roleName');
        $scope.filter = {};
        $scope.memberUploadList={};
        $scope.filteredRoleList=[];
        $scope.attachcopyStatus = false;
        $scope.attach_copy_name = '';
        $scope.fileUploadTypes = ["csv","xlsx","xls"];
        // to receive filter case list
        $scope.$on('activeTab', function (event, tabStatus) {
            $scope.currentTab = tabStatus;
        });

        $scope.getFilterCeses = function(roleId){
            $scope.$broadcast('filterCases',roleId);
            $rootScope.memberRoleId=roleId;
        } 

        // to get all values
        $scope.resetcases = function () {
            $scope.$broadcast('resetCases', 'reset');
        }

        DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
            $scope.roledetails = newdata.results;
            $scope.roleId=newdata.results[0].id;
            for(var index=0;index<newdata.results.length;index++){
                if(newdata.results[index].name=='SDRP'){
                    $scope.sdrpRoleId=newdata.results[index].id;
                }
                if(newdata.results[index].name=='Principal Mediator'){
                     $scope.pmRoleId=newdata.results[index].id;
                }
                if(newdata.results[index].name=='International Mediator'){
                     $scope.imRoleId=newdata.results[index].id;
                }
                if(newdata.results[index].name=='Adjudicator' || newdata.results[index].name=='Associate Mediator' || newdata.results[index].name=='CFP' || newdata.results[index].name=='SDRP' || newdata.results[index].name=='Principal Mediator' || newdata.results[index].name=='International Mediator' || newdata.results[index].name=='Family Panel'){
                    var obj={
                        "name":newdata.results[index].name,
                        "id":newdata.results[index].id
                    }
                    $scope.filteredRoleList.push(obj);
                }
            }
            if( $rootScope.roleId){
                for(var index=0;index<newdata.results.length;index++){
                    if(newdata.results[index].name=='Associate Meidator'){
                         $scope.roleId=newdata.results[index].id;
                    }
                }
            }else{
                $scope.roleId=newdata.results[0].id;
            }
        });
// upload a file - before that check file size,valid exetension
        $scope.uploadFile = function (file) {
                var file = file;
                if (file.size < 5242881) {
                    if (validateUploadFileExtention(file.name)) {
                        var fd = new FormData();
                        fd.append('Excel file', file);
                        fd.append('roleId', $rootScope.memberRoleId);
                        fd.append('loginId', $cookies.get('memberId'));
                        httpPostFactory(smcConfig.services.MediatorInviteListDetails.url, fd, function (data) {
                            $scope.$broadcast('filterCases',$rootScope.memberRoleId);
                            $scope.attachcopyStatus = true;
                        });
                    } else {
                        $scope.attachcopyStatus = true;
                        $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                    }
                } else {
                    NotifyFactory.log('error', "Please select below 5MB file");
                }
            }  

                    // check valid file by exetension
        function validateUploadFileExtention(val) {
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for (var i = 0; i < allowedExt.length; i++) {
                if ($scope.fileUploadTypes[i] == ext) {
                    return true;
                }
            }
        }      
    }
})();
