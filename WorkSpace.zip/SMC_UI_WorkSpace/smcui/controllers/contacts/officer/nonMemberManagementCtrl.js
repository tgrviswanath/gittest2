(function() {
    'use strict';
    angular
        .module('smc')
        .controller('nonMemberManagementCtrl',nonMemberManagementCtrl);

    nonMemberManagementCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$sce'];

    function nonMemberManagementCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$sce){
    	if(($cookies.get('roleName') != "SMC Officer" || $cookies.get('roleName') != "SMC Management") && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'nonMemberManagement'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $scope.roleName = $cookies.get('roleName');
        $scope.confirmOptions = ['Yes','No'];

        $scope.userStatusList = ['Active','In-active'];
        $scope.fileUploadTypes = ["pdf","csv","xlsx","xls","xml","xlsm"];
        $scope.nonMemberList = [];
        $scope.selectedMembers = [];
    	get_non_member_list($scope.pagenumber);//call to get panel list function
        $cookies.put('currentTab','nonMemberManagement');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
        // Get Non member category list
        DataService.get('GetNonMemberCategoryDetails').then(function (newdata) {
            $scope.categoryList = newdata.results;
            $scope.currentCategories = [];
            for(var category in $scope.categoryList){
                if($scope.categoryList[category].name != 'Party'){
                    $scope.currentCategories.push($scope.categoryList[category])
                }
                switch($scope.categoryList[category].name){
                    case 'Charter Signatory' : 
                        $scope.charterSignatoryId = $scope.categoryList[category].id;
                        break;
                    case 'Business Lead' : 
                        $scope.businessLeadId = $scope.categoryList[category].id;
                        break;
                    case 'Service Provider' :
                        $scope.serviceProviderId = $scope.categoryList[category].id;
                        break;
                    case 'Party' : 
                        $scope.partyId = $scope.categoryList[category].id;
                        break;
                     case 'Customer' : 
                        $scope.customerId = $scope.categoryList[category].id;
                        break;
                    default : 
                        $scope.externalTrainerId = $scope.categoryList[category].id;
                        break;
                }
            }
        });

        // get level of desiganation list
        DataService.get('GetNonMemberDesignationDetails').then(function (newdata) {
            $scope.desigList = newdata.results;
        });

        // get service provider types
        DataService.get('GetServiceProviderTypes').then(function (newdata) {
            $scope.serviceProviderTypes = newdata.results;
        });

        // get service salutation list
        DataService.get('GetSalutationList').then(function (newdata) {
            $scope.salutationList = newdata.results;
        });

        // get service level of designations
        DataService.get('GetLevelOfDesignations').then(function (newdata) {
            $scope.desgLevels = newdata.results;
        });


        // get industries
        DataService.get('GetIndustries').then(function (newdata) {
            $scope.industryList = newdata.results;
            $scope.industries = [];
            for(var industry in $scope.industryList){
                if($scope.industryList[industry].name != 'Industry' && $scope.industryList[industry].name != 'Industry 1'){
                    $scope.industries.push($scope.industryList[industry].name)
                }
            }
            $scope.industries.push('Others');
        });
        
    	// get non member list
    	function get_non_member_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
            var filterData = {};
            var query = buildQuery(filterData,$scope.pagenumber)
            if($scope.roleName == 'SMC Officer'){
                var listServiceUrl = 'ContactGetNonMemberList';
            }else{
                var listServiceUrl = 'ContactGetNonMemberListByManager';
            }
    		getNonMemberList(query,listServiceUrl);
    	}

    	function getNonMemberList(query,listServiceUrl){
    		DataService.post(listServiceUrl,query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.nonMemberList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.selectedMembers = [];
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.nonMemberList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
            $scope.pagenumber = pageNo;
            $cookies.put('pageNumber',$scope.pagenumber)
            var chkfilter = checkfilternotnull();
            if(!chkfilter){
                get_non_member_list(pageNo);
            }else{
                var query = buildQuery($scope.filter,pageNo)
                if($scope.roleName == 'SMC Officer'){
                    var listServiceUrl = 'ContactGetNonMemberList';
                }else{
                    var listServiceUrl = 'ContactGetNonMemberListByManager';
                }
                getNonMemberList(query,listServiceUrl);
            }
        } 

        function checkfilternotnull(){
            var find = false;
            for(var filter in $scope.filter){
                if($scope.filter[filter]){
                    find = true;
                }
            }
            return find;
        }

        //search members 
        $scope.getMember = function(filterData){
            $scope.pagenumber = 0;
            var query = buildQuery(filterData,0)
            if($scope.roleName == 'SMC Officer'){
                var listServiceUrl = 'ContactGetNonMemberList';
            }else{
                var listServiceUrl = 'ContactGetNonMemberListByManager';
            }
            getNonMemberList(query,listServiceUrl);
        }

        function buildQuery(filterData,pageNo){
            var query = {
                "pageIndex": pageNo,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "loginId": $cookies.get('memberId'),
                "name": undefinedSetNull(filterData.name),
                "categoryId": undefinedSetNull(filterData.categoryId),
                "charterSignatoryUEN": undefinedSetNull(filterData.charterSignatoryUEN),
                "organisation": undefinedSetNull(filterData.organisation),
                "levelOfDesignationId": undefinedSetNull(filterData.levelOfDesignationId),
                "industryId": undefinedSetNull(filterData.industryId),
                "emailAddress": undefinedSetNull(filterData.emailAddress),
                "emailOptIn" : undefinedSetNull(filterData.emailOptIn)
            }
            return query;
        }

        $scope.openAddNonMember = function(){
            $scope.addMemberData={};
            $scope.popupTitle = 'Add';
            $scope.addMemberData.categoryId = $scope.serviceProviderId;
            angular.element(".overlay").css("display","block");
            angular.element(".non-member-add").css("display","block");
        }

        $scope.closeAddNonMember = function(){
            angular.element(".non-member-add").css("display","none");
            angular.element(".overlay").css("display","none");
        }

        $scope.uploadFile = function(file){
            angular.element(".non-member-add").css("display","none");
            angular.element(".loading-container").css("display","block");
            $scope.addMemberData.document = {};
            var file = file;
            if (file.size < 5242881) {
                if (validateUploadFileExtention(file.name)) {
                    var fd = new FormData();
                    fd.append('file', file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                        $scope.addMemberData.document.name = file.name;
                        $scope.addMemberData.document.fileLocation = data.result;
                        $scope.attachcopyStatus = true;
                        angular.element(".loading-container").css("display","none");
                        angular.element(".non-member-add").css("display","block");
                    });
                } else {
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                    angular.element(".loading-container").css("display","none");
                    angular.element(".non-member-add").css("display","block");
                }
            } else {
                NotifyFactory.log('error', "Please select below 5MB file");
                angular.element(".loading-container").css("display","none");
                angular.element(".non-member-add").css("display","block");
            }
        }

        // if we want remove upload file
        $scope.attachcopyRemove = function () {
            $scope.addMemberData.document = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprtDocumentName").val("");
            angular.element("#fileLocation").val("");
        }

        // check valid file by exetension
        function validateUploadFileExtention(val) {
             var allowedExt = $scope.fileUploadTypes;

             var ext = val.split('.').pop();
             for (var i = 0; i < allowedExt.length; i++) {
                 if ($scope.fileUploadTypes[i] == ext) {
                     return true;
                 }
             }
        }

        $scope.clearMemberData = function(categoryId){
            $scope.addMemberData = {};
            if(categoryId==$scope.customerId){
                $scope.addMemberData.pdpa='No'; 
            }else{
                 $scope.addMemberData.pdpa=undefined; 
            }
            $scope.addMemberData.categoryId = categoryId;
        }

        $scope.saveNonMemberData =function (memberData,memberType,actionType){
            angular.element(".non-member-add").css("display","none");
            angular.element(".loading-container").css("display","block");
            switch(memberType){
                case 'businessLead':
                    var query = buildBusinessLeadQuery(memberData);
                    break;
                case 'charterSignatory' :
                    var query = buildCharterSignatoryQuery(memberData);
                    break;
                case 'externalTrainer' : 
                    var query = buildExternalTrainerQuery(memberData);
                    break;
                case 'customer' : 
                    var query = buildCustomerQuery(memberData);
                    break;
                default : 
                    var query = buildServiceProviderQuery(memberData);
                    break;
            }
            if(actionType == 'Add'){
                var serviceUrl = 'AddNonMember';
                var successMessage = 'Member added successfully';
            }else{
                var serviceUrl = 'UpdateNonMember';
                var successMessage = 'Member updated successfully';
                query.memberId = memberData.memberId;
            }
            DataService.post(serviceUrl,query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',successMessage);
                    var chkfilter = checkfilternotnull();
                    if(!chkfilter){
                        get_non_member_list($cookies.get('pageNumber'));
                    }else{
                        var query = buildQuery($scope.filter,$cookies.get('pageNumber'))
                        getNonMemberList(query);
                    }
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".non-member-add").css("display","block");
            });
        }

        function buildBusinessLeadQuery(memberData){
            var query = {
                "loginId" : $cookies.get('memberId'),
                "categoryId": undefinedSetNull(memberData.categoryId),
                "salutaionId": undefinedSetNull(memberData.salutationId),
                "firstName": undefinedSetNull(memberData.firstName), 
                "surName": undefinedSetNull(memberData.surName),
                "gender": undefinedSetNull(memberData.gender),
                "designation": undefinedSetNull(memberData.designationName),
                "levelOfDesgId": undefinedSetNull(memberData.designationLevelId),
                "orgName": undefinedSetNull(memberData.organisationName),
                "industry": (memberData.industryName != 'Others')?memberData.industryName:memberData.otherIndustry,
                "email": undefinedSetNull(memberData.userEmail),
                "source": undefinedSetNull(memberData.source),
                "emailOptIn": undefinedSetNull(memberData.emailOptIn),
                "address": buildAddress(memberData.address),
                "document": memberData.document? memberData.document : null
            }
            return query;
        }

        function buildCharterSignatoryQuery(memberData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "categoryId": undefinedSetNull(memberData.categoryId),
                "memberUIDValue": undefinedSetNull(memberData.uidValue),
                "orgName": undefinedSetNull(memberData.organisationName),
                "contactName": undefinedSetNull(memberData.contactPersonName),
                "contactDesg": undefinedSetNull(memberData.designationName),
                "contactNumber": undefinedSetNull(memberData.contactNumber),
                "industry": (memberData.industryName != 'Others')?memberData.industryName:memberData.otherIndustry,
                "email": undefinedSetNull(memberData.userEmail),
                "isPdpaConsentClause": undefinedSetNull(memberData.isPDPAConsentClause),
                "memberStatus": undefinedSetNull(memberData.memberStatus),
                "address": buildAddress(memberData.address),
                "document": memberData.document? memberData.document : null
            }
            return query;
        }

        function buildExternalTrainerQuery(memberData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "categoryId": undefinedSetNull(memberData.categoryId),
                "memberUIDValue": undefinedSetNull(memberData.uidValue),
                "traineeName": undefinedSetNull(memberData.trainerName),
                "gstRegistrationNo": undefinedSetNull(memberData.gstRegistrationNumber),
                "trainingSubject": undefinedSetNull(memberData.trainingSubject),
                "payeeName": undefinedSetNull(memberData.payeeName),
                "email": undefinedSetNull(memberData.userEmail),
                "isPdpaConsentClause": undefinedSetNull(memberData.isPDPAConsentClause),
                "memberStatus": "Active",
                "orgName": undefinedSetNull(memberData.organisationName),
                "designation": undefinedSetNull(memberData.designationName),
                "address": buildAddress(memberData.address)
            }
            if(memberData.isGSTRegistered == 'Yes'){
                query.isGST = true;
            }else{
                query.isGST = false;
            }
            return query;
        }

        function buildServiceProviderQuery(memberData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "categoryId": undefinedSetNull(memberData.categoryId),
                "memberUIDValue": undefinedSetNull(memberData.uidValue),
                "userType": undefinedSetNull(memberData.memberType),
                "contactPerson": undefinedSetNull(memberData.contactPersonName),
                "type": undefinedSetNull(memberData.serviceProviderType),
                "payeeName": undefinedSetNull(memberData.payeeName),
                "email": undefinedSetNull(memberData.userEmail),
                "isPdpaConsentClause": undefinedSetNull(memberData.isPDPAConsentClause),
                "memberStatus": "Active",
                "address": buildAddress(memberData.address)
            }
            if(memberData.memberType == 'Individual'){
                query.userName = undefinedSetNull(memberData.userName);
            }else{
                query.companyName = undefinedSetNull(memberData.companyName);
            }
            return query;
        }

        function buildCustomerQuery(memberData){
            if(memberData.address.phoneNumber){
                memberData.address.phoneNumber='+65'+memberData.address.phoneNumber;
            }
            if(memberData.address.mobileNumber){
                memberData.address.mobileNumber='+65'+memberData.address.mobileNumber;
            }
            if(memberData.address.faxNumber){
                memberData.address.faxNumber='+65'+memberData.address.faxNumber;
            }
            var query = {
                "loginId": $cookies.get('memberId'),
                "categoryId": undefinedSetNull(memberData.categoryId),
                "memberUIDValue": undefinedSetNull(memberData.memberUIDValue),
                "customerName":undefinedSetNull(memberData.userName),
                "email": undefinedSetNull(memberData.userEmail),
                "designation": undefinedSetNull(memberData.designationName),
                "orgName": undefinedSetNull(memberData.organisationName),
                "isPdpaConsentClause": undefinedSetNull(memberData.pdpa),
                "address": buildAddress(memberData.address)
            }
            return query;
        }

        function buildAddress(memberAddress){
            var address = {
                "address1": undefinedSetNull(memberAddress.address1),
                "address2": undefinedSetNull(memberAddress.address2),
                "address3": undefinedSetNull(memberAddress.address3),
                "address4": undefinedSetNull(memberAddress.address4),
                "phoneNumber": undefinedSetNull(memberAddress.phoneNumber),
                "mobileNumber": undefinedSetNull(memberAddress.mobileNumber),
                "postalCode": undefinedSetNull(memberAddress.postalCode),
                "faxNumber": undefinedSetNull(memberAddress.faxNumber),
                "country": undefinedSetNull(memberAddress.country)
            }
            return address;
        };

        $scope.viewMemberData = function(memberDetails){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            $scope.popupTitle = 'View';
            var query = {
                "memberId" : memberDetails.memberId,
                "loginId" : $cookies.get('memberId'),
                "categoryId" : memberDetails.categoryId
            }
            if(memberDetails.category != 'Party'){
                var serviceUrl = 'GetNonMemberDetails';
            }else{
                var serviceUrl = 'GetNonMemberPartyDetails';
            }

            DataService.post(serviceUrl,query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    if(memberDetails.category != 'Party'){
                        $scope.addMemberData = data.result;
                        if($scope.addMemberData.isGSTRegistered == true){
                            $scope.addMemberData.isGSTRegistered = 'Yes';
                        }else{
                            $scope.addMemberData.isGSTRegistered = 'No';
                        }
                        if($scope.addMemberData.document){
                            $scope.attachcopyStatus = true;
                        }else{
                            $scope.attachcopyStatus = false;
                        }
                        if($scope.addMemberData.emailOptIn){
                            $scope.addMemberData.emailOptIn = 'true'
                        }else{
                            $scope.addMemberData.emailOptIn = 'false'
                        }
                        angular.element(".loading-container").css("display","none");
                        angular.element(".non-member-add").css("display","block");
                    }else{
                        $scope.viewPartyData = data.result;
                        angular.element(".loading-container").css("display","none");
                        angular.element(".view-party-details").css("display","block");
                    }
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".overlay").css("display","none");
            });
        }

        $scope.closePartyDetails = function (){
            angular.element(".view-party-details").css("display","none");
            angular.element(".overlay").css("display","none");
        }

        $scope.savePartyData = function(partyData){
            angular.element(".view-party-details").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = {
                "memberId" : partyData.memberId,
                "loginId" : $cookies.get('memberId'),
                "isPdpaConsentClause" : partyData.isPDPAConsentClause
            }
            DataService.post('UpdateNonMemberPartyDetails',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Party details updated successfully');
                    var chkfilter = checkfilternotnull();
                    if(!chkfilter){
                        get_non_member_list(pageNo);
                    }else{
                        var query = buildQuery($scope.filter,$cookies.get('pageNumber'))
                        getNonMemberList(query);
                    }
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".view-party-details").css("display","block");
            });
        }       

        $scope.exportNonMemberList = function(){
            var checkfilter = checkfilternotnull();
            if(checkfilter){
                var query = buildQuery($scope.filter,$cookies.get('pageNumber'));
                DataService.post('ExportSMCNonMemberList',query).then(function (data) {
                    if(data){
                        var blob = new Blob([data], {
                            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
                        });
                        saveAs(blob, "Non-memberList.xls");
                    }else{
                        $scope.shownodataavailable = true;
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error',error.errorMessage)
                });
            }else{
                NotifyFactory.log('error','Please select member type')
            }

        }

        $scope.pushMemberinList = function(selectedmember){
            
            if(selectedmember.category != 'Party'){
                var findMemberinList = -1;
                for(var member in $scope.selectedMembers){
                    if($scope.selectedMembers[member].id == selectedmember.memberId){
                        findMemberinList = member;
                    }
                }
                if(findMemberinList == -1){
                    var pushQuery = {
                        "id": selectedmember.memberId,
                        "membershipId": selectedmember.userId
                    }
                   $scope.selectedMembers.push(pushQuery) 
                }else{
                    $scope.selectedMembers.splice(findMemberinList,1)
                }
            }else{
                var findMemberinList = $scope.selectedMembers.indexOf(selectedmember.memberId);
                if(findMemberinList != -1){
                    $scope.selectedMembers.splice(findMemberinList,1)
                }else{
                    $scope.selectedMembers.push(selectedmember.memberId)
                }
            }
        }

        $scope.openGenerateLetter = function(categoryId){
            $scope.selectedCategoryId = categoryId;
            $scope.messageContents = '';
            angular.element(".overlay").css("display","block");
            angular.element(".smcmember-generate-letter").css("display","block");
        }

        $scope.closeGenerateLetter = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".smcmember-generate-letter").css("display","none");
        }

        $scope.generateLetter = function(messageContents,categoryId){
            angular.element(".smcmember-generate-letter").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId": $cookies.get('memberId'),
                "message": messageContents,
                "categoryId" : categoryId,
            }
            if(categoryId != $scope.partyId){
                query.memberIds = $scope.selectedMembers;
            }else{
                query.caseMemberIds = $scope.selectedMembers;
            }
            
            $http.post(smcConfig.services.SMCNonMemberGenerateLetter.url, query, {
                responseType: 'arraybuffer'
            })
            .success(function (response) {
                var file = new Blob([response], {
                    type: 'application/pdf'
                });
                var fileURL = URL.createObjectURL(file);
                $scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
                angular.element(".loading-container").css("display","none");
                angular.element("#member_letter_view").css("display", "block");
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".smcmember-generate-letter").css("display","block");
            });
        }

        $scope.closePrintPdf = function(modelId,popupProcess){
            angular.element("#"+modelId).css("display", "none");
            if(!popupProcess){
                angular.element(".smcmember-generate-letter").css("display","block");
            }else{
                angular.element(".overlay").css("display","none");
                $scope.popupProcess = undefined;
                $scope.selectedMembers = [];
            }
        }


    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();