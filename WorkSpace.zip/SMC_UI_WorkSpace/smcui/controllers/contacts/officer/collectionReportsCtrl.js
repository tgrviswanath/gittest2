(function() {
    'use strict';
    angular
        .module('smc')
        .controller('contactCollectionReportsCtrl',contactCollectionReportsCtrl);

    contactCollectionReportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$sce'];

    function contactCollectionReportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$sce){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'collectionReports'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.collectionList = [];
        $scope.max_pagenumber = '';
    	get_collection_reports($scope.pagenumber);//call to get collection report list function
        $cookies.put('currentTab','collectionReports');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status

        // get member types
        DataService.get('GetSmcMemberRoleDetails').then(function (data) {
            var roledetails = data.results;
            $scope.currentMemberTypes = [];
            for(var role in roledetails){
                if(roledetails[role].name == 'Associate Mediator' || roledetails[role].name == 'Principal Mediator' || roledetails[role].name == 'CFP'){
                    $scope.currentMemberTypes.push(roledetails[role]);
                }
            }
        }).catch(function (error) {
            $scope.currentMemberTypes = [];
        });

        //Get Payment Mode List Service
        DataService.get('GetPaymentModes').then(function(data){
            var paymentModes = data.results;
            $scope.currentPaymentModes = [];
            for(var mode in paymentModes){
                if(paymentModes[mode].name == 'E-Nets' || paymentModes[mode].name == 'Cheque'){
                    $scope.currentPaymentModes.push(paymentModes[mode]);
                }
            }
        }).catch(function (error) {
            $scope.currentPaymentModes = [];
        });

         //Get Payment Types List Service
        DataService.get('GetPaymentTypes').then(function(data){
            var paymentTypes = data.results;
            $scope.currentPaymentTypes = [];
            for(var type in paymentTypes){
                if(paymentTypes[type].name == 'Membership Fee' || paymentTypes[type].name == 'Renewal Fee'){
                    $scope.currentPaymentTypes.push(paymentTypes[type]);
                }
            }
        });
        
    	// get collection report list
    	function get_collection_reports(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var filterData = {};
            var query = buildReportsQuery(filterData,$scope.pagenumber)
    		getCollectionReports(query);
    	}

    	function getCollectionReports(query){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
    		DataService.post('GetContactCollectionReports',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.collectionList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.collectionList.length == 0){
                        $scope.shownodataavailable = true;
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}else{
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
            $scope.pagenumber = pageNo;
            $cookies.put('pageNumber',$scope.pagenumber)
            var chkfilter = checkfilternotnull();
            if(!chkfilter){
                get_collection_reports(pageNo);
            }else{
                var query = buildReportsQuery($scope.filter,pageNo)
                getCollectionReports(query);
            }
        } 

        //search reports 
        $scope.getReports = function(filterData){
            $scope.pagenumber = 0;
            var query = buildReportsQuery(filterData,0)
            getCollectionReports(query);
        }

        function buildReportsQuery(filterData,pageNo){
            var query = {
                "pageIndex":$scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null,
                "memberName": undefinedSetNull(filterData.memberName),
                "memberShipId": undefinedSetNull(filterData.memberShipId),
                "memberRoleId": undefinedSetNull(filterData.memberRoleId),
                "paymentMode": undefinedSetNull(filterData.paymentMode),
                "paymentFromDate": undefinedSetNull(filterData.paymentFromDate),
                "paymentToDate": undefinedSetNull(filterData.paymentToDate),
                "amountFrom": undefinedSetNull(filterData.amountFrom),
                "amountTo": undefinedSetNull(filterData.amountTo),
                "paymentType": undefinedSetNull(filterData.paymentType),
                "chequeNumber": undefinedSetNull(filterData.chequeNumber),
                "cashierOrderNumber": undefinedSetNull(filterData.cashierOrderNumber),
                "transactionRefNum": undefinedSetNull(filterData.transactionRefNum),
                "invoiceNumber": undefinedSetNull(filterData.invoiceNumber)
            }
            return query;
        }

        function checkfilternotnull(){
            var find = false;
            for(var filter in $scope.filter){
                if($scope.filter[filter]){
                    find = true;
                }
            }
            return find;
        }


        //reset report list
        $scope.resetreports = function(){
            $scope.filter = undefined;
            get_collection_reports(0);
        }

        $scope.exportCollectionReportList = function(){
            var checkfilter = checkfilternotnull();
            if(checkfilter){
                var query = buildReportsQuery($scope.filter,$cookies.get('pageNumber'));
                DataService.post('ExportSMCMemberList',query).then(function (data) {
                    if(data){
                        var blob = new Blob([data], {
                            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
                        });
                        saveAs(blob, "Memberlist.xls");
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error',error.errorMessage)
                });
            }else{
                NotifyFactory.log('error','Please select member type')
            }
        }

        $scope.downloadIdentifier = function(reportData,identifier){
            if(identifier == 'regenrate'){
                angular.element(".form-submitt-confirm").css("display", "none");
            }
            downloadIdentifier(reportData,identifier)
        }

        function downloadIdentifier(reportData,identifier){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = {
                "id": reportData.id,
                "loginId": $cookies.get('memberId'),
            }
            if(identifier == 'invoice' ){
                query.financeIdentifier = reportData.financeIdentifier;
                var serviceUrl = smcConfig.services.DownloadCollectionReportInvoice.url;
            }else if(identifier == 'regenrate'){
                query.financeIdentifier = reportData.financeIdentifier;
                var serviceUrl = smcConfig.services.RegenerateCollectionReportInvoice.url;
            }else{
                query.financeIdentifier = reportData.receiptNumber;
                var serviceUrl = smcConfig.services.DownloadCollectionReportReceipt.url;
            }
            $http.post(serviceUrl, query, {
                responseType: 'arraybuffer'
            })
            .success(function (response) {
                var file = new Blob([response], {
                    type: 'application/pdf'
                });
                var fileURL = URL.createObjectURL(file);
                $scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
                angular.element(".loading-container").css("display","none");
                angular.element("#invoice_document_view").css("display", "block");
            }).catch(function (error) {
                NotifyFactory.log('error',error.data.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".overlay").css("display","none");
            });
        }

        $scope.closePrintPdf = function(modelId){
            angular.element("#"+modelId).css("display", "none");
            angular.element(".overlay").css("display","none");
        }

        $scope.regenrateInvoice = function(reportData,identifier){
            $scope.reportData = reportData;
            $scope.pdfIdentifier = identifier;
            angular.element(".overlay").css("display", "block");
            angular.element(".form-submitt-confirm").css("display", "block");
        }

        $scope.cancelRegenrate = function(){
            angular.element(".form-submitt-confirm").css("display", "none");
            angular.element(".overlay").css("display", "none");
        }

        $scope.updateAkgmntDate = function(reportId,paymentMode){
            $scope.akgmntData = {};
            $scope.akgmntData.id = reportId;
            $scope.paymentMode = paymentMode;
            angular.element(".overlay").css("display","block");
            angular.element(".update-ackg-date").css("display","block");
        }

        $scope.cancelupdaterecipt = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".update-ackg-date").css("display","none");
        }

        $scope.updateReciptDate = function(reciptData){
            angular.element(".loading-container").css("display","block");
            angular.element(".update-ackg-date").css("display","none");
            reciptData.loginId = $cookies.get('memberId');
            DataService.post('ContactUpdateCollectionReceiptDate',reciptData).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Receipt date updated successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".update-ackg-date").css("display","block");
            });
        }


        $scope.addPaymentData = function(report){
            $scope.paymentData = {};
            var query = {
                "loginId": $cookies.get('memberId'),
                "resourceId":report.memberRoleId,
                "memberId": report.memberId
            }
            DataService.post('GetContactFailedInvoices',query).then(function(data){
                if(data.data.status == 'SUCCESS'){
                    $scope.invoices = data.results;
                }
            });
            angular.element(".overlay").css("display","block");
            angular.element(".add-payment-details-officer").css("display","block");
        }

        $scope.canceladdpayment = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-payment-details-officer").css("display","none");
        }

        $scope.submitAddPayment = function (paymentData){
            angular.element(".loading-container").css("display","block");
            angular.element(".add-payment-details-officer").css("display","none");
            var query = buildPaymentQuery(paymentData);
            DataService.post('AddPaymentByContactOfficer',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Payment added successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".add-payment-details-officer").css("display","block");
            });
        }

        function buildPaymentQuery(paymentData){
            var dataQuery = {
                "loginId":$cookies.get('memberId'),
                "memberId": undefinedSetNull(paymentData.memberId),
                "resourceId": undefinedSetNull(paymentData.memberRoleId),
                "paymentMode": undefinedSetNull(paymentData.paymentMode),
                "referenceNumber": undefinedSetNull(paymentData.referenceNumber),
                "dateOfOrder": undefinedSetNull(paymentData.dateOfOrder),
                "amount": undefinedSetNull(paymentData.amount),
                "bankName": undefinedSetNull(paymentData.bankName),
                "paymentType": undefinedSetNull(paymentData.paymentType),
                "receiptDate": undefinedSetNull(paymentData.receiptDate),
                "invoiceNumber": undefinedSetNull(paymentData.invoiceNumber),
                "payerName": undefinedSetNull(paymentData.payerName)
            }
            return dataQuery;
        }

        $scope.modeChange = function(data,id){
            $scope.paymentData = {};
            $scope.paymentData.paymentMode = id;
            $scope.paymentData.caseNumber = data.caseNumber;
            $scope.paymentData.payerName = data.payerName;
        }


        $scope.openStatus = function(reportData){
            $scope.updateCqkData = {};
            var viewDataUrl = smcConfig.services.GetContactPaymentDetailstoView.url + reportData.id;
            $http.get(viewDataUrl).then(function(data){
                if(data.data.status == 'SUCCESS'){
                    $scope.chkData = data.data.result;
                    $scope.updateCqkData.paymentId = $scope.chkData.id;
                    $scope.updateCqkData.referenceNumber = $scope.chkData.chequeNumber;
                    angular.element(".overlay").css("display","block");
                    angular.element(".payment-view-status").css("display","block");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
            });
        }

        $scope.cancelViewStatus = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".payment-view-status").css("display","none"); 
        }

        $scope.updateCheque = function (updatedData){
            angular.element(".loading-container").css("display","block");
            angular.element(".payment-view-status").css("display","none");
            var query = buildUpdateChequeQuery(updatedData);
            DataService.post('ContactUpdateChequeDetails',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Cheque updated successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".payment-view-status").css("display","block");
            });
        }
        $scope.toDateLimit=0;  
        $scope.changeMinDate=function(){
                var fromDate = $scope.filter.paymentFromDate;         
                $scope.toDateLimit = fromDate;        
                $scope.filter.paymentToDate = '';        
                $( "#paymentTo" ).datepicker( "option", "minDate",fromDate );     
        }

        $scope.openAddInvoice = function(){
            $scope.invoiceData = {};
            $scope.invoiceData.paymentMode = 'Cheque/Internet Banking';
            $scope.invoiceData.paymentType = 'Renewal Fees';
            angular.element(".overlay").css("display","block");
            angular.element(".add-invoice-details-officer").css("display","block");
        }

        $scope.cancelAddInvoice = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-invoice-details-officer").css("display","none");
        }

        function buildUpdateChequeQuery(updatedData){
            var query = {
                "paymentId": updatedData.paymentId,
                "loginId": $cookies.get('memberId'),
                "referenceNumber": undefinedSetNull(updatedData.referenceNumber),
                "amount":undefinedSetNull(updatedData.amount),
                "dateOfOrder":undefinedSetNull(updatedData.dateOfOrder),
                "bankName":undefinedSetNull(updatedData.bankName),
                "remarks":undefinedSetNull(updatedData.remarks)
            }

            return query;
        }

        $scope.getMemberName = function (memberRoleId,memberShipId){
            if(memberRoleId&&memberShipId){
                var query = {
                    "memberShipId":memberShipId,
                    "memberRoleId":memberRoleId
                }
                DataService.post('GetInvoiceMemberByOfficer',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        $scope.invoiceData.memberName = data.result.memberName;
                        $scope.invoiceData.memberId = data.result.memberId;
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error',error.errorMessage);
                });
            }
        }

        $scope.submitAddInvoice = function(invoiceData){
            angular.element(".add-invoice-details-officer").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = buildInvoiceQuery(invoiceData);
            DataService.post('ContactAddInvoiceByOfficer',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Invoice added successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".add-invoice-details-officer").css("display","block");
            });
        }

        function buildInvoiceQuery(invoiceData){
            var query = {
                "loginId": $cookies.get('memberId'),
                "memberId": undefinedSetNull(invoiceData.memberId),
                "memberRoleId": undefinedSetNull(invoiceData.memberRoleId),
                "memberShipId": undefinedSetNull(invoiceData.memberShipId),
                "memberName": undefinedSetNull(invoiceData.memberName),
                "paymentMode":"CHEQUE",
                "paymentType":"RENEWAL_FEE",
                "referenceNumber":undefinedSetNull(invoiceData.referenceNumber),
                "amount":undefinedSetNull(invoiceData.amount),
                "paymentDate": undefinedSetNull(invoiceData.paymentDate),
                "bankName": undefinedSetNull(invoiceData.bankName),
                "invoiceNumber": undefinedSetNull(invoiceData.invoiceNumber),
                "memberShipFrom": undefinedSetNull(invoiceData.memberShipFrom),
                "memberShipTo": undefinedSetNull(invoiceData.memberShipTo)
            }
            return query;
        }

        $scope.membershipFromDateClick = function(){
            var fromDate = $scope.invoiceData.memberShipFrom;
            var toDate = $scope.invoiceData.memberShipTo;
            $scope.membershipMinDate = fromDate;
            $( "#membershipTo" ).datepicker( "option", "minDate",fromDate );
            if((new Date(fromDate)) > (new Date(toDate))){
                $scope.invoiceData.memberShipTo = undefined;
            }
        }

    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();