(function () {
    'use strict';
    angular
        .module('smc')
        .controller('contactstobeinvitedCaseCtrl', contactstobeinvitedCaseCtrl);

    contactstobeinvitedCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function contactstobeinvitedCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('moduleName') != 'Contact') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        var roledetails;
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fullselectid = true;
        $scope.defaultSelectStatus = true;
        $scope.shownocheckboxchecked = false;
        /**athira*/
        $scope.firstchkd = true;
        $scope.secondckd = true;
        $scope.case_id = [];
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'tobeinvited') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
            console.log("pageno in if" + $scope.pagenumber);
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_tobeinvited_caselist($scope.pagenumber); //call to tobeinvited case list function
        $cookies.put('currentTab', 'tobeinvited');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status


        // get tobeinvited case list
        function get_tobeinvited_caselist(pageNumber) {

            DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
                console.log("newdata", newdata)
                roledetails = newdata.results;
                var memberRoleIdarr = [];
                var memberRoleName = [];
                if(!$scope.roleId){
                    angular.forEach(roledetails, function (value) {
                    memberRoleIdarr.push(value.id);
                    memberRoleName.push(value.name);
                        if (angular.equals('Adjudicator', value.name)) {
                            $scope.roleId = value.id;
                        }
                    });
                }
                $scope.memberRoleids = memberRoleIdarr;
                $scope.memberRoleNames = memberRoleName;
                aftergettingMemberRoleid(pageNumber);
            });

            function aftergettingMemberRoleid(pageNumber) {
                var memberroleids = [];
                memberroleids = $scope.memberRoleids;
                if (pageNumber) {
                    $scope.pagenumber = pageNumber;
                } else {
                    $scope.pagenumber = 0;
                }
                $cookies.put('pageNumber', $scope.pagenumber)
                var sorting = [
                    [0, 0],
                    [1, 0]
                ];
                var query = {
                    "pageIndex": $scope.pagenumber,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": $scope.roleId
                }                         

                getAllTobeInvitedCases(query);
            }
        }
        //get all tobeinvited case list 
        function getAllTobeInvitedCases(query) {
            DataService.post('GetContactsTobeCompletedList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    
                    $scope.tobeinvited_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    console.log(value);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    if($scope.firstchkd){
                       for (var i = 0; i < data.result.responseData.length; i++) {
                            console.log("enterd in list");
                            var dataId = data.result.responseData[i].id;
                            console.log("dataid" + dataId);
                            $scope.case_id[dataId] = true;
                        } 
                    }else if($scope.case_id.length==0){
                         $scope.shownocheckboxchecked = true;
                    }
                    $scope.first_clk = function () {
                        if ($scope.firstchkd) {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].id;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = true;
                                $scope.shownocheckboxchecked = false;
                            }
                        } else {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].id;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = false;
                                $scope.shownocheckboxchecked = true;
                            }
                        }
                    }
                } else {
                    $scope.shownodataavailable = true;
                    $scope.firstchkd = false;   
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.firstchkd = false;   
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
                $scope.firstchkd = false;   
            });
        }
        $scope.goToPageNumber = function (pageNo) {
                get_tobeinvited_caselist(pageNo);
        }
        $scope.$on('filterCases', function (event, roleId) {
            if ($cookies.get('currentTab') == 'tobeinvited') {
                 var query = {
                    "pageIndex": $scope.pagenumber,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": roleId
                    
                }
                $scope.case_id=[];
                $scope.roleId=roleId;
                getAllTobeInvitedCases(query);
            }
        });
            // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'tobeinvited') {
                get_tobeinvited_caselist(0);
            }
        });
        $scope.invite = function (data) {
            var listLength = data.length;
            var checkedInviteList = [];
            for (var i = 0; i < listLength; i++) {
                var checkedID = i;
                if (data[checkedID] == true) {
                    checkedInviteList.push(checkedID);
                }
            }
           
             var url='InviteAllMembersFromApprovedList';
             var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "participantIds": checkedInviteList,
                    "startDate": $scope.schedule.date
                }
          
            inviteall(query,url);

            function inviteall(query,url) {
                DataService.post(url, query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        if(data.results.length>1){
                            NotifyFactory.log('success',data.results.toString()+' are already adjudicators and others will be invited.' );
                        }else if(data.results.length==1){
                            NotifyFactory.log('success',data.results.toString()+' is already an adjudicator and others will be invited.' );
                        }else{
                            NotifyFactory.log('success', "Member invited successfully");
                        }
                        get_tobeinvited_caselist(0);
                        $scope.schedule.date = null;

                    } else {
                       
                        NotifyFactory.log('error', "error");
                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        console.log(error);
                    }
                });
            }
        };
        $scope.invitefirst=function(id){
            $scope.schedule.date = null;
        }
        $scope.cancelInvite = function () {
            $scope.schedule.date = null;
        };
        $scope.NotInterested = function (data) {
            var listLength = data.length;
            var checkedInviteList = [];
            for (var i = 0; i < listLength; i++) {
                var checkedID = i;
                if (data[checkedID] == true) {
                    checkedInviteList.push(checkedID);
                }
            }
            var query = {
                "loginId": $cookies.get('memberId'),
                "participantIds": checkedInviteList,
                "memberStatus": "Not Interested"
            }
            console.log(JSON.stringify(query));
            notinterest(query);

            function notinterest(query) {
                DataService.post('UpdatememberStatusBySMCOfficer', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "Status Changed successfully");
                        get_tobeinvited_caselist(0);

                    } else {
                        NotifyFactory.log('error', "error");
                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        console.log(error);
                    }
                });
            }
        }
        $scope.second_click = function (name) {
            var count_dynamic_chkboxes = document.getElementsByClassName('secondchk').length;
            console.log(count_dynamic_chkboxes);
            var totalcheckboxes = count_dynamic_chkboxes;
            var checkedcheckboxescount = document.querySelectorAll('.secondchk:checked').length
            if (totalcheckboxes == checkedcheckboxescount) {
                console.log("count is equal");
                $scope.shownocheckboxchecked = false;
                $scope.firstchkd = true;
            } else if (totalcheckboxes != checkedcheckboxescount) {
                console.log('count is not equal');
                $scope.firstchkd = false;
                $scope.shownocheckboxchecked = false;
            }
        }
        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }
        $scope.copyText=function (value) { 
            value=value.address1+' '+value.address2+' '+value.address3+' '+value.address4;
            var tempInput = document.createElement("input");
            tempInput.style = "position: absolute; left: -1000px; top: -1000px";
            tempInput.value = value;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            document.body.removeChild(tempInput);
        }

    }
})();
