(function() {
    'use strict';
    angular
        .module('smc')
        .controller('smcMemberManagementCtrl',smcMemberManagementCtrl);

    smcMemberManagementCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$sce'];

    function smcMemberManagementCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$sce){
    	if(($cookies.get('roleName') != "SMC Officer" || $cookies.get('roleName') != "SMC Management") && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'smcMemberManagement'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.roleName = $cookies.get('roleName');
        $scope.max_pagenumber = '';
        $scope.memberList = [];
        $scope.selectedMembers = [];
    	get_member_list($scope.pagenumber);//call to get panel list function
        $cookies.put('currentTab','smcMemberManagement');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
        DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
            $scope.memberRoles = newdata.results;
        });
        
    	// get panel list
    	function get_member_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
            var filterData = {};
            var query = buildQuery(filterData,$scope.pagenumber)
    		getMemberList(query);
    	}

    	function getMemberList(query){
    		DataService.post('ContactGetSMCMemberList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.memberList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.memberList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
            $scope.pagenumber = pageNo;
            $cookies.put('pageNumber',$scope.pagenumber)
            var chkfilter = checkfilternotnull();
            if(!chkfilter){
                get_member_list(pageNo);
            }else{
                var query = buildQuery($scope.filter,pageNo)
                getMemberList(query);
            }
        } 

        function checkfilternotnull(){
            var find = false;
            for(var filter in $scope.filter){
                if($scope.filter[filter]){
                    find = true;
                }
            }
            return find;
        }

        //search members 
        $scope.getMember = function(filterData){
            $scope.pagenumber = 0;
            var query = buildQuery(filterData,0)
            getMemberList(query);
        }

        function buildQuery(filterData,pageNo){
            var query = {
                "pageIndex":pageNo,
                "dataLength":$scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null,
                "name": undefinedSetNull(filterData.name),
                "memberTypeId":undefinedSetNull(filterData.memberRoleId),
                "memberStatus":undefinedSetNull(filterData.memberStatus),
                "gender":undefinedSetNull(filterData.gender),
                "loginId" : $cookies.get('memberId'),
                "numberOfAdjudicationCasesFrom":undefinedSetNull(filterData.numberOfAdjudicationCasesFrom),
                "numberOfAdjudicationCasesTo":undefinedSetNull(filterData.numberOfAdjudicationCasesTo),
                "numberOfMediationCasesFrom":undefinedSetNull(filterData.numberOfMediationCasesFrom),
                "numberOfMediationCasesTo":undefinedSetNull(filterData.numberOfMediationCasesTo),
                "adjudicatorRateOfAcceptanceFrom":undefinedSetNull(filterData.adjudicatorRateOfAcceptanceFrom),
                "adjudicatorRateOfAcceptanceTo":undefinedSetNull(filterData.adjudicatorRateOfAcceptanceTo),
                "adjudicatorRateOfHoldingConferenceFrom":undefinedSetNull(filterData.adjudicatorRateOfHoldingConferenceFrom),
                "adjudicatorRateOfHoldingConferenceTo":undefinedSetNull(filterData.adjudicatorRateOfHoldingConferenceTo),
                "mediationSettlementRateFrom":undefinedSetNull(filterData.mediationSettlementRateFrom),
                "mediationSettlementRateTo":undefinedSetNull(filterData.mediationSettlementRateTo),
                "dateOfBirthFrom":undefinedSetNull(filterData.dateOfBirthFrom),
                "dateOfBirthTo":undefinedSetNull(filterData.dateOfBirthTo),
                "pdpaConsentClause":undefinedSetNull(filterData.pdpaConsentClause)
            }
            return query;
        }

        $scope.goToViewDetails = function(memberId){
            $cookies.put('currentActionMenu', 'Additional Rights');
            $state.go('smclayout.contactlayout.additionalrights.basicprofile',{'memberId' : memberId})
        } 

        $scope.exportMemberList = function(){
            var checkfilter = checkfilternotnull();
            if(checkfilter){
                var query = buildQuery($scope.filter,$cookies.get('pageNumber'));
            }else{
                $scope.filter = undefined;
                var query = buildQuery($scope.filter,$cookies.get('pageNumber'));
            }
            DataService.post('ExportSMCMemberList',query).then(function (data) {
                if(data){
                    var blob = new Blob([data], {
                        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
                    });
                    saveAs(blob, "Collectionreportlist.xls");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.pushMemberinList = function(selectedmember){
            var findMemberinList = -1;
            for(var member in $scope.selectedMembers){
                if($scope.selectedMembers[member].id == selectedmember.id){
                    findMemberinList = member;
                }
            }
            if(findMemberinList == -1){
                var pushQuery = {
                    "id": selectedmember.id,
                    "membershipId": selectedmember.membershipId
                }
               $scope.selectedMembers.push(pushQuery) 
            }else{
                $scope.selectedMembers.splice(findMemberinList,1)
            }
        }

        $scope.openGenerateLetter = function(){
            $scope.messageContents = '';
            angular.element(".overlay").css("display","block");
            angular.element(".smcmember-generate-letter").css("display","block");
        }

        $scope.closeGenerateLetter = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".smcmember-generate-letter").css("display","none");
        }

        $scope.generateLetter = function(messageContents){
            angular.element(".smcmember-generate-letter").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId": $cookies.get('memberId'),
                "message": messageContents,
                "memberIds": $scope.selectedMembers
            }
            
            $http.post(smcConfig.services.SMCMemberGenerateLetter.url, query, {
                responseType: 'arraybuffer'
            })
            .success(function (response) {
                var file = new Blob([response], {
                    type: 'application/pdf'
                });
                var fileURL = URL.createObjectURL(file);
                $scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
                angular.element(".loading-container").css("display","none");
                angular.element("#member_letter_view").css("display", "block");
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".smcmember-generate-letter").css("display","block");
            });
        }

        $scope.closePrintPdf = function(modelId,popupProcess){
            angular.element("#"+modelId).css("display", "none");
            if(!popupProcess){
                angular.element(".smcmember-generate-letter").css("display","block");
            }else{
                angular.element(".overlay").css("display","none");
                $scope.popupProcess = undefined;
                $scope.selectedMembers = [];
            }
        }

        $scope.sendMail = function(messageContents){
            angular.element(".smcmember-generate-letter").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId": $cookies.get('memberId'),
                "message": messageContents,
                "memberIds": $scope.selectedMembers
            }
            DataService.post('SMCMemberSendMail',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Mail sent successfully');
                    $scope.selectedMembers = [];
                    var query = buildQuery($scope.filter,0)
                    getMemberList(query);
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".smcmember-generate-letter").css("display","block");
            });
        }

        $scope.openRenewalLetter = function(){
            $scope.popupProcess = 'renewal';
            $scope.renewalDate = '';
            angular.element(".overlay").css("display","block");
            angular.element(".smcmember-renewal-letter").css("display","block");
        }

        $scope.closeRenewalLetter = function(){
            angular.element(".smcmember-renewal-letter").css("display","none");
            angular.element(".overlay").css("display","none");
        }

        $scope.RenewalLetter = function (renewalDate){
            angular.element(".smcmember-renewal-letter").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = {
                "renewalDate": renewalDate,
                "memberIds": $scope.selectedMembers
            }
            $http.post(smcConfig.services.SMCMemberRenewalLetter.url, query, {
                responseType: 'arraybuffer'
            })
            .success(function (response) {
                var file = new Blob([response], {
                    type: 'application/pdf'
                });
                var fileURL = URL.createObjectURL(file);
                $scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
                angular.element(".loading-container").css("display","none");
                angular.element("#member_letter_view").css("display", "block");
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".smcmember-renewal-letter").css("display","block");
            });
        }
        $scope.setMinDate = function(){
            var fromDate = $scope.filter.dateOfBirthFrom;
            var toDate = $scope.filter.dateOfBirthTo;
            $scope.toDateMinLimit = fromDate;
            $( "#dobTo" ).datepicker( "option", "minDate",fromDate );
            if((new Date(fromDate)) > (new Date(toDate))){
                $scope.filter.dateOfBirthTo = undefined;
            }
        }
    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();