(function () {
    'use strict';
    angular
        .module('smc')
        .controller('contactsAcceptedlistCtrl', contactsAcceptedlistCtrl);

    contactsAcceptedlistCtrl.$inject = ['$rootScope', '$scope', '$sce', '$window', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function contactsAcceptedlistCtrl($rootScope, $scope, $sce, $window, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('moduleName') != 'Contact') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        var roledetails;
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fullselectid = true;
        $scope.defaultSelectStatus = true;
        $scope.shownocheckboxchecked = false;

        $scope.firstchkd = true;
        $scope.secondckd = true;
        $scope.case_id = [];
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'accepted') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_accepted_caselist($scope.pagenumber); //call to accepted case list function
        $cookies.put('currentTab', 'accepted');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status
        
        // get accepted case list
        function get_accepted_caselist(pageNumber) {
            DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
                console.log("newdata", newdata)
                roledetails = newdata.results;
                var memberRoleIdarr = [];
                var memberRoleName = [];
                if(!$scope.roleId){
                    angular.forEach(roledetails, function (value) {
                    memberRoleIdarr.push(value.id);
                    memberRoleName.push(value.name);
                    if (angular.equals('Adjudicator', value.name)) {
                        $scope.roleId = value.id;
                    }
                });
                }
                
                $scope.memberRoleids = memberRoleIdarr;
                $scope.memberRoleNames = memberRoleName;
                aftergettingMemberRoleid(pageNumber);
            });

            function aftergettingMemberRoleid(pageNumber) {
                var memberroleids = [];
                memberroleids = $scope.memberRoleids;
                if (pageNumber) {
                    $scope.pagenumber = pageNumber;
                } else {
                    $scope.pagenumber = 0;
                }
                $cookies.put('pageNumber', $scope.pagenumber)
                var sorting = [
                    [0, 0],
                    [1, 0]
                ];
                var query = {
                    "pageIndex": $scope.pagenumber,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": $scope.roleId
                    
                }
                getAllAcceptedCases(query);
            }
        }
        //get all accepted case list 
        function getAllAcceptedCases(query) {

            DataService.post('AdjudicatorAccepetdMemberDetails', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.accepted_Case_List = data.result.responseData;

                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;

                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    for (var i = 0; i < data.result.responseData.length; i++) {
                        var dataId = data.result.responseData[i].membershipId;
                        $scope.case_id[dataId] = true;
                    }
                    var membership_period_array = [];
                    var splittedarray = [];
                    for (var i = 0; i < data.result.responseData.length; i++) {
                        membership_period_array.push(data.result.responseData[i].membershipPeriod);
                        var stringArrayofmembership_period_array = membership_period_array.toString();
                        splittedarray = stringArrayofmembership_period_array.split('null').join('');
                        var arrayofmembershipPeriod = splittedarray.split(",");
                        data.result.responseData[i].membershipPeriod = arrayofmembershipPeriod[i];
                        // var splittedarraystr = stringArrayofmembership_period_array.split('-');

                        // var arraysplittedfordate = stringArrayofmembership_period_array.split('null').join("").split(',');
                        // console.log(arraysplittedfordate);
                        // if (arraysplittedfordate[i] != null) {
                        //     var myDate = new Date(arraysplittedfordate[i]);
                        //     // $scope.myDateFiltered = $filter('date')($scope.myDate, 'dd/MM/yy');
                        //     console.log(myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear());
                        //     var finallyFixeddate = myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear();
                        //     data.result.responseData[i].membershipPeriod = finallyFixeddate;
                        // }
                    }
                    if ($scope.firstchkd) {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].membershipId;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = true;
                                 
                            }
                        } else if($scope.case_id.length==0){
                            $scope.shownocheckboxchecked = true;
                        }
                    $scope.first_clk = function () {    
                        console.log("uncheck all");
                        if ($scope.firstchkd) {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].membershipId;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = true;
                                 $scope.shownocheckboxchecked = false;
                            }
                        } else {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].membershipId;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = false;
                                $scope.shownocheckboxchecked = true;
                            }
                        }
                    }
                } else {
                    $scope.firstchkd = false;   
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                    $scope.firstchkd = false;
                }
                $scope.shownodataavailable = true;
                $scope.firstchkd = false;
            });
        }
        $scope.goToPageNumber = function (pageNo) {
                get_accepted_caselist(pageNo);
            }

        $scope.$on('filterCases', function (event, roleId) {
          
            if ($cookies.get('currentTab') == 'accepted') {
                 var query = {
                    "pageIndex": 0,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": roleId
                    
                }
                getAllAcceptedCases(query);
            }
        });
            // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'accepted') {
                get_accepted_caselist(0);
            }
        });
        $scope.invite = function (data) {
            console.log(data);
            var checkedInviteList = [];
            for (var key in data) {
                if (data[key]) {
                    checkedInviteList.push(key);
                }
            }
            console.log("list", checkedInviteList);
            var query = {
                    "membershipIds": checkedInviteList
                }
            var generatecertificate = smcConfig.services.GenerateCertificateBySmcOfficer.url;
            $http.post(generatecertificate, {
                    "membershipIds": checkedInviteList
                }, {
                    responseType: 'arraybuffer'
                })
                .success(function (response) {
                    var file = new Blob([response], {
                        type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                    $scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
                    angular.element(".overlay").css("display", "block");
                    angular.element("#view-certificate").css("display", "block");
                    get_accepted_caselist(0);
                });
        }
        $scope.closePrintPdf=function(){
            angular.element(".overlay").css("display", "none");
            angular.element("#view-certificate").css("display", "none");
        }

        $scope.second_click = function (name) {
            var count_dynamic_chkboxes = document.getElementsByClassName('secondchk').length;
            console.log(count_dynamic_chkboxes);
            var totalcheckboxes = count_dynamic_chkboxes;
            var checkedcheckboxescount = document.querySelectorAll('.secondchk:checked').length
            if (totalcheckboxes == checkedcheckboxescount) {
                console.log("count is equal");
                $scope.shownocheckboxchecked = false;
                $scope.firstchkd = true;
            } else if (totalcheckboxes != checkedcheckboxescount) {
                console.log('count is not equal');
                $scope.firstchkd = false;
                $scope.shownocheckboxchecked = false;
            }
        }
        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

    }
})();
