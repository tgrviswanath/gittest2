(function () {
    'use strict';
    angular
        .module('smc')
        .controller('monthlyRenewalReportCtrl', monthlyRenewalReportCtrl);

    monthlyRenewalReportCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function monthlyRenewalReportCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'monthlyRenewalReport');
        
        $scope.$emit('addActiveTab',$cookies.get('currentTab'));
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'monthlyRenewalReport') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_month_renewals($scope.pagenumber);

        function get_month_renewals(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "loginId": $cookies.get('memberId'),
                "memberType":null,
                "invoiceNumber": null,
                "pageIndex":$scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null
            }
            getMonthRenewals(query);
        }

        function getMonthRenewals(query) {
            DataService.post('OfficerGetMonthlyRenewalList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.monthlyReviewReport = data.result.responseDTO.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.responseDTO.totalPages;
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_month_renewals(pageNo);
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();
