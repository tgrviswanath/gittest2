(function() {
    'use strict';
    angular
        .module('smc')
        .controller('addWatchListCtrl',addWatchListCtrl);

    addWatchListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function addWatchListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'addWatchlist'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.max_pagenumber = '';
    	get_watch_list($scope.pagenumber);
        $cookies.put('currentTab','addWatchlist');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status


        DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
            $scope.memberRoles = newdata.results;
        });
        
    	
    	function get_watch_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
                "loginId" : $cookies.get('memberId'),
    			"pageIndex": $scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn": null,
                "sortDirection":null,
                "dateOfEntryFrom":null,
                "dateOfEntryTo":null,
                "memberRoleId": null,
                "memberName":null
    		}
      		getWatchList(query);
    	}

    	function getWatchList(query){
    		DataService.post('ContactGetWatchList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.watchList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.watchList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
           get_watch_list(pageNo);
        } 

        //search watchlist 
        $scope.getWatchList = function(filterData){
            var query = {
            	"dateOfEntryFrom": undefinedSetNull(filterData.addWatchlistDateFrom),
                "dateOfEntryTo": undefinedSetNull(filterData.addWatchlistDateTo),
                "memberRoleId": undefinedSetNull(filterData.addWatchlistMemberRole),
                "memberName": undefinedSetNull(filterData.addWatchlistMemberName)
            }
            getWatchList(query);
        }

        //reset watchlist list
        $scope.resetWatchlist = function(){
            $scope.filter = undefined;
            get_watch_list(0);
        }

        $scope.addWatchlist = function(){
            $scope.watchlistTitle='Add watchlist';
            $scope.watchlistButtonName='Submit';
            $scope.watchlistSubmitUrl='ContactAddWatchlist';
            $scope.watchlistId=null;
            $scope.addWatchlistData = {};
            $scope.addWatchlistData.managementDocument = {};
            $scope.selectedMembers = [];
            $scope.memberNames = [];
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
            angular.element(".overlay").css("display","block");
            angular.element(".add-watchlist-popup").css("display","block");
        }

        $scope.closeAddWatchlist = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-watchlist-popup").css("display","none");
        }

        $scope.getMembersbyRoleId = function(roleId){
           getMembersbyRoleId(roleId);
        }

        function getMembersbyRoleId(roleId){
            $scope.memberNames = [];
            $scope.selectedMembers = [];
            var ContactGetMembersbyRoleUrl = smcConfig.services.ContactGetMembersbyRole.url;
            ContactGetMembersbyRoleUrl = ContactGetMembersbyRoleUrl + roleId;
            $http.get(ContactGetMembersbyRoleUrl).then(function(data){
                $scope.memberNames = data.data.results;
                if($scope.memberNames.length == 0){
                    NotifyFactory.log('error','No members found for the selected role');
                    $scope.hideBtn = true;
                }else{
                    $scope.hideBtn = false;
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.checkMemberStatus = function(memId,len){
            if(len != undefined && len != ''){
                $scope.notLenSelected = false;
                var index = $scope.selectedMembers.indexOf(memId);
                if(index != -1){
                    $scope.selectedMembers.splice(index,1)
                }else{
                    if($scope.selectedMembers.length < len){
                        $scope.selectedMembers.push(memId);
                    }
                }
            }else{
                $scope.notLenSelected = true;
            }
        }

        // upload a file - before that check file size,valid exetension
         $scope.uploadWatchlistFile = function (file,name) {
            angular.element(".add-watchlist-popup").css("display","none");
            angular.element(".loading-container").css("display","block");
                 var file = file;
                 if (file.size < 5242881) {
                     if (validateUploadFileExtention(file.name)) {
                         var fd = new FormData();
                         fd.append('file', file);
                         httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                             console.log(data);
                            
                                $scope.addWatchlistData.managementDocument.name = file.name;
                                $scope.addWatchlistData.managementDocument.fileLocation = data.result;
                                 $scope.addWatchlistData.managementDocument.documentDescription="Management Document";
                             
                             $scope.attachcopyStatus = true;
                             angular.element(".loading-container").css("display","none");
                             angular.element(".add-watchlist-popup").css("display","block");
                         });
                     } else {
                         $scope.attachcopyStatus = true;
                         $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                         NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                         angular.element(".loading-container").css("display","none");
                         angular.element(".add-watchlist-popup").css("display","block");
                     }
                 } else {
                     NotifyFactory.log('error', "Please select below 5MB file");
                     angular.element(".loading-container").css("display","none");
                     angular.element(".add-watchlist-popup").css("display","block");
                 }
             }
             // check valid file by exetension
         function validateUploadFileExtention(val) {
             var allowedExt = $scope.fileUploadTypes;

             var ext = val.split('.').pop();
             for (var type = 0; type < allowedExt.length; type++) {
                 if ($scope.fileUploadTypes[type] == ext) {
                     return true;
                 }
             }
         }
         // if we want remove upload file
         $scope.attachcopyRemove = function () {
            $rootScope.supprtDocumentName = undefined;
            $rootScope.supportingDocument = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
         }

        $scope.submitWatchlist = function(watchlistData){
            if($scope.watchlistId){
                watchlistData.watchId=$scope.watchlistId;
            }
            watchlistData.loginId = $cookies.get('memberId');
            DataService.post($scope.watchlistSubmitUrl,watchlistData).then(function (data) {
                if(data.status == 'SUCCESS'){
                    if($scope.watchlistSubmitUrl=='UpdateWatch'){
                        NotifyFactory.log('success','Watch List updated successfully')
                    }else{
                        NotifyFactory.log('success','Watch List added successfully')
                    }

                    get_watch_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".add-watchlist-popup").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.canceldelete=function(){
             angular.element(".overlay").css("display","none");
             angular.element(".form-submitt-confirm").css("display","none");
        }

        $scope.editWatchlist=function(id){
            $scope.watchlistTitle='Edit Watch List';
            $scope.watchlistButtonName='Update';
            $scope.watchlistSubmitUrl='UpdateWatch';
            $scope.watchlistId=id;
            var ContactGetWatchbyWatchId = smcConfig.services.GetWatchbyWatchId.url;
            ContactGetWatchbyWatchId = ContactGetWatchbyWatchId + id;
            $http.get(ContactGetWatchbyWatchId).then(function(data){
                $scope.viewWatchData=data.data.result;
                $scope.addWatchlistData=$scope.viewWatchData;
                getMembersbyRoleId($scope.viewWatchData.memberRoleId);
                angular.element(".overlay").css("display","block");
                angular.element(".add-watchlist-popup").css("display","block");
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.openConfirmPopup=function(id){
            $scope.watchId=id;
            angular.element(".overlay").css("display","block");
            angular.element(".form-submitt-confirm").css("display","block");
        }

        $scope.deleteWatchList=function(){
            var query={
                "loginId": $cookies.get('memberId'),
                "watchId":$scope.watchId
            }
            console.log(JSON.stringify(query));
            DataService.post('DeleteWatch',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Watch deleted successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".form-submitt-confirm").css("display","none");
                    get_watch_list($scope.pagenumber);

                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }

    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();