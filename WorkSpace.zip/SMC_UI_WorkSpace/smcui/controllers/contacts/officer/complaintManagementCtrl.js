(function() {
    'use strict';
    angular
        .module('smc')
        .controller('complaintManagementCtrl',complaintManagementCtrl);

    complaintManagementCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function complaintManagementCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if(($cookies.get('roleName') != "SMC Officer" || $cookies.get('roleName') != "SMC Management") && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'complaintManagement'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.roleName = $cookies.get('roleName');
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.max_pagenumber = '';
    	get_complaint_list($scope.pagenumber);//call to get panel list function
        $cookies.put('currentTab','complaintManagement');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status


        DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
            $scope.memberRoles = newdata.results;
        });
        
    	// get panel list
    	function get_complaint_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex": $scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn": null,
                "sortDirection":null,
                "complaintDateFrom":null,
                "complaintDateTo":null,
                "compliantCaseNumber":null,
                "compliantMemberRole":null,
                "compliantMemberName":null
    		}
    		getComplaintList(query);
    	}

    	function getComplaintList(query){
    		DataService.post('ContactGetComplaintList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.complaintList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if($scope.complaintList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
           get_complaint_list(pageNo);
        } 

        //search complaint 
        $scope.getComplaint = function(filterData){
            var query = {
            	"complaintDateFrom": undefinedSetNull(filterData.complaintDateFrom),
                "complaintDateTo": undefinedSetNull(filterData.complaintDateTo),
                "compliantCaseNumber": undefinedSetNull(filterData.compliantCaseNumber),
                "compliantMemberRole": undefinedSetNull(filterData.compliantMemberRole),
                "compliantMemberName": undefinedSetNull(filterData.compliantMemberName)
            }
            getComplaintList(query);
        }

        //reset complaint list
        $scope.resetcomplaints = function(){
            $scope.filter = undefined;
            get_complaint_list(0);
        }

        $scope.addComplaint = function(){
            $scope.complaintData = {};
            $scope.complaintData.complaintDocument = {};
            $scope.complaintData.complaintDecisionDocument = {};
            $scope.selectedMembers = [];
            $scope.memberNames = [];
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
            angular.element(".overlay").css("display","block");
            angular.element(".add-complaint-popup").css("display","block");
        }

        $scope.closeAddComplaint = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-complaint-popup").css("display","none");
        }

        $scope.getMembersbyRoleId = function(roleId){
            $scope.memberNames = [];
            $scope.selectedMembers = [];
            var ContactGetMembersbyRoleUrl = smcConfig.services.ContactGetMembersbyRole.url;
            ContactGetMembersbyRoleUrl = ContactGetMembersbyRoleUrl + roleId;
            $http.get(ContactGetMembersbyRoleUrl).then(function(data){
                $scope.memberNames = data.data.results;
                  if($scope.memberNames.length == 0){
                    NotifyFactory.log('error','No members found for the selected role');
                    $scope.hideBtn = true;
                }else{
                    $scope.hideBtn = false;
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });
        }

        $scope.checkMemberStatus = function(memId,len){
            if(len != undefined && len != ''){
                $scope.notLenSelected = false;
                var index = $scope.selectedMembers.indexOf(memId);
                if(index != -1){
                    $scope.selectedMembers.splice(index,1)
                }else{
                    if($scope.selectedMembers.length < len){
                        $scope.selectedMembers.push(memId);
                    }
                }
            }else{
                $scope.notLenSelected = true;
            }
        }

        // upload a file - before that check file size,valid exetension
         $scope.uploadComplaintFile = function (file,name) {
            angular.element(".add-complaint-popup").css("display","none");
            angular.element(".loading-container").css("display","block");
                 var file = file;
                 if (file.size < 5242881) {
                     if (validateUploadFileExtention(file.name)) {
                         var fd = new FormData();
                         fd.append('file', file);
                         httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                             console.log(data);
                             if(name == 'support'){
                                $scope.complaintData.complaintDocument.name = file.name;
                                $scope.complaintData.complaintDocument.fileLocation = data.result;
                             }else{
                                $scope.complaintData.complaintDecisionDocument.name = file.name;
                                $scope.complaintData.complaintDecisionDocument.fileLocation = data.result;
                             }
                             $scope.attachcopyStatus = true;
                             angular.element(".loading-container").css("display","none");
                             angular.element(".add-complaint-popup").css("display","block");
                         });
                     } else {
                         $scope.attachcopyStatus = true;
                         $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                         NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                         angular.element(".loading-container").css("display","none");
                         angular.element(".add-complaint-popup").css("display","block");
                     }
                 } else {
                     NotifyFactory.log('error', "Please select below 5MB file");
                     angular.element(".loading-container").css("display","none");
                     angular.element(".add-complaint-popup").css("display","block");
                 }
             }
             // check valid file by exetension
         function validateUploadFileExtention(val) {
             var allowedExt = $scope.fileUploadTypes;

             var ext = val.split('.').pop();
             for (var type = 0; type < allowedExt.length; type++) {
                 if ($scope.fileUploadTypes[type] == ext) {
                     return true;
                 }
             }
         }
         // if we want remove upload file
         $scope.attachcopyRemove = function () {
            $rootScope.supprtDocumentName = undefined;
            $rootScope.supportingDocument = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
         }

        $scope.submitComplaint = function(comData,selectedMembers){
            comData.memberIds = selectedMembers;
            comData.loginId = $cookies.get('memberId');
            DataService.post('ContactAddComplaint',comData).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Complaint added successfully')
                    get_complaint_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".add-complaint-popup").css("display","none");
                }
            }).catch(function (error) {  
                if(error.errorMessage=='Case Not Found'){
                    NotifyFactory.log('error','Invalid Case Number');
                }else{
                    NotifyFactory.log('error',error.errorMessage);
                }
            });
        }

    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();