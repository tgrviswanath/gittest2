
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('userIdUpdateCtrl',userIdUpdateCtrl);

    userIdUpdateCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function userIdUpdateCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'userIdUpdate'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.isExistingMail=false;
        $scope.dataLength = 10;
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.max_pagenumber = '';
        $cookies.put('currentTab','userIdUpdate');
        get_member_list($scope.pagenumber);
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
        var ContactGetMembersTypeUrl = smcConfig.services.ContactGetMemberTypeList.url;
            $http.get(ContactGetMembersTypeUrl).then(function(data){
                $scope.memberTypes = data.data.results;
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage)
            });

        function get_member_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex": $scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn": null,
                "sortDirection":null,
                "memberTypeId":null,
                "memberName":null,
                "membershipId": null
               
    		}
      		getMemberList(query);
    	}

    	function getMemberList(query){
    		DataService.post('ContactGetMemberList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.userList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if($scope.userList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}
    	$scope.goToPageNumber = function(pageNo){
           get_member_list(pageNo);
        } 

         $scope.getMemberList = function(filterData){
            var query = {
                "memberTypeId":undefinedSetNull(filterData.userIdUpdateMemberType),
                "memberName":undefinedSetNull(filterData.userIdUpdateMemberName),
                "membershipId": undefinedSetNull(filterData.userIdUpdateMembershipId)               
            }
            getMemberList(query);
        }
        $scope.resetUserIdlist = function(){
            $scope.filter = undefined;
            get_member_list(0);
        }

        $scope.openUpdateUserIdPopup=function(userlist){
            $scope.oldMail=userlist.email;
        	$scope.updateUserIdData=null
        	$scope.smcMemberId=userlist.id;
        	angular.element(".overlay").css("display","block");
            angular.element(".update-userId-popup").css("display","block");
        }
        $scope.comparePassword=function(){
            if($scope.oldMail==$scope.updateUserIdData.oldEmailId){
                $scope.isExistingMail=true;
            }else{
                 $scope.isExistingMail=false;
            }
        }
        $scope.closeUpdateUserIdPopup=function(){
        	angular.element(".overlay").css("display","none");
            angular.element(".update-userId-popup").css("display","none");
        }
        $scope.updateUserId=function(updateUserIdData){
        	var query={
        		"loginId":$cookies.get('memberId'),
				"smcMemberId":$scope.smcMemberId,
				"oldEmailId":updateUserIdData.oldEmailId,
				"newEmailId":updateUserIdData.newEmailId
        	}
        	DataService.post('ContactUpdateUserId',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','User Id updated successfully')
                    angular.element(".overlay").css("display","none");
            		angular.element(".update-userId-popup").css("display","none");
            		get_member_list(0);
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                   NotifyFactory.log('error',error.errorMessage)
                   
                }
	        });

        }
    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();