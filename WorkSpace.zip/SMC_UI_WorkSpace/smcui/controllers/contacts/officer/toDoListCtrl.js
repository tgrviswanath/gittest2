(function () {
    'use strict';
    angular
        .module('smc')
        .controller('toDoListCtrl', toDoListCtrl);

    toDoListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function toDoListCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
          if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('moduleName') != 'Contact') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $rootScope.roleId=null;
        $scope.shownodataavailable = false;
        var AMRoleId= 27;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'ContactToDoList') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $cookies.put('currentTab', 'ContactToDoList');
        $scope.$emit('addActiveTab',$cookies.get('currentTab'));



        getToDoActionList($scope.pagenumber);

        function getToDoActionList(pageNumber){
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var query = {
                "loginId" : $cookies.get('memberId')
            }
            DataService.post('ContactGetToDoList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.toDoActionList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToAction = function(action){
            switch(action){
                case "Invite adjudicator" : 
                    $state.go('smclayout.contactlayout.caselist.tobeinvited');
                    break;
                case "Invite associate mediator" : 
                    goToAssociatemediatorPage();
                    break;
                case "Member Accepted Invite" :
                    $state.go('smclayout.contactlayout.caselist.accepted');
                    break;
                default :
                    NotifyFactory.log('error','Unknown action found');
                    break;
            }
        }
        
       function goToAssociatemediatorPage(){
             $state.go('smclayout.contactlayout.caselist.tobeinvited');
             $rootScope.roleId=AMRoleId;
       }
    }
})();
