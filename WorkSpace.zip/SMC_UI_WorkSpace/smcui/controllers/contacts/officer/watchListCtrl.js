(function () {
    'use strict';
    angular
        .module('smc')
        .controller('watchListCtrl', watchListCtrl);

    watchListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function watchListCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $cookies.put('currentTab', 'watchList');
        
        $scope.$emit('addActiveTab',$cookies.get('currentTab'));
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'watchList') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_watch_list($scope.pagenumber);

        function get_watch_list(pageNumber) {

            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "loginId": $cookies.get('memberId'),
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection":null,
                "memberTypeId":null
            }
            getWatchList(query);
        }

        function getWatchList(query) {
            DataService.post('OfficerGetWatchListReport', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.watchListData = data.result.responseData;
                    $scope.complaintDates = [];
                    $scope.complaintNumbers = [];
                    for(var complaint in $scope.watchListData.complaints){
                        $scope.complaintDates.push($scope.watchListData.complaints[complaint].complaintDate);
                        $scope.complaintNumbers.push($scope.watchListData.complaints[complaint].compliantNumber);
                    }
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_watch_list(pageNo);
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();
