(function () {
    'use strict';
    angular
        .module('smc')
        .controller('contactscertificateprintedlistCtrl', contactscertificateprintedlistCtrl);

    contactscertificateprintedlistCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function contactscertificateprintedlistCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('moduleName') != 'Contact') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        var roledetails;
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fullselectid = true;
        $scope.defaultSelectStatus = true;



        /**athira*/
        $scope.firstchkd = true;
        $scope.secondckd = true;
        $scope.case_id = [];
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'certificateprinted') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_certificateprinted_caselist($scope.pagenumber); //call to certificateprinted case list function
        $cookies.put('currentTab', 'certificateprinted');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status
        // get certificateprinted case list
        function get_certificateprinted_caselist(pageNumber) {


            DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
                console.log("newdata", newdata)
                roledetails = newdata.results;
                var memberRoleIdarr = [];
                var memberRoleName = [];
                angular.forEach(roledetails, function (value) {
                    memberRoleIdarr.push(value.id);
                    memberRoleName.push(value.name);
                    if (angular.equals('Adjudicator', value.name)) {
                        $scope.roleid = value.id;
                    }
                });

                $scope.memberRoleids = memberRoleIdarr;
                $scope.memberRoleNames = memberRoleName;
                aftergettingMemberRoleid(pageNumber);
            });

            function aftergettingMemberRoleid(pageNumber) {

                var memberroleids = [];

                memberroleids = $scope.memberRoleids;

                if (pageNumber) {
                    $scope.pagenumber = pageNumber;
                } else {
                    $scope.pagenumber = 0;
                }
                $cookies.put('pageNumber', $scope.pagenumber)
                var sorting = [
                    [0, 0],
                    [1, 0]
                ];
                var query = {
                    "pageIndex": $scope.pagenumber,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": $scope.roleid
                        // "memberRoleId": $cookies.get('memberId')
                }
                getAllCertificatePrintedCases(query);
            }


        }
        //get all certificateprinted case list 
        function getAllCertificatePrintedCases(query) {
            DataService.post('CertificatedPrintedList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.certificateprinted_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;

                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    for (var i = 0; i < data.result.responseData; i++) {
                        var dataId = data.result.responseData[i].id;
                        $scope.case_id[dataId] = true;
                    }
                    var membership_period_array = [];
                    var splittedarray = [];
                    for (var i = 0; i < data.result.responseData.length; i++) {

                        membership_period_array.push(data.result.responseData[i].membershipPeriod);
                        console.log(membership_period_array);

                        var stringArrayofmembership_period_array = membership_period_array.toString();
                        splittedarray = stringArrayofmembership_period_array.split('null').join('');

                        var arrayofmembershipPeriod = splittedarray.split(",");
                        console.log(arrayofmembershipPeriod);
                        data.result.responseData[i].membershipPeriod = arrayofmembershipPeriod[i];
                    }
                    // for (var i = 0; i < data.result.responseData.length; i++) {
                    //     membership_period_array.push(data.result.responseData[i].membershipPeriod);
                    //     var stringArrayofmembership_period_array = membership_period_array.toString();
                    //     splittedarray = stringArrayofmembership_period_array.split('null').join('');
                    //     var arrayofmembershipPeriod = splittedarray.split(",");
                    //     // data.result.responseData[i].membershipPeriod = arrayofmembershipPeriod[i];
                    //     var splittedarraystr = stringArrayofmembership_period_array.split('-');

                    //     var arraysplittedfordate = stringArrayofmembership_period_array.split('null').join("").split(',');
                    //     console.log(arraysplittedfordate);
                    //     if (arraysplittedfordate[i] != null) {
                    //         var myDate = new Date(arraysplittedfordate[i]);
                    //         console.log(myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear());
                    //         var finallyFixeddate = myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear();
                    //         data.result.responseData[i].membershipPeriod = finallyFixeddate;
                    //     }
                    // }
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });
        }
        $scope.goToPageNumber = function (pageNo) {
                get_certificateprinted_caselist(pageNo);
        }
        $scope.$on('filterCases', function (event, roleId) {
          
            if ($cookies.get('currentTab') == 'certificateprinted') {
                 var query = {
                    "pageIndex": 0,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": roleId
                    
                }
                getAllCertificatePrintedCases(query);
            }
        });
            // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'certificateprinted') {
                get_certificateprinted_caselist(0);
            }
        });
        $scope.invite = function (data) {

            var listLength = data.length;
            var checkedInviteList = [];
            for (var i = 0; i < listLength; i++) {
                var checkedID = i;
                if (data[checkedID] == true) {
                    checkedInviteList.push(checkedID);
                }
            }
            console.log("list", checkedInviteList);
            var query = {
                "smcOfficerId": $cookies.get('memberId'),
                "participantIds": checkedInviteList,
                "startDate": $scope.schedule.date
            }
            console.log(JSON.stringify(query));
            inviteall(query);

            function inviteall(query) {
                console.log("adsasd");
                DataService.post('Invitealladjudicatorfrmapprovedlis', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "Case assigned successfully");

                    } else {

                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        console.log(error);
                    }
                });
            }
        };
        $scope.selectAllAction = function (selectStatus) {
            if (selectStatus == true) {
                $scope.defaultSelectStatus = true;
            } else if (selectStatus == false) {
                $scope.defaultSelectStatus = false;
            }
        }
        $scope.checkedStatus = function () {
            var selectedProducts = [];
            $scope.certificateprinted_Case_List = $scope.responseData;
            for (var index in $scope.certificateprinted_Case_List) {
                if ($scope.case_id[$scope.certificateprinted_Case_List[index].id]) {
                    selectedProducts.push($scope.certificateprinted_Case_List[index].id);
                }
            }
            console.log($scope.certificateprinted_Case_List);
            console.log(selectedProducts);
        }
        $scope.first_clk = function () {
            if ($scope.firstchkd) {
                $scope.secondckd = true;
            } else {
                $scope.secondckd = false;
            }
        }
        $scope.second_click = function (name) {
            var count_dynamic_chkboxes = document.getElementsByClassName('secondchk').length;
            console.log(count_dynamic_chkboxes);
            var totalcheckboxes = count_dynamic_chkboxes;
            var checkedcheckboxescount = document.querySelectorAll('.secondchk:checked').length
            if (totalcheckboxes == checkedcheckboxescount) {
                console.log("count is equal");
                $scope.firstchkd = true;
            } else if (totalcheckboxes != checkedcheckboxescount) {
                console.log('count is not equal');
                $scope.firstchkd = false;
            }
        }
        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }
    }
})();
