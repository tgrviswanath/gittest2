(function() {
    'use strict';
    angular
        .module('smc')
        .controller('panelManagementCtrl',panelManagementCtrl);

    panelManagementCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function panelManagementCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'panelManagement'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_panel_list($scope.pagenumber);//call to get panel list function
        $cookies.put('currentTab','panelManagement');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get panel list
    	function get_panel_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex": $scope.pagenumber,
			    "dataLength":$scope.dataLength,
			    "sortingColumn": null,
			    "sortDirection":null,
			    "name": null
    		}
    		getPanelList(query);
    	}

    	function getPanelList(query){
    		DataService.post('ContactGetPanelList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.panelList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if($scope.panelList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
           get_panel_list(pageNo);
        } 

        //search panel 
        $scope.getPanel = function(filterData){
            var query = {
            	"name":filterData.name
            }
            getPanelList(query);
        }

        //reset panel list
        $scope.resetpanels = function(){
            $scope.filter = undefined;
            get_panel_list(0);
        }


        //to close add a user model
        $scope.closeaddusermodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".admin-add-user").css("display","none");
        }

    	$scope.openAddPanel=function(){
    		$scope.panelData = {};
    		$scope.popupTitle = "Add";
             angular.element(".overlay").css("display","block");
             angular.element(".add-panel-popup").css("display","block");
        }
        $scope.closeAddPanel=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-panel-popup").css("display","none");
        }

        $scope.addPanel = function(panelData,action){
        	var query={
        		"loginId":$cookies.get('memberId'),
			    "description":undefinedSetNull(panelData.description),
			    "membershipPeriod":undefinedSetNull(panelData.membershipPeriod),
			    "panelFee":undefinedSetNull(panelData.panelFee),
			    "panelStatus" :"true"
        	}
        	if(action == 'Add'){
        		var serviceUrl = 'ContactAddPanel';
        		var sucMsg = 'Panel added successfully';
                query.name = undefinedSetNull(panelData.name);
        	}else{
        		var serviceUrl = 'ContactEditPanel';
        		query.panelId = panelData.id;
                query.panelName = undefinedSetNull(panelData.name);
        		var sucMsg = 'Panel updated successfully';
        	}

        	DataService.post(serviceUrl,query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success',sucMsg);
    				get_panel_list(0);
    				angular.element(".overlay").css("display","none");
            		angular.element(".add-panel-popup").css("display","none");
    			}
    		}).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
	        });
        }

        $scope.openEditPanel = function(panelData){
        	$scope.panelData = panelData;
        	$scope.popupTitle = "Edit";
             angular.element(".overlay").css("display","block");
             angular.element(".add-panel-popup").css("display","block");
        }

    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();