(function() {
    'use strict';
    angular
        .module('smc')
        .controller('contactbalancepaymentreportsCtrl',contactbalancepaymentreportsCtrl);

    contactbalancepaymentreportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function contactbalancepaymentreportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'balancePaymentReports'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_balance_payment_reports($scope.pagenumber);//call to get balance list function
        $cookies.put('currentTab','balancePaymentReports');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status

        // get member types
        DataService.get('GetSmcMemberRoleDetails').then(function (data) {
            var roledetails = data.results;
            $scope.currentMemberTypes = [];
            for(var role in roledetails){
                if(roledetails[role].name == 'Associate Mediator' || roledetails[role].name == 'Principal Mediator' || roledetails[role].name == 'CFP'){
                    $scope.currentMemberTypes.push(roledetails[role]);
                }
            }
        }).catch(function (error) {
            $scope.currentMemberTypes = [];
        });


        //Get Payment Types List Service
        DataService.get('GetPaymentTypes').then(function(data){
            var paymentTypes = data.results;
            $scope.currentPaymentTypes = [];
            for(var type in paymentTypes){
                if(paymentTypes[type].name == 'Membership Fee' || paymentTypes[type].name == 'Renewal Fee'){
                    $scope.currentPaymentTypes.push(paymentTypes[type]);
                }
            }
        });

        //Get Payment Mode List Service
        DataService.get('GetPaymentModes').then(function(data){
            var paymentModes = data.results;
            $scope.currentPaymentModes = [];
            for(var mode in paymentModes){
                if(paymentModes[mode].name == 'E-Nets' || paymentModes[mode].name == 'Cheque'){
                    $scope.currentPaymentModes.push(paymentModes[mode]);
                }
            }
        }).catch(function (error) {
            $scope.currentPaymentModes = [];
        });
        
    	// get balance report list
    	function get_balance_payment_reports(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var filterData = {};
            var query = buildReportsQuery(filterData,$scope.pagenumber)
    		getBalanceReports(query);
    	}

    	function getBalanceReports(query){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
    		DataService.post('GetContactBalancePaymentReports',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.balanceList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if($scope.balanceList.length == 0){
                        $scope.shownodataavailable = true;
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}else{
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
            $scope.pagenumber = pageNo;
            $cookies.put('pageNumber',$scope.pagenumber)
            var chkfilter = checkfilternotnull();
            if(!chkfilter){
                get_balance_payment_reports(pageNo);
            }else{
                var query = buildReportsQuery($scope.filter,pageNo)
                getBalanceReports(query);
            }
        } 

        //search reports 
        $scope.getReports = function(filterData){
            $scope.pagenumber = 0;
            $cookies.put('pageNumber',$scope.pagenumber)
            var query = buildReportsQuery(filterData,0)
            getBalanceReports(query);
        }

        function buildReportsQuery(filterData,pageNumber){
            var query = {
                "pageIndex":pageNumber,
                "dataLength": $scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null,
                "membershipId":undefinedSetNull(filterData.membershipId),
                "memberName":undefinedSetNull(filterData.memberName),
                "memberTypeId":undefinedSetNull(filterData.memberTypeId),
                "amountFrom":undefinedSetNull(filterData.amountFrom),
                "amountTo":undefinedSetNull(filterData.amountTo),
                "paymentType":undefinedSetNull(filterData.paymentType),
                "invoiceNumber":undefinedSetNull(filterData.invoiceNumber)
            }
            return query;
        }

        //reset report list
        $scope.resetreports = function(){
            $scope.filter = undefined;
            get_balance_payment_reports(0);
        }

        function checkfilternotnull(){
            var find = false;
            for(var filter in $scope.filter){
                if($scope.filter[filter]){
                    find = true;
                }
            }
            return find;
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();