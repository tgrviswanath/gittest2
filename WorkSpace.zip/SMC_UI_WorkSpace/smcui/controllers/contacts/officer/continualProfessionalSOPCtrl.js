(function () {
    'use strict';
    angular
        .module('smc')
        .controller('continualProfessionalSOPCtrl', continualProfessionalSOPCtrl);

    continualProfessionalSOPCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$sce'
    ];

    function continualProfessionalSOPCtrl($rootScope, $scope, $state, $cookies, DataService, $http,
        patternConfig, httpPostFactory, smcConfig, NotifyFactory, $sce) {

        $scope.reverseSort = false;
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.dataLength = 10;
        $scope.requirementDetails = {};
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.relevantDocumentDownloadUrl = smcConfig.services.DownloadSupportingDocument.url;
        $cookies.put('currentTab', 'CPDR');
        $scope.$emit('addActiveTab',$cookies.get('currentTab'));
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'CPDR') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        } 
        get_requirement_data($scope.pagenumber);   

        DataService.get('GetSeminarProgramList').then(function (response) {
            if (response.status == 'SUCCESS') {
                var seminarProgramLists = response.results;
                $scope.seminarNameList = [];
                for(var program in seminarProgramLists){
                    $scope.seminarNameList.push(seminarProgramLists[program].name)
                }
                $scope.seminarNameList.push('Others');
            }
        }).catch(function (error) {
            NotifyFactory.log('error', error.errorMessage);
        });  

        function get_requirement_data(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
            var query = {
                "pageIndex":$scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null
            }
            getRequirementData(query);
        }

        function getRequirementData(query){
            DataService.post('OfficerGetMemberProfessionalRequirements',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.requirementData = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    if($scope.requirementData.length == 0){
                        $scope.shownodataavailable = true;
                    }
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                    $scope.max_pagenumber = 1;
                }
            });
        }

        $scope.goToPageNumber = function(pageNo){
            get_requirement_data(pageNo)
        }

        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

        $scope.openSaveRequirement = function(title,watchData){
            if(title == 'Update'){
                $scope.requirementDetails = angular.copy(watchData);
                if($scope.seminarNameList.indexOf($scope.requirementDetails.seminarProgram) == -1){
                    $scope.requirementDetails.otherProgram = $scope.requirementDetails.seminarProgram;
                    $scope.requirementDetails.seminarProgram = 'Others';
                    $scope.otherProgram = $scope.requirementDetails.seminarProgram;
                }
                $scope.attachcopyStatus = true;
            }else{
                $scope.requirementDetails = {};
                $scope.attachcopyStatus = false;
            }
            $scope.popupTitle = title;
            angular.element(".overlay").css("display","block");
            angular.element(".officer-professional-requierment").css("display","block");
        }

        $scope.closeRequirement = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".officer-professional-requierment").css("display","none");
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file){
            $scope.requirementDetails.document={};
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        $scope.requirementDetails.document.name = file.name;
                        $scope.requirementDetails.document.fileLocation = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }
        // check valid file by exetension
        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.fileUploadTypes[i] == ext){
                    return true;
                }
            }
        }

        // if we want remove upload file
        $scope.attachcopyRemove = function(){
            $scope.requirementDetails.document={};
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        // Save requirements
        $scope.saveRequirement =function (requirementData,actionTitle){
            angular.element(".officer-professional-requierment").css("display","none");
            angular.element(".loading-container").css("display","block");
            var query = {
                "seminarProgram": requirementData.seminarProgram != 'Others'? requirementData.seminarProgram : requirementData.otherProgram,
                "seminarProgramDate":requirementData.seminarProgramDate,
                "description":requirementData.description,
                "document":requirementData.document,
                "smcOfficerLoginId": $cookies.get('memberId')
            }
            if(actionTitle == 'Add'){
                query.memberLoginId = $state.params.id;
                var serviceUrl = 'AddMemberProfessionalRequirementBySMCOfficer';
                var successMessage = 'Continual professional requirement details added successfully'
            }else{
                query.id = requirementData.id;
                var serviceUrl = 'UpdateMemberProfessionalRequirementBySMCOfficer';
                var successMessage = 'Continual professional requirement details updated successfully'
            }
            saveRequirementData(query,serviceUrl,successMessage)
        }

        function saveRequirementData(query,serviceUrl,successMessage){
            DataService.post(serviceUrl,query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success',successMessage);
                    get_requirement_data($cookies.get('pageNumber'))
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".officer-professional-requierment").css("display","block");
            });
        }

        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
        }
    }
})();
