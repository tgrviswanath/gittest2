(function() {
    'use strict';
    angular
        .module('smc')
        .controller('waiverReportCtrl',waiverReportCtrl);

    waiverReportCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function waiverReportCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Contact') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.waiverdataavailable = false;
        $scope.renewaldataavailable = false;
        $scope.waiverPagenumber = 0;
        $scope.renewalPagenumber = 0;
        $scope.dataLength = 10;
        var waiverStatus = true;
        var renewalStatus = false;
        var waiverListName = 'WaiverReportList';
        var waiverMaxPageName = 'maxWaiverReportPagenumber';
        var isWaiverData = 'waiverdataavailable';
        var renewalListName = 'RenewalReportList';
        var renewalMaxPageName = 'maxRenewalReportPagenumber';
        var isRenewalData = 'renewaldataavailable';
        $scope.max_pagenumber = '';
    	get_waiver_report_list($scope.waiverPagenumber);//call to get waiver list function
        get_renewal_report_list($scope.renewalPagenumber);//call to get renewal list function
        $cookies.put('currentTab','waiverReport');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get waiver report list
    	function get_waiver_report_list(pageNumber){
            $scope.submitWaiverData = {};
            if(pageNumber){
                $scope.waiverPagenumber = pageNumber;
            }else{
                $scope.waiverPagenumber = 0;
            }
            var query = buildReportListQuery($scope.waiverPagenumber,waiverStatus);
    		
    		getReportList(query,waiverListName,waiverMaxPageName,isWaiverData);
    	}

        // get renewal report list
        function get_renewal_report_list(pageNumber){
            if(pageNumber){
                $scope.renewalPagenumber = pageNumber;
            }else{
                $scope.renewalPagenumber = 0;
            }
            var query = buildReportListQuery($scope.renewalPagenumber,renewalStatus);
            
            getReportList(query,renewalListName,renewalMaxPageName,isRenewalData);
        }

    	function getReportList(query,listName,maxPage,isDataAvalaible){
    		DataService.post('ContactGetWaiverAndRenewalList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope[listName] = data.result.responseData;
                    $scope[isDataAvalaible] = false;
                    $scope[maxPage] = data.result.totalPages;
                    if($scope[listName].length ==0){
                        $scope[isDataAvalaible] = true;
                    }
    			}else{
                    $scope[isDataAvalaible] = true;
    			}
    		}).catch(function (error) {
                $scope[isDataAvalaible] = true;
	        });
    	}

    	$scope.goToPageNumber = function(pageNo,tabName){
            if(tabName == 'waiver'){
                get_waiver_report_list(pageNo);
            }else{
                get_renewal_report_list(pageNo);
            }
        } 

        function buildReportListQuery(pageNo,status){
            var query = {
                "loginId": $cookies.get('memberId'),
                "waiverStatus": status,
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null
            }
            return query;
        }

        $scope.invokeRenewal = function(){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = {
                "loginId" : $cookies.get('memberId')
            }
            DataService.post('ContactOfficerInvokeRenewalProcess',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Invoke renewal process submitted successfully')
                    get_renewal_report_list(0);
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {  
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".overlay").css("display","none");
            });
        }

        $scope.openCancelInvoiceModel = function(reviewData){
            $scope.cancelInvoiceData = {};
            $scope.cancelInvoiceData.memberId = reviewData.memberId;
            $scope.cancelInvoiceData.roleId = reviewData.roleId;
            angular.element(".overlay").css("display","block");
            angular.element(".officer-cancel-invoice-case").css("display","block");
        }

        $scope.closeCancelInvoice = function(){
            angular.element(".officer-cancel-invoice-case").css("display","none");
            angular.element(".overlay").css("display","none");
        }

        $scope.submitCancelInvoice = function(invoiceData){
            angular.element(".officer-cancel-invoice-case").css("display","none");
            angular.element(".loading-container").css("display","block");
            invoiceData.loginId = $cookies.get('memberId');
            DataService.post('SubmitCancelInvoiceToManager',invoiceData).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Cancel invoice requested successfully')
                    get_renewal_report_list(0);
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {  
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".officer-cancel-invoice-case").css("display","block");
            });
        }

        $scope.submitToManagerApproval = function(remarkData,waiverData){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var query = buildManagerQuery(remarkData,waiverData);
            DataService.post('ContactOfficerSubmitWaiverToManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Waiver report submitted to management successfully')
                    get_waiver_report_list(0);
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }).catch(function (error) {  
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".overlay").css("display","none");
            });
        }

        function buildManagerQuery(remarkData,waiverData){
            var waiverIdList = [];
            for(var waiver in waiverData){
                waiverIdList.push(waiverData[waiver].memberId)
            }
            var query = {
                "loginId": $cookies.get('memberId'),
                "membershipRenewalWaiverIds" : waiverIdList,
                "officerRemarks": undefinedSetNull(remarkData.officerRemarks)
            }
            return query;
        }

    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();