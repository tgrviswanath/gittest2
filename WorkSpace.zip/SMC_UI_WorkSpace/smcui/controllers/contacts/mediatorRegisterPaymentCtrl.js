
(function () {
    'use strict';
    angular
        .module('smc')
        .controller('mediatorRegisterPaymentCtrl', mediatorRegisterPaymentCtrl);

    mediatorRegisterPaymentCtrl.$inject = ['$rootScope', '$scope','$interval', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function mediatorRegisterPaymentCtrl($rootScope, $scope,$interval, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {
        var chequeValue="CHEQUE";
        var enetsValue="ENETS";
        $scope.fail_templatefile = 'views/contacts/smcmemberaccount/mediator-payment-fail.html';
        $scope.success_templatefile = 'views/contacts/smcmemberaccount/mediator-payment-success.html';
        $scope.ChequePayment=true;
        $scope.payment_summary = true;
        $scope.paymentMethod = chequeValue;
        $scope.eNetsData={};
            // for e-Net
        var minYear = new Date().getFullYear();
        var maxYear = minYear+30;
        var minMonth = 1;
        var maxMonth = 12;
        $scope.yearList = [];
        for (var expYear = minYear; expYear < maxYear; expYear++) {
            $scope.yearList.push(expYear);
        }
        $scope.monthList = [];
        for (var expMonth = minMonth; expMonth <= maxMonth; expMonth++) {
            if(expMonth<=9){
                $scope.monthList.push('0'+expMonth);
            }else{
                $scope.monthList.push(expMonth);
            }
        }

        getPaymentDetails();
        DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
            $scope.roledetails = newdata.results;
            $scope.roleId=newdata.results[0].id;
            for(var i=0;i<$scope.roledetails.length;i++){
                if($scope.roledetails[i].name==$state.params.memberRoleName){
                    $scope.resourceId=$scope.roledetails[i].id;
                }
            }
        });
        function getPaymentDetails(){
            var query={
                "loginId": $state.params.loginId,
                "memberRole": $state.params.memberRoleName
            }
            DataService.post('GetMediatorRegisterPaymentDetail', query).then(function (data) {
                if(data.status=="SUCCESS"){
                    $scope.mediatorRegisterPaymentDetail=data.result; 
                    $scope.eNetsData.amount=data.result.totalAmount;
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }



        $scope.check_method=function(payment_method){
            $scope.paymentMethod=payment_method;
            if(payment_method==chequeValue){
                $scope.ChequePayment=true;
                $scope.eNetsPayment=false;
            }else{
                $scope.eNetsPayment=true;
                $scope.ChequePayment=false;
            }
        }
        $scope.convertCardNo = function(){
            var numberLen = $scope.eNetsData.referenceNumber.length;
            if(numberLen == 4 || numberLen == 9 || numberLen == 14){
                $scope.eNetsData.referenceNumber = $scope.eNetsData.referenceNumber + '-';
            }
            if(numberLen == 19){
                $scope.hideSubmitBtn = false;
            }else{
                $scope.hideSubmitBtn = true;
            }
        }
        $scope.makePayment=function(paymentData){
            var query={
                "loginId":$state.params.loginId,
                "memberId":$state.params.smcMemberId,
                "resourceId":$scope.resourceId,
                "paymentMode":$scope.paymentMethod,
                "paymentType":"MEMBERSHIP_FEE",
                "amount":paymentData.paymentFormAmount,
                "referenceNumber":paymentData.referenceNumber,
                "bankName":paymentData.bankName,
                "payerName":paymentData.payerName,
                "dateOfOrder":paymentData.chequePaymentdate
            }
         
            DataService.post('MakeMediatorPayment', query).then(function (data) {
                if(data.status=="SUCCESS"){
                     $scope.mediatorRegisterPaymentSuccess=data.result;
                    $scope.payment_summary = false;
                    $scope.payment_success = true;
                   
                }else{
                    $scope.theTime = 10;
                    $interval(function () {
                        $scope.theTime = $scope.theTime-1;
                        if($scope.theTime == 0){
                            $scope.theTime = undefined;
                            $scope.ChequePayment=false;
                            $scope.eNetsPayment=false;
                            $scope.payment_summary = false;
                            $scope.payment_success = true;
                        }
                    },1000);
                }
            }).catch(function (error) {
                        $scope.theTime = 10;
                        $scope.payment_summary = false;
                        $scope.payment_failed = true;
                    $interval(function () {
                        $scope.theTime = $scope.theTime-1;
                        if($scope.theTime == 0){
                            $scope.payment_summary = true;
                            $scope.payment_failed = false;   
                            $scope.theTime = undefined;
                            $scope.ChequePayment=true;
                            $scope.eNetsPayment=false;  
                        }
                    },1000);
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.addpayment=function(method,payment){
                var selectedMonth = String(payment.month);
                var selectedYear = String(payment.year).substring(2);
                var expiry = selectedMonth + selectedYear;
                var query={
                    "paymentMode":method,
                    "referenceNumber":payment.referenceNumber.split('-').join(""), 
                    "amount":payment.amount, 
                    "dateOfOrder":payment.dateOfOrder, 
                    "bankName":payment.bankName,
                    "payerName" : payment.payerName,
                    "cardHolderName":payment.cardHolderName,
                    "cardCVV":payment.cardCVV,
                    "cardExpiry": expiry,
                    "loginId":$state.params.loginId,
                    "memberId":$state.params.smcMemberId,
                    "resourceId":$scope.resourceId
                }
                    DataService.post('MakeMediatorPayment', query).then(function (data) {
                        if(data.status=="SUCCESS"){
                             $scope.mediatorRegisterPaymentSuccess=data.result;
                            $scope.payment_summary = false;
                            $scope.payment_success = true;
                           
                        }else{
                            $scope.theTime = 10;
                            $interval(function () {
                                $scope.theTime = $scope.theTime-1;
                                if($scope.theTime == 0){
                                    $scope.theTime = undefined;
                                    $scope.ChequePayment=false;
                                    $scope.eNetsPayment=false;
                                    $scope.payment_summary = false;
                                    $scope.payment_success = true;
                                }
                            },1000);
                        }
                    }).catch(function (error) {
                                $scope.theTime = 10;
                                $scope.payment_summary = false;
                                $scope.payment_failed = true;
                            $interval(function () {
                                $scope.theTime = $scope.theTime-1;
                                if($scope.theTime == 0){
                                    $scope.payment_summary = true;
                                    $scope.payment_failed = false;   
                                    $scope.theTime = undefined;
                                    $scope.ChequePayment=true;
                                    $scope.eNetsPayment=false;  
                                }
                            },1000);
                        NotifyFactory.log('error', error.errorMessage);
                    });
        }
    }
})();
