(function () {
    'use strict';
    angular
        .module('smc')
        .controller('tcCtrl', tcCtrl);

    tcCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function tcCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory, $stateParams) {
        var currentUrl = window.location.href.split('/');
        var token = currentUrl[currentUrl.length - 1];
        console.log(token)
        var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
        var memberdetailsforTc = termsandconditions + token;
        $http.get(memberdetailsforTc).then(function (tcdata) {
            $scope.tcdata = tcdata.data;
        });
        $scope.acceptTermsandConditions = function (idOfparticipant) {
            console.log(idOfparticipant);
            var query = {
                "participantId": idOfparticipant,
                "isAccepted": true
            }
            acceptTermsandConditionsfrall(query);

            function acceptTermsandConditionsfrall(query) {
                DataService.post('AcceptTermsandConditionsbyMember', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "Terms and conditions accepted successfully");
                    } else {
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                    
                });
            }

        };
    }
})();
