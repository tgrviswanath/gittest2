/*This controller used to a user can save and submit a mediation case details
(Applicant and Respondent details,mediation dates,mediatior preference,etc).This one controller used for 
different types of mediation cases - CMS,SCCMS,CPE*/


(function() {
    'use strict';
    angular
        .module('smc')
        .controller('cmsFormCtrl',cmsFormCtrl);

    cmsFormCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','mediationPatternConfig','httpPostFactory','smcConfig','navigateConfig','$window','$sce','NotifyFactory'];

    function cmsFormCtrl($rootScope,$scope,$state,$cookies,DataService,$http,mediationPatternConfig,httpPostFactory,smcConfig,navigateConfig,$window,$sce,NotifyFactory){
        
    	var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	$scope.tabName = tab;
    	$scope.ifPaymentProcess = false;
    	$scope.ifFormFillingProcess = true;

    	if($rootScope.mediationFormType == undefined){
    		$rootScope.mediationFormType = "CPE";
    		$rootScope.medationFormTitle = "CPE Form";
    	}
    	var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches
    	//Error Messages
		$scope.pattern = mediationPatternConfig;

		//Form Related Default settings
		$scope.cms_form = {};
		$scope.cms_form.applicantInfo = {};
		$scope.cms_form.applicantInfo.applicants = [];
		$scope.cms_form.applicantInfo.applicants[0] = {};
		


		$scope.cms_form.respondentInfo = [];



		//Default Initial Value
		$scope.cms_form.isAllPartiesAgree = true;
		$scope.cms_form.applicantInfo.applicants[0].businessAddress = {};
		$scope.cms_form.applicantInfo.applicants[0].authRepAddress = {};
		$scope.cms_form.applicantInfo.applicants[0].memberType = "Individual";
		$scope.cms_form.applicantInfo.applicants[0].salutationType = "Mr";
		$scope.cms_form.applicantInfo.applicants[0].authRepSalutationType = "Mr";
		$scope.cms_form.applicantInfo.applicants[0].isLegallyAided = false;
		$scope.cms_form.applicantInfo.applicants[0].businessAddress.countryCode = "+65";
		$scope.cms_form.applicantInfo.applicants[0].authRepAddress.countryCode = "+65";
		$scope.cms_form.applicantInfo.isLegallyRepresented = "Yes";
		$scope.cms_form.applicantInfo.lawFirm ={};
		$scope.cms_form.applicantInfo.lawFirm.lawyerDetails = [];
		$scope.cms_form.applicantInfo.lawFirm.lawyerDetails[0] = {};
		$scope.cms_form.applicantInfo.lawFirm.lawyerDetails[0].addressDTO = {};
		$scope.cms_form.applicantInfo.lawFirm.lawyerDetails[0].addressDTO.countryCode = "+65";
		$scope.cms_form.respondentInfo[0] = {};
		$scope.cms_form.respondentInfo[0].memberType = "Individual";
		$scope.cms_form.respondentInfo[0].salutationType = "Mr";
		$scope.cms_form.respondentInfo[0].authRepSalutationType = "Mr";
		$scope.cms_form.respondentInfo[0].businessAddress = {};
		$scope.cms_form.respondentInfo[0].authRepAddress = {};
		$scope.cms_form.respondentInfo[0].businessAddress.countryCode = "+65";
		$scope.cms_form.respondentInfo[0].authRepAddress.countryCode = "+65";
		$scope.cms_form.respondentInfo[0].isLegallyRepresented = "Unknown";
		$scope.cms_form.respondentInfo[0].lawFirm = {};
		$scope.cms_form.respondentInfo[0].lawFirm.lawyerDetails = [];
		$scope.cms_form.respondentInfo[0].lawFirm.lawyerDetails[0] = {};
		$scope.cms_form.respondentInfo[0].lawFirm.lawyerDetails[0].addressDTO = {};
		$scope.cms_form.respondentInfo[0].lawFirm.lawyerDetails[0].addressDTO.countryCode = "+65";

		$scope.disabledApplicantLawFirmData = true;
		$scope.disabledRespondLawFirmData = true;
		$scope.cms_form.mediatorPreferenceInfo = {};
		$scope.cms_form.mediatorPreferenceInfo.preferenceType = "SMC Appointed Mediators";
		$scope.applicantLawyerDetailShow = true;
		$scope.ApplicantLawFirmStatus = true;
		$scope.RespondentLawFirmStatus = [];
		$scope.RespondentLawFirmStatus[0] = true;
		$scope.cms_form.mediatorPreferenceInfo.numOfMediators = 1;
		$scope.mediationClauseShow = false;
		$scope.cms_form.caseInfo = {};
		$scope.cms_form.caseInfo.isLegalProceed = false;
		$scope.isPreviewClicked = false;
		$scope.selectedPrincipalMediatorList = [];
		$scope.selectedAssociateMediatorList = [];
		$scope.otherMediatorDetail = {};
		$scope.otherMediatorDetail.countryCode =  "+65";
		$scope.otherMedatorList = [];
		$scope.mediatorSelectStatus = true;
		$scope.cms_form.mediatorPreferenceInfo.language = 'English';
		$scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo = [];
		$scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[0] = {};
		$scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[1] = {};
		$scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[0].languages = ['English'];
		$scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[1].languages = ['English'];
		$scope.sccmQuatumValidate = false;
		$scope.distriputeNotSelected = false;
		$scope.selectMediatorCount = 0;
		$scope.cms_form.suitInfo = [];
		$scope.cms_form.disputeIds = [];
		$scope.cms_form.hearAboutUsIds = [];
		$scope.submitMediationFormAcknolegement =  false;
		$scope.saveMediationFormAcknolegement =  false;
		$scope.respondentLawyerCount = 0;
		
		


		$scope.applicantList = [{id: 'Applicant 1'}];
		$scope.applicantLawyerList = [{id: 'Lawyer 1'}];

		$scope.respondentList = [{id: 'Respondent 1'}];
		$scope.respondentLawyerList = [{
								  "lawyers" : [{"id" : "lawyer 1"}]
								}];

		$scope.suitList = [{id: 'Suit 1'}];

		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];

		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Salutation Type List Service
        DataService.get('GetSalutationList').then(function(data){
			$scope.salutationList = data.results;
        });

		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
			} else {
				$scope.lawFirmList = [];
			}
        });

        //Get Dispute Type List Service
        DataService.get('MediationDistriputeList').then(function(data){
			$scope.distriputeList = data.results;
        });

        //Get Language List Service
        DataService.get('GetLanguageList').then(function(data){
			$scope.languageList = data.results;
			console.log('languageList',$scope.languageList)
        });

        //Get Profession/Industry List Service
        DataService.get('MediationIndustryList').then(function(data){
			$scope.industryList = data.results;
        });

        //Get Specialisation List Service
        DataService.get('MediationSpecialisationList').then(function(data){
			$scope.specialisationList = data.results;
        });

        //Get Age Group List Service
        DataService.get('MediationAgeGroupList').then(function(data){
			$scope.ageGroupList = data.results;
        });

        //Get Hear About Us List Service
        DataService.get('MediationHearAboutusList').then(function(data){
			$scope.hearAboutUsList = data.results;
        });

        //Get Country Code List Service
        DataService.get('MediationCountryCodeList').then(function(data){
			$scope.countryCodeList = data.results;
        });

        //Principle Mediator List Service
        
        var principleMediatorQuery = {
							   "pageIndex":0,
							   "dataLength":100,
							   "sortingColumn":null,
							   "sortDirection":null,
							   "mediatorType":null,
							   "specialisation":"Principle Mediator",
							   "name":null
							}
        DataService.post('MediationMediatorList',principleMediatorQuery).then(function(data){
			$scope.principleMediatorList = data.result.responseData;
        });

		$scope.getprinciplemediator = function(principalmediatorsearch){
			var principleMediatorQuery = {
							   "pageIndex":0,
							   "dataLength":100,
							   "sortingColumn":null,
							   "sortDirection":null,
							   "mediatorType":null,
							   "specialisation":undefinedSetNull(principalmediatorsearch.specialisation),
							   "name":undefinedSetNull(principalmediatorsearch.name)
							}
        DataService.post('MediationMediatorList',principleMediatorQuery).then(function(data){
			$scope.principleMediatorList = data.result.responseData;
        });
		}

        var associateMediatorQuery = {
							   "pageIndex":0,
							   "dataLength":100,
							   "sortingColumn":null,
							   "sortDirection":null,
							   "mediatorType":null,
							   "specialisation":"Associate Mediator",
							   "name":null
							}
        DataService.post('MediationMediatorList',associateMediatorQuery).then(function(data){
			$scope.associateMediatorList = data.result.responseData;
        });
		$scope.getassosiatemediator = function(assosiatemediatorName){
			var associateMediatorQuery = {
							   "pageIndex":0,
							   "dataLength":100,
							   "sortingColumn":null,
							   "sortDirection":null,
							   "mediatorType":null,
							   "specialisation":"Associate Mediator",
							   "name":undefinedSetNull(assosiatemediatorName.name)
							}
	        DataService.post('MediationMediatorList',associateMediatorQuery).then(function(data){
				$scope.associateMediatorList = data.result.responseData;
	        });
		}

		$scope.applicantAddStatus = function(val){
			if(val == 'No'){
				$scope.applicantList = [{id: 'Applicant 1'}];
			}
		}

		if($rootScope.formDoingType == 'Update'){
			viewCaseDetails();
		}

		function viewCaseDetails(){
            if($scope.mediationFormType == 'CMS'){
                var ViewCMSFormUrl = smcConfig.services.ViewCMSForm.url;
                ViewCMSFormUrl = ViewCMSFormUrl + $scope.viewCaseNumber;
                getViewData(ViewCMSFormUrl)
            }else if($scope.mediationFormType == 'SCCMS'){
            	var ViewSCCMSFormUrl = smcConfig.services.ViewSCCMSForm.url;
                ViewSCCMSFormUrl = ViewSCCMSFormUrl + $scope.viewCaseNumber;
                getViewData(ViewSCCMSFormUrl)
            }
        }


  		//load applicant choosed lawfirm details
        $scope.loadApplicantLawFirmDetails = function(lawFirm){
        	lawFirm.lawyerDetails = [];
        	$scope.applicantLawyerList = [{id: 'Lawyer 1'}];
        	lawFirm.lawyerDetails[0] = {};
        	lawFirm.lawyerDetails[0].addressDTO = {};
        	lawFirm.lawyerDetails[0].addressDTO.countryCode = "+65";
        	if(lawFirm.name == 'Others'){
        		$scope.disabledApplicantLawFirmData = false;
        	}else{
        		$scope.disabledApplicantLawFirmData = true;
        	}
        }

        

        //load respondent choosed lawfirm details
        $scope.loadRespondantLawFirmDetails = function(lawFirm,index){
        	$scope.respondentLawyerList[index].lawyers = [{id: 'Lawyer 1'}];
        	lawFirm.lawyerDetails = [];
        	lawFirm.lawyerDetails[0] = {};
        	lawFirm.lawyerDetails[0].addressDTO = {};
        	lawFirm.lawyerDetails[0].addressDTO.countryCode = "+65";
        	if(lawFirm.name == 'Others'){
        		$scope.disabledRespondLawFirmData = false;
        	}else{
        		$scope.disabledRespondLawFirmData = true;
        	}
        }

        function getViewData(serviceUrl){
        	//set default value for updates
        	$scope.applicantList = [];
        	$scope.respondentList = [];
        	$scope.respondentLawyerList = {};
        	$scope.applicantLawyerList = [];
        	$scope.suitList = [];

            $http.get(serviceUrl).then(function(data){
                console.log("data",data);
                $scope.cms_form = data.data.result;
                
                for(var applicant in $scope.cms_form.applicantInfo.applicants){
                    $scope.applicantList.push({id: 'Applicant '+applicant})
                    if(!$scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided){
                    	$scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = false;
                    	$scope.cms_form.applicantInfo.applicants[applicant].reMail = $scope.cms_form.applicantInfo.applicants[applicant].email;
                    	$scope.cms_form.applicantInfo.applicants[applicant].authRepConEmail = $scope.cms_form.applicantInfo.applicants[applicant].authRepEmail;
                    }
                    if($scope.cms_form.applicantInfo.lawFirm){
                    	for(var lawyercont in $scope.cms_form.applicantInfo.lawFirm.lawyerDetails){
                    		$scope.cms_form.applicantInfo.lawFirm.lawyerDetails[lawyercont].reMail = $scope.cms_form.applicantInfo.lawFirm.lawyerDetails[lawyercont].email;
                    	}
                    }
                }
                
                for(var respondent in $scope.cms_form.respondentInfo){
                    $scope.respondentList.push({id: 'Respondent '+respondent})
                    if($scope.cms_form.respondentInfo[respondent].isLegallyAided){
                        $scope.cms_form.respondentInfo[respondent].isLegallyAided = 'Yes'
                    }else{
                        $scope.cms_form.respondentInfo[respondent].isLegallyAided = 'No'
                    }
                    $scope.respondentLawyerList[respondent] = {}
                    $scope.respondentLawyerList[respondent].lawyers = [];
                    $scope.cms_form.respondentInfo[respondent].reMail = $scope.cms_form.respondentInfo[respondent].email;
                    $scope.cms_form.respondentInfo[respondent].authRepConEmail = $scope.cms_form.respondentInfo[respondent].authRepEmail;
                    if($scope.cms_form.respondentInfo[respondent].lawFirm){
                        for (var lawyer in $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails){
                            $scope.respondentLawyerList[respondent].lawyers.push({'id':'Lawyer '+lawyer});
                            $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails[lawyer].reEmail = $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails[lawyer].email; 
                        }
                    }else{
                        $scope.respondentLawyerList[respondent].push({'id':'Lawyer '+1});
                    }
                }
                
                if($scope.cms_form.applicantInfo.lawFirm){
                    for (var lawyer in $scope.cms_form.applicantInfo.lawFirm.lawyerDetails){
                        $scope.applicantLawyerList.push({'id':'Lawyer '+lawyer});
                    }
                }else{
                    $scope.applicantLawyerList.push({'id':'Lawyer '+1});
                }

                
                if($scope.cms_form.suitInfo){
                    for(var suit in $scope.cms_form.suitInfo){
                        $scope.suitList.push({'id':'Suit '+suit});
                    }
                }
                $scope.applicantInfoLength = $scope.cms_form.applicantInfo.applicants.length;
                $scope.respondentInfoLength = $scope.cms_form.respondentInfo.length;
            });
        }

		
		//if legally represented value is yes,add multi applicants,this function used to add one more applicant 
		$scope.addNewApplicant = function() {
            var index = $scope.applicantList.length;
            var newItemNo = $scope.applicantList.length+1;
            $scope.applicantList.push({'id':'Applicant '+newItemNo});
            $scope.cms_form.applicantInfo.applicants[index] = {};
            $scope.cms_form.applicantInfo.applicants[index].memberType = "Individual";
            $scope.cms_form.applicantInfo.applicants[index].salutationType = "Mr";
            $scope.cms_form.applicantInfo.applicants[index].authRepSalutationType = "Mr";
            $scope.cms_form.applicantInfo.applicants[index].businessAddress = {};
            $scope.cms_form.applicantInfo.applicants[index].authRepAddress = {};
            $scope.cms_form.applicantInfo.applicants[index].businessAddress.countryCode = "+65";
            $scope.cms_form.applicantInfo.applicants[index].authRepAddress.countryCode = "+65";
            $scope.cms_form.applicantInfo.applicants[index].isLegallyAided = $scope.cms_form.applicantInfo.applicants[0].isLegallyAided;
        };
        //This function use to add one more lawyer for applicant
		$scope.addNewApplicantLawyer = function() {
            var newItemNo = $scope.applicantLawyerList.length+1;
            $scope.cms_form.applicantInfo.lawFirm.lawyerDetails[$scope.applicantLawyerList.length] = {};
            $scope.cms_form.applicantInfo.lawFirm.lawyerDetails[$scope.applicantLawyerList.length].addressDTO = {};
            $scope.cms_form.applicantInfo.lawFirm.lawyerDetails[$scope.applicantLawyerList.length].addressDTO.countryCode = "+65";
            $scope.applicantLawyerList.push({'id':'Lawyer '+newItemNo});
        };
        //This function use to remove one lawyer for applicant
        $scope.removeApplicantLawyer = function(index){
        	$scope.cms_form.applicantInfo.lawFirm.lawyerDetails.splice(index,1);
        	$scope.applicantLawyerList.splice(index,1)
        }
        //This function use to add one more Respondent 
		$scope.addNewRespondent = function() {
			var index = $scope.respondentList.length;
		    var newItemNo = $scope.respondentList.length+1;
		    $scope.respondentList.push({'id':'Respondent '+newItemNo});
		    $scope.respondentLawyerList[index] = {};
		    $scope.respondentLawyerList[index].lawyers = [];
		    $scope.cms_form.respondentInfo[index] = {};

		    var primaryLawyers = $scope.respondentLawyerList[0].lawyers;
		    $scope.respondentLawyerList[index].lawyers.push(primaryLawyers);



		    

		    $scope.cms_form.respondentInfo[index].isLegallyRepresented = 'Unknown';
		    $scope.cms_form.respondentInfo[index].memberType = "Individual";
			$scope.cms_form.respondentInfo[index].salutationType ="Mr";
			$scope.cms_form.respondentInfo[index].authRepSalutationType ="Mr";
			$scope.cms_form.respondentInfo[index].businessAddress = {};
            $scope.cms_form.respondentInfo[index].authRepAddress = {};
            $scope.cms_form.respondentInfo[index].lawFirm = {};
            $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails = [];
            $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails[0] = {};
		    $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails[0].addressDTO = {};
		    $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails[0].addressDTO.countryCode = "+65";
			$scope.cms_form.respondentInfo[index].businessAddress.countryCode = "+65";
			$scope.cms_form.respondentInfo[index].authRepAddress.countryCode = "+65";

		};
		//This function use to add one more lawyer for Respondent
		$scope.addNewRespondentLawyer = function(index) {
			$scope.respondCount = index;
		    $scope.respondentLawyerCount = $scope.respondentLawyerList[index].lawyers.length+1;
		    if(!$scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails){
		    	$scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails = [];
		    }
		    $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails[$scope.respondentLawyerList[index].lawyers.length] = {};
		    $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails[$scope.respondentLawyerList[index].lawyers.length].addressDTO = {};
		    $scope.cms_form.respondentInfo[index].lawFirm.lawyerDetails[$scope.respondentLawyerList[index].lawyers.length].addressDTO.countryCode = "+65";
		    $scope.respondentLawyerList[index].lawyers.push({'id':'Lawyer '+$scope.respondentLawyerCount});
		};
		//This function use to remove one lawyer for Respondent
		$scope.removeRespondLawyer = function(count,index){
			$scope.cms_form.respondentInfo[count].lawFirm.lawyerDetails.splice(index,1);
			$scope.respondentLawyerList[0].lawyers.splice(index,1);
		}

		/*under hear about us section if applicant choosen mediation clause option,then applicant should be enter deatils 
		or a pdf file, this function helps to if that option checked show textbox*/

		$scope.showMediationClause = function(data,status){
			console.log(data);
			console.log(status);
			var data = data.trim();
			var curStatus = status.target.checked;
			if(data == "Mediation Clause" && curStatus == true){
				$scope.mediationClauseShow = true;
			} else if(data == "Mediation Clause" && curStatus == false){
				$scope.mediationClauseShow = false;
			}
		}

		$scope.legalProceedingSuitList = function(){
			var newItemNo = $scope.suitList.length+1;
		    $scope.suitList.push({'id':'Suit '+newItemNo});
		}

		$scope.principalMediatorsSelectCheck = function(event){
			var selectCount = selectedMediatorCount();
			if(selectCount > 3){
				event.target.checked = false
			}
		}

		$scope.addNewMediator = function(){
			var selectCount = selectedMediatorCount();
			var formInvalid = angular.element("#addNewOtherMediator .ng-invalid");
			var formInvalidCount = formInvalid.length;

			if(formInvalidCount > 0){
				angular.element("#addNewOtherMediator .ng-invalid").addClass("error");
			} else {
				if(selectCount <= 3){
					if($scope.otherMediatorDetail.name){
						delete $scope.otherMediatorDetail.reEmail;
						$scope.otherMedatorList.push($scope.otherMediatorDetail);
						$scope.otherMediatorDetail = {};
                        $scope.otherMediatorDetail.countryCode = '+65';
					}
				} else {
					$scope.mediatorSelectStatus = true;
				}
			}
            var  endvalue;
            var  startvalue;
            $('#selectedMediatorsList > tbody').sortable({
                update: function( event, ui ) {
                    endvalue = ui.item.index()
                    if(startvalue < endvalue){
                        var selectvalue = $scope.otherMedatorList[startvalue];
                        for(var index =startvalue;index<endvalue;index++){
                            $scope.otherMedatorList[index] = $scope.otherMedatorList[index+1];
                        }
                        $scope.otherMedatorList[endvalue] = selectvalue;
                    }else{
                        var selectvalue = $scope.otherMedatorList[startvalue];
                         for(var index =startvalue;index>endvalue;index--){
                            $scope.otherMedatorList[index] = $scope.otherMedatorList[index-1];
                        }
                        $scope.otherMedatorList[endvalue] = selectvalue;
                    }
                    $scope.$apply();
                },
                start: function( event, ui ) {
                    startvalue = ui.item.index()
                }
            });
		}
        $scope.dupEmail = false;
        $scope.chkunicmail = function(curMail){
            if($scope.otherMedatorList.length != 0){
                for(var med in $scope.otherMedatorList){
                    if($scope.otherMedatorList[med].email.indexOf(curMail) != -1){
                        $scope.dupEmail = true;
                    }else{
                        $scope.dupEmail = false;
                    }
                }
            }
        }

		$scope.removeOtherNewMediator = function(index){
			$scope.otherMedatorList.splice(index,1);
		}

		function selectedMediatorCount(){
			if($scope.selectedPrincipalMediatorList.length > 0){
				var selectedPrincipleCount = getCheckedArrayCount($scope.selectedPrincipalMediatorList);
				if(selectedPrincipleCount){
					console.log(selectedPrincipleCount);
				}
			} else {
				var selectedPrincipleCount = 0;
			}
			if($scope.selectedAssociateMediatorList.length > 0){
				var selectedAssociateCount = getCheckedArrayCount($scope.selectedAssociateMediatorList);
			} else {
				var selectedAssociateCount = 0;
			}
			if($scope.otherMedatorList.length > 0){
				var otherCount = $scope.otherMedatorList.length;
			} else {
				var otherCount = 0;
			}
			if(selectedPrincipleCount != undefined && selectedAssociateCount != undefined && otherCount != undefined){
				var selectCount = (selectedPrincipleCount) + (selectedAssociateCount) + otherCount;
			}
			return selectCount;
		}

		function getCheckedArrayCount(data) {
		    var count = 0;
		    angular.forEach(data, function(status){
		        count += status ? 1 : 0;
		    });
		    return count; 
		}
		/*Document Uploads*/
		$scope.legalAidCerticate = function(event){

			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.cms_form.applicantInfo.applicants[0].legalCertificate = {};
				$scope.termsUploadPathStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						$scope.cms_form.applicantInfo.applicants[0].legalCertificate.name = fileName;
						angular.element("#suport_upload1_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload1_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								$scope.legallyAidUploadedStatus = true;
								console.log(data);
								$scope.cms_form.applicantInfo.applicants[0].legalCertificate.location = data.result;
								$scope.termsUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload1_name").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.termsUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload1_name").addClass("error");
					$scope.termsErrorStatus = true;
					$scope.termsUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.legallyAidUploadedRemove = function(){
			$scope.cms_form.applicantInfo.legal_aid_certificate = undefined;
			$scope.cms_form.applicantInfo.legal_aid_certificate_name = undefined;
			angular.element("#legal_aid_certificate_name").val("");
			angular.element("#legal_aid_certificate").val("");
			$scope.legallyAidUploadedStatus = false;
		}

		$scope.mediationClauseFileUpload = function(event){

			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.termsUploadPathStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						$scope.cms_form.MediationClauseFileName = fileName;
						angular.element("#suport_upload1_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload1_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								
								console.log(data);
								$scope.cms_form.MediationClauseFile = data.result;
								$scope.termsUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload1_name").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.termsUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#suport_upload1_name").addClass("error");
					$scope.termsErrorStatus = true;
					$scope.termsUploadErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}
		$scope.termsUploadRemove = function(){
			
			$scope.aa1_form1.suport_upload1 = undefined;
			$scope.aa1_form1.suport_upload1_name = undefined;
			$scope.termsUploadPath = undefined;
			angular.element("#suport_upload1_name").val("");
			angular.element("#suport_upload1").val("");
			$scope.termsUploadPathStatus = false;
			if(!$scope.termsUploadPath && !$scope.paymentClaimUploadPath && !$scope.intentionNoticeUploadPath){
				$scope.onlineFileUploadStatus = true;
				$("#suport_upload1_name").addClass("error");
				$("#suport_upload2_name").addClass("error");
				$("#suport_upload4_name").addClass("error");
			}
		}

		
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if(allowedExt[i] == ext){
					return true;
				}
			}
		}

		$scope.mediatorErrorClose = function(){
			angular.element(".overlay").css("display","none");
			angular.element("#mediator_count_error").css("display","none");
		}

		//Form Preview
    	$scope.mediationFormPreview = function(newItem){
    		var setDate = selectedDateSetScope();
    		var distriputeLen = $scope.cms_form.disputeIds.length;
    		var formStatusValidate = quantumAmountValidate();
    		var selectCount = selectedMediatorCount();
    		var formInvalid = angular.element("#mediation_cms_form .ng-invalid");
			var formInvalidCount = formInvalid.length;

			if(formInvalidCount > 0){
				angular.element("#mediation_cms_form .ng-invalid").addClass("error");
				formInvalid[0].focus();
			}
			if(distriputeLen < 1){
				$scope.distriputeNotSelected = true;
			} else {
				$scope.distriputeNotSelected = false;
			}
			if(formStatusValidate){
				if(selectCount < 4 && $scope.cms_form.mediatorPreferenceInfo.preferenceType == 'Choose own Mediators'){
					if($scope.cms_form.mediatorPreferenceInfo.numOfMediators == 1){
						if(selectCount > 0){
							$scope.mediatorStatus = true;
						} else {
							$scope.mediatorStatus = false;
							$scope.selectMediatorCount = 1;
							angular.element(".overlay").css("display","block");
							angular.element("#mediator_count_error").css("display","block");
						}
					} else if($scope.cms_form.mediatorPreferenceInfo.numOfMediators == 2) {
						if(selectCount > 1){
							$scope.mediatorStatus = true;
						} else {
							$scope.mediatorStatus = false;
							$scope.selectMediatorCount = 2;
							angular.element(".overlay").css("display","block");
							angular.element("#mediator_count_error").css("display","block");
						}
					}
				} else if($scope.cms_form.mediatorPreferenceInfo.preferenceType == 'SMC Appointed Mediators'){
					$scope.mediatorStatus = true;
				} else {
					$scope.mediatorStatus = false;
				}
			}
    		if(setDate){
    			if(formStatusValidate && distriputeLen > 0 && $scope.mediatorStatus){
				   	$scope.isPreviewClicked = false;
				   	//Validate Claimant Details are entered
					if(formInvalidCount > 0){
						angular.element("#mediation_cms_form .ng-invalid").addClass("error");
						formInvalid[0].focus();
					} else{
						$scope.isPreviewClicked = true; 
					}
				}
			}
		}


		//action in form SAVE/SUBMIT
		$scope.actionOfForm = function(FormType,actionType){
			if(actionType == 'Save'){
				var selectedDate = angular.element("#selectedDate").val();
				$scope.cms_form.mediationDates = selectedDate;
				var successMsg = FormType+' saved successfully'
			}else{
				var successMsg = FormType+' submitted successfully'
			}

			var actionQuery = buildQurey(FormType);
			var postQuery = angular.copy(actionQuery);
			postQuery = trimDataQuery(postQuery,FormType);

			var actionServiceUrl = 'Mediation'+actionType+FormType+'Form';

			goToAction(actionServiceUrl,postQuery,successMsg,actionType)
		}

		//to trim un wanted data in query
		function trimDataQuery(postQuery,Type){
			if(postQuery.applicantInfo.lawFirm){
			 	for(var lawyer in postQuery.applicantInfo.lawFirm.lawyerDetails){
            		postQuery.applicantInfo.lawFirm.lawyerDetails[lawyer].reMail = undefined;
            	}
			}
			for(var applicant in postQuery.applicantInfo.applicants){
				postQuery.applicantInfo.applicants[applicant].reMail = undefined;
				postQuery.applicantInfo.applicants[applicant].authRepConEmail = undefined;
                postQuery.applicantInfo.applicants[applicant].businessAddress.faxNumber = '+65' + postQuery.applicantInfo.applicants[applicant].businessAddress.faxNumber;
			}
            for(var respo in postQuery.respondentInfo){
                postQuery.respondentInfo[respo].reMail = undefined;
                postQuery.respondentInfo[respo].authRepConEmail = undefined;
                if(postQuery.respondentInfo[respo].lawFirm){
                    for(var lawyer in postQuery.respondentInfo[respo].lawFirm.lawyerDetails){
                        postQuery.respondentInfo[respo].lawFirm.lawyerDetails[lawyer].reEmail = undefined;
                    }
                }
            }
			if(Type == 'SCCMS'){
				for(var applicant in postQuery.applicantInfo.applicants){
					postQuery.applicantInfo.applicants[applicant].gender = undefined;
					postQuery.applicantInfo.applicants[applicant].isLegallyAided = undefined;
					postQuery.applicantInfo.applicants[applicant].legalCertificate = undefined;
				}
				for(var respo in postQuery.respondentInfo){
					postQuery.respondentInfo[respo].gender = undefined;
				}
			}
			if($rootScope.formDoingType == 'Update'){
				postQuery.applicantInfo.applicantLoginEmail = undefined;
				postQuery.applicantInfo.applicantLoginMemberRole = undefined;
				postQuery.applicantInfo.applicantLoginName = undefined;
                postQuery.applicantInfo.id=undefined;
                for(var applicant in postQuery.applicantInfo.applicants){
                    postQuery.applicantInfo.applicants[applicant].id = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.id = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.address1 = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.address2 = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.address3 = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.address4 = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.country = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.isServiceAddress = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepAddress.postalCode = undefined;
                    postQuery.applicantInfo.applicants[applicant].isLegallyAidedConfirmed = undefined;
                    postQuery.applicantInfo.applicants[applicant].isUndertakingReceived = undefined;
                    postQuery.applicantInfo.applicants[applicant].reEnterEmail = undefined;
                    postQuery.applicantInfo.applicants[applicant].applicantUidDto = undefined;
                    postQuery.applicantInfo.applicants[applicant].authRepSalutation = undefined;
                    postQuery.applicantInfo.applicants[applicant].memberUidType = undefined;
                    postQuery.applicantInfo.applicants[applicant].salutationDTO = undefined;
                    if(!postQuery.applicantInfo.applicants[applicant].partyType){
                        postQuery.applicantInfo.applicants[applicant].partyType = undefined;
                    }
                }
                for(var respo in postQuery.respondentInfo){
                    postQuery.respondentInfo[respo].id = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.id = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.address1 = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.address2 = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.address3 = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.address4 = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.country = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.isServiceAddress = undefined;
                    postQuery.respondentInfo[respo].authRepAddress.postalCode = undefined;
                    postQuery.respondentInfo[respo].isLegallyAidedConfirmed = undefined;
                    postQuery.respondentInfo[respo].isUndertakingReceived = undefined;
                    postQuery.respondentInfo[respo].reEnterEmail = undefined;
                    postQuery.respondentInfo[respo].applicantUidDto = undefined;
                    postQuery.respondentInfo[respo].authRepSalutation = undefined;
                    postQuery.respondentInfo[respo].memberUidType = undefined;
                    postQuery.respondentInfo[respo].salutationDTO = undefined;
                    if(!postQuery.respondentInfo[respo].partyType){
                        postQuery.respondentInfo[respo].partyType = undefined;
                    }
                }
                var dates = postQuery.mediationDates[0].split(',');
                postQuery.mediationDates = dates;
				for(var respo1 in postQuery.respondentInfo){
					postQuery.respondentInfo[respo1].respondentLoginMemberRole = undefined;
					postQuery.respondentInfo[respo1].respondentLoginName = undefined;
					postQuery.respondentInfo[respo1].responentLoginEmail = undefined;
				}
				var trimCaseInfo = {
					'quantumClaim' : postQuery.caseInfo.quantumClaim,
					'quantumCounterClaim' : postQuery.caseInfo.quantumCounterClaim,
					'disputeDescription' : postQuery.caseInfo.disputeDescription,
					'otherClaim' : postQuery.caseInfo.otherClaim,
					'isLegalProceed' : postQuery.caseInfo.isLegalProceed,
				}
				postQuery.caseInfo = trimCaseInfo;
				for(var suit in postQuery.suitInfo){
					var trimCaseInfo = {
						'suitNumber' : postQuery.suitInfo[suit].suitNumber,
						'partyName' : postQuery.suitInfo[suit].partyName,
						'suitRole' : postQuery.suitInfo[suit].suitRole,
					}
					postQuery.suitInfo[suit] = trimCaseInfo;
				}
			}
			return postQuery;
		}

		//function from final action to post query
		function goToAction(actionServiceUrl,postQuery,successMsg,actionType){
			DataService.post(actionServiceUrl,postQuery).then(function(data){
				NotifyFactory.log('success',successMsg);
				angular.element(".mediationFormContainer").addClass("hide");
				if(actionType == 'Save'){
					$scope.saveMediationFormAcknolegement =  true;
					$rootScope.tempCaseNumber = data.result;
                    $rootScope.downloadUrl = smcConfig.services.MediationDownloadForm.url + "/" + $rootScope.tempCaseNumber;
				}else{
					$scope.submitMediationFormAcknolegement =  true;
					$rootScope.memberData = data.result;
					//Generate Download URL
					$rootScope.downloadUrl = smcConfig.services.MediationDownloadForm.url + "/" + $rootScope.memberData.tempCaseNumber;
				}
			}).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
	        });
		}

		$scope.amendFormPreview=function(){
			$scope.isPreviewClicked = false;
		}
		$scope.backToForm=function(){
			$scope.isPreviewClicked = false;
			angular.element(".mediationFormContainer").removeClass("hide");
			$scope.saveMediationFormAcknolegement =  false;
			$scope.submitMediationFormAcknolegement =  false;
		}

		function buildQurey(type){

            var caseInfoQuery = buildcaseInfoQuery();
            var mediatorPreference = mediatorPreferenceInfoQuery();
            var applicantsQueryInfo = buildApplicantsInfo();
            var respondentsQueryInfo = buildrespondentsInfo();
            var query = { 
                "isAllPartiesAgree" : undefinedSetNull($scope.cms_form.isAllPartiesAgree),
                "tempCaseNumber":undefinedSetNull($rootScope.tempCaseNumber?$rootScope.tempCaseNumber:$scope.cms_form.caseInfo.tempCaseNumber),
                "mediationType": type,
                "applicantInfo" : applicantsQueryInfo,
                "respondentInfo":respondentsQueryInfo,
                "disputeIds":$scope.cms_form.disputeIds,
                "hearAboutUsIds": $scope.cms_form.hearAboutUsIds,
                "mediationDates":$scope.cms_form.mediationDates.split(', '),
                "caseInfo": caseInfoQuery,
                "suitInfo": $scope.cms_form.suitInfo,
                "mediatorPreferenceInfo": mediatorPreference,
            }
            console.log('finalQuery', query)
            return query;
		}

		function buildBusAdd(busi_addrs){
            if(busi_addrs.faxNumber){
                var faxNumber = busi_addrs.faxNumber;
            }
			var query = {
				"address1": undefinedSetNull(busi_addrs.address1),
                "address2": undefinedSetNull(busi_addrs.address2),
                "address3": undefinedSetNull(busi_addrs.address3),
                "address4": undefinedSetNull(busi_addrs.address4),
                "countryCode": undefinedSetNull(busi_addrs.countryCode),
                "faxNumber": undefinedSetNull(faxNumber),
                "mobileNumber": undefinedSetNull(busi_addrs.mobileNumber),
                "phoneNumber": undefinedSetNull(busi_addrs.phoneNumber),
                "postalCode": undefinedSetNull(busi_addrs.postalCode)
			}
			return query;
		}
		
		function buildApplicantsInfo(){
			if($scope.cms_form.applicantInfo.isLegallyRepresented != 'Yes'){
            	$scope.cms_form.applicantInfo.lawFirm = null;
            }
            if($scope.cms_form.applicantInfo.lawFirm){
            	if($scope.cms_form.applicantInfo.lawFirm.name == 'Others'){
            		$scope.cms_form.applicantInfo.lawFirm.name = $scope.cms_form.applicantInfo.lawFirm.otherName;
            		$scope.cms_form.applicantInfo.lawFirm.otherName = undefined;
            	}
            	var applicant_lawfirm_bus_add = buildBusAdd($scope.cms_form.applicantInfo.lawFirm.businessAddress);
            	$scope.cms_form.applicantInfo.lawFirm.businessAddress = applicant_lawfirm_bus_add;
            	$scope.cms_form.applicantInfo.lawFirm.isUserEntered = undefined;
            	$scope.cms_form.applicantInfo.lawFirm.serviceAddress = undefined;
            }

            for(var applicant in $scope.cms_form.applicantInfo.applicants){
                if(!$scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided){
                    $scope.cms_form.applicantInfo.applicants[applicant].legalCertificate = null;
                }
                var applicant_bus_add = buildBusAdd($scope.cms_form.applicantInfo.applicants[applicant].businessAddress);
                $scope.cms_form.applicantInfo.applicants[applicant].businessAddress = applicant_bus_add;
                $scope.cms_form.applicantInfo.applicants[applicant].gender = null;
                $scope.cms_form.applicantInfo.applicants[applicant].authRepAddress.faxNumber = null;

            }
            return $scope.cms_form.applicantInfo;
		}

		function buildrespondentsInfo(){
			for(var respondent in $scope.cms_form.respondentInfo){
                
                if($scope.cms_form.respondentInfo[respondent].isLegallyRepresented != 'Yes'){
                	$scope.cms_form.respondentInfo[respondent].lawFirm = null;
                }
                var respondent_bus_add = buildBusAdd($scope.cms_form.respondentInfo[respondent].businessAddress);
                $scope.cms_form.respondentInfo[respondent].businessAddress = respondent_bus_add;
                $scope.cms_form.respondentInfo[respondent].gender = null;
                $scope.cms_form.respondentInfo[respondent].authRepAddress.faxNumber = null;
                if($scope.cms_form.respondentInfo[respondent].lawFirm){
                	if($scope.cms_form.respondentInfo[respondent].lawFirm.name == 'Others'){
	            		$scope.cms_form.respondentInfo[respondent].lawFirm.name = $scope.cms_form.respondentInfo[respondent].lawFirm.otherName;
	            		$scope.cms_form.respondentInfo[respondent].lawFirm.otherName = undefined;
	            	}
                	var respondent_lawfirm_bus_add = buildBusAdd($scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress);
                	$scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress = respondent_lawfirm_bus_add;
                	$scope.cms_form.respondentInfo[respondent].lawFirm.isUserEntered = undefined;
            		$scope.cms_form.respondentInfo[respondent].lawFirm.serviceAddress = undefined;
                }
            }
            return $scope.cms_form.respondentInfo;
		}

		function buildcaseInfoQuery(){
			
            $scope.cms_form.caseInfo.isDamagesToBeAssessed = undefined;

            return $scope.cms_form.caseInfo
		}

		$scope.addHearAbtUsIds = function(id){
			var findIndex = $scope.cms_form.hearAboutUsIds.indexOf(id);
			if(findIndex == -1){
				$scope.cms_form.hearAboutUsIds.push(id);
			}else{
				$scope.cms_form.hearAboutUsIds.splice(findIndex,1)
			}
		} 

		$scope.adddisputeIds = function(id){
			var findIndex = $scope.cms_form.disputeIds.indexOf(id);
			if(findIndex == -1){
				$scope.cms_form.disputeIds.push(id);
			}else{
				$scope.cms_form.disputeIds.splice(findIndex,1)
			}

            if($scope.cms_form.disputeIds.length == 0){
                $scope.distriputeNotSelected = true;
            }else{
                $scope.distriputeNotSelected = false;
            }
		} 

		function principleMediatosrQuery(){
			var principleMediators = [];
			for(var key in $scope.selectedPrincipalMediatorList){
				if($scope.selectedPrincipalMediatorList[key] == true){
					principleMediators.push(parseInt(key))
				}
			}
			console.log('principleMediators',principleMediators);
			return principleMediators;
		}

		function assosiateMediatosrQuery(){
			var assosiateMediators = [];
			for(var key in $scope.selectedAssociateMediatorList){
				if($scope.selectedAssociateMediatorList[key] == true){
					assosiateMediators.push(parseInt(key))
				}
			}
			console.log('assosiateMediators',assosiateMediators);
			return assosiateMediators;
		}

		function mediatorPreferenceInfoQuery(){
			if($scope.cms_form.mediatorPreferenceInfo.preferenceType == 'Choose own Mediators'){
				var query = {
					"preferenceType": $scope.cms_form.mediatorPreferenceInfo.preferenceType,
					"numOfMediators": $scope.cms_form.mediatorPreferenceInfo.numOfMediators,
					"ownMediatorInfo": {
						"principalMediators": principleMediatosrQuery(),
						"associateMediators": assosiateMediatosrQuery(),
						"otherMediators": $scope.otherMedatorList
					}
				}
					query.languagesInfo = [$scope.cms_form.mediatorPreferenceInfo.language]
			}else{
				 var query = {};
				 var smcMediatorQueryInfo = updateSmcMediatorInfo();
				query.smcMediatorInfo = smcMediatorQueryInfo;
				query.preferenceType = $scope.cms_form.mediatorPreferenceInfo.preferenceType;
				query.numOfMediators = $scope.cms_form.mediatorPreferenceInfo.numOfMediators;
			}
				

			return query;
		}

		//build smc mediator info query 
		function updateSmcMediatorInfo(){
			if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                $scope.cms_form.mediator = [];
                for(var mediator in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                    $scope.cms_form.mediator[mediator] = {};
                    $scope.cms_form.mediator[mediator].industry = [];
                    $scope.cms_form.mediator[mediator].specialisation = [];
                    $scope.cms_form.mediator[mediator].language = [];
                    for(var industry in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes){
                        if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry].name){
                            $scope.cms_form.mediator[mediator].industry.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry].name) 
                        }else{
                            $scope.cms_form.mediator[mediator].industry.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry]) 
                        }
                    }
                    for(var specialisation in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes){
                        if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation].specialisationName){
                            $scope.cms_form.mediator[mediator].specialisation.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation].specialisationName) 
                        }else{
                            $scope.cms_form.mediator[mediator].specialisation.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation])  
                        }
                    }
                    for(var language in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages){
                        if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language].languageName){
                            $scope.cms_form.mediator[mediator].language.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language].languageName) 
                        }else{
                            $scope.cms_form.mediator[mediator].language.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language]) 
                        }
                    }
                    $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes = $scope.cms_form.mediator[mediator].industry;
                    $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes = $scope.cms_form.mediator[mediator].specialisation;
                    $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages = $scope.cms_form.mediator[mediator].language;
                }
            }
            return $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo;
		}

		

		//Generate Download URL
		var generateDownloadUrl = smcConfig.services.DownloadAAForm.url;
		$rootScope.downloadUrl = generateDownloadUrl + "/" + $rootScope.pdfCaseNumber;
		
		$scope.openPrintPdf = function(){

			var generatePdfUrl = smcConfig.services.DownloadAAForm.url;
            generatePdfUrl = generatePdfUrl + "/" + $rootScope.pdfCaseNumber;
			
			$http
		    .get(generatePdfUrl,{ responseType: 'arraybuffer' })
		    .success(function(data){
		    	var file = new Blob([data], {type: 'application/pdf'});
      			var fileURL = URL.createObjectURL(file);
		        
      			$scope.pdfFileData = $sce.trustAsResourceUrl(fileURL);
		        //data is link to pdf
		        //$window.open(fileURL);
		        angular.element(".overlay").css("display","block");
				angular.element("#aa_pdf_view").css("display","block");
		    });
		}
		$scope.closePrintPdf = function(formId){
			angular.element(".overlay").css("display","none");
			angular.element("#"+formId).css("display","none");
		}

		function selectedDateSetScope(){
			var selectedDate = angular.element("#selectedDate").val();
			$scope.cms_form.mediationDates = selectedDate;
			$rootScope.selectedDate = selectedDate;
			return true;
		}


		//SCCMS Form validate
		function quantumAmountValidate(){
			if($scope.cms_form.caseInfo.quantumClaim != undefined){
				var quantumClaim = parseInt($scope.cms_form.caseInfo.quantumClaim);
			} else {
				var quantumClaim = 0;
			}
			if($scope.cms_form.caseInfo.quantumCounterClaim != undefined){
				var quantumCounterClaim = parseInt($scope.cms_form.caseInfo.quantumCounterClaim);
			} else {
				var quantumCounterClaim = 0;
			}
			if(((quantumClaim + quantumCounterClaim) > 60000) && $rootScope.mediationFormType == "SCCMS"){
				$scope.sccmQuatumValidate = true;
				angular.element(".statusOnQuantum").html("Kindly note that for SCCMS applications, the total quantum in dispute should lower than S$60,000. Please use the “Others” field for providing additional details about the quantum in dispute.");
				angular.element(".overlay").css("display","block");
				angular.element("#quantum_claim_status").css("display","block");
			} else if(((quantumClaim + quantumCounterClaim) < 60001) && $rootScope.mediationFormType == "CMS"){
				$scope.sccmQuatumValidate = true;
				angular.element(".statusOnQuantum").html("Kindly note that for CMS applications, the total quantum in dispute should exceed S$60,000. Please use the “Others” field for providing additional details about the quantum in dispute.");
				angular.element(".overlay").css("display","block");
				angular.element("#quantum_claim_status").css("display","block");
			}
			return true;
		}

		$scope.quantumClaimClose = function(){
			angular.element(".overlay").css("display","none");
			angular.element("#quantum_claim_status").css("display","none");
		}

		function undefinedSetNull(val){
			if(val){
				return val;
			} else {
				var val = null;
				return val;
			}
			return val;
		}

		function undefinedSetFalse(val){
			if(val){
				return val;
			} else {
				var val = false;
				return val;
			}
			return val;
		}


		$scope.proceedToPayment = function(){
			$scope.submitMediationFormAcknolegement = false;
			$scope.ifPaymentProcess = true;
		}
		
		$(function() {
			$('#embeddingDatePicker').multiDatesPicker({
				todayHighlight: true,
				dateFormat: 'dd-mm-yy',
				maxPicks: 10,
				altField: "#selectedDate",
				minDate: 21,
				maxDate: 386
			});
		});
		
 	}
 })();