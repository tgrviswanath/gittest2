(function() {
    'use strict';
    angular
        .module('smc')
        .controller('mediationLapsedCaseCtrl',mediationLapsedCaseCtrl);

    mediationLapsedCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function mediationLapsedCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName')!="Mediation") {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'lapsed'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_lapsed_caselist($scope.pagenumber);//call to lapsed case list function
        $cookies.put('currentTab','lapsed');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//sent current tab status
        //call to incomplete case list function from outside
        $rootScope.mediationlapsedcaselist = function(){
            get_lapsed_caselist($cookies.get('pageNumber'));
        } 

    	// get incomplete case list
    	function get_lapsed_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
            var sorting = [[0,0], [1,0]];
    		var query = {
    			"pageIndex":$scope.pagenumber, 
                "dataLength":$scope.dataLength, 
                "sortingColumn":null, 
                "sortDirection":null, 
                "partyName":null, 
                "caseOfficer":null, 
                "assistantManager":null, 
                "tempCaseNumber":null, 
                 "lapsedDateFrom":null,
                "lapsedDateTo":null
    		}
            getAllLapsedCases(query);
    	}
        //get all lapsed case list 
        function getAllLapsedCases(query){
            DataService.post('GetMediationLapsedCaseList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.lapsed_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
        }

         $scope.goToPageNumber = function(pageNo){
           get_lapsed_caselist(pageNo);
        }

        // to receive filter case list
        $scope.$on('filterCases', function(event, filter) { 
            if($cookies.get('currentTab') == 'lapsed'){
               var query = {
                "partyName":undefinedSetNull(filter.partyName), 
                "caseOfficer":undefinedSetNull(filter.caseOfficer), 
                "assistantManager":undefinedSetNull(filter.assistantManager), 
                "tempCaseNumber":undefinedSetNull(filter.caseNumber), 
                "lapsedDateFrom":undefinedSetNull(filter.lapsedDateFrom), 
                "lapsedDateTo":undefinedSetNull(filter.lapsedDateTo), 
               }
               getAllLapsedCases(query);
            }
        });

         // to receive reset action 
        $scope.$on('resetCases', function(event, reset) { 
            if($cookies.get('currentTab') == 'lapsed'){
                get_lapsed_caselist(0);
            }
        });

        $scope.viewCancelData = function(caseNumber){
            $scope.cancelCaseNumber = caseNumber;
            var GetLapsedCancelDetailUrl = smcConfig.services.GetLapsedCancelDetail.url;
            GetLapsedCancelDetailUrl = GetLapsedCancelDetailUrl + $scope.cancelCaseNumber;
            $http.get(GetLapsedCancelDetailUrl).then(function(data){
               $scope.cancelDetail =  data.data.result;
            });
            angular.element(".overlay").css("display","block");
            angular.element(".view-cancel-lapsed-case").css("display","block");
        }

        $scope.cancelviewDetails = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".view-cancel-lapsed-case").css("display","none");
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        //to view form
        $scope.openViewApplication = function(caseType,caseNumber){
            $rootScope.viewCaseNumber = caseNumber;
            $rootScope.mediationFormType = caseType;
            $rootScope.workingTab = 'lapsed';
            $state.go('smclayout.cmsFormLayout.viewForm');
        }
    }
})();