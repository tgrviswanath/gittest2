(function () {
    'use strict';
    angular
        .module('smc')
        .controller('mediationIncompleteCaseCtrl', mediationIncompleteCaseCtrl);

    mediationIncompleteCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function mediationIncompleteCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName')!="Mediation") {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf", "jpg", "jpeg", "png"];
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'incomplete') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_incomplete_caselist($scope.pagenumber); //call to incomplete case list function
        $cookies.put('currentTab', 'incomplete');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status

        $scope.update_payeename_modal_path = 'views/member/update-payeename-modal.html';
        //call to incomplete case list function from outside
        $rootScope.mediationincompletecaselist = function () {
            get_incomplete_caselist($cookies.get('pageNumber'));
        }

        // get incomplete case list
        function get_incomplete_caselist(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "partyName": null,
                "caseOfficer": null,
                "assistantManager": null,
                "tempCaseNumber": null,
                "submissionDateFrom": null,
                "submissionDateTo": null,
                "mediationCaseStatus": [
                    "CMS Saved",
                    "CMS Submitted",
                    "SCCMS Saved",
                    "SCCMS Submitted",
                    "CPE Saved",
                    "CPE Submitted"
                ]
            }
            getAllIncompleteCases(query);
        }
        //get all incomplete case list 
        function getAllIncompleteCases(query) {
            DataService.post('GetMediationIncompleteCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.incomplete_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_incomplete_caselist(pageNo);
        }

        // to receive filter case list
        $scope.$on('filterCases', function (event, filter) {
            if ($cookies.get('currentTab') == 'incomplete') {
                var query = {
                    "partyName": undefinedSetNull(filter.partyName),
                    "caseOfficer": undefinedSetNull(filter.caseOfficer),
                    "assistantManager": undefinedSetNull(filter.assistantManager),
                    "tempCaseNumber": undefinedSetNull(filter.caseNumber),
                    "submissionDateFrom": undefinedSetNull(filter.dateFrom),
                    "submissionDateTo": undefinedSetNull(filter.dateTo),
                    "mediationCaseStatus": [
                        "CMS Saved",
                        "CMS Submitted",
                        "SCCMS Saved",
                        "SCCMS Submitted",
                        "CPE Saved",
                        "CPE Submitted"
                    ]
                }
                getAllIncompleteCases(query);
            }
        });

        // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'incomplete') {
                get_incomplete_caselist(0);
            }
        });

        //assign case to case officer
        $scope.assignCase = function (caseNumber) {
            $scope.assignCaseNumber = caseNumber;
            $scope.casedetail = {};
            getManagerList();
            getOfficerList();
            angular.element(".overlay").css("display", "block");
            angular.element(".case-submitt-confirm").css("display", "block");
        }

        $scope.cancelassignCase = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case-submitt-confirm").css("display", "none");
        }

        function getManagerList() {
            var query = {
                "moduleName": "Mediation",
                "roleName": 'Assistant Manager'
            }
            DataService.post('GetMemberList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.managers = data.results;
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        //to get SMC Officer list
        function getOfficerList() {
            var query = {
                "moduleName": "Mediation",
                "roleName": 'Case Officer'
            }
            DataService.post('GetMemberList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.officers = data.results;
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //to assign case to case officer 
        $scope.assignCasetoOfficer = function (case_details, caseNumber) {
            var query = {
                "caseNumber": caseNumber,
                "caseOfficerId": parseInt(case_details.caseOfficerId),
                "assistantManagerId": parseInt(case_details.assistantManagerId)
            }
            console.log("query", query)
            DataService.post('AssignMediationCaseToOfficer', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Case assigned successfully");
                    get_incomplete_caselist($cookies.get('pageNumber'))
                    angular.element(".overlay").css("display", "none");
                    angular.element(".case-submitt-confirm").css("display", "none");

                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //to open update payee name modal
        $scope.updatePayeeModal = function (caseNumber) {
            $rootScope.payeeCaseNumber = caseNumber;
            $rootScope.payeedetails = {};
            $rootScope.supprtDocumentName = null;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-payee-name").css("display", "block");
            $rootScope.getPayeeName(); //call function
        }

        //to close update payee name modal
        $scope.closepayeepop = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-payee-name").css("display", "none");
        }

        //to view form
        $scope.openViewApplication = function (status, caseNumber) {
            $rootScope.viewCaseNumber = caseNumber;
            $rootScope.mediationFormType = status.split(' ')[0];
            $rootScope.workingTab = 'incomplete';
            $state.go('smclayout.cmsFormLayout.viewForm');
        }

        //to view form
        $scope.openUpdateParties = function (status, caseNumber) {
            $rootScope.viewCaseNumber = caseNumber;
            $rootScope.mediationFormType = status.split(' ')[0];
            $state.go('smclayout.cmsFormLayout.updateForm');
        }

        $scope.updateMediationType = function (caseNumber, status) {
            $scope.typeCaseNumber = caseNumber;
            $scope.oldMediationTypes = status.split(' ')[0];
            angular.element(".overlay").css("display", "block");
            angular.element(".change-type-mediation").css("display", "block");
        }
        $scope.cancelChangeTypes = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".change-type-mediation").css("display", "none");
        }

        $scope.changeMediationType = function (types, typeCaseNumber) {
            var query = {
                "caseNumber": typeCaseNumber,
                "mediationType": types.newType,
                "smcOfficerId": $cookies.get('memberId')
            }
            DataService.post('ChangeMediationType', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Type changed successfully");
                    get_incomplete_caselist($cookies.get('pageNumber'))
                    angular.element(".overlay").css("display", "none");
                    angular.element(".change-type-mediation").css("display", "none");

                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.updateQuantumDispute = function (caseNumber, status) {
            $scope.quantumCaseNumber = caseNumber;
            $scope.mediationTypes = status.split(' ')[0];
            $scope.updateQuantum = {};
            if ($scope.mediationTypes == 'CMS') {
                var ViewCMSFormUrl = smcConfig.services.ViewCMSForm.url;
                ViewCMSFormUrl = ViewCMSFormUrl + $scope.quantumCaseNumber;
                $http.get(ViewCMSFormUrl).then(function (data) {
                    $scope.updateQuantum.oldQuantumOfClaim = data.data.result.caseInfo.quantumClaim;
                    $scope.updateQuantum.oldQuantumOfCounterclaim = data.data.result.caseInfo.quantumCounterClaim;
                    $scope.updateQuantum.oldOtherClaim = data.data.result.caseInfo.otherClaim;
                });
            } else if ($scope.mediationTypes == 'SCCMS') {
                var ViewSCCMSFormUrl = smcConfig.services.ViewSCCMSForm.url;
                ViewSCCMSFormUrl = ViewSCCMSFormUrl + $scope.quantumCaseNumber;
                $http.get(ViewSCCMSFormUrl).then(function (data) {
                    $scope.updateQuantum.oldQuantumOfClaim = data.data.result.caseInfo.quantumClaim;
                    $scope.updateQuantum.oldQuantumOfCounterclaim = data.data.result.caseInfo.quantumCounterClaim;
                    $scope.updateQuantum.oldOtherClaim = data.data.result.caseInfo.otherClaim;
                });
            } else {
                var ViewCPEFormUrl = smcConfig.services.ViewCPEForm.url;
                ViewCPEFormUrl = ViewCPEFormUrl + $scope.quantumCaseNumber;
                $http.get(ViewCPEFormUrl).then(function (data) {
                    $scope.updateQuantum.oldQuantumOfClaim = data.data.result.caseInfo.quantumClaim;
                    $scope.updateQuantum.oldQuantumOfCounterclaim = data.data.result.caseInfo.quantumCounterClaim;
                    $scope.updateQuantum.oldOtherClaim = data.data.result.caseInfo.otherClaim;
                });
            }
            angular.element(".overlay").css("display", "block");
            angular.element(".update-dispute-quantum").css("display", "block");
        }

        $scope.cancelupdatequantum = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-dispute-quantum").css("display", "none");
        }


        $scope.submitUpdateQuantum = function (updates, caseNumber) {
            var query = {
                "caseNumber": caseNumber,
                "oldQuantumOfClaim": updates.oldQuantumOfClaim,
                "newQuantumOfClaim": undefinedSetNull(updates.newQuantumOfClaim),
                "oldQuantumOfCounterclaim": updates.oldQuantumOfCounterclaim,
                "newQuantumOfCounterclaim": undefinedSetNull(updates.newQuantumOfCounterclaim),
                "oldOtherClaim": updates.oldOtherClaim,
                "newOtherClaim": undefinedSetNull(updates.newOtherClaim),
                "remarks": undefinedSetNull(updates.remarks),
                "smcOfficerId": $cookies.get('memberId')

            }
            DataService.post('UpdateQuantumDispute', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Quantum dispute updated successfully");
                    get_incomplete_caselist($cookies.get('pageNumber'))
                    angular.element(".overlay").css("display", "none");
                    angular.element(".update-dispute-quantum").css("display", "none");

                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        function getCancelReasons() {
            DataService.get('GetCancelCaseReasons').then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.cancelReasons = data.results;
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.openCancelCase = function (caseNumber) {
            $scope.cancelCaseNumber = caseNumber;
            getCancelReasons();
            angular.element(".overlay").css("display", "block");
            angular.element(".case-cancel-confirm").css("display", "block");
        }

        $scope.cancelMediationCase = function (cancelData, caseNumber) {
            var dateObj = new Date();
            var month = dateObj.getUTCMonth() + 1; //months from 1-12
            var day = dateObj.getUTCDate();
            var year = dateObj.getUTCFullYear();
            var requestedDate = day + "-" + month + "-" + year;

            var query = {
                "caseNumber": caseNumber,
                "requestedDate": requestedDate,
                "smcOfficerId": parseInt($cookies.get('memberId'))
            }
            if (cancelData.reason != 'Others') {
                query.reason = cancelData.reason;
            } else {
                query.reason = cancelData.others;
            }
            DataService.post('CancelMediationCase', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', "Cancel case submitted successfully");
                    get_incomplete_caselist($cookies.get('pageNumber'))
                    angular.element(".overlay").css("display", "none");
                    angular.element(".case-cancel-confirm").css("display", "none");

                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.cancelCancelCase = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case-cancel-confirm").css("display", "none");
        }

        $scope.openUpdateLawfirm = function (caseNumber) {
            $scope.lawFirmCasenumber = caseNumber;
        }
     
        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();
