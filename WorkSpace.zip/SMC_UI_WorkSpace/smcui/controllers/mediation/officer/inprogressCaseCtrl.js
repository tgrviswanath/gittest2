(function () {
    'use strict';
    angular
        .module('smc')
        .controller('mediationInprogressCaseCtrl', mediationInprogressCaseCtrl);

    mediationInprogressCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function mediationInprogressCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
         if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName')!="Mediation") {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf", "jpg", "jpeg", "png"];
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'inprogress') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_inprogress_caselist($scope.pagenumber); //call to incomplete case list function
        $cookies.put('currentTab', 'inprogress');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status

        $scope.update_payeename_modal_path = 'views/member/update-payeename-modal.html';
        //call to incomplete case list function from outside
        $rootScope.mediationincompletecaselist = function () {
            get_inprogress_caselist($cookies.get('pageNumber'));
        }

        // get incomplete case list
        function get_inprogress_caselist(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "caseType": null,
                "partyName": null,
                "caseOfficer": null,
                "assistantManager": null,
                "tempCaseNumber": null,
                "mediationDate": null,
                "submissionDateFrom": null,
                "submissionDateTo": null,
                "lodgeDateFrom": null,
                "lodgeDateTo": null,
                "mediationCaseStatus": ["CMS Submitted", "CMS Payment Pending", "Different dates", "CMS Payment Completed", "Lodged"]
            }
            getAllInprogressCases(query);
        }
        //get all incomplete case list 
        function getAllInprogressCases(query) {
            DataService.post('GetMediationInprogressCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.incomplete_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_inprogress_caselist(pageNo);
        }

        // to receive filter case list
        $scope.$on('filterCases', function (event, filter) {
            if ($cookies.get('currentTab') == 'inprogress') {
                var query = {
                    "partyName": undefinedSetNull(filter.partyName),
                    "caseOfficer": undefinedSetNull(filter.caseOfficer),
                    "assistantManager": undefinedSetNull(filter.assistantManager),
                    "tempCaseNumber": undefinedSetNull(filter.caseNumber),
                    "submissionDateFrom": undefinedSetNull(filter.dateFrom),
                    "submissionDateTo": undefinedSetNull(filter.dateTo),
                    "lodgeDate": undefinedSetNull(filter.ladgedDate),
                    "mediationCaseStatus": [
                        "CMS Saved",
                        "CMS Submitted",
                        "SCCMS Saved",
                        "SCCMS Submitted",
                        "CPE Saved",
                        "CPE Submitted"
                    ]
                }
                getAllInprogressCases(query);
            }
        });

        // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'inprogress') {
                get_inprogress_caselist(0);
            }
        });

        //to view form
        $scope.openViewApplication = function (caseType, caseNumber) {
            $rootScope.viewCaseNumber = caseNumber;
            $rootScope.mediationFormType = caseType;
            $rootScope.workingTab = 'inprogress';
            $state.go('smclayout.cmsFormLayout.viewForm');
        }

        //to open update mediation date model 
        $scope.openUpdateMediateDate = function (caseNumber) {
            $scope.UpdateDateData = {};
            $scope.partiesDates = [];
            $scope.MediateCaseNumber = caseNumber;
            getmediationPartiesDates(caseNumber);
            getUpdatedMediationDate(caseNumber);
            angular.element(".overlay").css("display", "block");
            angular.element(".update-mediation-date-officer").css("display", "block");
        }

        //to close update mediation date model 
        $scope.closeUpdateMediateDate = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-mediation-date-officer").css("display", "none");
        }

        //to get find all parties prefered mediation dates
        function getmediationPartiesDates(caseNumber) {

            var GetPartiesMediatorAndDatesUrl = smcConfig.services.GetPartiesMediatorAndDates.url;
            GetPartiesMediatorAndDatesUrl = GetPartiesMediatorAndDatesUrl + caseNumber;
            $http.get(GetPartiesMediatorAndDatesUrl).then(function (data) {
                $scope.partiesDates = data.data.result.memberDates;
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //if mediation Date was already updated,get updated date
        function getUpdatedMediationDate(caseNumber) {
            var query = {
                "smcOfficerId": $cookies.get('memberId'),
                "caseNumber": caseNumber
            }
            DataService.post('GetUpdatedMediationDate', query).then(function (data) {
                $scope.UpdateDateData.mediationDate = data.result.mediationDate;
            });
        }

        //update mediation date
        $scope.submitUpdateMediationDate = function (updateData, caseNumber) {
            var query = {
                "smcOfficerId": undefinedSetNull($cookies.get('memberId')),
                "caseNumber": undefinedSetNull(caseNumber),
                "remarks": undefinedSetNull(updateData.remarks),
                "mediationDate": undefinedSetNull(updateData.mediationDate)
            }
            DataService.post('UpdateMediationDateByOfficer', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', 'Mediation date updated successfully');
                    get_inprogress_caselist($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display", "none");
                    angular.element(".update-mediation-date-officer").css("display", "none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        $scope.openVenuemanagement = function (caseNumber) {
            console.log(caseNumber);
            $cookies.put('caseNumber', caseNumber);
            $state.go('smclayout.mediationlayout.venuemanagementforacase');
        }
 
        function undefinedSetNull(val) {
            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();
