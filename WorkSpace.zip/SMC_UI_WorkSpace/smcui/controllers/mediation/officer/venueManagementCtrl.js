(function () {
    'use strict';
    angular
        .module('smc')
        .controller('venueManagementCtrl', venueManagementCtrl);

    venueManagementCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function venueManagementCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName')!="Mediation") {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        
        $scope.venue = {};
        $scope.venueRoombyStatus = true;
        $scope.venuRentalFullday = true;
        $scope.venueChargesFor6To10 = true;
        $scope.venueChargesFor10To12 = true;
        $scope.venueRoomRentalOvertimeCharge = true;
        getVenueManagementDetails();


        function getVenueManagementDetails() {
            var query = {
                "pageIndex": 0,
                "dataLength": 20,
                "sortingColumn": null,
                "sortDirection": null,
                "smcOfficerId": $cookies.get('memberId')
            }

            DataService.post('GetMediationVenueManagementDetails', query).then(function (data) {
                console.log(data);
                $scope.venueManagementDetails = data.result.responseData;
            });
        }

        /*get all the Mediation Venue name */
        var venuenameList = smcConfig.services.GetMediationVenueName.url;
        $http.get(venuenameList).then(function (response) {
                if (response.data.status == 'SUCCESS') {
                    $scope.venueNamelist = response.data.results;
                } else {
                    NotifyFactory.log('error', "error");
                }

            })
            /*get mediation rooms */
        $scope.getmediationRooms = function (venue) {

            if (venue.name == "Supreme Court") {
                $scope.venuRentalFullday = false;
                $scope.venueChargesFor6To10 = true;
                $scope.venueChargesFor10To12 = true;
                $scope.venueRoomRentalOvertimeCharge = false;
            } else {
                $scope.venuRentalFullday = true;
                $scope.venueChargesFor6To10 = false;
                $scope.venueChargesFor10To12 = false;
                $scope.venueRoomRentalOvertimeCharge = true;
            }
            if (venue.name != "Others") {
                $scope.venueRoombyStatus = true;
                console.log("This is venue id" + venue.id);
                console.log("case number" + $cookies.get('caseNumber'));
                var venueRoomById = smcConfig.services.GetMediationvenueroomByvenueid.url;
                var venueRoomUrl = venueRoomById + venue.id + '/rooms';
                $http.get(venueRoomUrl).then(function (Data) {
                    if (Data.data.status == 'SUCCESS') {
                        $scope.venueRoombyId = Data.data.result.venueRooms;


                    } else {
                        NotifyFactory.log('error', "error");
                    }
                })
            } else {
                $scope.venueRoombyStatus = false;
                $scope.venue.room = "Not Applicable"
            }
        }


        /*save mediation venue management details */

        $scope.addVenuemanagement = function (venue) {
            if (venue.name.name == 'Supreme Court') {
                var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "venueId": venue.name.id,
                    "fbCharges": venue.fbCharges,
                    "roomId": venue.room.roomId,
                    "chargesFor6To10": venue.chargesFor6To10,
                    "chargesFor10To12": venue.chargesFor10To12,
                    "otherCharges": venue.otherCharges
                }
            } else if (venue.name.name == 'Others') {
                var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "venueId": venue.name.id,
                    "otherVenueName": venue.otherName,
                    "fbCharges": venue.fbCharges,
                    "otherRoomType": venue.room,
                    "venueRentalFullDay": venue.RentalFullDay,
                    "roomRentalOvertimeCharge": venue.roomRentalOvertimeCharge,
                    "otherCharges": venue.otherCharges
                }
            } else {
                var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "venueId": venue.name.id,
                    "roomId": venue.room.roomId,
                    "fbCharges": venue.fbCharges,
                    "venueRentalFullDay": venue.RentalFullDay,
                    "roomRentalOvertimeCharge": venue.roomRentalOvertimeCharge,
                    "otherCharges": venue.otherCharges
                }
            }
            console.log(query);
            DataService.post('SaveMediationVenueManagementDetails', query).then(function (data) {
                console.log(data);
                if (data.status == "SUCCESS") {
                    $scope.venue = {};
                    $scope.venueRoombyStatus = true;
                    $scope.venuRentalFullday = true;
                    $scope.venueChargesFor6To10 = true;
                    $scope.venueChargesFor10To12 = true;
                    $scope.venueRoomRentalOvertimeCharge = true;
                    getVenueManagementDetails();
                    NotifyFactory.log('success', "Venue Management Detail added successfully.");
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }

            }).catch(function (error) {
                if (error.status == 'FAILURE')

                    NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.updateVenueManagementDetailPopUp = function (venue) {
            $scope.venueDetail = angular.copy(venue);
            if (venue.venueName == 'Supreme Court') {
                $scope.venuRentalFullday = false;
                $scope.venueChargesFor6To10 = true;
                $scope.venueChargesFor10To12 = true;
                $scope.venueRoomRentalOvertimeCharge = false;
            } else {
                $scope.venuRentalFullday = true;
                $scope.venueChargesFor6To10 = false;
                $scope.venueChargesFor10To12 = false;
                $scope.venueRoomRentalOvertimeCharge = true;
            }
            if (venue.venueName != 'Others') {
                $scope.venueRoombyStatus = true;
            } else {
                $scope.venueRoombyStatus = false;
                $scope.venueDetail.room = "Not Applicable"
            }
            angular.element("#venueManagementUpdate").modal("show");
        }

        $scope.updateVenueManagementDetail = function (venueDetail) {
            console.log(venueDetail);
            if (venueDetail.venueName == 'Supreme Court') {
                var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "venueId": venueDetail.venueId,
                    "fbCharges": venueDetail.fbCharges,
                    "roomId": venueDetail.venueRoomId,
                    "chargesFor6To10": venueDetail.chargesFor6To10,
                    "chargesFor10To12": venueDetail.chargesFor10To12,
                    "otherCharges": venueDetail.otherCharges
                }
            } else if (venueDetail.venueName == 'Others') {
                var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "venueId": venueDetail.venueId,
                    "otherVenueName": venueDetail.otherName,
                    "fbCharges": venueDetail.fbCharges,
                    "otherRoomType": venueDetail.room,
                    "venueRentalFullDay": venueDetail.RentalFullDay,
                    "roomRentalOvertimeCharge": venueDetail.roomRentalOvertimeCharge,
                    "otherCharges": venueDetail.otherCharges
                }
            } else {
                var query = {
                    "smcOfficerId": $cookies.get('memberId'),
                    "venueId": venueDetail.venueId,
                    "roomId": venueDetail.venueRoomId,
                    "fbCharges": venueDetail.fbCharges,
                    "venueRentalFullDay": venueDetail.RentalFullDay,
                    "roomRentalOvertimeCharge": venueDetail.roomRentalOvertimeCharge,
                    "otherCharges": venueDetail.otherCharges
                }
            }
            console.log(query);
            DataService.post('UpdateMediationVenueManagementDetails', query).then(function (data) {
                console.log(data);
                if (data.status == "SUCCESS") {
                    angular.element("#venueManagementUpdate").modal("hide");
                    $scope.venue = {};
                    $scope.venueRoombyStatus = true;
                    $scope.venuRentalFullday = true;
                    $scope.venueChargesFor6To10 = true;
                    $scope.venueChargesFor10To12 = true;
                    $scope.venueRoomRentalOvertimeCharge = true;
                    getVenueManagementDetails();
                    NotifyFactory.log('success', "Venue Management Detail updated successfully.");
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }

            });
        }

    }
})();
