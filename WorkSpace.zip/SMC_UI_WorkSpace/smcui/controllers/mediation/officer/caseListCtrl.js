(function() {
    'use strict';
    angular
        .module('smc')
        .controller('mediationCaseListCtrl',mediationCaseListCtrl);

    mediationCaseListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function mediationCaseListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){

      $scope.userRole = $cookies.get('roleName');
      $scope.filter = {};
      // to receive filter case list
        $scope.$on('activeTab', function(event, tabStatus) { 
            $scope.currentTab = tabStatus;
        });

      // this function filter case list by query value
      $scope.getFilterCeses = function(filter){
        $scope.$broadcast('filterCases',filter);
      }
     

      // to get all values
      $scope.resetcases = function(){
       $scope.$broadcast('resetCases','reset');
      }

      
  	}
})();