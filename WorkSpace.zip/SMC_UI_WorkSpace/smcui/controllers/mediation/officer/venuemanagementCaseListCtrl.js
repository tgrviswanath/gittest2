(function () {
    'use strict';
    angular
        .module('smc')
        .controller('venuemanagementCaseListCtrl', venuemanagementCaseListCtrl);

    venuemanagementCaseListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService',
        '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'
    ];

    function venuemanagementCaseListCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig,
        httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName')!="Mediation") {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.vanue = {};
        $scope.venueRoombyStatus = true;
        $scope.disableMediationdate = true;
        var venuename;
        var roomtype;
        var arrVenues = [];


        /*Get Venue management details for case */
        var venumangementforcase = smcConfig.services.GetVenueManagementDetailsforCase.url;
        var casenumber = $cookies.get('caseNumber');
        var viewVenueUrl = venumangementforcase + casenumber + '/venue/management/view'
        $http.get(viewVenueUrl).then(function (venueData) {
            if (venueData.data.status == 'SUCCESS') {
                // $scope.venueDetails = venueData.data.results;
                $scope.venueDetails = venueData.data.result;
                console.log("Venue details" + $scope.venueDetails);
                $scope.venue = $scope.venueDetails;
                $scope.durationName = $scope.venueDetails.durationName;
                venuename = $scope.venueDetails.venueName;
                $scope.getmediationRooms(venuename);
                $scope.roomtype = $scope.venueDetails.venueRoomName;
                console.log("inside the loop roomtype name" + $scope.roomtype);
                venueNamefunction();
                venueRoomtypefunction();
            } else {
                NotifyFactory.log('error', "error");
            }
        });


        /*Get the Mediation Venue Durations */
        var menuduraion = smcConfig.services.GetMediationVenueDuration.url;
        $http.get(menuduraion).then(function (responseData) {
            if (responseData.data.status == 'SUCCESS') {
                $scope.venueDates = responseData.data.results;
                console.log("Selected Venue Name" + venuename);

            } else {
                NotifyFactory.log('error', "error");
            }
        })
        venueNamefunction();

        function venueNamefunction() {
            /*get all the Mediation Venue name */
            var lengthOfVenuenames;
            var venuenameList = smcConfig.services.GetMediationVenueName.url;
            $http.get(venuenameList).then(function (response) {
                if (response.data.status == 'SUCCESS') {
                    $scope.venueNamelists = response.data.results;
                    $scope.venueName = venuename;
                    console.log("venue name in lists" + $scope.venueNamelists[0].name);
                    lengthOfVenuenames = $scope.venueNamelists.length;
                    console.log("length of venue array" + lengthOfVenuenames);
                    for (var i = 0; i < lengthOfVenuenames; i++) {

                        if ($scope.venueNamelists[i].name == $scope.venueName) {
                            console.log("This is venue id when dey are equal" + $scope.venueNamelists[i].id);

                            $scope.data = {
                                selectedOption: $scope.venueNamelists[i].name
                            };
                        }
                    }
                    console.log("outside the loop venue name" + $scope.venueName);
                } else {
                    NotifyFactory.log('error', "error");
                }

            })
        }

        venueRoomtypefunction();

        function venueRoomtypefunction() {

            /*get mediation rooms */
            $scope.getmediationRooms = function (venue) {
                console.log("this is the venue name" + venue);

                console.log("testinf kshg" + venue);
                console.log("am checking the scope value" + JSON.stringify($scope.venueNamelists));

                for (var i = 0; i < $scope.venueNamelists.length; i++) {
                    console.log("name" + $scope.venueNamelists[0].name);
                    if ($scope.venueNamelists[i].name == venue) {
                        if (venue != "Others") {
                            $scope.venueRoombyStatus = true;

                            $scope.venueId = $scope.venueNamelists[i].id;
                            console.log("case number" + $cookies.get('caseNumber'));
                            var venueRoomById = smcConfig.services.GetMediationvenueroomByvenueid.url;
                            var venueRoomUrl = venueRoomById + $scope.venueNamelists[i].id + '/rooms';
                            $http.get(venueRoomUrl).then(function (Data) {
                                if (Data.data.status == 'SUCCESS') {
                                    $scope.venueRoombyId = Data.data.result.venueRooms;
                                    console.log("room type" + $scope.venueRoombyId[0].roomType);
                                    $scope.newdata = {
                                        selectedOption: $scope.venueRoombyId[0].roomType
                                    };

                                    console.log("This is new data" + JSON.stringify($scope.newdata));
                                } else {
                                    NotifyFactory.log('error', "error");
                                }
                            })
                        } else {
                            $scope.venueRoombyStatus = false;
                            $scope.venue.room = "Not Applicable"
                        }
                    }
                }

            }
        }

        /*SMC Officer to Update Mediation Date for the Mediaiton Case. */
        $scope.updateVenuemanagement = function () {

            console.log("Checking total Rooms" + $scope.venueRoombyId);

            for (var i = 0; i < $scope.venueRoombyId.length; i++) {
                if ($scope.venueRoombyId[i].roomType == $scope.newdata.selectedOption) {
                    console.log("This is room id" + $scope.venueRoombyId[i].roomId);
                    $scope.roomId = $scope.venueRoombyId[i].roomId;
                }

            }
            console.log("This is venue id" + $scope.venueId);
            console.log("sopn name" + $cookies.get('caseNumber'));
            var query = {
                "caseNumber": $cookies.get('caseNumber'),
                "smcOfficerId": $cookies.get('memberId'),
                "venueId": $scope.venueId,
                "roomId": $scope.roomId,
                "duration": $scope.durationName
            }
            updateVenuedetailsfrCase(query);

            function updateVenuedetailsfrCase(query) {
                DataService.post('UpdateVenueDetailsForParticularCase', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "Venue Details For Case Is Updated Successfully");
                    }

                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
        }

        /*to view deadline date of the parties */
        var deadline = smcConfig.services.ToViewDeadlineDateoftheParties.url;
        var deadlineUrl = deadline + $cookies.get('caseNumber');
        $http.get(deadlineUrl).then(function (deadLinedata) {
            if (deadLinedata.data.status == 'SUCCESS') {
                $scope.venueNamelist = deadLinedata.data.result;
                console.log("vies deadline date of parties" + $scope.venueNamelist);
            } else {
                NotifyFactory.log('error', "error");
            }

        })

        /*update deadline date */
        $scope.updateDeadlinedate = function () {
            console.log("dates" + $scope.venueNamelist.caseStatementDate);

            // var momentDate = moment($scope.venueNamelist.lastDateForCancellationDate);
            // console.log("final test date" + momentDate.format('L LT'))
            // var finalDate = momentDate.format('L LT');
            // var myDate = finalDate.split('/');
            // var newDate = myDate[1] + "-" + myDate[0] + "-" + myDate[2];
            // console.log("new final date" + newDate);
            var lastDateForCancellationDate;
            lastDateForCancellationDate = $scope.venueNamelist.lastDateForCancellationDate + " " + "06:00 PM"

            var deadLineQuery = {
                "loginId": $cookies.get('roleId'),
                "caseNumber": $cookies.get('caseNumber'),
                "caseStatementDate": $scope.venueNamelist.caseStatementDate,
                "listOfAttendeesDate": $scope.venueNamelist.listOfAttendeesDate,
                "mediationAgreementDate": $scope.venueNamelist.mediationAgreementDate,
                "lastDateForCancellationDate": lastDateForCancellationDate
            }

            updateMediationdateForCase(deadLineQuery)



            function updateMediationdateForCase(deadLineQuery) {
                DataService.post('UpdateDeadLIneDateForCase', deadLineQuery).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "updated Deadline Date for Parties.");
                    } else if (data.status == 'FAILURE') {
                        console.log("errr messgane" + data.errorMessage);
                        NotifyFactory.log('error', "data.errorMessage");
                    }
                }).catch(function (error) {
                    if (error.status == 'FAILURE')

                        NotifyFactory.log('error', error.errorMessage);
                });
            }
        }

        /*SMC Officer to update Mediation Date for Case. */
        $scope.enableMediationUpdate = function () {
            $scope.disableMediationdate = false;
        }
        $scope.cancelMediationDateUpdation = function () {
            $scope.disableMediationdate = true;
        }
        $scope.upDatemediationDate = function () {
            console.log("mediation date" + $scope.mediationDate);
            var queryFrMediationDate = {
                "smcOfficerId": $cookies.get('memberId'),
                "caseNumber": $cookies.get('caseNumber'),
                "mediationDate": $scope.mediationDate
            }
            updateDateOfMediation(queryFrMediationDate);

            function updateDateOfMediation(queryFrMediationDate) {
                DataService.post('UpdateMediationDateForCaseBySmcOfficer', queryFrMediationDate).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        NotifyFactory.log('success', "Mediation Date Is Updated Successfully");
                    }

                }).catch(function (error) {
                    NotifyFactory.log('error', "error");
                });
            }
        }

        console.log('cookies stored member id' + $cookies.get('memberId'));
        /*To view mediation date */
        var meditaiondateData = {
            "smcOfficerId": $cookies.get('memberId'),
            "caseNumber": $cookies.get('caseNumber')
        }
        viewMediationDate(meditaiondateData);

        function viewMediationDate(meditaiondateData) {
            DataService.post('GetUpdatedMediationDate', meditaiondateData).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.mediationDate = data.result.mediationDate;
                    console.log("mediation date" + $scope.mediationDate);
                } else if (data.status == 'FAILURE') {
                    console.log("errr messgane" + data.errorMessage);
                }
            }).catch(function (error) {
                if (error.status == 'FAILURE')

                    NotifyFactory.log('error', error.errorMessage);
            });

        }



     

    }
})();
