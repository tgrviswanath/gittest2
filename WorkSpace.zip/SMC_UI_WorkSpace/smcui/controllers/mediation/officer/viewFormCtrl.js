(function() {
    'use strict';
    angular
        .module('smc')
        .controller('viewCmsFormCtrl',viewCmsFormCtrl);

    viewCmsFormCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function viewCmsFormCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' ) {
            $state.go('smclayout.membershiplayout.memberlogin');
        }else if(!$rootScope.mediationFormType && !$scope.viewCaseNumber){
            $state.go('smclayout.mediationlayout.caselist.inprogress');
        }
        $scope.mediationFormType = $rootScope.mediationFormType;
        $scope.viewCaseNumber = $scope.viewCaseNumber;
        $scope.applicantList = [];
        $scope.respondentList = [];
        $scope.downloadCMSUrl = smcConfig.services.DownloadCMSForm.url;
        $scope.isPreviewClicked = true;
        $scope.mediationDates = '';
        $scope.pattern = patternConfig;
        $scope.applicantInfoLength = 0;
        $scope.respondentInfoLength = 0;
        viewCaseDetails();
        function viewCaseDetails(){
            if($scope.mediationFormType == 'CMS'){
                var ViewCMSFormUrl = smcConfig.services.ViewCMSForm.url;
                ViewCMSFormUrl = ViewCMSFormUrl + $scope.viewCaseNumber;
                getViewData(ViewCMSFormUrl)
            }else if($scope.mediationFormType == 'SCCMS'){
                var ViewSCCMSFormUrl = smcConfig.services.ViewSCCMSForm.url;
                ViewSCCMSFormUrl = ViewSCCMSFormUrl + $scope.viewCaseNumber;
                getViewData(ViewSCCMSFormUrl)
            }else{
                var ViewCPEFormUrl = smcConfig.services.ViewCPEForm.url;
                ViewCPEFormUrl = ViewCPEFormUrl + $scope.viewCaseNumber;
                getViewData(ViewCPEFormUrl)
            }
        }

        $scope.suitList = [];

        function getViewData(serviceUrl){
            $http.get(serviceUrl).then(function(data){
                console.log("data",data);
                $scope.cms_form = data.data.result;
                if($scope.cms_form.isAllPartiesAgree){
                    $scope.cms_form.isAllPartiesAgree = 'Yes'
                }else{
                    $scope.cms_form.isAllPartiesAgree = 'No'
                }
                if($scope.cms_form.caseInfo.isLegalProceed){
                    $scope.cms_form.caseInfo.isLegalProceed = 'Yes'
                }else{
                    $scope.cms_form.caseInfo.isLegalProceed = 'No'
                }
                for(var applicant in $scope.cms_form.applicantInfo.applicants){
                    $scope.applicantList.push({id: 'Applicant '+applicant})
                    if($scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided){
                        $scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = 'Yes'
                    }else{
                        $scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = 'No'
                    }
                    if($scope.cms_form.applicantInfo.applicants[applicant].isLegallyRepresented){
                        $scope.cms_form.applicantInfo.applicants[applicant].isLegallyRepresented = 'Yes'
                    }else{
                        $scope.cms_form.applicantInfo.applicants[applicant].isLegallyRepresented = 'No'
                    }
                    if($scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber){
                        if($scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber[0] == '+'){
                            $scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber = $scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber.substring(3);
                        }
                    }
                    if($scope.cms_form.applicantInfo.applicants[applicant].lawFirm){
                        if($scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber){
                            if($scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber[0] == '+'){
                                $scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber = $scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber.substring(3);
                            }
                        }
                    }
                }
                $scope.respondentLawyerList = {};
                for(var respondent in $scope.cms_form.respondentInfo){
                    $scope.respondentList.push({id: 'Respondent '+respondent})
                    if($scope.cms_form.respondentInfo[respondent].isLegallyAided){
                        $scope.cms_form.respondentInfo[respondent].isLegallyAided = 'Yes'
                    }else{
                        $scope.cms_form.respondentInfo[respondent].isLegallyAided = 'No'
                    }
                    if($scope.cms_form.respondentInfo[respondent].isLegallyRepresented == 'true'){
                        $scope.cms_form.respondentInfo[respondent].isLegallyRepresented = 'Yes';
                    }else if($scope.cms_form.respondentInfo[respondent].isLegallyRepresented == 'false'){
                        $scope.cms_form.respondentInfo[respondent].isLegallyRepresented = 'No';
                    }else{
                        $scope.cms_form.respondentInfo[respondent].isLegallyRepresented = 'Unknown';
                    }
                    $scope.respondentLawyerList[respondent] = [];
                    if($scope.cms_form.respondentInfo[respondent].lawFirm){
                        for (var lawyer in $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails){
                            $scope.respondentLawyerList[respondent].push({'id':'Lawyer '+lawyer});
                        }
                        if($scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber){
                            if($scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber[0] == '+'){
                                $scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber = $scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber.substring(3);
                            }
                        }
                    }else{
                        $scope.respondentLawyerList[respondent].push({'id':'Lawyer '+1});
                    }
                    if($scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber){
                        if($scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber[0] == '+'){
                            $scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber = $scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber.substring(3);
                        }
                    }
                }
                $scope.applicantLawyerList = [];
                if($scope.cms_form.applicantInfo.lawFirm){
                    for (var lawyer in $scope.cms_form.applicantInfo.lawFirm.lawyerDetails){
                        $scope.applicantLawyerList.push({'id':'Lawyer '+lawyer});
                    }
                }else{
                    $scope.applicantLawyerList.push({'id':'Lawyer '+1});
                }

                if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                    $scope.cms_form.mediator = [];
                    for(var mediator in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                        $scope.cms_form.mediator[mediator] = {};
                        $scope.cms_form.mediator[mediator].industry = [];
                        $scope.cms_form.mediator[mediator].specialisation = [];
                        $scope.cms_form.mediator[mediator].language = [];
                        for(var industry in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes){
                            var check = {'name' : $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry]}
                           $scope.cms_form.mediator[mediator].industry.push(check)  
                        }
                        for(var specialisation in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes){
                            var check = {'specialisationName' : $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation]}
                           $scope.cms_form.mediator[mediator].specialisation.push(check)  
                        }
                        for(var language in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages){
                            var check = {'languageName' : $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language]}
                           $scope.cms_form.mediator[mediator].language.push(check)  
                        }
                        $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes = $scope.cms_form.mediator[mediator].industry;
                        $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes = $scope.cms_form.mediator[mediator].specialisation;
                        $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages = $scope.cms_form.mediator[mediator].language;
                    }
                }
                if($scope.cms_form.suitInfo){
                    for(var suit in $scope.cms_form.suitInfo){
                        $scope.suitList.push({'id':'Suit '+suit});
                    }
                }
                $scope.applicantInfoLength = $scope.cms_form.applicantInfo.applicants.length;
                $scope.respondentInfoLength = $scope.cms_form.respondentInfo.length;
            });
        }

        $scope.legalProceedingSuitList = function(){
            var newItemNo = $scope.suitList.length+1;
            $scope.suitList.push({'id':'Suit '+newItemNo});
        }

        $scope.getSuitList = function(){
            if($scope.cms_form.caseInfo.isLegalProceed == 'Yes'){
                var newItemNo = $scope.suitList.length+1;
                $scope.suitList.push({'id':'Suit '+newItemNo});
            }else{
                $scope.suitList = [];
            }
        }
        
        //Get Salutation Type List Service
        DataService.get('MediationSalutation').then(function(data){
            $scope.salutationList = data.results;
        });

        //Get Language List Service
        DataService.get('MediationLanguageList').then(function(data){
            $scope.languageList = data.results;
        });

        $scope.updateMediationApplication = function(){
            $scope.saveQuery = buildQurey($scope.mediationFormType);
            var successMsg = $scope.mediationFormType + ' updated successfully'
            DataService.post('MediationUpdateFormData',$scope.saveQuery).then(function(data){
                NotifyFactory.log('success',successMsg);
                if($rootScope.workingTab == 'inprogress' ){
                    $state.go('smclayout.mediationlayout.caselist.inprogress')
                }
                else if($rootScope.workingTab == 'lapsed' ){
                    $state.go('smclayout.mediationlayout.caselist.lapsed')
                }else{
                    $state.go('smclayout.mediationlayout.caselist.incomplete')
                }
            }).catch(function (error) {
               NotifyFactory.log('error',error.errorMessage)
            });;
            console.log('save',$scope.saveQuery)
        }

        function buildQurey(type){
            if($scope.cms_form.caseInfo.isLegalProceed == 'Yes'){
                $scope.cms_form.caseInfo.isLegalProceed = true
            }else{
                $scope.cms_form.caseInfo.isLegalProceed = false
            }
            for(var applicant in $scope.cms_form.applicantInfo.applicants){
                $scope.applicantList.push({id: 'Applicant '+applicant})
                if($scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided == 'Yes'){
                    $scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = true
                }else{
                    $scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = false
                }

                if($scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber){
                    $scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber = '+65' + $scope.cms_form.applicantInfo.applicants[applicant].businessAddress.faxNumber;
                }
                if($scope.cms_form.applicantInfo.applicants[applicant].lawFirm){
                    if($scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber){
                        $scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber = '+65' + $scope.cms_form.applicantInfo.applicants[applicant].lawFirm.businessAddress.faxNumber;
                    }
                }
                
            }
            for(var respondent in $scope.cms_form.respondentInfo){
                $scope.respondentList.push({id: 'Respondent '+respondent})
                if($scope.cms_form.respondentInfo[respondent].isLegallyAided == 'Yes'){
                    $scope.cms_form.respondentInfo[respondent].isLegallyAided = true;
                }else{
                    $scope.cms_form.respondentInfo[respondent].isLegallyAided = false;
                }

                if($scope.cms_form.respondentInfo[respondent].isLegallyRepresented == 'Yes'){
                    $scope.cms_form.respondentInfo[respondent].isLegallyRepresented = true;
                }else{
                    $scope.cms_form.respondentInfo[respondent].isLegallyRepresented = false;
                }

                if($scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber){
                    $scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber = '+65' + $scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber;
                }
                if($scope.cms_form.respondentInfo[respondent].lawFirm){
                    if($scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber){
                        $scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber = '+65' + $scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber;
                    }
                }
            }

            if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                $scope.cms_form.mediator = [];
                for(var mediator in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                    $scope.cms_form.mediator[mediator] = {};
                    $scope.cms_form.mediator[mediator].industry = [];
                    $scope.cms_form.mediator[mediator].specialisation = [];
                    $scope.cms_form.mediator[mediator].language = [];
                    for(var industry in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes){
                        if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry].name){
                            $scope.cms_form.mediator[mediator].industry.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry].name) 
                        }else{
                            $scope.cms_form.mediator[mediator].industry.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry]) 
                        }
                    }
                    for(var specialisation in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes){
                        if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation].specialisationName){
                            $scope.cms_form.mediator[mediator].specialisation.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation].specialisationName) 
                        }else{
                            $scope.cms_form.mediator[mediator].specialisation.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation])  
                        }
                    }
                    for(var language in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages){
                        if($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language].languageName){
                            $scope.cms_form.mediator[mediator].language.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language].languageName) 
                        }else{
                            $scope.cms_form.mediator[mediator].language.push($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language]) 
                        }
                    }
                    $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes = $scope.cms_form.mediator[mediator].industry;
                    $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes = $scope.cms_form.mediator[mediator].specialisation;
                    $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages = $scope.cms_form.mediator[mediator].language;
                }
            }

            

            if($scope.cms_form.isAllPartiesAgree == 'Yes'){
                $scope.cms_form.isAllPartiesAgree = true;
            }else{
                $scope.cms_form.isAllPartiesAgree = false;
            }
            
            var query = { 
                "smcOfficerId" : $cookies.get('memberId'),
                "isAllPartiesAgree" : undefinedSetNull($scope.cms_form.isAllPartiesAgree),
                "caseNumber":undefinedSetNull($scope.viewCaseNumber),
                "mediationType": type,
                "applicantInfo" : $scope.cms_form.applicantInfo,
                "respondentInfo":$scope.cms_form.respondentInfo,
                "disputeIds":$scope.cms_form.disputeIds,
                "disputeInfo" : $scope.cms_form.disputeInfo,
                "hearAboutUsIds": $scope.cms_form.hearAboutUsIds,
                "hearAboutUsInfo" : $scope.cms_form.hearAboutUsInfo,
                "mediationDates":$scope.cms_form.mediationDates,
                "caseInfo": $scope.cms_form.caseInfo,
                "suitInfo": $scope.cms_form.suitInfo,
                "mediatorPreferenceInfo": $scope.cms_form.mediatorPreferenceInfo,
                
            }
            console.log('finalQuery', query)
            return query;
        }

        $scope.removeRespondentParty = function(index){
            $scope.cms_form.respondentInfo.splice(index,1);
            $scope.respondentList.splice(index,1)
        }

        $scope.removeApplicantParty = function(index){
            $scope.cms_form.applicantInfo.applicants.splice(index,1);
            $scope.applicantList.splice(index,1)
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        /*---------- Initial Service Calls Data for Form Elements --------------*/
        //Get Salutation Type List Service
        DataService.get('MediationSalutation').then(function(data){
            $scope.salutationList = data.results;
        });

        //Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
            if(data.errorCode == 0){
                $scope.lawFirmList = data.results;
            } else {
                $scope.lawFirmList = [];
            }
            
        });

        //Get Dispute Type List Service
        DataService.get('MediationDistriputeList').then(function(data){
            $scope.distriputeList = data.results;
        });

        //Get Language List Service
        DataService.get('MediationLanguageList').then(function(data){
            $scope.languageList = data.results;
        });

        //Get Profession/Industry List Service
        DataService.get('MediationIndustryList').then(function(data){
            $scope.industryList = data.results;
        });

        //Get Specialisation List Service
        DataService.get('MediationSpecialisationList').then(function(data){
            $scope.specialisationList = data.results;
        });

        //Get Age Group List Service
        DataService.get('MediationAgeGroupList').then(function(data){
            $scope.ageGroupList = data.results;
        });

        //Get Hear About Us List Service
        DataService.get('MediationHearAboutusList').then(function(data){
            $scope.hearAboutUsList = data.results;
        });

        //Get Country Code List Service
        DataService.get('MediationCountryCodeList').then(function(data){
            $scope.countryCodeList = data.results;
        });

        //Principle Mediator List Service
        
        var principleMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":"Principle Mediator",
                               "name":null
                            }
        DataService.post('MediationMediatorList',principleMediatorQuery).then(function(data){
            $scope.principleMediatorList = data.result.responseData;
        });

        $scope.getprinciplemediator = function(principalmediatorsearch){
            var principleMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":undefinedSetNull(principalmediatorsearch.specialisation),
                               "name":undefinedSetNull(principalmediatorsearch.name)
                            }
        DataService.post('MediationMediatorList',principleMediatorQuery).then(function(data){
            $scope.principleMediatorList = data.result.responseData;
        });
        }

        var associateMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":"Associate Mediator",
                               "name":null
                            }
        DataService.post('MediationMediatorList',associateMediatorQuery).then(function(data){
            $scope.associateMediatorList = data.result.responseData;
        });
        $scope.getassosiatemediator = function(assosiatemediatorName){
            var associateMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":"Associate Mediator",
                               "name":undefinedSetNull(assosiatemediatorName.name)
                            }
            DataService.post('MediationMediatorList',associateMediatorQuery).then(function(data){
                $scope.associateMediatorList = data.result.responseData;
            });
        }

        $scope.addNewApplicant = function() {
            var index = $scope.applicantList.length;
            var newItemNo = $scope.applicantList.length+1;
            $scope.applicantList.push({'id':'Applicant '+newItemNo});
            $scope.cms_form.applicantInfo.applicants[index] = {};
            $scope.cms_form.applicantInfo.applicants[index].memberType = "Individual";
            $scope.cms_form.applicantInfo.applicants[index].salutationType = {"name" : "Mr"};
            $scope.cms_form.applicantInfo.applicants[index].authRepSalutationType = {"name" : "Mr"};
            $scope.cms_form.applicantInfo.applicants[index].businessAddress.countryCode = {"countryCode":"+65"};
            $scope.cms_form.applicantInfo.applicants[index].authRepAddress.countryCode = {"countryCode":"+65"};
        };
        $scope.addNewApplicantLawyer = function() {
            var newItemNo = $scope.applicantLawyerList.length+1;
            $scope.applicantLawyerList.push({'id':'Lawyer '+newItemNo});
        };

        $scope.addNewRespondent = function() {
            var index = $scope.respondentList.length;
            var newItemNo = $scope.respondentList.length+1;
            $scope.respondentList.push({'id':'Respondent '+newItemNo});
            $scope.respondentLawyerList[index] = [];
            $scope.cms_form.respondentInfo[index] = {};

            var primaryLawyers = $scope.respondentLawyerList[0].lawyers;
            $scope.respondentLawyerList[index].push(primaryLawyers);



            //Set default values
            var legallyRepresented = $scope.cms_form.respondentInfo[0].legallyRepresented;

            $scope.cms_form.respondentInfo[index].legallyRepresented = legallyRepresented;
            $scope.cms_form.respondentInfo[index].memberType = "Individual";
            $scope.cms_form.respondentInfo[index].salutationType = "Mr";
            $scope.cms_form.respondentInfo[index].authRepSalutationType = "Mr";
            $scope.cms_form.respondentInfo[index].businessAddress = {};
            $scope.cms_form.respondentInfo[index].authRepAddress = {};
            $scope.cms_form.respondentInfo[index].businessAddress.countryCode ="+65";
            $scope.cms_form.respondentInfo[index].authRepAddress.countryCode = "+65";
            $scope.cms_form.respondentInfo[index].lawFirm = {};
            $scope.cms_form.respondentInfo[index].lawFirm.businessAddress = {};
            $scope.cms_form.respondentInfo[index].isLegallyAided = 'No';
            $scope.cms_form.respondentInfo[index].isLegallyRepresented = 'Unknown';
        };

        $scope.addNewRespondentLawyer = function(index) {
            var newItemNo = $scope.respondentLawyerList[index].length+1;
            $scope.respondentLawyerList[index].push({'id':'Lawyer '+newItemNo});
        };

        $scope.applicantLawFirmDetail = function(){
            if($scope.cms_form.applicantInfo.legallyRepresented == 'Yes'){
                $scope.applicantLawyerDetailShow = true;
            } else {
                $scope.applicantLawyerDetailShow = false;
            }
        }

        //Claimant Load Law firm details on selecting law firm and reset
        $scope.loadApplicantLawFirmDetails = function(data){
            console.log(data);
            if(data){
                if(data.name == "Others"){
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.addresr1 = undefined;
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.addresr2 = undefined;
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.addresr3 = undefined;
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.addresr4 = undefined;
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.postalCode = undefined;
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.phoneNumber = undefined;
                    $scope.cms_form.applicantInfo.applicants[index].lawFirm.businessAddress.faxNumber = undefined;
                    $scope.ApplicantLawFirmStatus = false;
                } else {
                    $scope.ApplicantLawFirmStatus = true;
                    $scope.cms_form.applicantInfo.respresentative_lawfirmId = data.id;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.addresr1 = data.businessAddress.address1;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.addresr2 = data.businessAddress.address2;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.addresr3 = data.businessAddress.address3;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.addresr4 = data.businessAddress.address4;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.postalCode = data.businessAddress.postalCode;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
                    $scope.cms_form.applicantInfo.lawFirm.businessAddress.faxNumber = data.businessAddress.phoneNumber;
                }
            } else {
                $scope.ApplicantLawFirmStatus = true;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address1 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address2 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address3 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address4 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.postalCode = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.phoneNumber = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.faxNumber = undefined;
            }
        }

        //Respondent Load Law firm details on selecting law firm and reset
        $scope.loadRespondantLawFirmDetails = function(data,index){
            console.log(data);
            if(data){
                if(data.name == "Others"){
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr1 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr2 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr3 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr4 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.postalCode = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.phoneNumber = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.faxNumber = undefined;
                    $scope.RespondentLawFirmStatus[index] = false;
                } else {
                    
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr1 = data.businessAddress.address1;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr2 = data.businessAddress.address2;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr3 = data.businessAddress.address3;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.addresr4 = data.businessAddress.address4;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.postalCode = data.businessAddress.postalCode;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
                    $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.faxNumber = data.businessAddress.phoneNumber;
                    $scope.RespondentLawFirmStatus[index] = true;
                }
            } else {
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address1 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address2 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address3 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address4 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.postalCode = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.phoneNumber = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.faxNumber = undefined;
                $scope.RespondentLawFirmStatus[index] = true;
            }
        }
    }
})();


