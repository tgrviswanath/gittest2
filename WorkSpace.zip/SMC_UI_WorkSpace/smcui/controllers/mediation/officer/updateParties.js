(function() {
    'use strict';
    angular
        .module('smc')
        .controller('updatePartiesCmsFormCtrl',updatePartiesCmsFormCtrl);

    updatePartiesCmsFormCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','mediationPatternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function updatePartiesCmsFormCtrl($rootScope,$scope,$state,$cookies,DataService,$http,mediationPatternConfig,httpPostFactory,smcConfig,NotifyFactory){
         if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName')!="Mediation") {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.mediationFormType = $rootScope.mediationFormType;
        $scope.viewCaseNumber = $scope.viewCaseNumber;
        $scope.applicantList = [];
        $scope.respondentList = [];
        //Error Messages
        $scope.pattern = mediationPatternConfig;
        $scope.downloadCMSUrl = smcConfig.services.DownloadCMSForm.url;
        $scope.isPreviewClicked = false;
         $scope.applicantLawyerList = [];
         $scope.respondentLawyerList = {};
        if($scope.mediationFormType == 'CMS'){
            var ViewCMSFormUrl = smcConfig.services.ViewCMSForm.url;
            ViewCMSFormUrl = ViewCMSFormUrl + $scope.viewCaseNumber;
            $http.get(ViewCMSFormUrl).then(function(data){
                console.log("data",data);
                $scope.cms_form = data.data.result;
                for(var applicant in $scope.cms_form.applicantInfo.applicants){
                    $scope.applicantList.push({id: 'Applicant '+applicant})
                    $scope.cms_form.applicantInfo.applicants[applicant].conEmail = $scope.cms_form.applicantInfo.applicants[applicant].email;
                    $scope.cms_form.applicantInfo.applicants[applicant].reAuthRepEmail = $scope.cms_form.applicantInfo.applicants[applicant].authRepEmail;

                    if($scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided){
                        $scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = 'Yes'
                    }else{
                        $scope.cms_form.applicantInfo.applicants[applicant].isLegallyAided = 'No'
                    }
                }
                if($scope.cms_form.applicantInfo.lawFirm){
                    for(var lawyer in $scope.cms_form.applicantInfo.lawFirm.lawyerDetails){
                        $scope.applicantLawyerList.push({'id':'Lawyer '+lawyer});
                        $scope.cms_form.applicantInfo.lawFirm.lawyerDetails[lawyer].reemail = $scope.cms_form.applicantInfo.lawFirm.lawyerDetails[lawyer].email;
                    }
                }
                for(var respondent in $scope.cms_form.respondentInfo){
                    $scope.respondentList.push({id: 'Respondent '+respondent})
                    $scope.cms_form.respondentInfo[respondent].conEmail = $scope.cms_form.respondentInfo[respondent].email;
                    $scope.cms_form.respondentInfo[respondent].reAuthRepEmail = $scope.cms_form.respondentInfo[respondent].authRepEmail;
                    $scope.respondentLawyerList[respondent] = {};
                    $scope.respondentLawyerList[respondent].lawyers = [];
                    if($scope.cms_form.respondentInfo[respondent].lawFirm){
                        for(var lawyer in $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails){
                            $scope.respondentLawyerList[respondent].lawyers.push({'id':'Lawyer '+lawyer});
                            $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails[lawyer].reemail = $scope.cms_form.respondentInfo[respondent].lawFirm.lawyerDetails[lawyer].email;
                        }
                    }
                }

            });
        }else if($scope.mediationFormType == 'SCCMS'){
            var ViewSCCMSFormUrl = smcConfig.services.ViewSCCMSForm.url;
            ViewSCCMSFormUrl = ViewSCCMSFormUrl + $scope.viewCaseNumber;
            $http.get(ViewSCCMSFormUrl).then(function(data){
                console.log("data",data)
                $scope.cms_form = data.data.result;
                for(var applicant in $scope.cms_form.applicantInfo.applicants){
                    $scope.applicantList.push({id: 'Applicant '+applicant})
                    $scope.cms_form.applicantInfo.applicants[applicant].conEmail = $scope.cms_form.applicantInfo.applicants[applicant].email;
                }
                for(var respondent in $scope.cms_form.respondentInfo){
                    $scope.respondentList.push({id: 'Respondent '+respondent})
                    $scope.cms_form.respondentInfo[respondent].conEmail = $scope.cms_form.respondentInfo[respondent].email;
                }
            });
        }else{
            var ViewCPEFormUrl = smcConfig.services.ViewCPEForm.url;
            ViewCPEFormUrl = ViewCPEFormUrl + $scope.viewCaseNumber;
            $http.get(ViewCPEFormUrl).then(function(data){
                console.log("data",data)
                $scope.cms_form = data.data.result;
                for(var applicant in $scope.cms_form.applicantInfo.applicants){
                    $scope.applicantList.push({id: 'Applicant '+applicant})
                    $scope.cms_form.applicantInfo.applicants[applicant].conEmail = $scope.cms_form.applicantInfo.applicants[applicant].email;
                }
                for(var respondent in $scope.cms_form.respondentInfo){
                    $scope.respondentList.push({id: 'Respondent '+respondent})
                    $scope.cms_form.respondentInfo[respondent].conEmail = $scope.cms_form.respondentInfo[respondent].email;
                }
            });
        }
       /*---------- Initial Service Calls Data for Form Elements --------------*/
        //Get Salutation Type List Service
        DataService.get('MediationSalutation').then(function(data){
            $scope.salutationList = data.results;
        });

        //Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
            if(data.errorCode == 0){
                $scope.lawFirmList = data.results;
            } else {
                $scope.lawFirmList = [];
            }
            
        });
        //Get Country Code List Service
        DataService.get('MediationCountryCodeList').then(function(data){
            $scope.countryCodeList = data.results;
        });

        $scope.addNewApplicant = function() {
            var index = $scope.applicantList.length;
            var newItemNo = $scope.applicantList.length+1;
            $scope.applicantList.push({'id':'Applicant '+newItemNo});
            $scope.cms_form.applicantInfo.applicants[index] = {};
            $scope.cms_form.applicantInfo.applicants[index].applicantType = "Individual";
            $scope.cms_form.applicantInfo.applicants[index].salutation = {"name" : "Mr"};
            $scope.cms_form.applicantInfo.applicants[index].authorisedSalutation = {"name" : "Mr"};
            $scope.cms_form.applicantInfo.applicants[index].mobileCode = {"countryCode":"+65"};
            $scope.cms_form.applicantInfo.applicants[index].authorisedMobileCode = {"countryCode":"+65"};
        };
        $scope.addNewApplicantLawyer = function() {
            var newItemNo = $scope.applicantLawyerList.length+1;
            $scope.applicantLawyerList.push({'id':'Lawyer '+newItemNo});
        };

        $scope.addNewRespondent = function() {
            var index = $scope.respondentList.length;
            var newItemNo = $scope.respondentList.length+1;
            $scope.respondentList.push({'id':'Respondent '+newItemNo});
            $scope.respondentLawyerList[index] = {};
            $scope.respondentLawyerList[index].lawyers = [];
            $scope.cms_form.respondentInfo.respondents[index] = {};

            var primaryLawyers = $scope.respondentLawyerList[0].lawyers;
            $scope.respondentLawyerList[index].lawyers.push(primaryLawyers);



            //Set default values
            var legallyRepresented = $scope.cms_form.respondentInfo.respondents[0].legallyRepresented;

            $scope.cms_form.respondentInfo.respondents[index].legallyRepresented = legallyRepresented;
            $scope.cms_form.respondentInfo.respondents[index].respondentType = "Individual";
            $scope.cms_form.respondentInfo.respondents[index].salutation = {"name" : "Mr"};
            $scope.cms_form.respondentInfo.respondents[index].autherisedSalutation = {"name" : "Mr"};
            $scope.cms_form.respondentInfo.respondents[index].mobileCode = {"countryCode":"+65"};
            $scope.cms_form.respondentInfo.respondents[index].authorisedMobileCode = {"countryCode":"+65"};

            $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres1 = $scope.cms_form.respondentInfo.respondents[0].lawFirmAddres1;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres2 = $scope.cms_form.respondentInfo.respondents[0].lawFirmAddres2;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres3 = $scope.cms_form.respondentInfo.respondents[0].lawFirmAddres3;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres4 = $scope.cms_form.respondentInfo.respondents[0].lawFirmAddres4;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmPostalCode = $scope.cms_form.respondentInfo.respondents[0].lawFirmPostalCode;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmTelephone = $scope.cms_form.respondentInfo.respondents[0].lawFirmTelephone;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmFax = $scope.cms_form.respondentInfo.respondents[0].lawFirmFax;
            $scope.cms_form.respondentInfo.respondents[index].lawFirmReference = $scope.cms_form.respondentInfo.respondents[0].lawFirmReference;

            var lawyerList = $scope.cms_form.respondentInfo.respondents[0].lawyer;
            $scope.cms_form.respondentInfo.respondents[index].lawyer = lawyerList;

        };

        $scope.addNewRespondentLawyer = function(index) {
            var newItemNo = $scope.respondentLawyerList.length+1;
            $scope.respondentLawyerList[index].lawyers.push({'id':'Lawyer '+newItemNo});
        };

        $scope.applicantLawFirmDetail = function(){
            if($scope.cms_form.applicantInfo.legallyRepresented == 'Yes'){
                $scope.applicantLawyerDetailShow = true;
            } else {
                $scope.applicantLawyerDetailShow = false;
            }
        }

        //Claimant Load Law firm details on selecting law firm and reset
        $scope.loadApplicantLawFirmDetails = function(data){
            console.log(data);
            if(data){
                if(data.name == "Others"){
                    $scope.cms_form.applicantInfo.lawFirmAddres1 = undefined;
                    $scope.cms_form.applicantInfo.lawFirmAddres2 = undefined;
                    $scope.cms_form.applicantInfo.lawFirmAddres3 = undefined;
                    $scope.cms_form.applicantInfo.lawFirmAddres4 = undefined;
                    $scope.cms_form.applicantInfo.lawFirmPostalCode = undefined;
                    $scope.cms_form.applicantInfo.lawFirmTelephone = undefined;
                    $scope.cms_form.applicantInfo.lawFirmFax = undefined;
                    $scope.ApplicantLawFirmStatus = false;
                } else {
                    $scope.ApplicantLawFirmStatus = true;
                    $scope.cms_form.applicantInfo.respresentative_lawfirmId = data.id;
                    $scope.cms_form.applicantInfo.lawFirmAddres1 = data.businessAddress.address1;
                    $scope.cms_form.applicantInfo.lawFirmAddres2 = data.businessAddress.address2;
                    $scope.cms_form.applicantInfo.lawFirmAddres3 = data.businessAddress.address3;
                    $scope.cms_form.applicantInfo.lawFirmAddres4 = data.businessAddress.address4;
                    $scope.cms_form.applicantInfo.lawFirmPostalCode = data.businessAddress.postalCode;
                    $scope.cms_form.applicantInfo.lawFirmTelephone = data.businessAddress.phoneNumber;
                    $scope.cms_form.applicantInfo.lawFirmFax = data.businessAddress.faxNumber;
                }
            } else {
                $scope.ApplicantLawFirmStatus = true;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address1 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address2 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address3 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.address4 = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.postalCode = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.phoneNumber = undefined;
                $scope.cms_form.applicantInfo.lawFirm.businessAddress.faxNumber = undefined;
            }
        }

        //Respondent Load Law firm details on selecting law firm and reset
        $scope.loadRespondantLawFirmDetails = function(data,index){
            console.log(data);
            if(data){
                if(data.name == "Others"){
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres1 = undefined;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres2 = undefined;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres3 = undefined;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres4 = undefined;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmPostalCode = undefined;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmTelephone = undefined;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmFax = undefined;
                    $scope.RespondentLawFirmStatus[index] = false;
                } else {
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres1 = data.businessAddress.address1;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres2 = data.businessAddress.address2;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres3 = data.businessAddress.address3;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmAddres4 = data.businessAddress.address4;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmPostalCode = data.businessAddress.postalCode;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmTelephone = data.businessAddress.phoneNumber;
                    $scope.cms_form.respondentInfo.respondents[index].lawFirmFax = data.businessAddress.faxNumber;
                    $scope.RespondentLawFirmStatus[index] = true;
                }
            } else {
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address1 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address2 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address3 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.address4 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.postalCode = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.phoneNumber = undefined;
                $scope.cms_form.respondentInfo[index].lawFirm.businessAddress.faxNumber = undefined;
                $scope.RespondentLawFirmStatus[index] = true;
            }
        }


        $scope.updateFormParties = function(formData){
            var query = {
                "caseNumber" : formData.tempCaseNumber,
                "smcOfficerId" : $cookies.get('memberId'),
                "applicantInfo" : buildApplicantQuery(formData.applicantInfo),
                "respondentInfo" : buildRespondQuery(formData.respondentInfo)
            }
            DataService.post('UpdateFormParties',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', "Parties updated successfully");
                    $state.go('smclayout.mediationlayout.caselist.incomplete');
                    
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function buildApplicantQuery(applicantInfo) {
            var query = {
                "applicants" : buildApplicantsList(applicantInfo.applicants),
                "id" : undefinedSetNull(parseInt(applicantInfo.id)),
                "isLegallyRepresented" : undefinedSetNull(applicantInfo.isLegallyRepresented),
                "payeeName" : undefinedSetNull(applicantInfo.payeeName)
            }
            if(applicantInfo.lawFirm){
                query.lawFirm = buildApplicantLawfirm(applicantInfo.lawFirm);
            }else{
                query.lawFirm = null;
            }
            return query;
        }

        function buildApplicantsList(applicantList){
            var listquery = [];
            for (var applicant in applicantList){
                var query = {
                    "id": undefinedSetNull(applicantList[applicant].id),
                    "memberType": undefinedSetNull(applicantList[applicant].memberType),
                    "salutationType": undefinedSetNull(applicantList[applicant].salutationType),
                    "name": undefinedSetNull(applicantList[applicant].name),
                    "memberUidValue": undefinedSetNull(applicantList[applicant].memberUidValue),
                    "email": undefinedSetNull(applicantList[applicant].email),
                    "gender" : undefinedSetNull(applicantList[applicant].gender),
                    "businessAddress": buildBussinessAddress(applicantList[applicant].businessAddress),
                    "authRepSalutation": undefinedSetNull(applicantList[applicant].authRepSalutation),
                    "authRepSalutationType": undefinedSetNull(applicantList[applicant].authRepSalutationType),
                    "authRepName": undefinedSetNull(applicantList[applicant].authRepName),
                    "authRepDesignation": undefinedSetNull(applicantList[applicant].authRepDesignation),
                    "authRepEmail": undefinedSetNull(applicantList[applicant].authRepEmail),
                    "authRepAddress": buildAuthRepAddress(applicantList[applicant].authRepAddress),
                    "partyType": undefinedSetNull(applicantList[applicant].partyType)
                }
                if(applicantList[applicant].isLegallyAided == 'Yes'){
                    query.isLegallyAided = true;
                    query.legalCertificate = {
                        "id": undefinedSetNull(applicantList[applicant].legalCertificate.id),
                        "name": undefinedSetNull(applicantList[applicant].legalCertificate.name),
                        "location": undefinedSetNull(applicantList[applicant].legalCertificate.location)
                    }
                }else{
                    query.isLegallyAided = false;
                    query.legalCertificate = null;
                }
                listquery.push(query);
            }
            return listquery;
        }

        function buildBussinessAddress(adressData){
            if(adressData.faxNumber){
                var faxNumber = '+65' + adressData.faxNumber;
            }
            var query = {
                "id" : undefinedSetNull(adressData.id),
                "address1": undefinedSetNull(adressData.address1),
                "address2": undefinedSetNull(adressData.address2),
                "address3": undefinedSetNull(adressData.address3),
                "address4": undefinedSetNull(adressData.address4),
                "postalCode": undefinedSetNull(adressData.postalCode),
                "phoneNumber": undefinedSetNull(adressData.phoneNumber),
                "faxNumber": undefinedSetNull(faxNumber),
                "countryCode": undefinedSetNull(adressData.countryCode),
                "mobileNumber": undefinedSetNull(adressData.mobileNumber)
            }
            return query;
        }

        function buildAuthRepAddress(adressData){
            if(adressData.faxNumber){
                var faxNumber = '+65' + adressData.faxNumber;
            }
            var query = {
                "id": undefinedSetNull(adressData.id),
                "phoneNumber": undefinedSetNull(adressData.phoneNumber),
                "faxNumber": undefinedSetNull(faxNumber),
                "countryCode":undefinedSetNull(adressData.countryCode),
                "mobileNumber": undefinedSetNull(adressData.mobileNumber)
            }
            return query;
        }

        function buildApplicantLawfirm(lawFirmData){
            var query = {
                "id": undefinedSetNull(lawFirmData.id),
                "name": undefinedSetNull(lawFirmData.name),
                "referenceNumber": undefinedSetNull(lawFirmData.referenceNumber),
                "businessAddress" : buildBussinessAddress(lawFirmData.businessAddress),
                "lawyerDetails" : buildLawyerDetails(lawFirmData.lawyerDetails)
            }
            return query;
        }

        function buildLawyerDetails(lawyerData){
            var lawyerList = [];
            for(var lawyer in lawyerData){
                var query = {
                    "id": undefinedSetNull(lawyerData[lawyer].id),
                    "lawyerName": undefinedSetNull(lawyerData[lawyer].lawyerName),
                    "email": undefinedSetNull(lawyerData[lawyer].email),
                    "index": undefinedSetNull(lawyerData[lawyer].index),
                    "addressDTO": {
                        "id": undefinedSetNull(lawyerData[lawyer].addressDTO.id),
                        "phoneNumber": undefinedSetNull(lawyerData[lawyer].addressDTO.phoneNumber),
                        "countryCode":undefinedSetNull(lawyerData[lawyer].addressDTO.countryCode),
                        "mobileNumber": undefinedSetNull(lawyerData[lawyer].addressDTO.mobileNumber)
                    }
                }
                lawyerList.push(query);
            }
            return lawyerList;
        }

        function buildRespondQuery(respondentInfo){
            var repondList = [];
            for (var respond in respondentInfo){
                var query = {
                    "id": undefinedSetNull(respondentInfo[respond].id),
                    "memberType": undefinedSetNull(respondentInfo[respond].memberType),
                    "salutationType": undefinedSetNull(respondentInfo[respond].salutationType.name),
                    "name": undefinedSetNull(respondentInfo[respond].name),
                    "gender": undefinedSetNull(respondentInfo[respond].gender),
                    "memberUidValue": undefinedSetNull(respondentInfo[respond].memberUidValue),
                    "email": undefinedSetNull(respondentInfo[respond].email),
                    "businessAddress": buildBussinessAddress(respondentInfo[respond].businessAddress),
                    "authRepSalutationType": undefinedSetNull(respondentInfo[respond].authRepSalutationType),
                    "authRepName": undefinedSetNull(respondentInfo[respond].authRepName),
                    "authRepDesignation": undefinedSetNull(respondentInfo[respond].authRepDesignation),
                    "authRepEmail": undefinedSetNull(respondentInfo[respond].authRepEmail),
                    "isLegallyRepresented": undefinedSetNull(respondentInfo[respond].isLegallyRepresented),
                    "authRepAddress": buildAuthRepAddress(respondentInfo[respond].authRepAddress),
                }
                if(respondentInfo[respond].lawFirm){
                    query.lawFirm = buildApplicantLawfirm(respondentInfo[respond].lawFirm);
                }else{
                    query.lawFirm = null;
                }
                repondList.push(query);
            }
            return repondList;
        }

        $scope.removeone = function(index){

        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


