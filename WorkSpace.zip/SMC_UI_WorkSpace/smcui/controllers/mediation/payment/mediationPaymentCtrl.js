(function() {
    'use strict';
    angular
        .module('smc')
        .controller('mediationpaymentCtrl',mediationpaymentCtrl);

    mediationpaymentCtrl.$inject = ['$rootScope','$scope','$interval','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function mediationpaymentCtrl($rootScope,$scope,$interval,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
		
		var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	if (tab == 'paymentprocess'){
	    	if ($cookies.get('roleName') != 'claimant'  || $cookies.get('roleName') != 'claimantLawyer') {
	            $state.go('smclayout.membershiplayout.login');
	        }
	    }


		var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches
		
		$scope.summary_templatefile = 'views/mediation/payment/payment.html';
		$scope.fail_templatefile = 'views/mediation/payment/paymentfail.html'
		$scope.success_templatefile = 'views/mediation/payment/paymentsuccess.html'
		$scope.pattern = patternConfig;
		$scope.payment_summary = true;
		$scope.payment_method = 'Cheque';
		$scope.payment_failed = false;
		$scope.payment_success = false;
		$scope.ifcheque = true;
		$scope.ifcashier = false;
		$scope.ifnetbank = false;
		$scope.service_charge = false;
		$scope.attachcopyStatus = false;
		$scope.attach_copy_name = '';
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.lawyerId = $cookies.get('lawyerId');
		$scope.caseNumber = $cookies.get('caseNumber');
		$scope.loagedStatus = false;
		$scope.onemorecheck = false;
		$scope.applicationFee = '';
		$scope.paidAmount = '';
		$scope.totalAmount = '';
		$scope.pendingAmount = '';
		getBankDetails();
		

		function getBankDetails(){
			DataService.get('GetBankDetails').then(function(data){
				$scope.accountName = data.result.accountName;
				$scope.accountNumber = data.result.accountNumber;
				$scope.bankName = data.result.bankName;
			});
		}

		// check_method function for which method choose to payment filed
		$scope.check_method = function(method){
			if(method == 'Cheque'){
				$scope.ifcheque = true;
				$scope.ifcashier = false;
				$scope.ifnetbank = false;
				$scope.service_charge = false;
			}else if (method == "Cashier's Order"){
				$scope.ifcheque = false;
				$scope.ifcashier = true;
				$scope.ifnetbank = false;
				$scope.service_charge = false;
			}else if (method == "Credit Card"){
				$scope.ifcheque = false;
				$scope.ifcashier = false;
				$scope.ifnetbank = true;
				$scope.service_charge = true;
			}else{
				$scope.ifcheque = false;
				$scope.ifcashier = false;
				$scope.ifnetbank = false;
				$scope.service_charge = true;
			}
		}

		// upload document copy
		$scope.attachcopy = function(event){
			$scope.creditPayment={};
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.attachcopyStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						$scope.attach_copy_name = fileName;
						angular.element("#attach_copy").val(fileName);
						if(fileName){
							angular.element("#attach_copy").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.creditPayment.attach_copyPath= data.result;
								$scope.attachcopyStatus = true;
							});
						}
					} else {
						angular.element("#attach_copy").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.attachcopyErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#attach_copy").addClass("error");
					$scope.termsErrorStatus = true;
					$scope.attachcopyErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}

		//remove document copy
		$scope.attachcopyRemove = function(){
			$scope.attach_copy_name = undefined;
			$scope.creditPayment.attach_copy = undefined;
			$scope.attachcopyPath = undefined;
			angular.element("#attach_copy").val("");
			angular.element("#attach_copy").val("");
			$scope.attachcopyStatus = false;
		}

		// process to payment
		$scope.addpayment = function(method,payment){
			var amountStatus = checkAmountisValid(payment);
			if (amountStatus){
				angular.element(".overlay").css("display","block");
				angular.element(".loading-container").css("display","block");
				/*if(animating) return false;
				animating = true;*/
				current_fs = $(".aa1-form-wizard2");
				next_fs = $(".aa1-form-wizard3");
				console.log("payment",payment);
				var paymentRequests = buildPaymentQuery(method,payment);
				var query = {
					"tempCaseNumber":$rootScope.memberData?$rootScope.memberData.tempCaseNumber:$cookies.get('caseNumber'),
					"paymentRequests": paymentRequests
				}
				console.log('query',query)
				DataService.post('MediationPaymentSubmit',query).then(function(data){
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
					console.log(data);
					if(data.status == "SUCCESS"){
						$scope.payment_summary = false;
						$scope.payment_success = true;
						$scope.payment_failed = false;
						$scope.paymentResponse = data.result;
						if(data.result.caseNumber){
							$scope.loagedStatus = true;
						}
						$scope.paymethod = method;

					}else{
						$scope.theTime = 10;
						$scope.payment_summary = false;
						$scope.payment_failed = true;
						$scope.payment_success = false;
						$interval(function () {
						    $scope.theTime = $scope.theTime-1;
						    if($scope.theTime == 0){
						        $scope.payment_summary = true;
								$scope.payment_failed = false;
						        $scope.theTime = undefined;
						        $scope.ifcheque = true;
								$scope.ifcashier = false;
								$scope.ifnetbank = false;
						    }
						},1000);
						
					}
	    		})
	    		.catch(function(error){
	    			angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
	    			$scope.theTime = 10;
	    			$scope.payment_summary = false;
	    			$scope.payment_failed = true;
		            console.log(error);
		            $interval(function () {
					    $scope.theTime = $scope.theTime-1;
					    if($scope.theTime == 0){
					        $scope.payment_summary = true;
							$scope.payment_failed = false;
					        $scope.theTime = undefined;
					        $scope.ifcheque = true;
							$scope.ifcashier = false;
							$scope.ifnetbank = false;
					    }
					},1000);
					
		        });
		    }
		}

		// upload document validation by exetension
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if($scope.fileUploadTypes[i] == ext){
					return true;
				}
			}
		}

		// after payment success return to case details
		$scope.returnToAdmin = function(){
			if($scope.caseNumber == $rootScope.tempCaseNumber){
				$state.go('smclayout.membershiplayout.lawyercasesummary');
			}
		}

		// add one more check 
		$scope.addonemorecheck = function(){
			if($scope.onemorecheck == false){
				$scope.onemorecheck = true;
			}else{
				$scope.onemorecheck = false;
			}
		}
		// check submit amount is valid or not
		function checkAmountisValid(payment){
			if(parseInt($scope.paidAmount) ==0){
				if($scope.onemorecheck){
					var validAmount = parseInt(payment.amount) + parseInt(payment.amount1);
					if(payment.referencenumber != payment.referencenumber1){
						if(parseInt(validAmount)< parseInt($scope.totalAmount)){
							NotifyFactory.log('error','You have to pay minimum amount of Total fees.')
						}else{
							return true;
						}
					}else{
						NotifyFactory.log('error','Cheque order should be not same')
					}
				}else{
					if(parseInt(payment.amount)< parseInt($scope.applicationFee)){
						NotifyFactory.log('error','You have to pay minimum amount of Application fees.')
					}else{
						return true;
					}
				}
			}else if(parseInt($scope.paidAmount) !=0){
				if(parseInt(payment.amount)<parseInt($scope.pendingAmount)){
					NotifyFactory.log('error','Minimum amount is Pending Amount')
				}else{
					return true
				}
			}
		}

		// build payment query
		function buildPaymentQuery(method,payment){
			var query = [];
				var cheque1 = {
					"memberId":undefinedSetNull($rootScope.memberData?$rootScope.memberData.id:$cookies.get('memberId')),
					"memberEmail":undefinedSetNull($rootScope.memberData?$rootScope.memberData.memberEmail:$cookies.get('userMail')),
					"paymentMode":method,
					"referenceNumber":payment.referencenumber, 
					"amount":payment.amount, 
					"dateOfOrder":payment.paymentdate, 
					"bankName":payment.bankname
				}
				query.push(cheque1);
				if($scope.onemorecheck == true){
					var cheque2 = {
						"memberId":undefinedSetNull($rootScope.memberData.id),
						"memberEmail":undefinedSetNull($rootScope.memberData.memberEmail),
						"paymentMode":method,
						"referenceNumber":payment.referencenumber1, 
						"amount":payment.amount1, 
						"dateOfOrder":payment.paymentdate1, 
						"bankName":payment.bankname1
					}
					query.push(cheque2);
				}
				return query
		}

		function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }


	}
}
)();