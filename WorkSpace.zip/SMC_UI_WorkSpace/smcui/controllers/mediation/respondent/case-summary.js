(function() {
    'use strict';
    angular
        .module('smc')
        .controller('mediationCaseSummaryCtrl',mediationCaseSummaryCtrl);

    mediationCaseSummaryCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function mediationCaseSummaryCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('roleName') != 'applicant'  && $cookies.get('roleName') != 'applicantLawyer' && $cookies.get('roleName') != 'respondent' && $cookies.get('roleName') != 'respondentLawyer' || $cookies.get('moduleName') != 'Mediation') {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.caseNumber = $cookies.get('caseNumber');
        $scope.roleName = $cookies.get('roleName');
        getRespondCaseSummary();

        function getRespondCaseSummary(){
        	var query = {
        		"loginId": $cookies.get('memberId'),
                "caseNumber" : $scope.caseNumber
        	}
        	DataService.post('GetRespondentcaseSummaryByCaseNumberMediation',query).then(function (data) {
				console.log('caselist',data);
				$scope.respondent_caselist = data.result;
			})
			.catch(function(error){
				console.log('errorcaselist',error)
			});
        }

        $scope.goToSubmit = function(currentFeePaid){
            $cookies.put('currentFeePaid',currentFeePaid);
            $state.go("smclayout.mediationlayout.respondantresponseform");
        }

        $scope.goToApplicantSubmit = function(type,caseNumber){
            $rootScope.viewCaseNumber = caseNumber;
            $rootScope.formDoingType = 'Update';
            if(type == "CMS"){
                $rootScope.mediationFormType = "CMS";
                $rootScope.medationFormTitle = "Commercial Mediation Scheme (CMS)";
                $state.go('smclayout.cmsFormLayout.applicantupdatecmstosubmit');
            } else if(type == "SCCMS"){
                $rootScope.mediationFormType = "SCCMS";
                $rootScope.medationFormTitle = "Small Case Commercial Mediation Scheme (SCCMS)";
                $state.go('smclayout.cmsFormLayout.applicantupdatesccmstosubmit');
            }
        }
    }
 })();