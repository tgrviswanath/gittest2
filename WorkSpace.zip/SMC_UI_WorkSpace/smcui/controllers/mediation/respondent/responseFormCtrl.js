(function() {
    'use strict';
    angular
        .module('smc')
        .controller('responseFormCtrl',responseFormCtrl);

    responseFormCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function responseFormCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('roleName') != 'respondent' && $cookies.get('roleName') != 'respondentLawyer' || $cookies.get('moduleName') != 'Mediation') {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.previewFormClicked = false;
        $scope.selectedPrincipalMediatorList = [];
        $scope.selectedAssociateMediatorList = [];
        $scope.otherMediatorDetail = {};
        $scope.otherMedatorList = [];
        $scope.RespondentLawFirmStatus = [];
        $scope.pattern = patternConfig;
        $scope.RespondentLawFirmStatus[0] = true;
        $scope.mediatorSelectStatus = true;
        $scope.medationFormTitle = 'Respondent Response Form';
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.respondentList = [];
        $scope.roleName = $cookies.get('roleName');
        $scope.currentFeePaid = $cookies.get('currentFeePaid');
        var generateDownloadUrl = smcConfig.services.MediationDownloadForm.url;
        $scope.downloadUrl = generateDownloadUrl + "/" + $cookies.get('caseNumber');
        getAllResponseData();
        
        // function getResponseFormDetails(){
        //     var query = {
        //         "caseNumber":$cookies.get('caseNumber'),
        //         "loginID":$cookies.get('memberId')
        //     }
        //     DataService.post('GetFormOnlyRespondentsDetailsByRespondent',query).then(function (data) {
        //         if(data.status == 'SUCCESS'){
        //             $scope.isPreviewClicked = true;
        //             $scope.cms_form = data.result;
        //             $scope.cms_form.agreed = 'true';
        //             console.log('$scope.cms_form',$scope.cms_form);
        //             for(var respondent in $scope.cms_form.respondentInfo){
        //                 $scope.respondentList.push({id: 'Respondent '+respondent})
        //             }
        //         }
        //     }).catch(function (error) {
        //         NotifyFactory.log('error', error.errorMessage);
        //     });
        // }

        $scope.changeFormDetails = function(){
            $scope.isPreviewClicked = false;
            // if($scope.cms_form.agreed == 'true'){
            //     getResponseFormDetails()
            // }else{
            //     getAllResponseData();
            // }
        }
        $scope.copyCMSForm = {};
        function getAllResponseData(){
            var query = {
                "caseNumber":$cookies.get('caseNumber'),
                "loginID":$cookies.get('memberId')
            }
            DataService.post('GetFormAllDetailsByRespondent',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.cms_form = data.result;
                    $scope.mediationFormType = 'CMS';
                    $scope.copyCMSForm = angular.copy(data.result);
                    $scope.isMediatorChanged = true;
                    $scope.isResponseChanged = true;
                    $scope.isMediationDateChanged = false;
                    if($scope.roleName == 'respondent'){
                        $scope.cms_form.agreed = 'true';
                        $scope.isPreviewClicked = true;
                    }else{
                        $scope.cms_form.agreed = 'false';
                    }
                    $scope.cms_form.respondentDates = [];
                    $scope.cms_form.mediator = [];
                    for(var mediator in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                        $scope.cms_form.mediator[mediator] = {};
                        $scope.cms_form.mediator[mediator].industry = [];
                        $scope.cms_form.mediator[mediator].specialisation = [];
                        $scope.cms_form.mediator[mediator].language = [];
                        for(var industry in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes){
                            var check = {'name' : $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes[industry]}
                           $scope.cms_form.mediator[mediator].industry.push(check)  
                        }
                        for(var specialisation in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes){
                            var check = {'specialisationName' : $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes[specialisation]}
                           $scope.cms_form.mediator[mediator].specialisation.push(check)  
                        }
                        for(var language in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages){
                            var check = {'languageName' : $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages[language]}
                           $scope.cms_form.mediator[mediator].language.push(check)  
                        }
                        $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].industryTypes = $scope.cms_form.mediator[mediator].industry;
                        $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].specialisationTypes = $scope.cms_form.mediator[mediator].specialisation;
                        $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediator].languages = $scope.cms_form.mediator[mediator].language;
                    }
                    
                    
                    
                    console.log('$scope.cms_form',$scope.cms_form);
                    for(var respondent in $scope.cms_form.respondentInfo){
                        $scope.respondentList.push({id: 'Respondent '+respondent})
                        if($scope.cms_form.respondentInfo[respondent].isLegallyAided){
                            $scope.cms_form.respondentInfo[respondent].isLegallyAided = 'Yes';
                        }else{
                            $scope.cms_form.respondentInfo[respondent].isLegallyAided = 'No';
                            $scope.cms_form.respondentInfo[respondent].legalCertificate = {};
                        }

                        if($scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber){
                            if($scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber[0] == '+'){
                                $scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber = $scope.cms_form.respondentInfo[respondent].businessAddress.faxNumber.substring(3);
                            }
                        }
                        if($scope.cms_form.respondentInfo[respondent].lawFirm){
                            if($scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber){
                                if($scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber[0] == '+'){
                                    $scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber = $scope.cms_form.respondentInfo[respondent].lawFirm.businessAddress.faxNumber.substring(3);
                                }
                            }
                        }
                    }
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        $scope.legallyAidUploadedStatus = [];
        /*Document Uploads*/
        $scope.legalAidCerticate = function(file,index){
            $scope.cms_form.respondentInfo[index].legalCertificat = {};
            var file = file;
            var fileName = file.name;
            if(fileName){
                $scope.termsUploadPathStatus = false;
                $scope.termsErrorStatus = false;
                if ( file.size < 5242881 ){
                    if(validateUploadFileExtention(fileName)){
                        $scope.cms_form.respondentInfo[index].legalCertificate.name = fileName;
                        angular.element("#suport_upload1_name").val(fileName);
                        if(fileName){
                            angular.element("#suport_upload1_name").removeClass("error");
                            var fd= new FormData();
                            fd.append('file',file);
                            httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                                
                                console.log(data);
                                $scope.legallyAidUploadedStatus[index] = true;
                                $scope.cms_form.respondentInfo[index].legalCertificate.location = data.result;
                                $scope.termsUploadPathStatus = true;
                            });
                        }
                    } else {
                        angular.element("#suport_upload1_name").addClass("error");
                        $scope.termsErrorStatus = true;
                        var allowedExt = $scope.fileUploadTypes;
                        $scope.termsUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString();
                    }
                } else {
                    angular.element("#suport_upload1_name").addClass("error");
                    $scope.termsErrorStatus = true;
                    $scope.termsUploadErrorMsg = "Maximum allowed file size should be 5MB";
                }
            }
        }

        $scope.legallyAidUploadedRemove = function(index){
            $scope.cms_form.respondentInfo[index].legalCertificate.location = undefined;
            $scope.cms_form.respondentInfo[index].legalCertificate.name = undefined;
            angular.element("#legal_aid_certificate_name").val("");
            angular.element("#legal_aid_certificate").val("");
            $scope.legallyAidUploadedStatus[index] = false;
        }

        $scope.amendRespondSection = function(){
            $scope.isResponseChanged = false;
        }

        $scope.confirmRespondSection = function(){
            $scope.isResponseChanged = true;
        }

        $scope.amendMediationDateSection = function(){
            $scope.isMediationDateChanged = true;
            
        }

        $scope.amendMediatorSection = function(){
            $scope.isMediatorChanged = false;
        }

        $scope.confirmMediatorSection = function(){
            $scope.isMediatorChanged = true;
        }

        
        $scope.pushDate = function(choose_date){
            var dateIndex = $scope.cms_form.respondentDates.indexOf(choose_date);
            if(dateIndex == -1){
                $scope.cms_form.respondentDates.push(choose_date)
            }else{
                $scope.cms_form.respondentDates.splice(dateIndex,1)
            }
            console.log($scope.cms_form.respondentDates)
        }

        $scope.previewForm = function(){
            // var dateValue = $('#selectedDate')[0].value;
            // if(dateValue){
            //     if(dateValue.indexOf(', ') != -1){
            //         var dates = dateValue.split(', ')
            //         $scope.cms_form.respondentDates = dates;
            //     }
            //     else{
            //         $scope.cms_form.respondentDates.push(dateValue)
            //     }
            // }
            $scope.previewFormClicked = true;
            $scope.isMediatorChanged = true;
            $scope.isResponseChanged = true;
            findDiffObjects($scope.cms_form,$scope.copyCMSForm,null)
        }
        $scope.diffOfApplicants = {};
        function findDiffObjects(object1,object2,objectKey){
            var sameKeyCount = 1;
            if(!Array.isArray(object1) && !Array.isArray(object2)){
                for(var key1 in object1){
                    for(var key2 in object2){
                        if(key1 != 'mediationDates' &&  key1 != 'otherParties'){
                            if(key1 == key2){
                                if(typeof object1[key1] === 'object' && typeof object2[key2] === 'object'){
                                    findDiffObjects(object1[key1],object2[key2],key1)
                                }
                                else if((typeof object1[key1] === 'string' || typeof object1[key1] === 'number') && (typeof object2[key2] === 'string' || typeof object2[key2] === 'number')){
                                    if(object1[key1] != object2[key2]){
                                        if(key1 != 'id' &&  typeof object1[point] != 'object'){
                                            var diffQuery = {
                                                "modifiedField" : key1,
                                                "oldValue" : object2[key2],
                                                "newValue" : object1[key1],
                                                "type" : 'object'
                                            } 
                                            var chk = 0; 
                                            for(var findedKey in $scope.diffOfApplicants){
                                                if(findedKey == objectKey){
                                                    chk = 1
                                                }
                                            }
                                            if(chk != 1){
                                                $scope.diffOfApplicants[objectKey] = diffQuery;
                                            }else{
                                                $scope.diffOfApplicants[objectKey+sameKeyCount] = diffQuery;
                                                sameKeyCount = sameKeyCount+1;
                                            }
                                            console.log($scope.diffOfApplicants)
                                            $scope.nxtBtnClicked = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }else{
                for(var point in object1){
                    for(var point1 in object2){
                        if(typeof object1[point] === 'object' && typeof object2[point1] === 'object'){
                            findDiffObjects(object1[point],object2[point1],objectKey)
                        }else if(object1[point] !== object2[point1]){
                            if(point != 'id' &&  typeof object1[point] != 'object'){
                                var diffQuery = {
                                    "modifiedField" : point,
                                    "oldValue" : object2[point1],
                                    "newValue" : object1[point],
                                    "type" : 'array'
                                }
                                $scope.diffOfApplicants[objectKey] = diffQuery;
                                console.log($scope.diffOfApplicants)
                                $scope.nxtBtnClicked = true;
                            }
                        }
                    }
                }
            }
        }

        $scope.amendPreviewForm = function(){
            $scope.previewFormClicked = false;
            $scope.nxtBtnClicked = false;
            $scope.diffOfApplicants = [];
        }

        $scope.AcceptMediationCase =function(){
            if($scope.cms_form.agreed == 'true'){
                approvalofrespondent('true');
            }else{
                updateRespondentDetails();
            }
            
        }

        $scope.RejectmediationCase = function (){
            approvalofrespondent('false');
        }
        $rootScope.memberData = {};
        $rootScope.memberData.id = $cookies.get('memberId');
        $rootScope.memberData.memberEmail = $cookies.get('userMail');

        function updateRespondentDetails(){
            var respondents = buildRespondentQuery();
            var mediationDates = buildMediationDatesQuery();
            var mediatorPreferenceInfo = buildMediatorPreferenceInfoQuery();
            var query = {
                'caseNumber' : $cookies.get('caseNumber'),
                'loginId' : $cookies.get('memberId'),
                'isAmend' : false,
                'isConfirm' : true,
                'respondents' : respondents,
                'mediationDates' : mediationDates,
                'mediatorPreferenceInfo' : mediatorPreferenceInfo
            }
            console.log('query4',query);
            DataService.post('UpdateRespondentDatabyRedpondent',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $rootScope.memberData.tempCaseNumber = data.result;
                    approvalofrespondent('true');
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function buildMediatorPreferenceInfoQuery (){
            var query = {
                'id' :undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.id),
                'preferenceType' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.preferenceType),
                'numOfMediators' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.numOfMediators),
                'languagesInfo' :undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.languagesInfo),
            }
            if($scope.cms_form.mediatorPreferenceInfo.preferenceType == 'SMC Appointed Mediators'){
                query.smcMediatorInfo = buildSmcMediatorInfo();
            }else{
                query.ownMediatorInfo = buildOwnMediatorInfo();
            }

            return query;
        }

        function buildSmcMediatorInfo(){
            var mediatorInfo = [];
            for (var mediate in $scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo){
                var query = {
                    'backgroundAttributes' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediate].backgroundAttributes),
                    'gender' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediate].gender),
                    'id':undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.smcMediatorInfo[mediate].id),
                }
                for(var mediate1 in $scope.cms_form.mediator){
                    query.ageLimits = [];
                    query.industryTypes =[];
                    query.languages = [];
                    query.specialisationTypes = [];
                    for(var industry in $scope.cms_form.mediator[mediate1].industry){
                       query.industryTypes.push($scope.cms_form.mediator[mediate1].industry[industry].name)  
                    }
                    for(var specialisation in $scope.cms_form.mediator[mediate1].specialisation){
                       query.specialisationTypes.push($scope.cms_form.mediator[mediate1].specialisation[specialisation].specialisationName);  
                    }
                    for(var language in $scope.cms_form.mediator[mediate1].language){
                       query.languages.push($scope.cms_form.mediator[mediate1].language[language].languageName);  
                    }
                    for(var age in $scope.cms_form.mediator[mediate1].ageGroup){
                       query.ageLimits.push($scope.cms_form.mediator[mediate1].ageGroup[age])
                    }
                }
                mediatorInfo.push(query);
            }


            return mediatorInfo;
        }

        function buildOwnMediatorInfo(){
            var query = { };
            query.principalMediators = [];
            query.associateMediators = [];
            query.otherMediators = [];
            query.ownMediatorsInfo = [];
            if($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo){
                if($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.principalMediators){
                    for(var princi in $scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.principalMediators){
                        query.principalMediators.push($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.principalMediators[princi]);
                    }
                }
                if($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.associateMediators){
                    for(var assit in $scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.associateMediators){
                        query.associateMediators.push($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.associateMediators[assit]);
                    }
                }
                if($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators){
                    for(var other in $scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators){
                        var query1 = {
                            'countryCode' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].countryCode),
                            'email' :  undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].email),
                            'gender' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].gender),
                            'id' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].id),
                            'mobileNumber' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].mobileNumber),
                            'name' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].name),
                            'phoneNumber' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.otherMediators[other].phoneNumber),
                        }
                        query.otherMediators.push(query1);
                    }
                }
                if($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.ownMediatorsInfo){
                    for(var own in $scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.ownMediatorsInfo){
                        var query2 = {
                            'id' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.ownMediatorsInfo[own].id),
                            'name' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.ownMediatorsInfo[own].name),
                            'email' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.ownMediatorsInfo[own].email),
                            'mediatorType' : undefinedSetNull($scope.cms_form.mediatorPreferenceInfo.ownMediatorInfo.ownMediatorsInfo[own].mediatorType)
                        }
                        query.ownMediatorsInfo.push(query2);
                    }
                }
            }else{
                query.principalMediators = principleMediatosrQuery();
                query.associateMediators = assosiateMediatosrQuery();
                query.otherMediators = $scope.otherMedatorList;
            }
            

            return query;
        }

        function buildOtherMediatorQuery(){
            var Other_Mediator = [];
            for(var mediat in $scope.otherMedatorList){
                var query = {
                    'name' : undefinedSetNull($scope.otherMedatorList.name),
                    'gender' : undefinedSetNull($scope.otherMedatorList.gender),
                    'email' : undefinedSetNull($scope.otherMedatorList.email),
                    'countryCode' : undefinedSetNull($scope.otherMedatorList.countryCode),
                    'mobileNumber' : undefinedSetNull($scope.otherMedatorList.mobileNumber),
                    'phoneNumber' : undefinedSetNull($scope.otherMedatorList.phoneNumber)
                }
               Other_Mediator.push(query) 
            }
            return Other_Mediator;
        }

        function buildMediationDatesQuery(){
            
            if($scope.cms_form.respondentDates){
                var datearray = $scope.cms_form.respondentDates;
            }else{
                var datearray =$scope.cms_form.mediationDates[0].dates;
            }

            return datearray
        }

        function approvalofrespondent(val){
            var query = {
                "caseNumber":$cookies.get('caseNumber'), 
                "respondentLoginId":$cookies.get('memberId'), 
                "isRespondentAccept": val
            }
            DataService.post('FinalResponseofRedpondent',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success','Request submitted successfully')
                    if(val == 'true'){
                        $rootScope.memberData.tempCaseNumber = $cookies.get('caseNumber');
                        angular.element(".mediationFormContainer").addClass("hide");
                        $scope.submitMediationFormAcknolegement =  true;
                    }
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function buildRespondentQuery(){
            var repondentData = [];
            for(var respondent in $scope.cms_form.respondentInfo){
                if($scope.cms_form.respondentInfo[respondent].businessAddress){
                    var businessAddress = buildBussinessAddress($scope.cms_form.respondentInfo[respondent].businessAddress);
                }
                if($scope.cms_form.respondentInfo[respondent].authRepAddress){
                    var authRepAddress = buildAuthRepAddress($scope.cms_form.respondentInfo[respondent].authRepAddress);
                }
                if($scope.cms_form.respondentInfo[respondent].lawFirm){
                    var lawFirm = buildApplicantLawfirm($scope.cms_form.respondentInfo[respondent].lawFirm)
                }
                
                var query = {
                    'id' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].id),
                    'memberType' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].memberType),
                    'memberUidValue' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].memberUidValue),
                    'salutationType' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].salutationType),
                    'name' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].name),
                    'gender' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].gender),
                    'businessAddress' : undefinedSetNull(businessAddress),
                    'isLegallyAided' : undefinedSetNull(($scope.cms_form.respondentInfo[respondent].isLegallyAided == 'Yes')?true:false),
                    'email' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].email),
                    'authRepSalutationType' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].authRepSalutationType),
                    'authRepName' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].authRepName),
                    'authRepDesignation' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].authRepDesignation),
                    'authRepEmail' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].authRepEmail),
                    'authRepAddress' : undefinedSetNull(authRepAddress),
                    'isLegallyRepresented' : undefinedSetNull($scope.cms_form.respondentInfo[respondent].isLegallyRepresented),
                    'lawFirm' : undefinedSetNull(lawFirm)
                }
                query["legalCertificate"] = {
                    "name": undefinedSetNull($scope.cms_form.respondentInfo[respondent].legalCertificate.name),
                    "location": undefinedSetNull($scope.cms_form.respondentInfo[respondent].legalCertificate.location)
                };

                repondentData.push(query)
            }
            return repondentData;
        }

        function buildBussinessAddress(adressData){
            if(adressData.faxNumber){
                var faxNumber = '+65' + adressData.faxNumber;
            }
            var query = {
                "id" : undefinedSetNull(adressData.id),
                "address1": undefinedSetNull(adressData.address1),
                "address2": undefinedSetNull(adressData.address2),
                "address3": undefinedSetNull(adressData.address3),
                "address4": undefinedSetNull(adressData.address4),
                "postalCode": undefinedSetNull(adressData.postalCode),
                "phoneNumber": undefinedSetNull(adressData.phoneNumber),
                "faxNumber": undefinedSetNull(faxNumber),
                "countryCode": undefinedSetNull(adressData.countryCode),
                "mobileNumber": undefinedSetNull(adressData.mobileNumber)
            }
            return query;
        }

        function buildAuthRepAddress(adressData){
            if(adressData.faxNumber){
                var faxNumber = '+65' + adressData.faxNumber;
            }
            var query = {
                "id": undefinedSetNull(adressData.id),
                "phoneNumber": undefinedSetNull(adressData.phoneNumber),
                "faxNumber": undefinedSetNull(faxNumber),
                "countryCode":undefinedSetNull(adressData.countryCode),
                "mobileNumber": undefinedSetNull(adressData.mobileNumber)
            }
            return query;
        }

        $scope.proceedToPayment = function(){
            $scope.submitMediationFormAcknolegement = false;
            $scope.ifPaymentProcess = true;
        }

        function buildApplicantLawfirm(lawFirmData){
            var query = {
                "id": undefinedSetNull(lawFirmData.id),
                "name": undefinedSetNull(lawFirmData.name),
                "referenceNumber": undefinedSetNull(lawFirmData.referenceNumber),
                "businessAddress" : buildBussinessAddress(lawFirmData.businessAddress),
                "lawyerDetails" : buildLawyerDetails(lawFirmData.lawyerDetails)
            }
            return query;
        }

        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if(allowedExt[i] == ext){
                    return true;
                }
            }
        }


        function buildLawyerDetails(lawyerData){
            var lawyerList = [];
            for(var lawyer in lawyerData){
                var query = {
                    "id": undefinedSetNull(lawyerData[lawyer].id),
                    "lawyerName": undefinedSetNull(lawyerData[lawyer].lawyerName),
                    "email": undefinedSetNull(lawyerData[lawyer].email),
                    "addressDTO": {
                        "id": undefinedSetNull(lawyerData[lawyer].addressDTO.id),
                        "phoneNumber": undefinedSetNull(lawyerData[lawyer].addressDTO.phoneNumber),
                        "countryCode":undefinedSetNull(lawyerData[lawyer].addressDTO.countryCode.countryCode),
                        "mobileNumber": undefinedSetNull(lawyerData[lawyer].addressDTO.mobileNumber)
                    }
                }
                lawyerList.push(query);
            }
            return lawyerList;
        }

        $scope.addNewMediator = function(){
            var selectCount = selectedMediatorCount();
            var formInvalid = angular.element("#addNewOtherMediator .ng-invalid");
            var formInvalidCount = formInvalid.length;

            if(formInvalidCount > 0){
                angular.element("#addNewOtherMediator .ng-invalid").addClass("error");
            } else {
                if(selectCount <= 3){
                    if($scope.otherMediatorDetail.name){
                        $scope.otherMedatorList.push($scope.otherMediatorDetail);
                        $scope.otherMediatorDetail = {};
                    }
                } else {
                    $scope.mediatorSelectStatus = true;
                }
            }
        }

        $scope.removeOtherNewMediator = function(index){
            $scope.otherMedatorList.splice(index,1);
        }

        function principleMediatosrQuery(){
            var principleMediators = [];
            for(var key in $scope.selectedPrincipalMediatorList){
                if($scope.selectedPrincipalMediatorList[key] == true){
                    principleMediators.push(parseInt(key))
                }
            }
            console.log('principleMediators',principleMediators);
            return principleMediators;
        }

        function assosiateMediatosrQuery(){
            var assosiateMediators = [];
            for(var key in $scope.selectedAssociateMediatorList){
                if($scope.selectedAssociateMediatorList[key] == true){
                    assosiateMediators.push(parseInt(key))
                }
            }
            console.log('assosiateMediators',assosiateMediators);
            return assosiateMediators;
        }

        function selectedMediatorCount(){
            if($scope.selectedPrincipalMediatorList.length > 0){
                var selectedPrincipleCount = getCheckedArrayCount($scope.selectedPrincipalMediatorList);
                if(selectedPrincipleCount){
                    console.log(selectedPrincipleCount);
                }
            } else {
                var selectedPrincipleCount = 0;
            }
            if($scope.selectedAssociateMediatorList.length > 0){
                var selectedAssociateCount = getCheckedArrayCount($scope.selectedAssociateMediatorList);
            } else {
                var selectedAssociateCount = 0;
            }
            if($scope.otherMedatorList.length > 0){
                var otherCount = $scope.otherMedatorList.length;
            } else {
                var otherCount = 0;
            }
            if(selectedPrincipleCount != undefined && selectedAssociateCount != undefined && otherCount != undefined){
                var selectCount = (selectedPrincipleCount) + (selectedAssociateCount) + otherCount;
            }
            return selectCount;
        }

        function getCheckedArrayCount(data) {
            var count = 0;
            angular.forEach(data, function(status){
                count += status ? 1 : 0;
            });
            return count; 
        }

        /*---------- Initial Service Calls Data for Form Elements --------------*/
        //Get Salutation Type List Service
        DataService.get('MediationSalutation').then(function(data){
            $scope.salutationList = data.results;
        });

        //Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
            if(data.errorCode == 0){
                $scope.lawFirmList = data.results;
            } else {
                $scope.lawFirmList = [];
            }
            
        });

        //Get Dispute Type List Service
        DataService.get('MediationDistriputeList').then(function(data){
            $scope.distriputeList = data.results;
        });

        //Get Language List Service
        DataService.get('MediationLanguageList').then(function(data){
            $scope.languageList = data.results;
        });

        //Get Profession/Industry List Service
        DataService.get('MediationIndustryList').then(function(data){
            $scope.industryList = data.results;
        });

        //Get Specialisation List Service
        DataService.get('MediationSpecialisationList').then(function(data){
            $scope.specialisationList = data.results;
        });

        //Get Age Group List Service
        DataService.get('MediationAgeGroupList').then(function(data){
            $scope.ageGroupList = data.results;
        });

        //Get Hear About Us List Service
        DataService.get('MediationHearAboutusList').then(function(data){
            $scope.hearAboutUsList = data.results;
        });

        //Get Country Code List Service
        DataService.get('MediationCountryCodeList').then(function(data){
            $scope.countryCodeList = data.results;
        });

        //Principle Mediator List Service
        
        var principleMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":"Principle Mediator",
                               "name":null
                            }
        DataService.post('MediationMediatorList',principleMediatorQuery).then(function(data){
            $scope.principleMediatorList = data.result.responseData;
        });

        $scope.getprinciplemediator = function(principalmediatorsearch){
            var principleMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":undefinedSetNull(principalmediatorsearch.specialisation),
                               "name":undefinedSetNull(principalmediatorsearch.name)
                            }
        DataService.post('MediationMediatorList',principleMediatorQuery).then(function(data){
            $scope.principleMediatorList = data.result.responseData;
        });
        }

        var associateMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":"Associate Mediator",
                               "name":null
                            }
        DataService.post('MediationMediatorList',associateMediatorQuery).then(function(data){
            $scope.associateMediatorList = data.result.responseData;
        });
        $scope.getassosiatemediator = function(assosiatemediatorName){
            var associateMediatorQuery = {
                               "pageIndex":0,
                               "dataLength":100,
                               "sortingColumn":null,
                               "sortDirection":null,
                               "mediatorType":null,
                               "specialisation":"Associate Mediator",
                               "name":undefinedSetNull(assosiatemediatorName.name)
                            }
            DataService.post('MediationMediatorList',associateMediatorQuery).then(function(data){
                $scope.associateMediatorList = data.result.responseData;
            });
        }

        //Respondent Load Law firm details on selecting law firm and reset
        $scope.loadRespondantLawFirmDetails = function(data,index){
            console.log(data);
            if(data){
                if(data.name == "Others"){
                    $scope.cms_form.respondentInfo[index].lawFirmAddres1 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirmAddres2 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirmAddres3 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirmAddres4 = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirmPostalCode = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirmTelephone = undefined;
                    $scope.cms_form.respondentInfo[index].lawFirmFax = undefined;
                    $scope.RespondentLawFirmStatus[index] = false;
                } else {
                    $scope.cms_form.respondentInfo[index].respresentative_lawfirmId = data.id;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmAddres1 = data.businessAddress.address1;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmAddres2 = data.businessAddress.address2;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmAddres3 = data.businessAddress.address3;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmAddres4 = data.businessAddress.address4;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmPostalCode = data.businessAddress.postalCode;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmTelephone = data.businessAddress.phoneNumber;
                    $scope.cms_form.respondentInfo[index].lawFirm.lawFirmFax = data.businessAddress.faxNumber;
                    $scope.RespondentLawFirmStatus[index] = true;
                }
            } else {
                $scope.cms_form.respondentInfo[index].lawFirmAddres1 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirmAddres2 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirmAddres3 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirmAddres4 = undefined;
                $scope.cms_form.respondentInfo[index].lawFirmPostalCode = undefined;
                $scope.cms_form.respondentInfo[index].lawFirmTelephone = undefined;
                $scope.cms_form.respondentInfo[index].lawFirmFax = undefined;
                $scope.RespondentLawFirmStatus[index] = true;
            }
        }

        $scope.respondentLawyerList = [{
          "lawyers" : [{"id" : "lawyer 1"}]
        }];

        $scope.addNewRespondentLawyer = function(index) {
            var newItemNo = $scope.respondentLawyerList.length+1;
            $scope.respondentLawyerList[index].lawyers.push({'id':'Lawyer '+newItemNo});
        };

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();