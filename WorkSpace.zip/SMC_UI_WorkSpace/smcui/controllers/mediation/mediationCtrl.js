(function() {
    'use strict';
    angular
        .module('smc')
        .controller('mediationCtrl',mediationCtrl);

    mediationCtrl.$inject = ['$rootScope','$scope','$interval','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function mediationCtrl($rootScope,$scope,$interval,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
		
		var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];

    	$scope.medationFormLoad = function(){
    		if($scope.cms_form_type == "CMS"){
    			$rootScope.mediationFormType = "CMS";
    			$rootScope.medationFormTitle = "Commercial Mediation Scheme (CMS)";
    			$state.go('smclayout.cmsFormLayout.cms');
    		} else if($scope.cms_form_type == "SCCMS"){
    			$rootScope.mediationFormType = "SCCMS";
    			$rootScope.medationFormTitle = "Small Case Commercial Mediation Scheme (SCCMS)";
    			$state.go('smclayout.cmsFormLayout.sccms');
    		}
    	}


	}
}
)();