(function() {
    'use strict';
    angular
        .module('smc')
        .controller('araformCtrl',araformCtrl);

    araformCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','navigateConfig','$window','$sce','NotifyFactory'];

    function araformCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,navigateConfig,$window,$sce,NotifyFactory){

    	if ($cookies.get('roleName') != 'respondent' && $cookies.get('roleName') != 'respondentLawyer') {
            $state.go('smclayout.membershiplayout.login');
        }
    	var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches

    	//Error Messages
		$scope.pattern = patternConfig;
		//Default Values settings
		$scope.directFormSataus = true;
    	$scope.isPreviewClicked = false;
    	$scope.claiamentStatus = false;
    	$scope.claiamentServiceAddressStatus = true;
    	$scope.claiamentLawFormDetailStatus = true;
    	$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
    	$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
    	$scope.uenOrnric = "Enter the organisation’s UEN";
    	$scope.respondentIndivStatus = false;
		$scope.registeredRespondentName = "Enter the respondent’s registered name";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
		$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.interestRateOfLatePaymentStatus = false;
		$scope.onlineFormSubmissionStatus = true;
		$scope.onlineFileUploadStatus = false;
		$scope.claimentLegallyRepresentStatus = false;
		$scope.respondentLegallyRepresentStatus = true;
		$scope.claiamentLawyerServiceAddressStatus = true;

		//Form Related Default settings
		$scope.araform = {};
		$scope.araform.claimantInfo = {};
		$scope.araform.claimantInfo.businessAddress = {};

		$scope.araform.claimantInfo.lawFirmDto = {};
		$scope.araform.claimantInfo.lawFirmDto.businessAddress = {};

		$scope.araform.claimantInfo.lawFirmDto.lawyerDetails = [];
		$scope.araform.respondentInfo = {};
		$scope.araform.respondentInfo.businessAddress = {};

		$scope.araform.respondentInfo.lawFirmDto = {};
		$scope.araform.respondentInfo.lawFirmDto.businessAddress = {};
		$scope.araform.respondentInfo.lawFirmDto.lawyerDetails = [];
		$scope.araform.regulationInfo = {};
		$scope.araform.regulationInfo.principalName = undefined;
		$scope.araform.contractInfo = {};
		$scope.araform.paymentInfo = {};
		$scope.araform.caseDto = {};

        GetARAFormDetails();
		$scope.araform.claimantInfo.caseMemberRoleType = "Organisation";
		$scope.araform.respondentInfo.caseMemberRoleType = "Organisation";
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.claimantLawFirmStatus = true;
		$scope.respondantLawFirmStatus = true;
		$scope.araform.claimantInfo.businessAddress.isServiceAddress = false;
		$scope.araform.claimantInfo.isLegallyRepresented = "Yes";
		$scope.araform.respondentInfo.isLegallyRepresented = "No";
		$scope.araform.respondentInfo.businessAddress.isServiceAddress = false;
		$scope.araform.respondentInfo.lawFirmDto.businessAddress.isServiceAddress = false;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.termsUploadPathStatus = false;
		$scope.paymentClaimUploadPathStatus = false;
		$scope.paymentResponseUploadPathStatus = false;
		$scope.intentionNoticeUploadPathStatus = false;
		$scope.otherDocUploadPathStatus = false;
		$scope.termsErrorStatus = false;
		$scope.paymentClaimErrorStatus = false;
		$scope.paymentResponseErrorStatus = false;
		$scope.intentionNoticeErrorStatus = false;
		$scope.otherDocErrorStatus = false;
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.isSubmitted = false;
        
		$rootScope.tempCaseNumber = null;

		$scope.toDateMinLimit = 0;

		//get ARA Form Details
        function GetARAFormDetails(){
            var GetARAFormDetailsUrl = smcConfig.services.GetARAFormDetails.url;
				GetARAFormDetailsUrl = GetARAFormDetailsUrl + $cookies.get('caseNumber');
				$http.get(GetARAFormDetailsUrl).then(function(data){
	        		console.log("ara-data",data)
	        		$scope.araform = data.data.result;
                    $scope.araform.changeRespondentDeatils = true;
                    if($scope.araform.claimantInfo.caseMemberRoleType == "Individual"){
                        $scope.claiamentStatus = true;
                        $scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
                        $scope.uenOrnricLabel = "NRIC/Passport Number";
                        $scope.uenOrnric = "Enter your NRIC / Passport No.";
                    } else {
                        $scope.claiamentStatus = false;
                        $scope.registeredClaimantName = "Enter your name as reflected in your business profile";
                        $scope.uenOrnricLabel = "Unique Entity Number (UEN)";
                        $scope.uenOrnric = "Enter the organisation’s UEN";
                    }

                    if($scope.araform.claimantInfo.businessAddress.isServiceAddress == false){
                        $scope.claiamentServiceAddressStatus = true;
                    } else {
                        $scope.claiamentServiceAddressStatus = false;
                    }
                    $rootScope.respondentName = $scope.araform.respondentInfo.memberName;
                    if($scope.araform.claimantInfo.isLegallyRepresented == "Yes"){
                        $scope.claiamentLawFormDetailStatus = true;
                        $scope.claimentLegallyRepresentStatus = false;
                    } else {
                        $scope.claiamentLawFormDetailStatus = false;
                        $scope.claimentLegallyRepresentStatus = true;
                    }
                    if($scope.araform.claimantInfo.lawFirmDto){
                        if($scope.araform.claimantInfo.lawFirmDto.businessAddress.isServiceAddress == false){
                            $scope.claiamentLawyerServiceAddressStatus = true;
                        } else {
                            $scope.claiamentLawyerServiceAddressStatus = false;
                        }
                    }
                    

                    if($scope.araform.respondentInfo.caseMemberRoleType == "Individual"){
                        $scope.respondentIndivStatus = true;
                        $scope.registeredRespondentName = "Enter the respondent’s registered name";
                        $scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
                        $scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
                    } else {
                        $scope.respondentIndivStatus = false;
                        $scope.registeredRespondentName = "Enter the respondent’s registered name";
                        $scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
                        $scope.uenOrnricRespondent = "Enter the organisation’s UEN";
                    }

                    if($scope.araform.respondentInfo.businessAddress.isServiceAddress == false){
                        $scope.respondentServiceAddressStatus = true;
                    } else {
                        $scope.respondentServiceAddressStatus = false;
                    }

                    if($scope.araform.respondentInfo.isLegallyRepresented == "Yes"){
                        $scope.respondentLawFormDetailStatus = true;
                        $scope.respondentLegallyRepresentStatus = false;
                    } else if ($scope.araform.respondentInfo.isLegallyRepresented == "No"){
                        $scope.respondentLawFormDetailStatus = false;
                        $scope.respondentLegallyRepresentStatus = true;
                    } else {
                        $scope.respondentLawFormDetailStatus = false;
                        $scope.respondentLegallyRepresentStatus = false;
                    }
                    if($scope.araform.respondentInfo.lawFirmDto){
                        if($scope.araform.respondentInfo.lawFirmDto.businessAddress.isServiceAddress == false){
                            $scope.respondentLawyerServiceAddressStatus = true;
                        } else {
                            $scope.respondentLawyerServiceAddressStatus = false;
                        }
                    }

                    if($scope.araform.respondentInfo.serviceAddress){
                        if($scope.araform.respondentInfo.serviceAddress.faxNumber){
                            $scope.araform.respondentInfo.serviceAddress.faxNumber = $scope.araform.respondentInfo.serviceAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.respondentInfo.serviceAddress.phoneNumber){
                            $scope.araform.respondentInfo.serviceAddress.phoneNumber = $scope.araform.respondentInfo.serviceAddress.phoneNumber.substring(2);
                        }
                    }
                    if($scope.araform.claimantInfo.serviceAddress){
                        if($scope.araform.claimantInfo.serviceAddress.faxNumber){
                            $scope.araform.claimantInfo.serviceAddress.faxNumber = $scope.araform.claimantInfo.serviceAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.claimantInfo.serviceAddress.phoneNumber){
                            $scope.araform.claimantInfo.serviceAddress.phoneNumber = $scope.araform.claimantInfo.serviceAddress.phoneNumber.substring(2);
                        }
                    }
                    if($scope.araform.respondentInfo.businessAddress.faxNumber){
                        $scope.araform.respondentInfo.businessAddress.faxNumber = $scope.araform.respondentInfo.businessAddress.faxNumber.substring(3);
                    }
                    if($scope.araform.respondentInfo.businessAddress.phoneNumber){
                        $scope.araform.respondentInfo.businessAddress.phoneNumber = $scope.araform.respondentInfo.businessAddress.phoneNumber.substring(2);
                    }
                    
                    if($scope.araform.claimantInfo.businessAddress.faxNumber){
                        $scope.araform.claimantInfo.businessAddress.faxNumber = $scope.araform.claimantInfo.businessAddress.faxNumber.substring(3);
                    }

                    if($scope.araform.claimantInfo.businessAddress.phoneNumber){
                        $scope.araform.claimantInfo.businessAddress.phoneNumber = $scope.araform.claimantInfo.businessAddress.phoneNumber.substring(2);
                    }
                    
                    if($scope.araform.respondentInfo.lawFirmDto){
                        if($scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber){
                            $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber = $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
                            $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber = $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                        }
                        if($scope.araform.respondentInfo.lawFirmDto.serviceAddress){
                            if($scope.araform.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
                                $scope.araform.respondentInfo.lawFirmDto.serviceAddress.faxNumber = $scope.araform.respondentInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                            }
                            if($scope.araform.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
                                $scope.araform.respondentInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.araform.respondentInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
                            }
                        }
                    }
                    if($scope.araform.claimantInfo.lawFirmDto){
                        if($scope.araform.claimantInfo.lawFirmDto.businessAddress.faxNumber){
                            $scope.araform.claimantInfo.lawFirmDto.businessAddress.faxNumber = $scope.araform.claimantInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.claimantInfo.lawFirmDto.businessAddress.phoneNumber){
                            $scope.araform.claimantInfo.lawFirmDto.businessAddress.phoneNumber = $scope.araform.claimantInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                        }
                        if($scope.araform.claimantInfo.lawFirmDto.serviceAddress){
                            if($scope.araform.claimantInfo.lawFirmDto.serviceAddress.faxNumber){
                                $scope.araform.claimantInfo.lawFirmDto.serviceAddress.faxNumber = $scope.araform.claimantInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                            }
                            if($scope.araform.claimantInfo.lawFirmDto.serviceAddress.phoneNumber){
                                $scope.araform.claimantInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.araform.claimantInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
                            }
                        }
                    }
                    
                    
					if($scope.araform.supportingDocuments){
						if($scope.araform.supportingDocuments[0]){
                            var splitedDocNames1 = $scope.araform.supportingDocuments[0].fileLocation.split("\\");
							$scope.araform.relevantProofDocs_name = splitedDocNames1[splitedDocNames1.length-1];
							$scope.araform.relevantProofDocs = $scope.araform.supportingDocuments[0].fileLocation;
							$scope.relevantProofDocsStatus = true;
						}
						if($scope.araform.supportingDocuments[1]){
                            var splitedDocNames2 = $scope.araform.supportingDocuments[1].fileLocation.split("\\");
							$scope.araform.adjudicationDeterminationDocs_name = splitedDocNames2[splitedDocNames2.length-1];
							$scope.araform.adjudicationDeterminationDocs = $scope.araform.supportingDocuments[1].fileLocation;
							$scope.adjudicationDeterminationDocsStatus = true;
						}
						if($scope.araform.supportingDocuments[2]){
                            var splitedDocNames3 = $scope.araform.supportingDocuments[2].fileLocation.split("\\");
							$scope.araform.adjudicationApplicationDocs_name = splitedDocNames3[splitedDocNames3.length-1];
							$scope.araform.adjudicationApplicationDocs = $scope.araform.supportingDocuments[2].fileLocation;
							$scope.adjudicationApplicationDocsStatus = true;
						}
						
					}
                    if(parseInt($rootScope.adjtedAmnt) < 1000000){
                        $scope.araform.adjudicatedAmount="100000.00";
                        $scope.araform.adjudicatedReviewAmount="100000.00";
                    }else{
                        $scope.araform.adjudicatedAmount="1000000.00";
                        $scope.araform.adjudicatedReviewAmount="1000000.00";
                    }
                    
	        	})
                .catch(function(error){
                    console.log('errorcaselist',error);
                });;
        }

        $scope.checkValueRange=function(amount){
            if(parseInt(amount)<100000){
                $scope.lesserValue=true;
            }else{
                $scope.lesserValue=false;
            }
        }

        //Respondent Click Actions
		$scope.respondentTypeClick = function(){
			$scope.araform.respondentInfo.applicantUidValue = undefined;
			$scope.araform.respondentInfo.gender = undefined;
			if($scope.araform.respondentInfo.caseMemberRoleType == "Individual"){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			} else {
				$scope.respondentIndivStatus = false;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
			}
		}

        // SAve ARA Foem
        $scope.formARA1Save = function(araForm){
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            var copyaraForm = angular.copy(araForm);
            var query = buildQurey(copyaraForm);
            DataService.post('SaveARAForm',query).then(function (data) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                if(data.status == "SUCCESS"){
                    $rootScope.araCaseNumber = data.result;
                    $scope.onlineFormActiveStatus = false;
                    $scope.onlineSubmitStatus = false;
                    $scope.onlineSaveStatus = true;
                }
                
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });
        }

		//Submit ARA Form
        $scope.formARASubmit = function(araForm){
			angular.element(".form-submitt-confirm").css("display","none");
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            var copyaraForm = angular.copy(araForm);
            var query = buildQurey(copyaraForm);
            DataService.post('SubmitARAForm',query).then(function (data) {
                if(data.status == "SUCCESS"){
					$scope.isPreviewClicked = false;
					$rootScope.araCaseNumber = data.result.araCaseNumber;
                    $scope.dateOfSubmission = data.result.dateOfSubmission;
                    $scope.timeOfSubmission = data.result.timeOfSubmission;
                    var generateDownloadUrl = smcConfig.services.DownloadARAForm.url;
                    $scope.downloadUrl = generateDownloadUrl + $rootScope.araCaseNumber;
					$scope.onlineFormActiveStatus = false;
					$scope.onlineSubmitStatus = true;
					$scope.onlineSaveStatus = false;
                    $rootScope.callFuntion();
					angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
				}
            })
            .catch(function(error){
                console.log('errorcaselist',error);
                NotifyFactory.log('error' , error.errorMessage)
            });
        }
		function buildQurey(form){
            if(form.respondentInfo.businessAddress.faxNumber){
                form.respondentInfo.businessAddress.faxNumber = '+65'+form.respondentInfo.businessAddress.faxNumber;
            }
            if(form.respondentInfo.businessAddress.phoneNumber){
                form.respondentInfo.businessAddress.phoneNumber = '65'+form.respondentInfo.businessAddress.phoneNumber;
            }
            if(form.respondentInfo.serviceAddress){
                if(form.respondentInfo.serviceAddress.faxNumber){
                    form.respondentInfo.serviceAddress.faxNumber = '+65'+form.respondentInfo.serviceAddress.faxNumber;
                }
                if(form.respondentInfo.serviceAddress.phoneNumber){
                    form.respondentInfo.serviceAddress.phoneNumber = '65'+form.respondentInfo.serviceAddress.phoneNumber;
                } 
            }
			var query = {
                "caseNumber":form.caseNumber,
                "araCaseNumber":undefinedSetNull($rootScope.araCaseNumber),
                "adjudicatedAmount":form.adjudicatedAmount,
                "responseAmount":form.responseAmount,
                "adjudicatedReviewAmount":form.adjudicatedReviewAmount,
                "authRepName":form.resAuthPersonName,
                "authRepReferenceNum":form.resAuthPersonRefNumber,
                "respondentInfo":{  
                    "businessAddress":form.respondentInfo.businessAddress,
                    "serviceAddress":form.respondentInfo.serviceAddress
                },
            }
            query.araDocuments = [];

            if(form.relevantProofDocs){
                var relevantDoc = {  
                    "name":"Relevant Proof of Payment of Adjudicated Amount to Claimant",
                    "fileLocation":undefinedSetNull(form.relevantProofDocs)
                }
                query.araDocuments.push(relevantDoc);
            }
            if(form.adjudicationDeterminationDocs){
                var DeterDoc = {  
                    "name":"Copy of the Adjudication Determination",
                    "fileLocation" : undefinedSetNull(form.adjudicationDeterminationDocs)
                }
                query.araDocuments.push(DeterDoc);
            }
            if(form.adjudicationApplicationDocs){
                var adjAppDoc = {  
                    "name":"Copy of the Adjudication Application",
                    "fileLocation":undefinedSetNull(form.adjudicationApplicationDocs)
                }
                query.araDocuments.push(adjAppDoc);
            }
            return query;
		}
		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
				// $scope.cliamentLegallyRepresentedClick();
				// $scope.respondentLegallyRepresentedClick();
			} else {
				$scope.lawFirmList = [];
			}
			
        });
		// upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file,filePath,fileName){
            angular.element(".loading-container").css("display","block");
            angular.element(".overlay").css("display","block");
            $scope.supprtDocumentName='';
            $scope.supportingDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    $scope.araform[fileName] = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.araform[filePath] = data.result;
                        $scope[filePath+'Status'] = true;
                        angular.element(".loading-container").css("display","none");
                        angular.element(".overlay").css("display","none");
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                    angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
                angular.element(".loading-container").css("display","none");
            }
        }
       
        // if we want remove upload file
        $scope.attachcopyRemove = function(file,file_name){
            $scope.araform[file_name] = undefined;
            $scope.araform[file] = undefined;
            $scope[file+'Status'] = false;
            angular.element("#"+file_name).val("");
            angular.element("#"+file).val("");
        }
       
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if(allowedExt[i] == ext){
					return true;
				}
			}
		}


		

		$scope.backToForm = function(){
			$scope.onlineFormActiveStatus = true;
			$scope.onlineSubmitStatus = false;
			$scope.onlineSaveStatus = false;
		}

		//Form Preview
    	$scope.aa1FormPreview = function(newItem){
    		
		   $scope.isPreviewClicked = false;
		   $scope.termsUploadPathStatus = false;
		   $scope.paymentClaimUploadPathStatus = false;
		   $scope.paymentResponseUploadPathStatus = false;
		   $scope.intentionNoticeUploadPathStatus = false;
		   $scope.otherDocUploadPathStatus = false;
		   //Validate Claimant Details are entered
			var claimentInvalid = angular.element("#araform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#araform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.isPreviewClicked = true; 
			}
		}
		$scope.aa1FormPreviewHide = function(newItem){
		   $scope.isPreviewClicked = false;
		   $scope.termsUploadPathStatus = true;
		   $scope.paymentClaimUploadPathStatus = true;
		   $scope.paymentResponseUploadPathStatus = true;
		   $scope.intentionNoticeUploadPathStatus = true;
		   $scope.otherDocUploadPathStatus = true;
		}

		$scope.confirmSubmit = function(){
			DataService.get('GetConfirmMessageAAform').then(function(data){
				$scope.displayMessage = data.result.displayMessage;
			});
			angular.element(".overlay").css("display","block");
			angular.element(".form-submitt-confirm").css("display","block");
		}

		$scope.cancelSubmit = function(){
			angular.element(".overlay").css("display","none");
			angular.element(".form-submitt-confirm").css("display","none");
		}

        //Respondent Load Law firm details on selecting law firm and reset
        $scope.loadRespondantLawFirmDetails = function(data){
            if($scope.araform.respondentInfo.lawFirmDto == undefined){
                $scope.araform.respondentInfo.lawFirmDto = {}
            }
            if($scope.araform.respondentInfo.lawFirmDto.businessAddress == undefined){
                $scope.araform.respondentInfo.lawFirmDto.businessAddress = {};
            }
            console.log(data);
            if(data){
                if(data.name == "Others"){
                    $scope.araform.respondentInfo.lawFirmDto.name = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
                    $scope.respondantLawFirmStatus = false;
                } else {
                    $scope.araform.respondentInfo.lawFirmDto.name = data.name;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
                    $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
                    $scope.respondantLawFirmStatus = true;
                }
            } else {
                $scope.araform.respondentInfo.lawFirmDto.name = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
                $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
                $scope.respondantLawFirmStatus = true;
            }
        }

		

		//Generate Download URL
		var generateDownloadUrl = smcConfig.services.DownloadAAForm.url;
		$rootScope.downloadUrl = generateDownloadUrl + "/" + $rootScope.pdfCaseNumber;
		
		$scope.openPrintPdf = function(){
            angular.element(".downloadLink").html(" ");
			var generatePdfUrl = smcConfig.services.DownloadAAForm.url;
            generatePdfUrl = generatePdfUrl + "/" + $rootScope.pdfCaseNumber;
			// Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'ARA Case'+$rootScope.pdfCaseNumber;
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="ARAform.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element(".overlay").css("display","block");
                angular.element("#aa_pdf_view").css("display","block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                    angular.element(".overlay").css("display","block");
                angular.element("#aa_pdf_view").css("display","block");
                }
            });
		}
		$scope.closePrintPdf = function(formId){
			angular.element(".overlay").css("display","none");
			angular.element("#"+formId).css("display","none");
		}


		function undefinedSetNull(val){
			if(val){
				return val;
			} else {
				var val = null;
				return val;
			}
			return val;
		}
		$scope.proceedToPayment = function(){
			/*if(animating) return false;
			animating = true;*/

			current_fs = $(".aa1-form-wizard1");
			next_fs = $(".aa1-form-wizard2");

			$rootScope.nextWisard(next_fs,current_fs);
		}

		$rootScope.nextWisard = function(next_fs,current_fs){
			//activate next step on progressbar using the index of next_fs
			$(".processbar-controller li").eq($("fieldset").index(current_fs)).removeClass("current").removeClass("error").addClass("active");
			$(".processbar-controller li").eq($("fieldset").index(next_fs)).addClass("current");
			
			//show the next fieldset
			next_fs.show(); 
			//hide the current fieldset with style
			current_fs.hide();
			current_fs.animate({opacity: 0}, {
				step: function(now, mx) {
					//as the opacity of current_fs reduces to 0 - stored in "now"
					//1. scale current_fs down to 80%
					scale = 1 - (1 - now) * 0.2;
					//2. bring next_fs from the right(50%)
					left = (now * 50)+"%";
					//3. increase opacity of next_fs to 1 as it moves in
					opacity = 1 - now;
					current_fs.css({'transform': 'scale('+scale+')'});
					next_fs.css({'left': left, 'opacity': opacity});
				}, 
				duration: 800, 
				complete: function(){
					current_fs.hide();
					animating = false;
				}, 
				//this comes from the custom easing plugin
				easing: 'easeInOutBack'
			});
		}
		$rootScope.previousWisard = function (current_fs,previous_fs){
			current_fs = $("."+current_fs);
			previous_fs = $("."+previous_fs);
			//de-activate current step on progressbar
			$(".processbar-controller li").eq($("fieldset").index(current_fs)).removeClass("current").removeClass("error");
			
			//show the previous fieldset
			previous_fs.show(); 
			//hide the current fieldset with style
			current_fs.hide();
			current_fs.animate({opacity: 0}, {
				step: function(now, mx) {
					//as the opacity of current_fs reduces to 0 - stored in "now"
					//1. scale previous_fs from 80% to 100%
					scale = 0.8 + (1 - now) * 0.2;
					//2. take current_fs to the right(50%) - from 0%
					left = ((1-now) * 50)+"%";
					//3. increase opacity of previous_fs to 1 as it moves in
					opacity = 1 - now;
					current_fs.css({'left': left});
					previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
				}, 
				duration: 800, 
				complete: function(){
					current_fs.hide();
				}, 
				//this comes from the custom easing plugin
				easing: 'easeInOutBack'
			});
		}
 	}
 })();