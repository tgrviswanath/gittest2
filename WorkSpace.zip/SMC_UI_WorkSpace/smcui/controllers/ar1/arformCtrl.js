(function() {
    'use strict';
    angular
        .module('smc')
        .controller('ar1formCtrl',ar1formCtrl);


    ar1formCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','navigateConfig','$window','$sce'];

    function ar1formCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,navigateConfig,$window,$sce){		
		var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	if (tab == 'respondantsubmitform'){
	    	if ($cookies.get('roleName') != 'respondent' && $cookies.get('roleName') != 'respondentLawyer') {
	            $state.go('smclayout.membershiplayout.login');
	        }
    	}
    	if($cookies.get('roleName') == "adjudicator"){
	    	$scope.downloadButtonStatus = false;
	    } else {
	    	$scope.downloadButtonStatus = true;
	    }
		$scope.registeredRespondentName = "Enter your name as reflected in your business profile";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number";
		$scope.uenOrnricRespondent = "Enter the respondent's identification number";
		var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
		if(tab != 'inprogress'){
			$rootScope.caseNumber = $cookies.get('caseNumber');
		}
		$scope.roleName = $cookies.get('roleName');
	    $scope.navigateConfig = navigateConfig;
	    $scope.backtoform = navigateConfig.BacktoCase[$scope.roleName].url;
		$scope.respondentIndivStatus = false;
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.respondentLegallyRepresentStatus = true;
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.ar1_form1 = {};
		$scope.ar1_form1.respondentInfo = {};
		$scope.ar1_form1.respondentInfo.businessAddress = {};
		$scope.ar1_form1.respondentInfo.lawFirmDto = {};
		$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress = {};
		$scope.ar1_form1.respondentInfo.caseMemberRoleType = "Organisation";
		$scope.ar1_form1.respondentInfo.isLegallyRepresented = "No";
		$scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress = false;
		$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress = false;
		$scope.otherDocErrorStatus = false;
		$scope.attachcopyStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
    	$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
    	$scope.documents = [true];
    	$scope.documentname = [];
		$scope.documentPath = [];
		$scope.documentUrl = [];
		$scope.termsUploadPathStatus = [];
    	//Error Messages
		$scope.pattern = patternConfig;


		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
				$scope.respondentLegallyRepresentedClick();
			} else {
				$scope.lawFirmList = [];
			}
			
        });

        //Get Contract Type List Service
        DataService.get('GetContractTypeList').then(function(data){
			$scope.contractTyoeList = data.results;
        });

        //Get Dispute Nature List Service
        DataService.get('GetDisputeNatureList').then(function(data){
			$scope.disputeNatureList = data.results;
        });


		$scope.respondentServiceAddressClick = function(){

			if($scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress == false){
				$scope.respondentServiceAddressStatus = true;
			} else {
				$scope.respondentServiceAddressStatus = false;
			}
		}

		$scope.respondentLegallyRepresentedClick = function(){

			if($scope.ar1_form1.respondentInfo.isLegallyRepresented == "Yes"){
				$scope.respondentLawFormDetailStatus = true;
				$scope.respondentLegallyRepresentStatus = false; 
			} else {
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = true;
			}
		}

		$scope.respondentLawyerServiceAddressClick = function(){

			if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress == false){
				$scope.respondentLawyerServiceAddressStatus = true;
			} else {
				$scope.respondentLawyerServiceAddressStatus = false;
			}
		}

		//Respondent Load Law firm details on selecting law firm and reset
		$scope.loadRespondantLawFirmDetails = function(data){
			if($scope.ar1_form1.respondentInfo.lawFirmDto == undefined){
				$scope.ar1_form1.respondentInfo.lawFirmDto = {}
			}
			if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress == undefined){
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress = {};
			}
			console.log(data);
			if(data){
				if(data.name == "Others"){
					$scope.ar1_form1.respondentInfo.lawFirmDto.name = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
					$scope.respondantLawFirmStatus = false;
				} else {
					$scope.ar1_form1.respondentInfo.lawFirmDto.name = data.name;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
					$scope.respondantLawFirmStatus = true;
				}
			} else {
				$scope.ar1_form1.respondentInfo.lawFirmDto.name = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
				$scope.respondantLawFirmStatus = true;
			}
		}



		$scope.contractTypeClick = function(){
			var contactTypes = JSON.parse($scope.ar1_form1.contractInfo.contractType);
			if(contactTypes.type == "Construction"){
				$scope.natureOfDistributeStatus = true;
			} else {
				$scope.ar1_form1.contractInfo.natureOfDispute = undefined;
				$scope.natureOfDistributeStatus = false;
			}
		}

		getAR1_Form_Details();//call function
		//to get AR form Details
		function getAR1_Form_Details(){
			var serviceGetARformDetailsUrl = smcConfig.services.GetARformDetails.url;
			serviceGetARformDetailsUrl = serviceGetARformDetailsUrl + "/" + $rootScope.caseNumber;
			$http.get(serviceGetARformDetailsUrl).then(function(data){
				$scope.ar1_form1 = data.data.result;
				if($scope.ar1_form1.contractInfo){
					if($scope.ar1_form1.contractInfo.contractTypeDto){
						$scope.ar1_form1.contractInfo.contractType = JSON.stringify($scope.ar1_form1.contractInfo.contractTypeDto);
						if($scope.ar1_form1.contractInfo.contractTypeDto.type == "Construction"){
							$scope.natureOfDistributeStatus = true;
						}
					}
					if($scope.ar1_form1.respondentInfo){
						if($scope.ar1_form1.respondentInfo.lawFirmDto){
							$scope.ar1_form1.respondentInfo.lawFirmDto.id = { 'id' : $scope.ar1_form1.respondentInfo.lawFirmDto.id};
						}
					}
				}
				if($scope.ar1_form1.respondentInfo.caseMemberRoleType == 'Individual'){
					$scope.respondentIndivStatus = true;
					$scope.registeredRespondentName = "Enter the respondent’s registered name";
					$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
					$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
				} 
				for(var doc in $scope.ar1_form1.supportingDocuments){
					$scope.documents[doc]=true;
					$scope.termsUploadPathStatus[doc] = true;
					$scope.documentname[doc] = $scope.ar1_form1.supportingDocuments[doc].name;
					$scope.documentPath[doc] = $scope.ar1_form1.supportingDocuments[doc].fileLocation;
					$scope.documentUrl[doc] = smcConfig.services.DownloadSupportingDocument.url+$scope.ar1_form1.supportingDocuments[doc].id;
				}
				$scope.roleName = $cookies.get('roleName');
	    		$scope.backtoform = navigateConfig.BacktoCase[$scope.roleName].url;
	    		if($scope.ar1_form1.respondentInfo.isLegallyRepresented != "No"){
	    			$scope.respondentLegallyRepresentStatus = false;
	    		}

	    		if($scope.ar1_form1.respondentInfo.serviceAddress){
	            	if($scope.ar1_form1.respondentInfo.serviceAddress.faxNumber){
		                $scope.ar1_form1.respondentInfo.serviceAddress.faxNumber = $scope.ar1_form1.respondentInfo.serviceAddress.faxNumber.substring(3);
		            }
		            if($scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber){
		                $scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber = $scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber.substring(2);
		            }
	            }
	            

	    		if($scope.ar1_form1.respondentInfo.businessAddress.faxNumber){
                    $scope.ar1_form1.respondentInfo.businessAddress.faxNumber = $scope.ar1_form1.respondentInfo.businessAddress.faxNumber.substring(3);
                }
                
                if($scope.ar1_form1.respondentInfo.businessAddress.phoneNumber){
                	$scope.ar1_form1.respondentInfo.businessAddress.phoneNumber = $scope.ar1_form1.respondentInfo.businessAddress.phoneNumber.substring(2)
                }
                
                
                if($scope.ar1_form1.respondentInfo.lawFirmDto){
                    if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                    }
                    if($scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                    }

                    if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                    }
                    if($scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
                    }
                }
                if($scope.ar1_form1.regulationInfo){
	            	if($scope.ar1_form1.regulationInfo.ownerAddress){
	            		if($scope.ar1_form1.regulationInfo.ownerAddress.faxNumber){
	            			$scope.ar1_form1.regulationInfo.ownerAddress.faxNumber = $scope.ar1_form1.regulationInfo.ownerAddress.faxNumber.substring(3);
	            		}
	            	}
	            	if($scope.ar1_form1.regulationInfo.principalAddress){
	            		if($scope.ar1_form1.regulationInfo.principalAddress.faxNumber){
	            			$scope.ar1_form1.regulationInfo.principalAddress.faxNumber = $scope.ar1_form1.regulationInfo.principalAddress.faxNumber.substring(3);
	            		}
	            	}
	            }

			})
		}

		$scope.supportingDocYes = function(){
			if($scope.ar1_form1.respondentInfo.anySupportingDocument == true){
				angular.element(".overlay").css("display","block");
				angular.element("#supportingDocPopup").css("display","block");
			}
		}

		$scope.supportingDocNotificationPopup = function(){
			angular.element(".overlay").css("display","none");
			angular.element("#supportingDocPopup").css("display","none");
		}

		$scope.confirmSubmit = function(){
			DataService.get('GetConfirmMessageARform').then(function(data){
				$scope.displayARMessage = data.result.displayMessage;
			});
			angular.element(".overlay").css("display","block");
			angular.element("#submitFormconfirmPopup").css("display","block");
		}

		$scope.cancelSubmit = function(){
			angular.element(".overlay").css("display","none");
			angular.element("#submitFormconfirmPopup").css("display","none");
		}

		//Form Preview
    	$scope.ar1FormPreview = function(newItem){
		   $scope.isPreviewClicked = false;
		   for(var value in $scope.termsUploadPathStatus){
		   		$scope.termsUploadPathStatus[value] = false;
		   }
		   //Validate Claimant Details are entered
			var claimentInvalid = angular.element("#respondantAR1form .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;

			if(claimentInvalidCount > 0){
				angular.element("#respondantAR1form .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.isPreviewClicked = true; 
			}
		}
		$scope.ar1FormPreviewHide = function(newItem){
		   $scope.isPreviewClicked = false;
		   for(var value in $scope.termsUploadPathStatus){
		   		$scope.termsUploadPathStatus[value] = true;
		   }
		}

		// to save AR Form
		$scope.formAR1Save = function(form_details){
			$scope.saveQuery = buildQurey();
			console.log("saveQuery",$scope.saveQuery)
			if($scope.saveQuery){
				DataService.post('SaveARForm',$scope.saveQuery).then(function(data){
					console.log(data);
					if(data.status == "SUCCESS"){
						$rootScope.caseNumber = data.result;
						$scope.onlineFormActiveStatus = false;
						$scope.onlineSubmitStatus = false;
						$scope.onlineSaveStatus = true;
					}
        		}).catch(function(error){
    				NotifyFactory.log('error',error.errorMessage)
    			});
    		}
		}


		// to submit AR form
		$scope.formAR1Submit = function(form){
			var claimentInvalid = angular.element("#respondantAR1form .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;
			var errorMsgCount = angular.element("#respondantAR1form .help-block:visible").length;
			if(claimentInvalidCount > 0 || errorMsgCount > 0){
				angular.element("#respondantAR1form .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.submitQuery = buildQurey();
				if($scope.submitQuery){
					DataService.post('SubmitARForm',$scope.submitQuery).then(function(data){
						console.log(data);
						if(data.status == "SUCCESS"){
							$scope.isPreviewClicked = false;
							angular.element(".overlay").css("display","none");
							angular.element("#submitFormconfirmPopup").css("display","none");
							$rootScope.submitResponseDetails = data.result;
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = true;
							$scope.onlineSaveStatus = false;
							var timeOfSubmissionView = $rootScope.submitResponseDetails.timeOfSubmission;
							timeOfSubmissionView = timeOfSubmissionView.split(".");

							$scope.timeOfSubmission = timeOfSubmissionView[0];
						}
	        		}).catch(function(error){
	    				NotifyFactory.log('error',error.errorMessage)
	    			});
				}
			}
		}

		// to Build query for Save or Sumbit
		function buildQurey(){
			var respondentInfoQueryVar = respondentInfoQuery();
			var contractInfoQueryVar = contractInfoQuery();
			var supportingDocumentsQueryVar = supportingDocumentsQuery();
			var caseDtoQueryVar = caseDtoQuery();
			var query = { 
				"caseNumber":undefinedSetNull($rootScope.caseNumber),
				"respondentInfo":respondentInfoQueryVar,
				"contractInfo":contractInfoQueryVar,
				"supportingDocuments":supportingDocumentsQueryVar,
				"caseDto": caseDtoQueryVar
			}
			return query;
		}

		// to build respondent query
		function respondentInfoQuery(){
			var query = {};
			if($scope.ar1_form1.respondentInfo){
				var caseMemberRoleType = $scope.ar1_form1.respondentInfo.caseMemberRoleType;
				var applicantUidValue = $scope.ar1_form1.respondentInfo.applicantUidValue;
				var memberName = $scope.ar1_form1.respondentInfo.memberName;
				$rootScope.respondentName = $scope.ar1_form1.respondentInfo.memberName;
				var gender = $scope.ar1_form1.respondentInfo.gender;
				var email = $scope.ar1_form1.respondentInfo.email;
				var authRepresentative = $scope.ar1_form1.respondentInfo.authRepresentative;
				var authRepDesignation = $scope.ar1_form1.respondentInfo.authRepDesignation;
				var payeeName = $scope.ar1_form1.respondentInfo.payeeName;
				var businessAddress = respondentBusinessAddressQuery();
				var serviceAddress = respondentServiceAddressQuery();
				var anySupportingDocument = $scope.ar1_form1.respondentInfo.anySupportingDocument;
				if(!anySupportingDocument){
					anySupportingDocument = false;
				}
				var isLegallyRepresented = $scope.ar1_form1.respondentInfo.isLegallyRepresented;
				var query = { 
					"caseMemberRoleType":undefinedSetNull(caseMemberRoleType),
					"applicantUidValue":undefinedSetNull(applicantUidValue),
				    "memberName":undefinedSetNull(memberName),
				    "gender":undefinedSetNull(gender),
				    "businessAddress":businessAddress,
					"serviceAddress":serviceAddress,
				    "email":undefinedSetNull(email),
				    "authRepresentative":undefinedSetNull(authRepresentative),
				    "authRepDesignation":undefinedSetNull(authRepDesignation),
				    "payeeName":undefinedSetNull(payeeName),
					"anySupportingDocument": anySupportingDocument,
					"isLegallyRepresented":isLegallyRepresented
				};
			}
			return query;
		}
		//build respondent business address
		function respondentBusinessAddressQuery(){
			var query = {};
			if($scope.ar1_form1.respondentInfo.businessAddress){
				var address1 = $scope.ar1_form1.respondentInfo.businessAddress.address1;
				var address2 = $scope.ar1_form1.respondentInfo.businessAddress.address2;
				var address3 = $scope.ar1_form1.respondentInfo.businessAddress.address3;
				var address4 = $scope.ar1_form1.respondentInfo.businessAddress.address4;
				var postalCode = $scope.ar1_form1.respondentInfo.businessAddress.postalCode;
				if($scope.ar1_form1.respondentInfo.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.ar1_form1.respondentInfo.businessAddress.phoneNumber;
				}
				
				if($scope.ar1_form1.respondentInfo.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.ar1_form1.respondentInfo.businessAddress.faxNumber;
				}

				var isLegallyRepresented = $scope.ar1_form1.respondentInfo.isLegallyRepresented;

				if($scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress;
				} else if (isLegallyRepresented == "Yes") {
					var isServiceAddress = null;
				} else {
					var isServiceAddress = false;
				}
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber),
			        "isServiceAddress":isServiceAddress
				};
			}
			return query;
		}

		//build respondent service address
		function respondentServiceAddressQuery(){
			var query = null;
			var respondent_service_address_status = $scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress;
			if(!respondent_service_address_status && $scope.ar1_form1.respondentInfo.serviceAddress != undefined){
				var query = {};
				var address1 = $scope.ar1_form1.respondentInfo.serviceAddress.address1;
				var address2 = $scope.ar1_form1.respondentInfo.serviceAddress.address2;
				var address3 = $scope.ar1_form1.respondentInfo.serviceAddress.address3;
				var address4 = $scope.ar1_form1.respondentInfo.serviceAddress.address4;
				var postalCode = $scope.ar1_form1.respondentInfo.serviceAddress.postalCode;
				if($scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber;
				}
				if($scope.ar1_form1.respondentInfo.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.ar1_form1.respondentInfo.serviceAddress.faxNumber;
				}
				var query = { 
			        "address1":undefinedSetNull(address1),
					"address2":undefinedSetNull(address2),
					"address3":undefinedSetNull(address3),
					"address4":undefinedSetNull(address4),
			        "postalCode":undefinedSetNull(postalCode),
			        "phoneNumber":undefinedSetNull(phoneNumber),
			        "faxNumber":undefinedSetNull(faxNumber)
				};
			};
			return query;
		}

		// to build respondent contract
		function contractInfoQuery(){
			var query = {};
			if($scope.ar1_form1.contractInfo){
				var projectReference = $scope.ar1_form1.contractInfo.projectReference;
				var contractNumber = $scope.ar1_form1.contractInfo.contractNumber;
				if($scope.ar1_form1.contractInfo.contractType && $scope.ar1_form1.contractInfo.contractType != "null"){
					var contractType = JSON.parse($scope.ar1_form1.contractInfo.contractType);
					contractType = contractType.id;
				} else {
					var contractType = undefined;
				}
				
				var natureOfDispute = $scope.ar1_form1.contractInfo.natureOfDispute;
				var contractMadeOn = $scope.ar1_form1.contractInfo.contractMadeOn;
				var mainContractMadeOn = $scope.ar1_form1.contractInfo.mainContractMadeOn;
				var query = {
					"projectReference":undefinedSetNull(projectReference),
					"contractNumber":undefinedSetNull(contractNumber),
					"contractType":undefinedSetNull(contractType),
					"natureOfDispute":undefinedSetNull(natureOfDispute),
					"contractMadeOn":undefinedSetNull(contractMadeOn),
					"mainContractMadeOn":undefinedSetNull(mainContractMadeOn)
				};
			}
			return query;
		}

		// respondent upload documents to build query
		function supportingDocumentsQuery(){
			var query = [];
			if($scope.documentPath.length != 0){
				for(var index = 0;index<$scope.documentPath.length;index++){
					var filepath = {
						"name":$scope.documentname[index],
						"fileLocation":$scope.documentPath[index]
					}
					query.push(filepath);
				}
			}
			return query;
		}


		function caseDtoQuery(){
			var query = {};
			if($scope.ar1_form1.caseDto){
				var claimAmount = $scope.ar1_form1.caseDto.claimAmount;
				if($scope.ar1_form1.caseDto.includeGst == "Yes"){
					var includeGst = true;
				} else if($scope.ar1_form1.caseDto.includeGst == "No") {
					var includeGst = false;
				}
				var authPerson = $scope.ar1_form1.caseDto.resAuthPerson;
				var authPersonRef = $scope.ar1_form1.caseDto.resAuthPersonRef;
				var constitutingDocResponse = $scope.ar1_form1.caseDto.constitutingDocResponse;
				var query = {
					"resAuthPerson":undefinedSetNull(authPerson),
					"resAuthPersonRef":undefinedSetNull(authPersonRef),
					"constitutingDocResponse":undefinedSetNull(constitutingDocResponse)
				};
			}
			return query;
		}

		if($rootScope.caseNumber){
			var caseNo = $rootScope.caseNumber;
		}
		if($rootScope.caseNumber){
			var caseNo = $rootScope.caseNumber;
		}
		$rootScope.pdfCaseNumber = caseNo;

		//Generate Download URL
		var generateDownloadUrl = smcConfig.services.DownloadARForm.url;
		$rootScope.downloadUrl = generateDownloadUrl + "/" + $rootScope.pdfCaseNumber;

		$scope.openPrintPdf = function(){
			angular.element(".downloadLink").html(" ");
			var generatePdfUrl = smcConfig.services.DownloadARForm.url;
            generatePdfUrl = generatePdfUrl + "/" + $rootScope.pdfCaseNumber;
            // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'AR Case'+$rootScope.pdfCaseNumber;
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="ARform.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element(".overlay").css("display","block");
				angular.element("#aa_pdf_view").css("display","block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                    angular.element(".overlay").css("display","block");
				angular.element("#aa_pdf_view").css("display","block");
                }
            });
		}
		$scope.closePrintPdf = function(formId){
			angular.element(".overlay").css("display","none");
			angular.element("#"+formId).css("display","none");
		}

		function undefinedSetNull(val){
			if(val){
				return val;
			} else {
				var val = null;
				return val;
			}
			return val;
		}

//Audit trial
		$scope.openAuditTrialPopup=function(){
			angular.element('.audit-trial-modal').css("display","block");
			angular.element(".overlay").css("display","block");
			var query = {
						"caseNumber":$cookies.get('caseNumber'),
						"formName":"ARForm"				
						};
			DataService.post('AuditTrialData', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                	$scope.shownodataavailable=false;
                    $scope.auditTrialData=data.result.responseData;
                }
            }).catch(function (error) {
                $scope.shownodataavailable=true;
                NotifyFactory.log('error', error.errorMessage);
            });
		}
		
		$scope.closeAuditTrial=function () {
			angular.element('.audit-trial-modal').css("display","none");
			angular.element(".overlay").css("display","none");
		}

		//Respondent Click Actions
		$scope.respondentTypeClick = function(){
			$scope.ar1_form1.respondentInfo.applicantUidValue = undefined;
			$scope.ar1_form1.respondentInfo.gender = undefined;
			if($scope.ar1_form1.respondentInfo.caseMemberRoleType == "Individual"){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter your name as reflected in your NRIC / Passport No";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			} else {
				$scope.respondentIndivStatus = false;
				$scope.registeredRespondentName = "Enter your name as reflected in your business profile";
				$scope.uenOrnricRespondentLabel = "Unique Entity Number";
				$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
			}
		}

		// upload a file - before that check file size,valid exetension
		$scope.uploadFile = function(file,index){
			var file = file;
			var index = index;
			if ( file.size < 5242881 ){
				if(validateUploadFileExtention(file.name)){
					$scope.documentname[index] = file.name;
					console.log('$scope.uploadname',$scope.documentname);
					var fd= new FormData();
					fd.append('file',file);
					httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
						console.log(data);
						$scope.documentPath[index] = data.result;
						console.log('$scope.documentPath',$scope.documentPath)
						$scope.termsUploadPathStatus[index] = true;
					});
				}
				else{
					var elementIdname = "#uploadname"+index;
					angular.element(elementIdname).addClass("error");
					var allowedExt = $scope.fileUploadTypes;
					$scope.termsUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString(); 
					NotifyFactory.log('error',$scope.termsUploadErrorMsg);
				}
			}else{
				NotifyFactory.log('error','Please upload below 5MB file')
			}
		}
		// check valid file by exetension
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if($scope.fileUploadTypes[i] == ext){
					return true;
				}
			}
		}
		// if we want remove upload file
		$scope.termsUploadRemove = function(index){
			var fileCount = 0;
			$scope.documentname[index] = undefined;
			$scope.documentPath[index] = undefined;
			for(var count=0;count<$scope.documentPath.length;count++){
				if($scope.documentPath[count] == undefined){
					fileCount = fileCount+1;
				}
			}
			if(fileCount == $scope.documentPath.length){
				$scope.documentPath =[];
				$scope.documentname = [];
			}
			$scope.termsUploadPathStatus[index] = false;
		}
		// back to form from acknowledgement
		$scope.backToForm = function(){
			$scope.onlineFormActiveStatus = true;
			$scope.onlineSubmitStatus = false;
			$scope.onlineSaveStatus = false;
		}
		// add one more element to upload document
		$scope.addonemoredocument = function(){
			if($scope.documents.length<5){
				$scope.documents.push(true);
			}else{
				NotifyFactory.log('error','limit only 5 documents')
			}
		}
		// remove one more element to upload document
		$scope.removeonemoredocument = function(){
			$scope.documents.pop()
		}
	}
})();