(function() {
    'use strict';
    angular
        .module('smc')
        .controller('respondentCaseDetailCtrl',respondentCaseDetailCtrl);

    respondentCaseDetailCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function respondentCaseDetailCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	
        if ($cookies.get('roleName') != 'respondent' && $cookies.get('roleName') != 'respondentLawyer') {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.schedule_templatefile = 'views/common/case-schedule.html';
        $scope.message_window_Path = 'views/adjudicator/messagewindow.html';
        $scope.userMail = $cookies.get('userMail');
        $scope.casenumber = $cookies.get('caseNumber');
        $scope.downloadServiceUrl = smcConfig.services.DownloadSupportingDocument.url;
        respondentCaseList();// call function
        getcasestatus();
        $scope.respondent_caselist = {};
    	//to get respondent caselist
    	function respondentCaseList(){
    		var query ={
    			'userId':$scope.userMail,
                'caseNumber':$scope.casenumber
    		}
    		DataService.post('GetRespondentcaseList',query).then(function (data) {
    			console.log('caselist',data);
    			$scope.respondent_caselist = data.result;
                $scope.respondent_caselist.adjudicatedAmount = parseInt($scope.respondent_caselist.adjudicatedAmount);
    		})
    		.catch(function(error){
    			console.log('errorcaselist',error)
    		});
    	}

        //get case status whether the form submit or save
        function getcasestatus(){
            var serviceGetSingleCaseStatusUrl = smcConfig.services.GetSingleCaseStatus.url;
            serviceGetSingleCaseStatusUrl = serviceGetSingleCaseStatusUrl  + $scope.casenumber;
            $http.get(serviceGetSingleCaseStatusUrl).then(function(data){
                $scope.caseStatus = data.data.result.caseStatus;
                $scope.caseType = data.data.result.caseType;
                $scope.arLodgedStatus = toFindStatus($scope.caseStatus,'AR Lodged');
                $scope.arSubmitStatus = toFindStatus($scope.caseStatus,'AR Submitted');
                $scope.scheduleStatus = toFindStatus($scope.caseStatus,'Adjudicator Advised On Timeline');
                $scope.messageStatus = toFindStatus($scope.caseStatus,'Adjudicator Initialised Message');
                $scope.determineStatus = toFindStatus($scope.caseStatus,'AA Determined');
                $scope.araSubmittedStatus = toFindStatus($scope.caseStatus,'ARA Submitted');
                $scope.araSavedStatus = toFindStatus($scope.caseStatus,'ARA Saved');
                $scope.araLodgedStatus = toFindStatus($scope.caseStatus,'ARA Lodged');
                $scope.araScheduleStatus = toFindStatus($scope.caseStatus,'Review Adjudicator(s) Advised on Timeline');
                $scope.araPaymantSubmitStatus = toFindStatus($scope.caseStatus,'ARA Payment Pending');
                $scope.araWithdrawApplyStatus = toFindStatus($scope.caseStatus,'Review Adjudicator(s) Withdrawn Request');
            })
            .catch(function(error){
                console.log('errorcaselist',error)
            });
        }

        // find case case to show actions
        function toFindStatus(searchArray,findString){
            for (var i = searchArray.length - 1; i >= 0; i--) {
                if(searchArray[i] == findString){
                    return findString;
                }
            }
        } 

         // go to payment page
            $scope.makePayment = function(){
                $rootScope.respondentName = $scope.respondent_caselist.respondentName;
                $rootScope.araCaseNumber = $cookies.get('caseNumber');
                $rootScope.paymentStatus = true;
                $state.go('smclayout.membershiplayout.arapaymentprocess');
            }

        //open withdraw application
        $scope.openWithDraw = function(caseNumber){
            $scope.withdrawnumber = caseNumber;
            $scope.supprtDocumentName = '';
            $scope.supportingDocument = '';
            $scope.withdraw = {};
            angular.element(".overlay").css("display","block");
            angular.element(".withdraw-application-modal").css("display","block");
        }
        //close withdraw application
        $scope.closeWithdrawpopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".withdraw-application-modal").css("display","none");
        }
        
         // go to addtional deposit payment payment page
        $scope.makeAdditionalDeposit = function(){
            $rootScope.respondentName = $scope.respondent_caselist.respondentName;
            $rootScope.caseNumber = $cookies.get('caseNumber');
            $rootScope.paymentStatus = true;
            $state.go('smclayout.membershiplayout.araadditionaldeposit');
        }

        //submit withdraw application
        $scope.submitwithdraw = function (withdrawData,caseNumber){
            var query = {
                "caseNumber": caseNumber, 
                "requesterRole": 'Respondent', 
                "reason": withdrawData.reason, 
                "requestedDate": withdrawData.requestedDate, 
                "supportingDocument":{ 
                    "name": $scope.supprtDocumentName, 
                    "fileLocation": $scope.supportingDocument
                }
            }
            DataService.post('SubmitARAWithDrawByRespondant',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Withdraw requested successfully');
                   angular.element(".overlay").css("display","none");
                    angular.element(".withdraw-application-modal").css("display","none");
                   
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file,index){
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    $scope.supprtDocumentName = file.name;
                    
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.supportingDocument = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }
        // check valid file by exetension
        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.fileUploadTypes[i] == ext){
                    return true;
                }
            }
        }
        // if we want remove upload file
        $scope.attachcopyRemove = function(){
            $scope.supprtDocumentName = undefined;
            $scope.supportingDocument = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        //view schedule detail
        $scope.getCaseSchedule = function(caseNumber){
            $scope.schedulenumber = caseNumber;
            var GetCaseScheduleUrl = smcConfig.services.GetCaseSchedule.url;
            GetCaseScheduleUrl = GetCaseScheduleUrl + $scope.schedulenumber;
            $http.get(GetCaseScheduleUrl).then(function(data){
                console.log("data",data)
                $scope.schedule = data.data.result;
                if($scope.schedule.isRoomRequired == true){
                    $scope.schedule.isRoomRequired = "Yes";
                }else{
                    $scope.schedule.isRoomRequired = "No";
                }
                if($scope.schedule.isParkingRequired == true){
                    $scope.schedule.isParkingRequired = "Yes";
                }else{
                    $scope.schedule.isParkingRequired = "No";
                }
                angular.element(".overlay").css("display","block");
                angular.element(".respondcase-schedule-model").css("display","block");
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.closeSchedulepopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".respondcase-schedule-model").css("display","none");
        }

        //open Messaging window between claimant/respondent and adjudicator
        $scope.openMessageWindow = function(caseNumber){
            var loginRole = $cookies.get('roleName');
            $rootScope.loginRole = loginRole[0].toUpperCase()+loginRole.slice(1);
            $scope.sendData = {};
            $scope.sendData.caseNumber = caseNumber;
            viewMessages(caseNumber,$rootScope.loginRole);
            angular.element(".overlay").css("display","block");
            angular.element(".reply-messaging-modal").css("display","block");
        }

        //close Messaging window between claimant/respondent and adjudicator
        $scope.closeMessageWindow = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".reply-messaging-modal").css("display","none");
        }
        // save message to others
        $scope.saveMessage = function(messageData){
            console.log('messageData',messageData);
            var query = {
                "id" : $rootScope.msgId,
                "caseNumber":messageData.caseNumber, 
                "adjudicatorId":$rootScope.adjudicatorId, 
                "message":messageData.message, 
                "recipientId":$cookies.get('memberId'),
                "supportDocument": null
            }
            if($scope.supprtDocumentName){
                query["supportDocument"] = { 
                    "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument 
                }
            }
            DataService.post('SaveReplyMessage',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Message saved successfully');
                   viewMessages(messageData.caseNumber,$rootScope.loginRole);
                   $scope.supprtDocumentName = '';
                   $scope.supportingDocument = '';
                   $scope.attachcopyStatus = false;
                   $scope.sendData = {};
                   $scope.sendData.caseNumber = messageData.caseNumber;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        // send message to others
        $scope.sendMessage = function(messageData){
            console.log('messageData',messageData);
            var query = {
                "id" : $rootScope.msgId,
                "caseNumber":messageData.caseNumber, 
                "adjudicatorId":$rootScope.adjudicatorId, 
                "message":messageData.message, 
                "recipientId":$cookies.get('memberId'),
                "supportDocument": null
            }
            if($scope.supprtDocumentName){
                query["supportDocument"] = { 
                    "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument 
                }
            }
            DataService.post('SendReplyMessage',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Message sent successfully');
                   viewMessages(messageData.caseNumber,$rootScope.loginRole);
                   $scope.supprtDocumentName = '';
                   $scope.supportingDocument = '';
                   $scope.attachcopyStatus = false;
                   $scope.sendData = {};
                   $scope.sendData.caseNumber = messageData.caseNumber;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        // get messages
        function viewMessages(caseNumber,role,searchRole){
            $scope.viewSendButton = false;
            var query = {
                "caseNumber":caseNumber, 
                "searchRole":undefinedSetNull(searchRole), 
                "memberRole":role
            }
            DataService.post('ViewMessages',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   $scope.messages = data.results;
                   if($scope.messages[$scope.messages.length-1].role == 'Adjudicator' || $scope.messages[$scope.messages.length-1].role == 'Claimant'){
                        $rootScope.adjudicatorId = $scope.messages[$scope.messages.length-1].memberId;
                        $rootScope.msgId = $scope.messages[$scope.messages.length-1].senderMessageId;
                        $scope.viewSendButton = true;
                    }

                    if(!$rootScope.msgId){
                        for(var msg in $scope.messages){
                            if($scope.messages[msg].role == 'Adjudicator'){
                                $rootScope.msgId = $scope.messages[msg].senderMessageId
                            }
                        }
                    }
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.viewARAForm = function(caseNumber){
            $rootScope.araCaseNumber = caseNumber;
            $cookies.put('currentActionMenu', 'View ARA Form');
            $state.go('smclayout.membershiplayout.viewARAForm');
        }

        $scope.goToSubmitARA = function(caseNumber,adjtedAmnt){
            $rootScope.araCaseNumber = caseNumber;
            $rootScope.adjtedAmnt = adjtedAmnt;
            $state.go('smclayout.membershiplayout.submitARAForm');
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
 })();