(function() {
    'use strict';
    angular
        .module('smc')
        .controller('araAddDepositCtrl',araAddDepositCtrl);

    araAddDepositCtrl.$inject = ['$rootScope','$scope','$interval','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function araAddDepositCtrl($rootScope,$scope,$interval,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
		
		if ($cookies.get('roleName') != 'respondent' && $cookies.get('roleName') != 'respondentLawyer') {
            $state.go('smclayout.membershiplayout.login');
        }
		
		
		$scope.pattern = patternConfig;
		$scope.payment_summary = true;
		$scope.paymentSuccess = false;
		$scope.payment_method = 'CHEQUE';
		$scope.ifcheque = true;
		$scope.ifcashier = false;
		$scope.ifnetbank = false;
		if(!$rootScope.caseNumber){
			$rootScope.caseNumber = $cookies.get('caseNumber');
		}
		$scope.attachcopyStatus = false;
		$scope.attach_copy_name = '';
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.lawyerId = $cookies.get('lawyerId');
		$scope.creditPayment={};
		$scope.downloadPerformaInvoiceUrl = smcConfig.services.DownloadPerformaInvoice.url

		// for e-Net
		var minYear = new Date().getFullYear();
		var maxYear = minYear+30;
		var minMonth = 1;
		var maxMonth = 12;
		$scope.yearList = [];
        for (var expYear = minYear; expYear < maxYear; expYear++) {
            $scope.yearList.push(expYear);
        }
        $scope.monthList = [];
        for (var expMonth = minMonth; expMonth <= maxMonth; expMonth++) {
        	if(expMonth<=9){
        		$scope.monthList.push('0'+expMonth);
        	}else{
        		$scope.monthList.push(expMonth);
        	}
        }

		$rootScope.callFuntion = function(){
			getDeposit();
		}
		getDeposit();
		// get deposit amount
		function getDeposit(){
			if($rootScope.caseNumber){
				var ARADepositeAmountUrl = smcConfig.services.ARADepositeAmount.url;
				ARADepositeAmountUrl = ARADepositeAmountUrl  + $rootScope.caseNumber;
				$http.get(ARADepositeAmountUrl).then(function(data){
	        		console.log("data",data)
	        		$scope.applicationFee = data.data.result.applicationFee;
	        		$scope.depositAmount = data.data.result.depositAmount;
	        		$scope.totalAmount = data.data.result.totalAmount;
	        		$rootScope.tempCaseNumber = data.data.result.tempCaseNumber;
	        		$scope.paidAmount = data.data.result.paidAmount;
	        		$scope.pendingAmount = data.data.result.pendingAmount;
	        		$scope.getBankDetails();
	        	});
	        	var viewAdditionalDepositUrl = smcConfig.services.viewAdditionalDeposits.url;
	            viewAdditionalDepositUrl = viewAdditionalDepositUrl + $rootScope.caseNumber;
	            $http.get(viewAdditionalDepositUrl).then(function(data){
	                console.log("data",data)
	                var depositData = data.data.results[data.data.results.length-1];
	                $rootScope.additionalDepositId = depositData.id;
	                $rootScope.amountPayable = depositData.amount;
	                $rootScope.depositDeadline = depositData.depositDeadline;
	            });
	        }
		}
		$scope.getBankDetails = function(){
			DataService.get('GetBankDetails').then(function(data){
				$scope.accountName = data.result.accountName;
				$scope.accountNumber = data.result.accountNumber;
				$scope.bankName = data.result.bankName;
			});
		}

		// check_method function for which method choose to payment filed
		$scope.check_method = function(method){
			if(method == 'CHEQUE'){
				$scope.ifcheque = true;
				$scope.ifcashier = false;
				$scope.ifnetbank = false;
				$scope.service_charge = false;
			}else if (method == "CASHIERS_ORDER"){
				$scope.ifcheque = false;
				$scope.ifcashier = true;
				$scope.ifnetbank = false;
				$scope.service_charge = false;
			}else if(method=="INTERNET_BANKING"){
				$scope.ifcheque = false;
				$scope.ifcashier = false;
				$scope.ifnetbank = true;
				$scope.ifeNets=false;
				$scope.service_charge = false;
				angular.element(".overlay").css("display","block");
			    angular.element(".internet-bank-popup").css("display","block");          
			}else{
				$scope.ifcheque = false;
				$scope.ifcashier = false;
				$scope.ifnetbank = false;
				$scope.ifeNets=true;
				$scope.service_charge = true;
				$scope.eNetsData = {};
				$scope.eNetsData.amount = $scope.totalAmount;
				$scope.paymentOptions = ['Yes','No'];
				$scope.confirmFullAmount = 'Yes';
			}
		}

		// upload document copy
		$scope.attachcopy = function(event){
			$scope.creditPayment.document={};
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.attachcopyStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						angular.element("#attach_copy").val(fileName);
						if(fileName){
							angular.element("#attach_copy").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.creditPayment.document={"name":fileName,"fileLocation":data.result};
								$scope.attachcopyStatus = true;
							});
						}
					} else {
						angular.element("#attach_copy").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						$scope.attachcopyErrorMsg = "You are allowed to upload only " + allowedExt.toString();
					}
				} else {
					angular.element("#attach_copy").addClass("error");
					$scope.termsErrorStatus = true;
					$scope.attachcopyErrorMsg = "Maximum allowed file size should be 5MB";
				}
			}
		}

		//remove document copy
		$scope.attachcopyRemove = function(){
			$scope.attach_copy_name = undefined;
			$scope.creditPayment.attach_copy = undefined;
			$scope.attachcopyPath = undefined;
			angular.element("#attach_copy").val("");
			angular.element("#attach_copy").val("");
			$scope.attachcopyStatus = false;
		}

		// get e-net amount
		$scope.geteNetAmount = function(confirmation){
			if(confirmation == 'Yes'){
				$scope.eNetsData.amount = $scope.totalAmount;
			}else{
				$scope.eNetsData.amount = $scope.applicationFee;
			}
		}

		// convert card number
		$scope.convertCardNo = function(){
			var numberLen = $scope.eNetsData.referenceNumber.length;
			if(numberLen == 4 || numberLen == 9 || numberLen == 14){
				$scope.eNetsData.referenceNumber = $scope.eNetsData.referenceNumber + '-';
			}
			if(numberLen == 19){
				$scope.hideSubmitBtn = false;
			}else{
				$scope.hideSubmitBtn = true;
			}
		}

		// process to payment
		$scope.addpayment = function(method,payment){
			if(method != 'ENETS'){
				var amountStatus = checkAmountisValid(payment);
			}else{
				var amountStatus = true;
			}
			$rootScope.paymethod = method;
			if (amountStatus){
				console.log("payment",payment);
				if(method=="CHEQUE" || method=="CASHIERS_ORDER"){
					var query = {
						"id":$rootScope.additionalDepositId, 
						"loginId":$cookies.get('memberId'),
						"caseNumber":$cookies.get('caseNumber'), 
						"paymentMode":method, 
						"referenceNumber":payment.referencenumber, 
						"amount":payment.amount, 
						"dateOfOrder":payment.paymentdate, 
						"bankName":payment.bankname,
						"payerName" : payment.payerName
					}
				}else if(method == "ENETS"){
					var selectedMonth = String(payment.month);
					var selectedYear = String(payment.year).substring(2);
					var expiry = selectedMonth + selectedYear;
					query={
						"id":$rootScope.additionalDepositId, 
						"loginId":$cookies.get('memberId'),
						"caseNumber":$cookies.get('caseNumber'),
						"paymentMode":method,
						"referenceNumber":payment.referenceNumber.split('-').join(""), 
						"amount":payment.amount, 
						"dateOfOrder":payment.dateOfOrder, 
						"bankName":payment.bankName,
						"payerName" : payment.payerName,
						"cardHolderName":payment.cardHolderName,
					    "cardCVV":payment.cardCVV,
					    "cardExpiry": expiry
					} 
				}else if(method=="INTERNET_BANKING"){
					var query = {
						"id":$rootScope.additionalDepositId, 
						"loginId":$cookies.get('memberId'),
						"caseNumber":$cookies.get('caseNumber'), 
						"paymentMode":method, 
						"referenceNumber":payment.referencenumber, 
						"amount":payment.amount, 
						"dateOfOrder":payment.paymentdate, 
						"bankName":payment.bankname,
						"document":payment.document,
						"payerName" : payment.payerName
					}
				}
				console.log('query',query)
				DataService.post('ARAAdditionalDeposit',query).then(function(data){
					console.log(data);
					if(data.status == "SUCCESS"){
						$scope.payment_summary = false;
						$scope.paymentSuccess = true;
					}else{
						NotifyFactory.log('error',data.errorMessage)
					}
	    		})
	    		.catch(function(error){
	    			NotifyFactory.log('error',error.errorMessage)
		        });
		    }
		}

		// upload document validation by exetension
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if($scope.fileUploadTypes[i] == ext){
					return true;
				}
			}
		}

		// close net banking popup
		$scope.cancelNetBank=function(){
			angular.element(".overlay").css("display","none");
			angular.element(".internet-bank-popup").css("display","none");   
		}

		// add one more check 
		$scope.addonemorecheck = function(){
			if($scope.onemorecheck == false){
				$scope.onemorecheck = true;
			}else{
				$scope.onemorecheck = false;
			}
		}

		// check submit amount is valid or not
		function checkAmountisValid(payment){
			if(parseInt(payment.amount)< parseInt($rootScope.amountPayable)){
				NotifyFactory.log('error','You have to pay minimum amount of Payable Amount.')
			}else{
				return true;
			}
		}

	}
}
)();