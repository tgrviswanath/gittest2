(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjdeterminedCaseCtrl',adjdeterminedCaseCtrl);

    adjdeterminedCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjdeterminedCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'determined'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_determined_caselist($scope.pagenumber);//call to determined case list function
        $cookies.put('currentTab','determined');
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.determinatinFileTypes = ["doc","dot","wbk","docx","docm","dotx","dotm","docb"];
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to determined case list function from outside
        $rootScope.determinedcaselist = function(){
            get_determined_caselist($cookies.get('pageNumber'));
        } 
        
    	// get rejected case list
    	function get_determined_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
    		}
    		DataService.post('GetDeterminationListAdjudicator',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.determined_Case_List = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    for(var index = 0;index<$scope.determined_Case_List.length;index++){
                        if($scope.determined_Case_List[index].caseStatus){
                            $scope.determined_Case_List[index].amendedRequestStatus= findStatus($scope.determined_Case_List[index].caseStatus,'Issue Amended Determination Requested');
                            $scope.determined_Case_List[index].araAmendedRequestStatus= findStatus($scope.determined_Case_List[index].caseStatus,'ARA Issue Amended Determination Requested');
                        }
                    }
                    if($scope.determined_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        $scope.goToPageNumber = function(pageNo){
           get_determined_caselist(pageNo);
        }

        //open model for issue amended determination
        $scope.openrequestissueamended = function(caseNumber,caseType,startDate){
            $scope.startDateofAmend = startDate;
            $scope.amendedCaseNumber = caseNumber;
            $scope.caseType = caseType;
            $scope.amendedData = {};
            $scope.supportingDocument = '';
            $scope.supprtDocumentName = '';
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
            angular.element(".overlay").css("display","block");
            angular.element(".issue-amended-modal").css("display","block");
        }
        //close model for issue amended determination
        $scope.closeamendedpopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".issue-amended-modal").css("display","none");
        }
        // upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file){
            $scope.supprtDocumentName='';
            $scope.supportingDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    $scope.supprtDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.supportingDocument = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }
        // check valid file by exetension
        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.fileUploadTypes[i] == ext){
                    return true;
                }
            }
        }

        // upload issue amend file
        $scope.uploadIssueAmendFile = function(file){
            $scope.supprtDocumentName='';
            $scope.supportingDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadAmendFileExtention(file.name)){
                    $scope.supprtDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.supportingDocument = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.determinatinFileTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        // check valid file by exetension
        function validateUploadAmendFileExtention(val){
            var allowedExt = $scope.determinatinFileTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.determinatinFileTypes[i] == ext){
                    return true;
                }
            }
        }


        // if we want remove upload file
        $scope.attachcopyRemove = function(){
            $scope.supprtDocumentName = undefined;
            $scope.supportingDocument = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        //request send for amended determination
        $scope.sentamendedRequest = function(amendedData,caseNumber,caseType){
            var query = buildIssueAmendQuery(amendedData,caseNumber);
            if(caseType == 'AA Case'){
                DataService.post('IssueAmendedRequest',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Issue amended request sent successfully');
                    get_determined_caselist();
                    angular.element(".overlay").css("display","none");
                        angular.element(".issue-amended-modal").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else if(caseType == 'ARA Case'){
                DataService.post('ARAIssueAmendedRequest',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Issue amended request sent successfully');
                    get_determined_caselist();
                    angular.element(".overlay").css("display","none");
                        angular.element(".issue-amended-modal").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
            
        }

        // build issue amend query
        function buildIssueAmendQuery(amendedData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "amendedDate":amendedData.amendedDate, 
                "adjudicatedAmount":amendedData.adjudicatedAmount, 
                "remarks":undefinedSetNull(amendedData.remarks), 
                "document":{ 
                    "name":$scope.supprtDocumentName, 
                    "fileLocation":$scope.supportingDocument 
                } 
            }
            return query;
        }

        //open upload invoice modal
         $scope.openUploadInvoice = function(caseData){
            $scope.invoiceCaseNumber = caseData.caseNumber;
            $scope.invoiceData = {};
            var query={
                        "adjudicatorId": $cookies.get('memberId'),
                        "caseNumber": caseData.caseNumber
            }
            DataService.post('ViewAdjudicatorCost',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                  $scope.invoiceData.invoiceAmount  = data.result;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
            $scope.supportingDocument = '';
            $scope.supprtDocumentName = '';
            $scope.attachcopyStatus = false;
            angular.element(".overlay").css("display","block");
            angular.element(".upload-invoice-modal").css("display","block");
        }


        //close upload invoice modal
        $scope.closeinvoicepopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".upload-invoice-modal").css("display","none");
        }

        //submit upload invoice
        $scope.uploadInvoice = function(invoiceData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "invoiceNumber":invoiceData.invoiceNo,
                "invoiceDate":invoiceData.invoiceDate, 
                "invoiceAmount":invoiceData.invoiceAmount, 
                "invoiceDocument":{ 
                    "name":$scope.supprtDocumentName, 
                    "fileLocation":$scope.supportingDocument
                }
            }
            DataService.post('UploadAdjudicatorInvoice',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Invoice uploaded successfully');
                   get_determined_caselist();
                   angular.element(".overlay").css("display","none");
                    angular.element(".upload-invoice-modal").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        function findStatus(array,action){
            var a = 0;
            if(array != undefined) {
                for(var index =0;index<array.length;index++){
                    if(array[index] == action){
                        a = 1;
                    }
                }
            }
            if(a == 1){
                return true;
            } else{
                return false;
            }
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


