(function () {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorInviteListCtrl', adjudicatorInviteListCtrl);

    adjudicatorInviteListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$window'];

    function adjudicatorInviteListCtrl($rootScope, $scope, $state, $cookies, DataService,
        $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, $window) {
        var roledetails;
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fullselectid = true;
        $scope.defaultSelectStatus = true;
        
        /**athira*/
        $scope.firstchkd = true;
        $scope.secondckd = true;
        $scope.case_id = [];
        if ($cookies.get('pageNumber')) {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_incomplete_caselist($scope.pagenumber); //call to incomplete case list function
        //call to incomplete case list function from outside
        $rootScope.mediationincompletecaselist = function () {
            get_incomplete_caselist($cookies.get('pageNumber'));
        }

        // get incomplete case list
        function get_incomplete_caselist(pageNumber) {
            DataService.get('GetSmcMemberRoleDetails').then(function (newdata) {
                console.log("newdata", newdata)
                roledetails = newdata.results;
                var memberRoleIdarr = [];
                var memberRoleName = [];
                angular.forEach(roledetails, function (value) {
                    memberRoleIdarr.push(value.id);
                    memberRoleName.push(value.name);
                    if (angular.equals('Adjudicator', value.name)) {
                        $scope.roleid = value.id;
                    }
                });
                $scope.memberRoleids = memberRoleIdarr;
                $scope.memberRoleNames = memberRoleName;
                aftergettingMemberRoleid(pageNumber);
            });

            function aftergettingMemberRoleid(pageNumber) {
                var memberroleids = [];
                memberroleids = $scope.memberRoleids;

                if (pageNumber) {
                    $scope.pagenumber = pageNumber;
                } else {
                    $scope.pagenumber = 0;
                }
                $cookies.put('pageNumber', $scope.pagenumber)
                var sorting = [
                    [0, 0],
                    [1, 0]
                ];
                var query = {
                    "pageIndex": $scope.pagenumber,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "memberRoleId": null,
                    "loginId": $cookies.get('memberId')
                }
                getAllIncompleteCases(query);
            }


        }
        //get all incomplete case list 
        function getAllIncompleteCases(query) {
            DataService.post('AdjudicatorInviteList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.incomplete_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    for (var i = 0; i < data.result.responseData.length; i++) {
                        console.log("enterd in list");
                        var dataId = data.result.responseData[i].id;
                        console.log("dataid" + dataId);
                        $scope.case_id[dataId] = true;
                    }
                    var membership_period_array = [];
                    var splittedarray = [];
                    for (var i = 0; i < data.result.responseData.length; i++) {
                        membership_period_array.push(data.result.responseData[i].membershipPeriod);
                        console.log(membership_period_array);
                        var stringArrayofmembership_period_array = membership_period_array.toString();
                        splittedarray = stringArrayofmembership_period_array.split('null').join('');
                        console.log(splittedarray);
                        var arrayofmembershipPeriod = splittedarray.split(",");
                        console.log(arrayofmembershipPeriod);
                        data.result.responseData[i].membershipPeriod = arrayofmembershipPeriod[i];
                    }
                    // for (var i = 0; i < data.result.responseData.length; i++) {
                    //     membership_period_array.push(data.result.responseData[i].membershipPeriod);
                    //     var stringArrayofmembership_period_array = membership_period_array.toString();
                    //     splittedarray = stringArrayofmembership_period_array.split('null').join('');
                    //     var arrayofmembershipPeriod = splittedarray.split(",");
                    //     // data.result.responseData[i].membershipPeriod = arrayofmembershipPeriod[i];
                    //     var splittedarraystr = stringArrayofmembership_period_array.split('-');

                    //     var arraysplittedfordate = stringArrayofmembership_period_array.split('null').join("").split(',');
                    //     console.log(arraysplittedfordate);
                    //     if (arraysplittedfordate[i] != null) {
                    //         var myDate = new Date(arraysplittedfordate[i]);
                    //         console.log(myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear());
                    //         var finallyFixeddate = myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear();
                    //         data.result.responseData[i].membershipPeriod = finallyFixeddate;
                    //     }
                    // }
                    $scope.first_clk = function () {
                        console.log("uncheck all");
                        if ($scope.firstchkd) {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].id;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = true;
                            }
                        } else {
                            for (var i = 0; i < data.result.responseData.length; i++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[i].id;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = false;
                            }
                        }
                    }
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
                get_incomplete_caselist(pageNo);
            }
            // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'incomplete') {
                get_incomplete_caselist(0);
            }
        });
        $scope.invite = function (token) {
          
            var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
            var memberdetailsforTc = termsandconditions + token;
            $http.get(memberdetailsforTc).then(function (tcdata) {
                $scope.tcdata = tcdata.data;
            });
        };

        $scope.acceptTermsandConditions = function (idOfparticipant) {
            var query = {
                "participantId": idOfparticipant,
                "isAccepted": true
            }
            acceptTermsandConditionsfrall(query);

             function acceptTermsandConditionsfrall(query) {
                DataService.post('AcceptTermsandConditionsbyMember', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display", "none");
                        angular.element(".adjudicator-accept-case").css("display", "none");
                        NotifyFactory.log('success', 'Member Invited successfully');
                        get_incomplete_caselist(0);

                    } else {
                        NotifyFactory.log('error', 'Member not Invited');
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', 'Member not Invited');
                });
            }

        };
        $scope.acceptSDRPTermsandConditions = function (idOfparticipant) {
            var query = {
                "participantId": idOfparticipant,
                "isAccepted": true
            }
            acceptTermsandConditionsfrall(query);

             function acceptTermsandConditionsfrall(query) {
                DataService.post('AcceptTermsandConditionsbyMember', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display", "none");
                        angular.element(".sdrp-accept-case").css("display", "none");
                        NotifyFactory.log('success', 'Member Invited successfully');
                        get_incomplete_caselist(0);

                    } else {
                        NotifyFactory.log('error', 'Member not Invited');
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', 'Member not Invited');
                });
            }

        };
        $scope.selectAllAction = function (selectStatus) {
            if (selectStatus == true) {
                $scope.defaultSelectStatus = true;
            } else if (selectStatus == false) {
                $scope.defaultSelectStatus = false;
            }
        }

        // to open accept the case popup
        $scope.open_accept_popup = function (member, caseType) {
                $scope.memberType=member.memberType;
                $scope.memberParticipantId=member.id;
                var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
                var memberdetailsforTc = termsandconditions + member.token;
                $http.get(memberdetailsforTc).then(function (tcdata) {
                    $scope.tcdata = tcdata.data;
                });
                $scope.token = member.token;
                $scope.caseType = caseType;
                $scope.annexAform = smcConfig.services.DownloadAnnexAform.url + $scope.token;
                $scope.annexFform = smcConfig.services.DownloadAnnexFform.url + $scope.token;
                angular.element(".overlay").css("display", "block");
                angular.element(".adjudicator-accept-case").css("display", "block");
            }

            //to close accept popup
            $scope.cancelaccept = function () {
                angular.element(".overlay").css("display", "none");
                angular.element(".adjudicator-accept-case").css("display", "none");
            }


            $scope.opensdrpPopup = function (member) {
                $scope.memberType=member.memberType;
                $scope.memberParticipantId=member.id;
                var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
                var memberdetailsforTc = termsandconditions + member.token;
                $http.get(memberdetailsforTc).then(function (tcdata) {
                    $scope.tcdata = tcdata.data;
                });
                $scope.token = member.token;
                $scope.annexAform = smcConfig.services.DownloadAnnexAform.url + $scope.token;
                $scope.annexFform = smcConfig.services.DownloadAnnexFform.url + $scope.token;
                angular.element(".overlay").css("display", "block");
                angular.element(".sdrp-accept-case").css("display", "block");
            }
            
            //to close accept popup
            $scope.cancelsdrpPopup = function () {
                angular.element(".overlay").css("display", "none");
                angular.element(".sdrp-accept-case").css("display", "none");
            }


        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

        $scope.mediatorRegister=function(member){
            $cookies.put('roleName', member.memberType);
            $cookies.put('currentActionMenu','Registration');
            $state.go('smclayout.contactlayout.mediatorRegisteration',{'participantId' : member.id,'memberRoleName': member.memberType})
        }
        $scope.cfpRegister=function(member){
            $cookies.put('roleName', member.memberType);
            $cookies.put('currentActionMenu','Payment');
            $state.go('smclayout.contactlayout.cfpPayment',{'participantId' : member.id})
        }
        $scope.familyPanel=function(member){
            $cookies.put('roleName', member.memberType);
            $cookies.put('currentActionMenu','Payment');
            $state.go('smclayout.contactlayout.mediatorRegisteration',{'participantId' : member.id,'memberRoleName': member.memberType})
        }
        $scope.principalMediator=function(member){
            $cookies.put('roleName', member.memberType);
            $cookies.put('currentActionMenu','Payment');
            $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$cookies.get('memberId'), 'smcMemberId': member.id,'memberRoleName':member.memberType}); 
        }
        $scope.internationalMediatorInvite=function(member){
            $cookies.put('roleName', member.memberType);
            $cookies.put('currentActionMenu','Payment');
            $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$cookies.get('memberId'), 'smcMemberId': member.id,'memberRoleName':member.memberType}); 
        }
    }
})();
