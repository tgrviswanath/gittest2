(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorloginCtrl',adjudicatorloginCtrl);

    adjudicatorloginCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjudicatorloginCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') == 'adjudicator'){
			$state.go('smclayout.membershiplayout.adjudicatorcaselist.torespond')
		}


    	
    	// login as a smc officer into admin page
    	$rootScope.adjudicatorLogin = function(adjudicatorlogin){
	      	if($scope.adjudicatorlogin.username && $scope.adjudicatorlogin.password ){
		        var query = {
		            "userId": $scope.adjudicatorlogin.username,
		            "password": $scope.adjudicatorlogin.password,
		        };
		        DataService.post('AdjudicatorLogin',query).then(function (data) {
		        	if(data.status == 'SUCCESS'){
						console.log("data",data);
						for(var role in data.result.moduleRoles){
							if(data.result.moduleRoles[role].roleName == 'Adjudicator'){
								$cookies.put('adjudicatorStatus',true);	
								//$cookies.put('roleName',data.result.moduleRoles[role].roleName);
								$cookies.put('roleName','Adjudicator');
							}
						}
						$cookies.put('memberId',data.result.memberId)// get member id in cookies
						$cookies.put('userName',data.result.memberName);
						$state.go('smclayout.membershiplayout.adjudicatorcaselist.torespond');
						NotifyFactory.log('success', "Logged in successfully.");
		        	}else{
		        		NotifyFactory.log('error', data.errorMessage);
		        	}
		        }, function (error) {
					NotifyFactory.log('error', error.errorMessage);
		        });
	        }
	    }
	}
})();