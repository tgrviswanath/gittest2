(function () {
    'use strict';
    angular
        .module('smc')
        .controller('CourierServiceManagementCtrl', CourierServiceManagementCtrl);

    CourierServiceManagementCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory'];

    function CourierServiceManagementCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        var roledetails;
        $scope.reverseSort = false;
        $scope.disbleViewg = false;
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fullselectid = true;
        $scope.defaultSelectStatus = true;
        $scope.couriercaselist;
        $scope.case_id = [];
        if ($cookies.get('pageNumber')) {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        /*Get Courier Document Type List */
        DataService.get('GetCourierDocumentTypeList').then(function (data) {
            if (data.status == 'SUCCESS') {
                $scope.getDocuments = data.results;
                console.log("this is document types" + $scope.getDocuments)
            }
        }).catch(function (error) {
            NotifyFactory.log('error', error.data.errorMsg)
        });

        /*Get Courier Time List */

        DataService.get('GetCourierTimeList').then(function (timedata) {

            if (timedata.status == 'SUCCESS') {
                $scope.gettimeDocuments = timedata.results;
            }
        }).catch(function (error) {
            NotifyFactory.log('error', error.data.errorMsg)
        });

        getAllcourierdetails();
        get_courier_case_list_for_smc_officer($scope.pagenumber); //call to incomplete case list function


        $scope.get_courier_case_list_for_smc_officer=function(pageNumber){

            get_courier_case_list_for_smc_officer(pageNumber); 
        }

        // get incomplete case list
        function get_courier_case_list_for_smc_officer(pageNumber) {


            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null

            }
            getCourierCaseListForSMCOfficer(query);

        }
        //get Courier Case List For SMCOfficer
        function getCourierCaseListForSMCOfficer(query) {
            $scope.courier = {};
            DataService.post('GetCourierCaseListForSMCOfficer', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.couriercaselist = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;

                    var value = Math.round($scope.max_pagenumber);
                    console.log(value);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }

                    $scope.first_clk = function () {
                        console.log("uncheck all");
                        if ($scope.firstchkd) {
                            for (var checkVar = 0; checkVar < data.result.responseData.length; checkVar++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[checkVar].id;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = true;
                            }
                        } else {
                            for (var checkVar = 0; checkVar < data.result.responseData.length; checkVar++) {
                                console.log("enterd in list");
                                var dataId = data.result.responseData[checkVar].id;
                                console.log("dataid" + dataId);
                                $scope.case_id[dataId] = false;
                            }
                        }
                    }

                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
         get_courier_case_list_for_smc_officer(pageNo);
        }
        $scope.goToPageStatusNumber = function (pageNo) {
         get_status_case_list_for_smc_officer(pageNo);
        }
         function get_status_case_list_for_smc_officer(pageNumber) {
            if (pageNumber) {
                $scope.statusPagenumber = pageNumber;
            } else {
                $scope.statusPagenumber = 0;
            }
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.statusPagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null

            }
            viewStatus(query);

        }
        function viewStatus(query){
                DataService.post('GetCourierViewingStatus', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.shownodataavailable = false;
                    $scope.statusDatas = data.result.responseData;
                    $scope.max_statusPagenumber = data.result.totalPages;
                }else{
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                $scope.shownodataavailable = true;
                NotifyFactory.log('error', error.errorMessage)
                
            });
        }
        $scope.selectAllAction = function (selectStatus) {
            if (selectStatus == true) {
                $scope.defaultSelectStatus = true;
            } else if (selectStatus == false) {
                $scope.defaultSelectStatus = false;
            }
        }
        $scope.checkedStatus = function () {
            var selectedProducts = [];
            $scope.couriercaselist = $scope.responseData;
            for (var index in $scope.couriercaselist) {
                if ($scope.case_id[$scope.couriercaselist[index].id]) {
                    selectedProducts.push($scope.couriercaselist[index].id);

                }
            }
            console.log($scope.couriercaselist);
            console.log(selectedProducts);
        }
        $scope.first_clk = function () {

            if ($scope.firstchkd) {
                $scope.secondckd = true;
            } else {
                $scope.secondckd = false;
            }
        }
        $scope.second_click = function (name) {
            var count_dynamic_chkboxes = document.getElementsByClassName('secondchk').length;
            console.log(count_dynamic_chkboxes);
            var totalcheckboxes = count_dynamic_chkboxes;
            var checkedcheckboxescount = document.querySelectorAll('.secondchk:checked').length
            if (totalcheckboxes == checkedcheckboxescount) {
                console.log("count is equal");
                $scope.firstchkd = true;
            } else if (totalcheckboxes != checkedcheckboxescount) {
                console.log('count is not equal');
                $scope.firstchkd = false;
            }
        }
        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }

        /*get all courrier details */
        function getAllcourierdetails() {
            var query = {
                "pageIndex": 0,
                "dataLength": 10,
                "sortingColumn": null,
                "sortDirection": null,
                "companyName": null,
                "contactNumber": null
            }
            get_courier_details(query);

            function get_courier_details(query) {
                DataService.post('ViewAllCourierDetails', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        $scope.courierDetails = data.result.responseData;
                        // console.log("courier details" + $scope.courierDetails);

                    } else {
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    if (error.errorCode == 100) {
                        NotifyFactory.log('error', error.errorMessage);
                    }

                });
            }

            $scope.getSingleCourierdetail = function () {

                // if ($scope.opt == null||) {
                if ($scope.opt == null) {
                    $scope.singleCourierDetails.contactPersonName = '';
                    $scope.singleCourierDetails.businessAddress.phoneNumber = '';
                } else {
                    $scope.disbleViewg = false;
                    $scope.courierId = $scope.opt.id;

                    var singleCourierDetail = smcConfig.services.ViewSingleCourierDetail.url;

                    var singleCourierDetailUrl = singleCourierDetail + $scope.courierId
                    $http.get(singleCourierDetailUrl).then(function (courierData) {
                        if (courierData.data.status == 'SUCCESS') {
                            $scope.singleCourierDetails = courierData.data.result;
                            console.log("singleCourierDetails" + $scope.singleCourierDetails);

                        } else {
                            NotifyFactory.log('error', "error");
                        }
                    });
                }
            }

        }
        $scope.msg = [];
        $scope.courier.type = [];
        $scope.courier.time = [];
        $scope.messageArray = [];
        $scope.messageIndexArr = [];
        $scope.templatePupUpOpen = function (viewedCase, index, action) {

            $scope.viewedCase = viewedCase;
            $scope.viewedMsgId = viewedCase.id;
            $scope.viewedIndex = index;
            // if (!$scope.courier.type[template] || !$scope.courier.time[template] || $scope.opt == null) {
            if (viewedCase.documentType == 'undefined' || viewedCase.documentType == null || viewedCase.courierTime == 'undefined' || viewedCase.courierTime == null || $scope.opt == null) {
                // $scope.msg[index] = 'Please Select all the mandatory fields';
                if (viewedCase.documentType == 'undefined' || viewedCase.documentType == null) {
                    $scope.msg[index] = 'Please Select The Document Type';
                }
                if (viewedCase.courierTime == 'undefined' || viewedCase.courierTime == null) {
                    $scope.msg[index] = 'Please Select The Courier Time';
                }
                if ($scope.opt == 'undefined' || $scope.opt == null) {
                    $scope.msg[index] = 'Please Select The Courier Company';
                }

            } else {
                if (!$scope.viewedCase.updatedMsg && !$scope.viewedCase.message) {
                    $scope.msg[index] = '';
                    $scope.templateData = {};
                    $scope.updateSelectTemplate = index;
                    var msgData = {
                        "id": $scope.viewedMsgId,
                        "deliveryPerson": $scope.singleCourierDetails.contactPersonName,
                        "deliveryPersonPhone": $scope.singleCourierDetails.businessAddress.phoneNumber,
                        "documentTypeId": viewedCase.documentType,
                        "courierTimeId": viewedCase.courierTime,
                        "courierId": $scope.opt.id,
                        "smcOfficerId": $cookies.get('memberId')
                    }
                    generateMsg(msgData,action);
                } else {
                    if ($scope.viewedCase.updatedMsg) {
                        $scope.templateDetail = $scope.viewedCase.updatedMsg;
                    } else {
                        $scope.templateDetail = $scope.viewedCase.message;
                    }
                    $scope.messageArray.push($scope.templateDetail);
                    angular.element(".overlay").css("display", "block");
                    angular.element(".update-email-template").css("display", "block");
                }



            }


        }

        function generateMsg(msgData,action) {
            DataService.post('GenerateSMSMessageForCourier', msgData).then(function (data) {
                if (data.status == 'SUCCESS') {

                    $scope.viewedCase.message = data.result;
                    $scope.templateDetail = data.result;

                    $scope.messageArray.push($scope.templateDetail);
                    if(action != 'getMessage'){
                        angular.element(".overlay").css("display", "block");
                        angular.element(".update-email-template").css("display", "block");
                    }

                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.data.errorMsg)

            });

        }

        $scope.templatePupUpClose = function () {
            $scope.updateSelectTemplate = undefined;
            $scope.templateData = undefined;
            angular.element(".overlay").css("display", "none");
            angular.element(".update-email-template").css("display", "none");
        }

        $scope.selfCollected = function (data) {

            var courierCases = [];

            for (var courier in $scope.couriercaselist) {
                if ($scope.couriercaselist[courier].selected) {
                    courierCases.push($scope.couriercaselist[courier].id);
                }
            }
            var finalDataquery = {
                "courierIds": courierCases,
                "smcOfficerId": $cookies.get('memberId')
            }


            selfCollectedall(finalDataquery);

            function selfCollectedall(finalDataquery) {
                DataService.post('UpdateCourierStatusToSelfCollected', finalDataquery).then(function (data) {
                    if (data.status == 'SUCCESS') {

                        NotifyFactory.log('success', 'Courier Status Is Updated To Self Collected Successfully');
                        get_courier_case_list_for_smc_officer($scope.pagenumber);

                    } else {
                        NotifyFactory.log('error', error.errorMessage)

                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage)

                });
            }

        };

        $scope.sendSMS = function () {
                var courierCases = [];

                for (var courier in $scope.couriercaselist) {
                    if ($scope.couriercaselist[courier].selected) {
                        var query = {
                            "id": $scope.couriercaselist[courier].id,
                            "documentTypeId": $scope.couriercaselist[courier].documentType,
                            "courierTimeId": $scope.couriercaselist[courier].courierTime,
                            "smsMessage": $scope.couriercaselist[courier].updatedMsg ? $scope.couriercaselist[courier].updatedMsg : $scope.couriercaselist[courier].message,
                        }
                        courierCases.push(query);
                    }
                }

                var finalObject = {
                    "courierId": $scope.opt.id,
                    "deliveryPerson": $scope.singleCourierDetails.contactPersonName,
                    "deliveryPersonPhone": $scope.singleCourierDetails.businessAddress.phoneNumber,
                    "courierCases": courierCases,
                    "smcOfficerId": $cookies.get('memberId')
                }

                console.log('finalObject', finalObject)
                sendMsgsToAll(finalObject);

                //get Courier Case List For SMCOfficer
                function sendMsgsToAll(finalObject) {

                    DataService.post('ArrangeCourierServiceWithSMS', finalObject).then(function (data) {
                        if (data.status == 'SUCCESS') {
                            NotifyFactory.log('success', 'Message Send Successfully');
                            get_courier_case_list_for_smc_officer($scope.pagenumber);
                        }
                    }).catch(function (error) {
                        NotifyFactory.log('error', error.errorMessage);
                    });
                }
            }
            $scope.courierCasesSelected=[];

            $scope.generateSms=function(){
                $scope.courierCasesSelected=[];
               for (var courier in $scope.couriercaselist) {
                    if ($scope.couriercaselist[courier].selected) {
                        $scope.courierCasesSelected.push($scope.couriercaselist[courier].id);
                    }
                }
            }

            /*View Status Tab */
        $scope.viewStatus =function() {
           $scope.statusPagenumber = 0;
            var statusData = {
                "pageIndex": $scope.statusPagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null
            }
            DataService.post('GetCourierViewingStatus', statusData).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.shownodataavailable = false;
                    $scope.statusDatas = data.result.responseData;
                    $scope.max_statusPagenumber = data.result.totalPages;
                }else{
                    $scope.shownodataavailable = true;
                    $scope.max_statusPagenumber=0;
                }
            }).catch(function (error) {
                $scope.max_statusPagenumber=0;
                $scope.shownodataavailable = true;
                NotifyFactory.log('error', error.errorMessage)
                
            });
        }
        $scope.updatedMsgArray = [];
        $scope.updateTemplateData = function (updatedMsg, updatedIndex, viewedCase) {
            if (viewedCase.message != updatedMsg) {
                $scope.couriercaselist[updatedIndex].updatedMsg = updatedMsg;
            }
            angular.element(".overlay").css("display", "none");
            angular.element(".update-email-template").css("display", "none");
        }




    }
})();
