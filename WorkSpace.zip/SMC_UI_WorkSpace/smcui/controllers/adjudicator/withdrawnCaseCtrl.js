(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjwithdrawnCaseCtrl',adjwithdrawnCaseCtrl);

    adjwithdrawnCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjwithdrawnCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'withdrawn'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_withdrawn_caselist($scope.pagenumber);//call to determined case list function
        $cookies.put('currentTab','withdrawn');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to determined case list function from outside
        $rootScope.withdrawncaselist = function(){
            get_withdrawn_caselist($cookies.get('pageNumber'));
        } 
        
    	// get withdrawn case list
    	function get_withdrawn_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
    		}
    		DataService.post('GetWithDrawnCaseList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.withdrawn_Case_List = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    for(var index = 0;index<$scope.withdrawn_Case_List.length;index++){
                        $scope.withdrawn_Case_List[index].timeSheetSubmitStatus= findStatus($scope.withdrawn_Case_List[index].caseStatus,'Time Sheet Submitted');
                        $scope.withdrawn_Case_List[index].adjudicatorAppointStatus= findStatus($scope.withdrawn_Case_List[index].caseStatus,'Adjudicator Appointed');
                        $scope.withdrawn_Case_List[index].scheduleStatus= findStatus($scope.withdrawn_Case_List[index].caseStatus,'Adjudicator Advised On Timeline');
                    }
                    if($scope.withdrawn_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        $scope.goToPageNumber = function(pageNo){
           get_withdrawn_caselist(pageNo);
        }

        function findStatus(array,action){
            var a = 0;
            if(array != undefined) {
                for(var index =0;index<array.length;index++){
                    if(array[index] == action){
                        a = 1;
                    }
                }
            }
            if(a == 1){
                return true;
            } else{
                return false;
            }
        }

        $scope.openTimesheet = function(caseData,action){
            $scope.caseData = caseData;
            $rootScope.confirmationMode = false;
            if(action == 'amend'){
                openTimeSheetModal(caseData);
            }else{
                angular.element(".overlay").css("display","block");
                angular.element(".confirmation-timesheet-modal").css("display","block");
            }
        }

        $scope.confirmationMemo = function(caseData){
            $scope.caseData = caseData;
            $rootScope.confirmationMode = true;
            angular.element(".overlay").css("display","block");
            angular.element(".confirmation-timesheet-modal").css("display","block");
        }

        $scope.closepopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".confirmation-timesheet-modal").css("display","none");
        }

        $scope.sendData = function(confirmation,caseData){
            var query = {
                "caseNumber":caseData.caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "timeCostOption":confirmation, 
                "invoice":null
            }
            DataService.post('AdjudicatorResignationTimeCostSubmit',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Resignation time cost submitted successfully');
                   get_withdrawn_caselist();
                   angular.element(".overlay").css("display","none");
                    angular.element(".confirmation-timesheet-modal").css("display","none");
                }else{
                    NotifyFactory.log('error', data.data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
            if(!$rootScope.confirmationMode){
                if(confirmation == 'I will be charging my time costs'){
                    angular.element(".confirmation-timesheet-modal").css("display","none");
                    angular.element(".overlay").css("display","block");
                    openTimeSheetModal(caseData);
                }else{
                    get_withdrawn_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".confirmation-timesheet-modal").css("display","none");
                }
            }
        }
        function openTimeSheetModal(caseData){
            $scope.timeDetails = {};
            $scope.timeDetails.workedDate='';
            $scope.timeDetails.description='';
            $scope.timeDetails.startTime='';
            $scope.timeDetails.endTime='';
            $rootScope.caseData = caseData;
            $scope.supprtDocumentName = '';
            $scope.supportingDocument = '';
            $scope.ClaimantName = caseData.claimantName;
            $scope.Respond = caseData.respondentName;
            $scope.startDateofTimesheet = caseData.adjudicatorAppointedDate;
            $scope.timesheetNumber = caseData.caseNumber;
            var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
            GetTimeSheetDataUrl = GetTimeSheetDataUrl + $scope.timesheetNumber;
            $http.get(GetTimeSheetDataUrl).then(function(data){
                console.log("data",data)
                $scope.timeSheetData = data.data.result;
                if($scope.timeSheetData.supportingDocument){
                    $scope.supprtDocumentName = $scope.timeSheetData.supportingDocument.name;
                    $scope.supportingDocument = $scope.timeSheetData.supportingDocument.fileLocation;
                    $scope.attachcopyStatus = true;
                }
                $rootScope.workingDatas = $scope.timeSheetData.workedHours;
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","block");
        }

        $scope.closetimesheetpopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".timeSheet-progress-modal").css("display","none");
        }

        // Add the time sheet
        $scope.addTimeSheet = function(timeDetails,timesheetNumber){
            if($rootScope.workingDatas == undefined){
                $rootScope.workingDatas = [];
            }
            timeDetails.startTime= document.getElementById("addstartTime").value;
            timeDetails.endTime = document.getElementById("addendTime").value;
            var query ={
                "id":undefinedSetNull(parseInt(timeDetails.id)),
                "workedDateStr":timeDetails.workedDate, 
                "description":timeDetails.description, 
                "startTime":timeDetails.startTime, 
                "endTime":timeDetails.endTime, 
            }
            $rootScope.workingDatas.push(query);
            $scope.timeDetails={};
        }

        
        // Update the time sheet
        $scope.updateTimeSheet = function(timeDetails){
            timeDetails.startTime= document.getElementById("addStartTime").value;
            timeDetails.endTime = document.getElementById("addEndTime").value;
            var query ={
                "id":undefinedSetNull(parseInt(timeDetails.id)),
                "workedDateStr":timeDetails.workedDateStr, 
                "description":timeDetails.description, 
                "startTime":timeDetails.startTime, 
                "endTime":timeDetails.endTime, 
            }
            console.log('$rootScope.dataIndex',$rootScope.dataIndex)
            $rootScope.workingDatas[$rootScope.dataIndex]=query;
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","block");
            angular.element(".edit-timeSheet-model").css("display","none");
        }

        // confirmation before Delete the schedule in time sheet
        $scope.opendeleteconfirmation= function(workingDataId,$index){
            $scope.workingDataId = workingDataId;
            $scope.workingDataIndex = $index;
            angular.element(".timeSheet-progress-modal").css("display","none");
            angular.element(".form-submitt-confirm").css("display","block");
        }
        // to close popup model for delete adjudicator
        $scope.canceldelete = function(){
            angular.element(".form-submitt-confirm").css("display","none");
            angular.element(".timeSheet-progress-modal").css("display","block");
        }

        // Delete the schedule in time sheet
        $scope.deleteTimeSheet = function(sheetId,index){
            if(sheetId != null){
                var DeleteTimeSheetDataUrl = smcConfig.services.DeleteTimeSheetData.url;
                DeleteTimeSheetDataUrl = DeleteTimeSheetDataUrl + sheetId;
                $http.get(DeleteTimeSheetDataUrl).then(function(data){
                    console.log("data",data)
                    NotifyFactory.log('success', 'Timesheet deleted successfully');
                    openTimeSheetModal($rootScope.caseData);
                    angular.element(".form-submitt-confirm").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else{
                $rootScope.workingDatas.splice(index,1);
                angular.element(".form-submitt-confirm").css("display","none");
                angular.element(".timeSheet-progress-modal").css("display","block");
            }
        }

        // save time sheet
        $scope.SaveTimeSheet = function(sheetData,caseNumber){
            var query = BuildTimesheetQuery(sheetData,caseNumber);
            console.log('query',query)
            DataService.post('SaveTimeSheet',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Timesheet saved successfully');
                   get_withdrawn_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //open confimation popup to submit time sheet
        $scope.openConfirmationTimesheet = function(timeSheetData,timesheetNumber,timeSheetCaseType){
            $scope.timeSheetData = timeSheetData;
            $scope.timesheetNumber = timesheetNumber;
            $scope.timeSheetCaseType = timeSheetCaseType;
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","none");
            angular.element(".timesheet-confirm-modal").css("display","block");
        }
        //close confimation popup to submit time sheet
        $scope.closeConfirmationTimesheet = function(){
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","block");
            angular.element(".timesheet-confirm-modal").css("display","none");
        }

        // Submit the time sheet
        $scope.submitTimeSheet = function(sheetData,caseNumber){
            var query = BuildTimesheetQuery(sheetData,caseNumber);
            DataService.post('SubmitTimeSheet',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Timesheet submited successfully');
                   get_withdrawn_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".timesheet-confirm-modal").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        // build query for save and submit the timesheet 
        function BuildTimesheetQuery(sheetData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":parseInt($cookies.get('memberId')), 
                "disbursementAmount":undefinedSetNull(sheetData.disbursementAmount), 
                "waivedHours":undefinedSetNull(sheetData.waivedHours), 
                "isGSTRegistered":sheetData.isGSTRegistered, 
                "supportingDocument": null
            }
            if($scope.supportingDocument){
                query.supportingDocument = { 
                    "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument 
                }
            }
            $scope.workingDetails = [];
            if(sheetData.workedHours){
                for(var index = 0; index<sheetData.workedHours.length;index++){
                    var workHours ={
                        "id":undefinedSetNull(parseInt(sheetData.workedHours[index].id)),
                        "workedDate":sheetData.workedHours[index].workedDateStr, 
                        "description":sheetData.workedHours[index].description, 
                        "startTime":sheetData.workedHours[index].startTime, 
                        "endTime":sheetData.workedHours[index].endTime, 
                    }
                    $scope.workingDetails.push(workHours);
                }
                query["workedHours"] = $scope.workingDetails;
            }else{
                for(var index = 0; index<$rootScope.workingDatas.length;index++){
                    var workHours ={
                        "id":undefinedSetNull(parseInt($rootScope.workingDatas[index].id)),
                        "workedDate":$rootScope.workingDatas[index].workedDateStr, 
                        "description":$rootScope.workingDatas[index].description, 
                        "startTime":$rootScope.workingDatas[index].startTime, 
                        "endTime":$rootScope.workingDatas[index].endTime, 
                    }
                    $scope.workingDetails.push(workHours);
                }
                query["workedHours"] = $scope.workingDetails;
            }

            return query;
        }

        //open add time sheet popup
        $scope.editTimeSheet = function(workingData,index){
            $scope.workingData = workingData;
            $rootScope.dataIndex = index;
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","none");
            angular.element(".edit-timeSheet-model").css("display","block");
        }

        //close add time sheet
        $scope.closeEditTimepop = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".edit-timeSheet-model").css("display","none");
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


