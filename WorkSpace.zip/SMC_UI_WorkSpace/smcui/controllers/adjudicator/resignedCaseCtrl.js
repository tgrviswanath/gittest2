(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjResignedCaseCtrl',adjResignedCaseCtrl);

    adjResignedCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjResignedCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
    	get_resigned_caselist();//call to resigned case list function
        $cookies.put('currentTab','resigned');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get withdrawn case list
    	function get_resigned_caselist(){
    		var query = {
    			 "pageIndex":0,
                 "dataLength":10,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
    		}
    		DataService.post('ViewAdjudicatorResignedCaseList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.resigned_Case_List = data.result.responseData;
                    for(var index = 0;index<$scope.resigned_Case_List.length;index++){
                        $scope.resigned_Case_List[index].timeSheetSubmitStatus= findStatus($scope.resigned_Case_List[index].caseStatus,'Time Sheet Submitted');
                    }
                    if($scope.resigned_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        function findStatus(array,action){
            var a = 0;
            if(array != undefined) {
                for(var index =0;index<array.length;index++){
                    if(array[index] == action){
                        a = 1;
                    }
                }
            }
            if(a == 1){
                return true;
            } else{
                return false;
            }
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


