(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjInprogressCaseCtrl',adjInprogressCaseCtrl);

    adjInprogressCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjInprogressCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'progress'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.sortReverse = false;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_progress_caselist($scope.pagenumber);//call to progress case list function
        $cookies.put('currentTab','progress');
        $scope.message_window_Path = 'views/adjudicator/messagewindow.html';
        $scope.request_deposit_modal_path = 'views/member/request_deposit.html';
        $scope.resignation_withdraw_modal_path = 'views/popups/resignation_withdraw_modal.html';
        $scope.resignation_approve_modal_path = 'views/popups/resignation_manager_approve_adj_modal.html';
        $scope.$emit('activeTab',$cookies.get('currentTab'));//sent current tab status
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png","doc","dot","wbk","docx","docm","dotx","dotm","docb"];
        $scope.determinatinFileTypes = ["doc","dot","wbk","docx","docm","dotx","dotm","docb"];
        $scope.schedule = {};
        $scope.timeDetails={};
        $scope.downloadServiceUrl = smcConfig.services.DownloadSupportingDocument.url;
        $scope.schedule.scheduleMeetings = [];
        $scope.messageViewOptions = [
                                        {'display':'All messages','value':''},
                                        {'display':'Claimant','value':'Claimant'},
                                        {'display':'Respondent','value':'Respondent'},
                                        {'display':'All','value':'All'}
                                    ];
        $scope.messageView = '';
        //call to progress case list function from outside
        $rootScope.progresscaselist = function(){
            get_progress_caselist($cookies.get('pageNumber'));
        } 

    	// get progress case list
    	function get_progress_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":0,
                 "dataLength":10,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
    		}
    		DataService.post('AdjudicatorProgressList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.progress_Case_List = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    for(var index = 0;index<$scope.progress_Case_List.length;index++){
                        if($scope.progress_Case_List[index].caseStatus.length != 0){
                            $scope.progress_Case_List[index].scheduleStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Adjudicator Advised On Timeline');
                            $scope.progress_Case_List[index].appointStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Adjudicator Appointed');
                            $scope.progress_Case_List[index].uplaodAcceptStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Parties Notified of Adjudicator Appointed');
                            $scope.progress_Case_List[index].timesheetSubmitStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Time Sheet Submitted');
                            $scope.progress_Case_List[index].draftRequestStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Draft Determination Requested');
                            $scope.progress_Case_List[index].changeRequestStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Draft Determination & Time Sheet Changes Required');
                            $scope.progress_Case_List[index].approveDeterminationStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Draft Determination And Time Sheet Submitted');
                            $scope.progress_Case_List[index].resignationRequestStatus= findStatus($scope.progress_Case_List[index].caseStatus,'Adjudicator Resignation Request'),
                            $scope.progress_Case_List[index].resignationApproveManagerStatus= findStatus($scope.progress_Case_List[index].caseStatus,'SMC Manager Approve Adjudicator Resignation')
                        }
                        if($scope.progress_Case_List[index].araCaseStatus.length != 0){
                            $scope.progress_Case_List[index].araappointStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'Review Adjudicator(s) Appointed');
                            $scope.progress_Case_List[index].uplaodAcceptStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'Parties Notified of the Review Adjudicator(s) Appointed');
                            $scope.progress_Case_List[index].aratimesheetSubmitStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'ARA Time Sheet Submitted');
                            $scope.progress_Case_List[index].aradraftRequestStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'ARA Draft Determination Requested');
                            $scope.progress_Case_List[index].arachangeRequestStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'ARA Draft Determination & Time Sheet Changes Required');
                            $scope.progress_Case_List[index].araapproveDeterminationStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'ARA Draft Determination And Time Sheet Submitted');
                            $scope.progress_Case_List[index].arascheduleStatus= findStatus($scope.progress_Case_List[index].araCaseStatus,'Review Adjudicator(s) Advised on Timeline');

                        }
                        
                    }
                    if($scope.progress_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        $scope.goToPageNumber = function(pageNo){
           get_progress_caselist(pageNo);
        }


        //to open model of upload annex A
        $scope.UploadAnnexA = function(caseNumber,caseType){
            $scope.CaseNumber = caseNumber;
            $scope.caseType = caseType;
            $scope.annexAform = smcConfig.services.DownloadAnnexAform.url+$scope.CaseNumber;
            $scope.annexFform = smcConfig.services.DownloadAnnexFform.url+$scope.CaseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".upload-annex-A-modal").css("display","block");
        }
        //to close model of upload annex A
        $scope.closepopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".upload-annex-A-modal").css("display","none");
        }
        // upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file){
            $scope.supprtDocumentName='';
            $scope.supportingDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    $scope.supprtDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.supportingDocument = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        // upload a file - before that check file size,valid exetension
        $scope.reUploadFile = function(file){
            if($scope.timeSheetData.supportingDocument){
               $scope.timeSheetData.supportingDocument.name='';
                $scope.timeSheetData.supportingDocument.fileLocation=''; 
            }else{
                $scope.timeSheetData.supportingDocument = {};
            }
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    $scope.timeSheetData.supportingDocument.name = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.timeSheetData.supportingDocument.fileLocation = data.result;
                        $scope.timeSheetattachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        // if we want remove upload file
        $scope.timeSheetRemoveStatus = function(){
            $scope.timeSheetData.supportingDocument.name  = undefined;
            $scope.timeSheetData.supportingDocument.fileLocation  = undefined;
            $scope.timeSheetattachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        // check valid file by exetension
        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.fileUploadTypes[i] == ext){
                    return true;
                }
            }
        }

        $scope.updateDeterminationFile = function(file){
            $scope.fileDoc = file;
            angular.element(".overlay").css("display","block");
            angular.element(".determination-file-updated-confirm").css("display","block");
            angular.element(".Submit-Draft-Determination").css("display","none");
        }

        $scope.updateDeterFile = function(updateDeterFile){
            uploadDeterminationFile(updateDeterFile);
            angular.element(".overlay").css("display","block");
            angular.element(".determination-file-updated-confirm").css("display","none");
            angular.element(".Submit-Draft-Determination").css("display","block");
        }

        $scope.closeUpdatedetfile = function(){
            angular.element(".overlay").css("display","block");
            angular.element(".determination-file-updated-confirm").css("display","none");
            angular.element(".Submit-Draft-Determination").css("display","block");
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadDeterminationFile = function(file){
            uploadDeterminationFile(file)
        }

        function uploadDeterminationFile(file){
            $scope.supprtDocumentName='';
            $scope.supportingDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileDetermination(file.name)){
                    $scope.supprtDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.supportingDocument = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.determinatinFileTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        // upload a file - before that check file size,valid exetension
        $scope.reUploadDeterminationFile = function(file){
            $scope.detreSupprtDocumentName='';
            $scope.detarSupportingDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileDetermination(file.name)){
                    $scope.detreSupprtDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.detarSupportingDocument = data.result;
                        $scope.deterAttachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyErrorMsg = "You can upload only " + $scope.determinatinFileTypes.toString();
                    NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        // if we want remove upload file
        $scope.deterattachcopyRemove = function(){
            $scope.detreSupprtDocumentName = undefined;
            $scope.detarSupportingDocument = undefined;
            $scope.deterAttachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        // check valid file by exetension determination
        function validateUploadFileDetermination(val){
            var allowedExt = $scope.determinatinFileTypes;

            var ext = val.split('.').pop();
            for(var exe = 0; exe < allowedExt.length; exe++){
                if($scope.determinatinFileTypes[exe] == ext){
                    return true;
                }
            }
        } 

        // check valid file by exetension determination
        function validateUploadFile(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var exe = 0; exe < allowedExt.length; exe++){
                if($scope.fileUploadTypes[exe] == ext){
                    return true;
                }
            }
        } 
        // if we want remove upload file
        $scope.attachcopyRemove = function(){
            $scope.supprtDocumentName = undefined;
            $scope.supportingDocument = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        //to submit document
        $scope.uploadDocument = function(CaseNumber,caseType){
            var query = {
                "adjudicatorId":$cookies.get('memberId'), 
                "caseNumber":CaseNumber, 
                "supportingDocument": { 
                    "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument 
                }
            }
            console.log('query',query);
            if(caseType == 'AA Case'){
                uploadDocumentAA(query);
            }else if(caseType == 'ARA Case'){
                uploadDocumentARA(query);
            }
        }

        //upload signature annex file for AA 
         function uploadDocumentAA(query){
             DataService.post('AdjudicatorSubmitWithSignature',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Document submitted successfully');
                    get_progress_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".upload-annex-A-modal").css("display","none");

                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
         }

         //upload signature annex file for ARA 
         function uploadDocumentARA(query){
             DataService.post('AdjudicatorSubmitWithSignatureARA',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Document submitted successfully');
                    get_progress_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".upload-annex-A-modal").css("display","none");

                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
         }

        //to view AA Form
        $scope.viewAAform = function(caseNumber){
            $rootScope.casenumber = caseNumber;
            var serviceGetSingleCaseListUrl = smcConfig.services.GetSingleCaseList.url;
            serviceGetSingleCaseListUrl = serviceGetSingleCaseListUrl + "/" + $rootScope.casenumber;
            $http.get(serviceGetSingleCaseListUrl).then(function(data){
                console.log('singlecagelist',data.data.result);
                $rootScope.singleCaseObject = data.data.result;
                $rootScope.loginSession = true;
                $state.go('smclayout.membershiplayout.AAview')
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });
        }

        //to view AR Form
        $scope.viewARform = function(caseNumber){
            $rootScope.caseNumber = caseNumber;
            $state.go('smclayout.membershiplayout.ARview')
        }

        //to open scedule form
        $scope.openSchedule = function(caseDetail){
            $scope.caseDetail = caseDetail;
            $scope.showAddBtn = false;
            $scope.showClsBtn = false;
            $scope.scheduleNumber = caseDetail.caseNumber;
            if(caseDetail.scheduleStatus != undefined){
              $scope.scheduleStatus = caseDetail.scheduleStatus;  
            }else{
                $scope.scheduleStatus = caseDetail.arascheduleStatus; 
            }
            
            $scope.scheduleCaseType = caseDetail.caseType;

            if($scope.scheduleStatus == false){
                $scope.ClaimantName = caseDetail.claimantName;
                $scope.Respond = caseDetail.respondentName;
                $scope.conferencelist = [true];
                $scope.schedule = {};
                $scope.schedule.scheduleMeetings = [];
                angular.element(".overlay").css("display","block");
                angular.element(".progress-schedule-modal").css("display","block");
            }else{
                var GetCaseScheduleUrl = smcConfig.services.GetCaseSchedule.url;
                GetCaseScheduleUrl = GetCaseScheduleUrl + $scope.scheduleNumber;
                $http.get(GetCaseScheduleUrl).then(function(data){
                    console.log("data",data)
                    $scope.schedule = data.data.result;
                    $scope.conferencelist = [];
                    var conf_count = 0;
                    var conf_venue_count = 0;
                    if($scope.schedule.scheduleMeetings.length != 0){
                       for(var con in $scope.schedule.scheduleMeetings){
                            $scope.conferencelist.push(true);
                            conf_count =conf_count+1;
                            if($scope.schedule.scheduleMeetings[con].isParkingRequired == true){
                                $scope.schedule.scheduleMeetings[con].isParkingRequired = "Yes";
                            }else{
                                $scope.schedule.scheduleMeetings[con].isParkingRequired = "No";
                            }
                            if($scope.schedule.scheduleMeetings[con].venue){
                                conf_venue_count = conf_venue_count +1;
                            }
                        } 
                    }else{
                        $scope.conferencelist = [true];
                    }
                    
                    if(conf_venue_count == conf_count){
                        $scope.showAddBtn = true;
                    }
                    if($scope.schedule.isRoomRequired == true){
                        $scope.schedule.isRoomRequired = "Yes";
                    }else{
                        $scope.schedule.isRoomRequired = "No";
                    }
                    
                    angular.element(".overlay").css("display","block");
                    angular.element(".progress-schedule-modal").css("display","block");
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
        }
        //to close scedule form
        $scope.closeSchedulepopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".progress-schedule-modal").css("display","none");
        }
        // to create and save schedule
        $scope.saveSchedule = function(scheduleDetail,caseNumber,scheduleCaseType){
            console.log('schedule',scheduleDetail);
            if(scheduleDetail.scheduleMeetings.length != 0){
                for(var times in scheduleDetail.scheduleMeetings){
                    scheduleDetail.scheduleMeetings[times].meetingStartTime = document.getElementById("startTime"+times).value;
                    scheduleDetail.scheduleMeetings[times].meetingEndTime = document.getElementById("endTime"+times).value;
                    var start_time = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[0];
                    var start_hour = start_time.split(':')[0];
                    var start_mini = start_time.split(':')[1];
                    var start_Sched = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[1];
                    var end_time = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[0];
                    var end_hour = end_time.split(':')[0];
                    var end_mini = end_time.split(':')[1];
                    var end_Sched = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[1];
                    if(start_Sched == 'am'&& end_Sched == 'pm'){
                        save_schedule(scheduleDetail,caseNumber,scheduleCaseType);
                    }else if(start_Sched == 'pm'&& end_Sched == 'am'){
                        NotifyFactory.log('error', 'Start time should be less than end time' );
                    }else if(start_Sched==end_Sched){
                        if(start_hour == '12' && start_Sched == 'pm'){
                            save_schedule(scheduleDetail,caseNumber,scheduleCaseType);
                        }
                        else if(start_hour < end_hour){
                            save_schedule(scheduleDetail,caseNumber,scheduleCaseType);
                        }else if(start_hour == start_hour){
                            if(start_mini < end_mini){
                                save_schedule(scheduleDetail,caseNumber,scheduleCaseType);
                            }else if(start_mini == end_mini){
                                NotifyFactory.log('error', 'Start time and end time should not be same' );
                            }else{
                                NotifyFactory.log('error', 'Start time should be less than end time' );
                            }
                        }else if(start_hour > start_hour){
                            NotifyFactory.log('error', 'Start time should be less than end time' );
                        }
                    }
                }
            }else{
                save_schedule(scheduleDetail,caseNumber,scheduleCaseType);
            }
        }

        $scope.viewARAForm = function(caseNumber){
            $rootScope.araCaseNumber = caseNumber;
            $cookies.put('currentActionMenu', 'View ARA Form');
            $state.go('smclayout.membershiplayout.viewARAForm');
        }

        $scope.addoneconference = function(){
            $scope.conferencelist.push(true);
            $scope.showAddBtn = false;
            $scope.showClsBtn = true;
        }

        $scope.removeoneconf = function(index){
            $scope.showAddBtn = true;
            $scope.showClsBtn = false;
            $scope.conferencelist.splice(index,1);
            $scope.schedule.scheduleMeetings.splice(index,1);
        }

        function save_schedule(scheduleDetail,caseNumber,scheduleCaseType){
            var query = BuildScheduleQuery(scheduleDetail,caseNumber)
            console.log('query',query);
            if(scheduleCaseType == 'AA Case'){
                DataService.post('SaveSchedule',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Schedule saved successfully');
                    get_progress_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".progress-schedule-modal").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else if(scheduleCaseType == 'ARA Case'){
                DataService.post('SaveARASchedule',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Schedule saved successfully');
                    get_progress_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".progress-schedule-modal").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
            
        }
        // to update the schedule
        $scope.updateSchedule = function(scheduleDetail,caseNumber){
            console.log('schedule',scheduleDetail);
            if(scheduleDetail.scheduleMeetings.length != 0){
                for(var times in scheduleDetail.scheduleMeetings){
                    if(!scheduleDetail.scheduleMeetings[times].venue){
                        scheduleDetail.scheduleMeetings[times].meetingStartTime = document.getElementById("startTime"+times).value;
                        scheduleDetail.scheduleMeetings[times].meetingEndTime = document.getElementById("endTime"+times).value;
                        var start_time = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[0];
                        var start_hour = start_time.split(':')[0];
                        var start_mini = start_time.split(':')[1];
                        var start_Sched = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[1];
                        var end_time = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[0];
                        var end_hour = end_time.split(':')[0];
                        var end_mini = end_time.split(':')[1];
                        var end_Sched = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[1];
                        if(start_Sched == 'am'&& end_Sched == 'pm'){
                            update_schedule(scheduleDetail,caseNumber);
                        }else if(start_Sched == 'pm'&& end_Sched == 'am'){
                            NotifyFactory.log('error', 'Start time should be less than end time' );
                        }else if(start_Sched==end_Sched){
                            if(start_hour == '12' && start_Sched == 'pm'){
                                update_schedule(scheduleDetail,caseNumber);
                            }
                            else if(start_hour < end_hour){
                                update_schedule(scheduleDetail,caseNumber);
                            }else if(start_hour == start_hour){
                                if(start_mini < end_mini){
                                    update_schedule(scheduleDetail,caseNumber);
                                }else if(start_mini == end_mini){
                                    NotifyFactory.log('error', 'Start time and end time should not be same' );
                                }else{
                                    NotifyFactory.log('error', 'Start time should be less than end time' );
                                }
                            }else if(start_hour > start_hour){
                                NotifyFactory.log('error', 'Start time should be less than end time' );
                            }
                        }
                    }
                }
            }else{
                update_schedule(scheduleDetail,caseNumber);
            }
            
        }

        function update_schedule(scheduleDetail,caseNumber){
            var query = BuildScheduleQuery(scheduleDetail,caseNumber)
            console.log('query',query);
            DataService.post('UpdateSchedule',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                NotifyFactory.log('success', 'Schedule updated successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".progress-schedule-modal").css("display","none");
                    get_progress_caselist();
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        function setvalue(value){
            if(value == 'Yes'){
                return true;
            }else{
                return false;
            }

        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        function undefinedSetFalse(val){
            if(val){
                return val;
            } else {
                var val = false;
                return val;
            }
            return val;
        }

        //build query for schedule
        function BuildScheduleQuery(scheduleDetail,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "arLodgedDueDate":undefinedSetNull(scheduleDetail.arLodgedDueDate), 
                "commencementDate":scheduleDetail.commencementDate, 
                "determineDuedate":scheduleDetail.determineDuedate, 
                "claimantReplyDeadline":undefinedSetNull(scheduleDetail.claimantReplyDeadline), 
                "respondentResponseDeadline":undefinedSetNull(scheduleDetail.respondentResponseDeadline), 
                "claimantFinalReplyDeadline":undefinedSetNull(scheduleDetail.claimantFinalReplyDeadline), 
                "isRoomRequired": setvalue(scheduleDetail.isRoomRequired), 
            }
            query.scheduleMeetings = [];
            if(scheduleDetail.scheduleMeetings.length != 0){
                for(var meet in scheduleDetail.scheduleMeetings){
                    var meetings = {
                        "id" : scheduleDetail.scheduleMeetings[meet].id,
                        "meetingDate": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingDate),
                        "meetingStartTime": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingStartTime),
                        "meetingEndTime": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingEndTime),
                        "isParkingRequired": setvalue(scheduleDetail.scheduleMeetings[meet].isParkingRequired), 
                        "vehicleRegNum": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].vehicleRegNum)
                    }
                    query.scheduleMeetings.push(meetings)
                }
            }
            return query;
        }

        function findStatus(array,action){
            var a = 0;
            if(array != undefined) {
                for(var index =0;index<array.length;index++){
                    if(array[index] == action){
                        a = 1;
                    }
                }
            }
            if(a == 1){
                return true;
            } else{
                return false;
            }
        }
        $scope.openTimesheet = function(caseData,ifamend){
            openTimesheet(caseData);
            if(ifamend == 'amend'){
                $scope.submitStatus = false;
            }else{
                if(caseData.timesheetSubmitStatus){
                    $scope.submitStatus = caseData.timesheetSubmitStatus;
                }else{
                    $scope.submitStatus = !caseData.isTimeSheetEnalbe;
                }
                
            }
            $scope.draftTimeSheet = false;
        }

        function openTimesheet(caseData){
            $scope.timeDetails.workedDate='';
            $scope.timeDetails.description='';
            $scope.timeDetails.startTime='';
            $scope.timeDetails.endTime='';
            $scope.isErrorMsgShown = false;
            $scope.turnRed = false;
            $scope.mustWavedHours = false;
            $rootScope.startDateofTimesheet = caseData.adjudicatorAppointedDate;
            $rootScope.caseData = caseData;
            $scope.timeSheetCaseType = caseData.caseType;
            $scope.ClaimantName = caseData.claimantName;
            $scope.Respond = caseData.respondentName;
            $scope.timesheetNumber = caseData.caseNumber;
            if($scope.timeSheetCaseType == 'AA Case'){
                viewAATimeSheetData($scope.timesheetNumber);
            }else if($scope.timeSheetCaseType == 'ARA Case'){
                viewARATimeSheetData($scope.timesheetNumber);
            }
            
        }
        $scope.workedDatesList = [];
        //view AA timesheet data
        function viewAATimeSheetData(timesheetNumber){
            var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
            GetTimeSheetDataUrl = GetTimeSheetDataUrl + timesheetNumber;
            $http.get(GetTimeSheetDataUrl).then(function(data){
                console.log("data",data)
                $scope.timeSheetData = data.data.result;
                if(parseInt($scope.timeSheetData.depositedAmount) < parseInt($scope.timeSheetData.costIncurredToDate)){
                    $scope.isErrorMsgShown = true;
                }else{
                    $scope.isErrorMsgShown = false;
                }
                if((parseInt($scope.timeSheetData.depositedAmount)-(parseInt($scope.timeSheetData.depositedAmount)/10)) <= (parseInt($scope.timeSheetData.costIncurredToDate)) && (parseInt($scope.timeSheetData.costIncurredToDate) < (parseInt($scope.timeSheetData.depositedAmount)))){
                    $scope.turnRed = true;
                }else{
                    $scope.turnRed = false;
                }
                if((parseInt($scope.timeSheetData.depositedAmount)/10) < (parseInt($scope.timeSheetData.costIncurredToDate))){
                    $scope.mustWavedHours = true;
                }else{
                    $scope.mustWavedHours = false;
                }
                if($scope.timeSheetData.supportingDocument){
                    $scope.supprtDocumentName = $scope.timeSheetData.supportingDocument.name;
                    $scope.supportingDocument = $scope.timeSheetData.supportingDocument.fileLocation;
                    $scope.attachcopyStatus = true;
                }
                $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                for(var date in $rootScope.workingDatas){
                    var findIndex = $scope.workedDatesList.indexOf($rootScope.workingDatas[date].workedDateStr);
                    if(findIndex == -1){
                        $scope.workedDatesList.push($rootScope.workingDatas[date].workedDateStr);
                    }
                }
                angular.element(".overlay").css("display","block");
                angular.element(".timeSheet-progress-modal").css("display","block");
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        //view ARA timesheet data
        function viewARATimeSheetData(timesheetNumber){
            var query = {
                "caseNumber" : timesheetNumber,
                "adjudicatorId" : parseInt($cookies.get('memberId'))
            }
            DataService.post('GetARATimeSheetData',query).then(function(data){
                console.log("data",data)
                $scope.timeSheetData = data.result;
                if(parseInt($scope.timeSheetData.depositedAmount) < parseInt($scope.timeSheetData.costIncurredToDate)){
                    $scope.isErrorMsgShown = true;
                }else{
                    $scope.isErrorMsgShown = false;
                }
                if((parseInt($scope.timeSheetData.depositedAmount)-(parseInt($scope.timeSheetData.depositedAmount)/10)) <= (parseInt($scope.timeSheetData.costIncurredToDate)) && (parseInt($scope.timeSheetData.costIncurredToDate) < (parseInt($scope.timeSheetData.depositedAmount)))){
                    $scope.turnRed = true;
                }else{
                    $scope.turnRed = false;
                }
                if((parseInt($scope.timeSheetData.depositedAmount)/10) < (parseInt($scope.timeSheetData.costIncurredToDate))){
                    $scope.mustWavedHours = true;
                }else{
                    $scope.mustWavedHours = false;
                }
                if($scope.timeSheetData.supportingDocument){
                    $scope.supprtDocumentName = $scope.timeSheetData.supportingDocument.name;
                    $scope.supportingDocument = $scope.timeSheetData.supportingDocument.fileLocation;
                    $scope.attachcopyStatus = true;
                }
                $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                angular.element(".overlay").css("display","block");
                angular.element(".timeSheet-progress-modal").css("display","block");
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        $scope.closetimesheetpopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".timeSheet-progress-modal").css("display","none");
        }

        // Add the time sheet
        $scope.addTimeSheet = function(timeDetails){
            if($rootScope.workingDatas == undefined){
                $rootScope.workingDatas = [];
            }
            timeDetails.startTime= document.getElementById("addstartTime").value;
            timeDetails.endTime = document.getElementById("addendTime").value;
            var start_time = timeDetails.startTime.split(' ')[0];
            var start_hour = start_time.split(':')[0];
            var start_mini = start_time.split(':')[1];
            var start_Sched = timeDetails.startTime.split(' ')[1];
            var end_time = timeDetails.endTime.split(' ')[0];
            var end_hour = end_time.split(':')[0];
            var end_mini = end_time.split(':')[1];
            var end_Sched = timeDetails.endTime.split(' ')[1];
            if(start_Sched == 'am'&& end_Sched == 'pm'){
                add_time_schedule(timeDetails);
            }else if(start_Sched == 'pm'&& end_Sched == 'am'){
                NotifyFactory.log('error', 'Start time should be less than end time' );
            }else if(start_Sched==end_Sched){
                if(start_hour == '12' && start_Sched == 'pm'){
                    add_time_schedule(timeDetails);
                }
                else if(start_hour < end_hour){
                    add_time_schedule(timeDetails);
                }else if(start_hour == start_hour){
                    if(start_mini < end_mini){
                        add_time_schedule(timeDetails);
                    }else if(start_mini == end_mini){
                        NotifyFactory.log('error', 'Start time and end time should not be same' );
                    }else{
                        NotifyFactory.log('error', 'Start time should be less than end time' );
                    }
                }else if(start_hour > start_hour){
                    NotifyFactory.log('error', 'Start time should be less than end time' );
                }
            }
        }

        function add_time_schedule(timeDetails){
            var query ={
                "id":undefinedSetNull(parseInt(timeDetails.id)),
                "workedDateStr":timeDetails.workedDate, 
                "description":timeDetails.description, 
                "startTime":timeDetails.startTime, 
                "endTime":timeDetails.endTime, 
            }
            if($scope.workedDatesList.indexOf(timeDetails.workedDate) == -1){
                $scope.workedDatesList.push(timeDetails.workedDate);
            }
            $rootScope.workingDatas.push(query);
            $scope.timeDetails={};
        }
        
        // Update the time sheet
        $scope.updateTimeSheet = function(timeDetails){
            timeDetails.startTime= document.getElementById("addStartTime").value;
            timeDetails.endTime = document.getElementById("addEndTime").value;
            var start_time = timeDetails.startTime.split(' ')[0];
            var start_hour = start_time.split(':')[0];
            var start_mini = start_time.split(':')[1];
            var start_Sched = timeDetails.startTime.split(' ')[1];
            var end_time = timeDetails.endTime.split(' ')[0];
            var end_hour = end_time.split(':')[0];
            var end_mini = end_time.split(':')[1];
            var end_Sched = timeDetails.endTime.split(' ')[1];
            if(start_Sched == 'am'&& end_Sched == 'pm'){
                update_time_schedule(timeDetails);
            }else if(start_Sched == 'pm'&& end_Sched == 'am'){
                NotifyFactory.log('error', 'Start time should be less than end time' );
            }else if(start_Sched==end_Sched){
                if(start_hour == '12' && start_Sched == 'pm'){
                    update_time_schedule(timeDetails);
                }
                else if(start_hour < end_hour){
                    update_time_schedule(timeDetails);
                }else if(start_hour == start_hour){
                    if(start_mini < end_mini){
                        update_time_schedule(timeDetails);
                    }else if(start_mini == end_mini){
                        NotifyFactory.log('error', 'Start time and end time should not be same' );
                    }else{
                        NotifyFactory.log('error', 'Start time should be less than end time' );
                    }
                }else if(start_hour > start_hour){
                    NotifyFactory.log('error', 'Start time should be less than end time' );
                }
            }
        }

        $scope.saveUpdateTimeSheet = function(timeDetails){
            timeDetails.startTime= document.getElementById("addStartTime").value;
            timeDetails.endTime = document.getElementById("addEndTime").value;
            var start_time = timeDetails.startTime.split(' ')[0];
            var start_hour = start_time.split(':')[0];
            var start_mini = start_time.split(':')[1];
            var start_Sched = timeDetails.startTime.split(' ')[1];
            var end_time = timeDetails.endTime.split(' ')[0];
            var end_hour = end_time.split(':')[0];
            var end_mini = end_time.split(':')[1];
            var end_Sched = timeDetails.endTime.split(' ')[1];
            if(start_Sched == 'am'&& end_Sched == 'pm'){
                save_update_time_schedule(timeDetails);
            }else if(start_Sched == 'pm'&& end_Sched == 'am'){
                NotifyFactory.log('error', 'Start time should be less than end time' );
            }else if(start_Sched==end_Sched){
                if(start_hour == '12' && start_Sched == 'pm'){
                    save_update_time_schedule(timeDetails);
                }
                else if(start_hour < end_hour){
                    save_update_time_schedule(timeDetails);
                }else if(start_hour == start_hour){
                    if(start_mini < end_mini){
                        save_update_time_schedule(timeDetails);
                    }else if(start_mini == end_mini){
                        NotifyFactory.log('error', 'Start time and end time should not be same' );
                    }else{
                        NotifyFactory.log('error', 'Start time should be less than end time' );
                    }
                }else if(start_hour > start_hour){
                    NotifyFactory.log('error', 'Start time should be less than end time' );
                }
            }
        }

        function update_time_schedule(timeDetails){
             var query ={
                "id":undefinedSetNull(parseInt(timeDetails.id)),
                "workedDateStr":timeDetails.workedDateStr, 
                "description":timeDetails.description, 
                "startTime":timeDetails.startTime, 
                "endTime":timeDetails.endTime, 
            }
            console.log('$rootScope.dataIndex',$rootScope.dataIndex)
            $rootScope.workingDatas[$rootScope.dataIndex]=query;
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","block");
            angular.element(".edit-timeSheet-model").css("display","none");
        }

        function save_update_time_schedule(timeDetails){
             var query ={
                "id":undefinedSetNull(parseInt(timeDetails.id)),
                "workedDateStr":timeDetails.workedDateStr, 
                "description":timeDetails.description, 
                "startTime":timeDetails.startTime, 
                "endTime":timeDetails.endTime, 
            }
            console.log('$rootScope.dataIndex',$rootScope.dataIndex)
            $rootScope.workingDatas[$rootScope.dataIndex]=query;
            angular.element(".overlay").css("display","block");
            angular.element(".view-timesheet-determination").css("display","block");
            angular.element(".edit-update-timeSheet-model").css("display","none");
        }

        


        // confirmation before Delete the schedule in time sheet
        $scope.opendeleteconfirmation= function(workingDataId,$index){
            $scope.workingDataId = workingDataId;
            $scope.workingDataIndex = $index;
            angular.element(".timeSheet-progress-modal").css("display","none");
            angular.element(".form-submitt-confirm").css("display","block");
        }

        $scope.opendeleteUpdatedconfirmation = function(workingDataId,$index){
            $scope.workingDataId = workingDataId;
            $scope.workingDataIndex = $index;
            angular.element(".view-timesheet-determination").css("display","none");
            angular.element(".form-submitt-updated-confirm").css("display","block");
        }

        // to close popup model for delete adjudicator
        $scope.canceldelete = function(){
            angular.element(".form-submitt-confirm").css("display","none");
            angular.element(".timeSheet-progress-modal").css("display","block");
        }

        $scope.cancelupdateddelete = function(){
            angular.element(".form-submitt-updated-confirm").css("display","none");
            angular.element(".view-timesheet-determination").css("display","block");
        }

        // Delete the schedule in time sheet
        $scope.deleteTimeSheet = function(sheetId,index){
            if(sheetId != null){
                var DeleteTimeSheetDataUrl = smcConfig.services.DeleteTimeSheetData.url;
                DeleteTimeSheetDataUrl = DeleteTimeSheetDataUrl + sheetId;
                $http.get(DeleteTimeSheetDataUrl).then(function(data){
                    console.log("data",data)
                    NotifyFactory.log('success', 'Timesheet entry deleted successfully');
                    openTimesheet($rootScope.caseData);
                    angular.element(".form-submitt-confirm").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else{
                $rootScope.workingDatas.splice(index,1);
                angular.element(".form-submitt-confirm").css("display","none");
                angular.element(".timeSheet-progress-modal").css("display","block");
            }
        }

        $scope.deleteUpdatedTimeSheet = function(sheetId,index){
            if(sheetId != null){
                var DeleteTimeSheetDataUrl = smcConfig.services.DeleteTimeSheetData.url;
                DeleteTimeSheetDataUrl = DeleteTimeSheetDataUrl + sheetId;
                $http.get(DeleteTimeSheetDataUrl).then(function(data){
                    console.log("data",data)
                    NotifyFactory.log('success', 'Timesheet entry deleted successfully');
                    openTimesheet($rootScope.caseData);
                    angular.element(".form-submitt-updated-confirm").css("display","none");
                    angular.element(".view-timesheet-determination").css("display","block");
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else{
                $rootScope.workingDatas.splice(index,1);
                angular.element(".form-submitt-updated-confirm").css("display","none");
                angular.element(".view-timesheet-determination").css("display","block");
            }
        }

        // save time sheet
        $scope.SaveTimeSheet = function(sheetData,caseNumber,timeSheetCaseType){
            var query = BuildTimesheetQuery(sheetData,caseNumber);
            console.log('query',query)
            if(timeSheetCaseType == 'AA Case'){
                DataService.post('SaveTimeSheet',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Timesheet saved successfully');
                    get_progress_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".timeSheet-progress-modal").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else if(timeSheetCaseType == 'ARA Case'){
                DataService.post('SaveARATimeSheet',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Timesheet saved successfully');
                    get_progress_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".timeSheet-progress-modal").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
        }

        //open confimation popup to submit time sheet
        $scope.openConfirmationTimesheet = function(timeSheetData,timesheetNumber,timeSheetCaseType){
            $scope.timeSheetData = timeSheetData;
            $scope.timesheetNumber = timesheetNumber;
            $scope.timeSheetCaseType = timeSheetCaseType;
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","none");
            angular.element(".timesheet-confirm-modal").css("display","block");
        }
        //close confimation popup to submit time sheet
        $scope.closeConfirmationTimesheet = function(){
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","block");
            angular.element(".timesheet-confirm-modal").css("display","none");
        }

        // Submit the time sheet
        $scope.submitTimeSheet = function(sheetData,caseNumber,timeSheetCaseType,isDraft){
            var query = BuildTimesheetQuery(sheetData,caseNumber);
            if(timeSheetCaseType == 'AA Case'){
                DataService.post('SubmitTimeSheet',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        get_progress_caselist();
                        if(isDraft == undefined){
                            NotifyFactory.log('success', 'Timesheet submitted successfully');
                            if($scope.draftTimeSheet == false){
                                if(sheetData.isGSTRegistered){
                                    openConfirmationUploadInvoice(caseNumber)
                                }else{
                                    angular.element(".overlay").css("display","none");
                                    angular.element(".timesheet-confirm-modal").css("display","none");
                                }
                            }else{
                                if($rootScope.caseData.caseType == 'AA Case'){
                                    $rootScope.caseData.caseStatus.push('Time Sheet Submitted');
                                }
                                
                                angular.element(".timesheet-confirm-modal").css("display","none");
                                openDraftDetermination($rootScope.caseData)
                            }  
                        }else{
                            reRequestDraft(isDraft);
                        }
                        
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else if(timeSheetCaseType == 'ARA Case'){
                DataService.post('SubmitARATimeSheet',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    get_progress_caselist();
                    if(isDraft == undefined){
                        NotifyFactory.log('success', 'Timesheet submitted successfully');
                            if($scope.draftTimeSheet == false){
                                if(sheetData.isGSTRegistered){
                                    openConfirmationUploadInvoice(caseNumber)
                                }else{
                                    angular.element(".overlay").css("display","none");
                                    angular.element(".timesheet-confirm-modal").css("display","none");
                                }
                            }else{
                                $rootScope.caseData.isTimeSheetEnalbe = false;
                                angular.element(".timesheet-confirm-modal").css("display","none");
                                openDraftDetermination($rootScope.caseData)
                            }  
                        }else{
                            reRequestDraft(isDraft);
                        }
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
        }

        // build query for save and submit the timesheet 
        function BuildTimesheetQuery(sheetData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":parseInt($cookies.get('memberId')), 
                "disbursementAmount":undefinedSetNull(sheetData.disbursementAmount), 
                "waivedHours":undefinedSetNull(sheetData.waivedHours), 
                "isGSTRegistered":sheetData.isGSTRegistered, 
                "supportingDocument": null
            }
            if($scope.supportingDocument || $scope.timeSheetData.supportingDocument){
                query.supportingDocument = { 
                    "name": $scope.supprtDocumentName ? $scope.supprtDocumentName : $scope.timeSheetData.supportingDocument.name,
                    "fileLocation":$scope.supportingDocument ? $scope.supportingDocument : $scope.timeSheetData.supportingDocument.fileLocation,
                }
            }
            $scope.workingDetails = [];
            if(sheetData.workedHours){
                for(var index = 0; index<sheetData.workedHours.length;index++){
                    var workHours ={
                        "id":undefinedSetNull(parseInt(sheetData.workedHours[index].id)),
                        "workedDate":sheetData.workedHours[index].workedDateStr, 
                        "description":sheetData.workedHours[index].description, 
                        "startTime":sheetData.workedHours[index].startTime, 
                        "endTime":sheetData.workedHours[index].endTime, 
                    }
                    $scope.workingDetails.push(workHours);
                }
                query["workedHours"] = $scope.workingDetails;
            }else{
                for(var index = 0; index<$rootScope.workingDatas.length;index++){
                    var workHours ={
                        "id":undefinedSetNull(parseInt($rootScope.workingDatas[index].id)),
                        "workedDate":$rootScope.workingDatas[index].workedDateStr, 
                        "description":$rootScope.workingDatas[index].description, 
                        "startTime":$rootScope.workingDatas[index].startTime, 
                        "endTime":$rootScope.workingDatas[index].endTime, 
                    }
                    $scope.workingDetails.push(workHours);
                }
                query["workedHours"] = $scope.workingDetails;
            }

            return query;
        }

        //open add time sheet popup
        $scope.editTimeSheet = function(workingData,index){
            $scope.workingData = workingData;
            $rootScope.dataIndex = index;
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","none");
            angular.element(".edit-timeSheet-model").css("display","block");
        }

        //close add time sheet
        $scope.closeEditTimepop = function(){
            angular.element(".edit-timeSheet-model").css("display","none");
            angular.element(".overlay").css("display","block");
            angular.element(".timeSheet-progress-modal").css("display","block");
            
        }

    function openConfirmationUploadInvoice(caseNumber){
            var query={
                        "adjudicatorId": $cookies.get('memberId'),
                        "caseNumber": caseNumber
            }
            DataService.post('ViewAdjudicatorCost',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   $scope.adjudicatorFee  = data.result;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });

            $scope.uploadInvoiceCaseNo = caseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".timesheet-confirm-modal").css("display","none");
            angular.element(".conformation-upload-invoice-modal").css("display","block");
        }

        $scope.closeConfirmationUpload = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".conformation-upload-invoice-modal").css("display","none");
        }

        //open upload invoice modal
        $scope.openUploadInvoice = function(caseNumber,adjFee){
            $scope.invoiceCaseNumber = caseNumber;
            $scope.invoiceData = {};
            $scope.invoiceData.invoiceAmount = adjFee;
            $scope.supportingDocument = '';
            $scope.supprtDocumentName = '';
            $scope.attachcopyStatus = false;
            angular.element(".overlay").css("display","block");
            angular.element(".conformation-upload-invoice-modal").css("display","none");
            angular.element(".upload-invoice-modal").css("display","block");
        }

        //close upload invoice modal
        $scope.closeinvoicepopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".upload-invoice-modal").css("display","none");
        }

        //submit upload invoice
        $scope.uploadInvoice = function(invoiceData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "invoiceNumber":invoiceData.invoiceNo,
                "invoiceDate":invoiceData.invoiceDate, 
                "invoiceAmount":invoiceData.invoiceAmount, 
                "invoiceDocument":{ 
                    "name":$scope.supprtDocumentName, 
                    "fileLocation":$scope.supportingDocument
                }
            }
            DataService.post('UploadAdjudicatorInvoice',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Invoice uploaded successfully');
                   get_progress_caselist();
                   angular.element(".overlay").css("display","none");
                    angular.element(".upload-invoice-modal").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //open model for request of EOT
        $scope.openRequestEOT = function(caseNumber,oldDueDate){
            $scope.requestEOTData = {};
            $scope.EOTnumber = caseNumber;
            $scope.oldDueDate = oldDueDate;
            angular.element(".overlay").css("display","block");
            angular.element(".request-EOT-model").css("display","block");
        }

        //close model for request of EOT
        $scope.closeRequestEOT = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".request-EOT-model").css("display","none");
        }

        //submit of request for EOT
        $scope.submitEOTRequest = function(requestEOTData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "newDueDate":requestEOTData.newDueDate, 
                "isConsentObtained":requestEOTData.isConsentObtained, 
                "adjudicatorId":parseInt($cookies.get('memberId')), 
                "remarks":undefinedSetNull(requestEOTData.remarks) 
            }
            DataService.post('SubmitEOTRequest',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'EOT requested successfully');
                    get_progress_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".request-EOT-model").css("display","none");
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

         //to get int type month for datepicker min date to select acknowledgement
        function getIntType(month){
            var months = {
                "Jan" : 1,
                "Feb" : 2,
                "Mar" : 3,
                "Apr" : 4,
                "May" : 5,
                "Jun" : 6,
                "Jul" : 7,
                "Aug" : 8,
                "Sep" : 9,
                "Oct" : 10,
                "Nov" : 11,
                "Dec" : 12
            }
            return months[month];
        }

        //open Messaging window between claimant/respondent and adjudicator
        $scope.openMessageWindow = function(caseNumber){
            $scope.supprtDocumentName = '';
               $scope.supportingDocument = '';
               $scope.attachcopyStatus = false;
            var loginRole = $cookies.get('roleName');
            $rootScope.loginRole = loginRole[0].toUpperCase()+loginRole.slice(1);
            $scope.sendData = {};
            $scope.sendData.caseNumber = caseNumber;
            viewMessages(caseNumber,$rootScope.loginRole);
            angular.element(".overlay").css("display","block");
            angular.element(".messaging-window-modal").css("display","block");
        }

        //close Messaging window between claimant/respondent and adjudicator
        $scope.closeMessageWindow = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".messaging-window-modal").css("display","none");
        }
         $scope.viewSendButton = true;
        // send message to others
        $scope.sendMessage = function(messageData){
            console.log('messageData',messageData);
            var query = {
                "caseNumber":messageData.caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "receipientRole":messageData.receipientRole, 
                "message":messageData.message, 
                "supportDocument": null
            }
            if($scope.supprtDocumentName){
                query["supportDocument"] = { 
                    "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument 
                }
            }
            DataService.post('SendAdjudicatorMessage',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Message sent successfully');
                   viewMessages(messageData.caseNumber,$rootScope.loginRole);
                   $scope.supprtDocumentName = '';
                   $scope.supportingDocument = '';
                   $scope.attachcopyStatus = false;
                   $scope.sendData = {};
                   $scope.sendData.caseNumber = messageData.caseNumber;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        // get messages
        function viewMessages(caseNumber,role,searchRole){
            var query = {
                "caseNumber":caseNumber, 
                "searchRole":undefinedSetNull(searchRole), 
                "memberRole":role
            }
            DataService.post('ViewMessages',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   $scope.messages = data.results;
                }
            }).catch(function (error) {
                if(error.errorMessage == 'No Messaegs found'){
                    NotifyFactory.log('error', 'No Messages found');
                }else{
                    NotifyFactory.log('error', error.errorMessage);
                }
            });
        }
        // get selected messages
        $scope.getselectedMessages = function(caseNumber,role){
            viewMessages(caseNumber,$rootScope.loginRole,role);
        }

        //open Draft Determination Submission
        $scope.openDraftDetermination = function(draft_case){
            $scope.updateDraft = false;
            if(draft_case.caseType == 'AA Case'){
                openDraftDetermination(draft_case);
            }else{
                getLatARADetermination(draft_case)
            }
            
        }

        function getLatARADetermination(draft_case) {
            if(!draft_case.isTimeSheetEnalbe){
                $scope.updateDraft = false;
                $scope.draftCaseNumber = draft_case.caseNumber;
                $scope.draftCaseType = draft_case.caseType;
                 var GetDeterminationListUrl = smcConfig.services.GetDeterminationList.url;
                 GetDeterminationListUrl = GetDeterminationListUrl + draft_case.caseNumber;
                 $http.get(GetDeterminationListUrl).then(function (data) {
                     console.log("data", data)
                     if(data.data.result){
                        $scope.draftData = data.data.result;
                         $scope.determinations = $scope.draftData.determinationVersions;
                         $scope.supprtDocumentName = $scope.determinations[$scope.determinations.length-1].documents.name;
                         $scope.supportingDocument = $scope.determinations[$scope.determinations.length-1].documents.fileLocation;
                         $scope.smcOfficerComment = $scope.determinations[$scope.determinations.length-1].comments;
                         $scope.attachcopyStatus = true;
                         $scope.updateDraft = true;
                     }else{
                        $scope.draftData = {};
                        $scope.supprtDocumentName = '';
                        $scope.attachcopyStatus = false;
                        $scope.updateDraft = false;
                     }
                 }).catch(function (error) {
                    $scope.draftData = {};
                    $scope.supprtDocumentName = '';
                    $scope.attachcopyStatus = false;
                    $scope.updateDraft = false;
                });
                 angular.element(".overlay").css("display","block");
                angular.element(".Submit-Draft-Determination").css("display","block");
            }else{
                openTimesheet(draft_case);
                $scope.submitStatus = false;
                $scope.draftTimeSheet = true;
                NotifyFactory.log('error','Please submit your time sheet before determination')
            }
         }

        function openDraftDetermination(draft_case){
            if(draft_case.caseType == 'AA Case'){
                if(draft_case.caseStatus.indexOf('Time Sheet Submitted') != -1){
                    $scope.draftData = {};
                    $scope.supprtDocumentName = '';
                    $scope.attachcopyStatus = false;
                    $scope.draftCaseNumber = draft_case.caseNumber;
                    $scope.draftCaseType = draft_case.caseType;
                    angular.element(".overlay").css("display","block");
                    angular.element(".Submit-Draft-Determination").css("display","block");
                }else{
                    openTimesheet(draft_case);
                    $scope.submitStatus = false;
                    $scope.draftTimeSheet = true;
                    NotifyFactory.log('error','Please submit your time sheet before determination')
                }
            }else{
                getLatARADetermination(draft_case) 
            }
            
        }

        //close Messaging window between claimant/respondent and adjudicator
        $scope.closeDraftDetermination = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".Submit-Draft-Determination").css("display","none");
        }

        //open request TopUp model
        $scope.openrequestTopUp = function (caseNumber,oldDueDate,topUpCaseType){
            $scope.topUpData = {};
            $scope.loginRole = $cookies.get('roleName');
            $scope.topUpCaseNumber = caseNumber;
            $scope.topUpCaseType = topUpCaseType;
            $scope.oldDueDate = oldDueDate;
            $scope.exceedErrorMsg = false;
            angular.element(".overlay").css("display","block");
            angular.element(".Request-TopUp-Model").css("display","block");
        }

        //close Messaging window between claimant/respondent and adjudicator
        $scope.closerequestTopUp = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".Request-TopUp-Model").css("display","none");
        }

        $scope.changeexceedErrorMsgStatus= function(){
            if($scope.exceedErrorMsg == true){
                 $scope.exceedErrorMsg = false
            }
        }

        //to Submit for approval Draft Datermination
        $scope.requestDraft = function(draftData,caseNumber,draftCaseType){
            var query = buildDraftQuery(draftData,caseNumber);
            if(draftCaseType == 'AA Case'){
                DataService.post('SaveDraftDetermine',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Determination Requested successfully');
                    get_progress_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".Submit-Draft-Determination").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else if(draftCaseType == 'ARA Case'){
                DataService.post('SaveARADraftDetermine',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Determination Requested successfully');
                    get_progress_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".Submit-Draft-Determination").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
        }
        // to build Draft determination query
        function buildDraftQuery(draftData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "isUseOfExperts":undefinedSetFalse(draftData.isUseOfExperts), 
                "expertDetails":draftData.expertDetails, 
                "isAdjudicatorConferenceMatter":undefinedSetFalse(draftData.isAdjudicatorConferenceMatter), 
                "reason":undefinedSetNull(draftData.reason), 
                "document":{ 
                    "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument 
                }
            }
            return query;
        }
        // To Submit Request for additional deposit
        $scope.submitTopUpRequest = function(requestData,caseNumber,topUpCaseType){
            var query = buildTopUpQuery(requestData,caseNumber);
            if(topUpCaseType == 'AA Case'){
                 DataService.post('SaveRequestTopUp',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Topup requested successfully');
                    get_progress_caselist();
                    angular.element(".overlay").css("display","none");
                        angular.element(".Request-TopUp-Model").css("display","none");
                    }
                }).catch(function (error) {
                    if(error.errorMessage == 'Amount exceeds that allowed by Section 12 of the Building and Construction Industry Security of Payment Regulations'){
                        $scope.exceedErrorMsg = true;
                    }else{
                        NotifyFactory.log('error', error.errorMessage);
                    }
                });
            }else if(topUpCaseType == 'ARA Case'){
                 DataService.post('SaveRequestARATopUp',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Topup requested successfully');
                    get_progress_caselist();
                    angular.element(".overlay").css("display","none");
                        angular.element(".Request-TopUp-Model").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
           
        }

        function buildTopUpQuery(requestData,caseNumber){
            var query = {
                "caseNumber":caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "amount":requestData.amount, 
                "dueDateDetermination":requestData.determineDueDate, 
                "depositDeadLine":requestData.depositDeadline
            }
            return query;
        }

        //open timesheet & determination for change
        $scope.openChangeDraft = function(caseData){
            $scope.dueDate = caseData.dueDateToDetermine;
            $scope.review_Determination_Path = 'views/member/reviewdetermination.html';
            $rootScope.viewCaseNumber = caseData.caseNumber;
            $rootScope.caseData = caseData;
            $scope.ClaimantName = caseData.claimantName;
            $scope.Respond = caseData.respondentName;
            $scope.timeSheetCaseType = caseData.caseType;
            $scope.startDateofTimesheet = caseData.adjudicatorAppointedDate;
            $rootScope.reviewComment = {};
            if($scope.timeSheetCaseType == 'AA Case'){
                gettimesheetList($rootScope.viewCaseNumber);
            }else{
                getARAtimesheetList($rootScope.viewCaseNumber)
            }
            getDeterminationList($rootScope.viewCaseNumber);
            angular.element(".overlay").css("display","block");
            angular.element(".view-timesheet-determination").css("display","block");
        }

        // close and review timesheet and determination
        $scope.closeDeterminationSheet = function(caseNumber){
            angular.element(".overlay").css("display","none");
            angular.element(".view-timesheet-determination").css("display","none");
        }

        //get all determination list
         function getDeterminationList(caseNumber) {
             var GetDeterminationListUrl = smcConfig.services.GetDeterminationList.url;
             GetDeterminationListUrl = GetDeterminationListUrl + caseNumber;
             $http.get(GetDeterminationListUrl).then(function (data) {
                 console.log("data", data)
                 $scope.draftData = data.data.result;
                 $scope.determinations = $scope.draftData.determinationVersions;
                 $scope.detreSupprtDocumentName = $scope.determinations[$scope.determinations.length-1].documents.name;
                 $scope.detarSupportingDocument = $scope.determinations[$scope.determinations.length-1].documents.fileLocation;
                 $scope.smcOfficerComment = $scope.determinations[$scope.determinations.length-1].comments;
                 $scope.deterAttachcopyStatus = true;
             });
         }

        
        //get all determination list
        function getAdjudicatorCost (caseNumber){
            var ViewAdjudicatorCostUrl = smcConfig.services.ViewAdjudicatorCost.url;
            ViewAdjudicatorCostUrl = ViewAdjudicatorCostUrl + caseNumber;
            $http.get(ViewAdjudicatorCostUrl).then(function(data){
                var adjFee  = data.data.result;
            });
            var finalAdjFee = adjFee;
            return finalAdjFee
        }
        //get all timesheet list
        function gettimesheetList (caseNumber){
            var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
            GetTimeSheetDataUrl = GetTimeSheetDataUrl +  caseNumber;
            $http.get(GetTimeSheetDataUrl).then(function(data){
                console.log("data",data)
                $scope.timeSheetData = data.data.result;
                if((parseInt($scope.timeSheetData.depositedAmount)/10) < (parseInt($scope.timeSheetData.costIncurredToDate))){
                    $scope.mustWavedHours = true;
                }else{
                    $scope.mustWavedHours = false;
                }
                if($scope.timeSheetData.workedHours){
                    $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                }
                if($scope.timeSheetData.supportingDocument){
                    $scope.timeSheetattachcopyStatus = true;
                }
            });
        }

        function getARAtimesheetList(caseNumber) {
            var query = {
                "caseNumber" : caseNumber,
                "adjudicatorId" : parseInt($cookies.get('memberId'))
            }
            DataService.post('GetARATimeSheetData',query).then(function(data){
                console.log("data",data)
                $scope.timeSheetData = data.result;
                if((parseInt($scope.timeSheetData.depositedAmount)/10) < (parseInt($scope.timeSheetData.costIncurredToDate))){
                    $scope.mustWavedHours = true;
                }else{
                    $scope.mustWavedHours = false;
                }
                if($scope.timeSheetData.workedHours){
                    $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                }
                if($scope.timeSheetData.supportingDocument){
                    $scope.timeSheetattachcopyStatus = true;
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $scope.editUpdateTimeSheet = function(workingData,index) {
            $scope.workingData = workingData;
            $rootScope.dataIndex = index;
            angular.element(".overlay").css("display","block");
            angular.element(".view-timesheet-determination").css("display","none");
            angular.element(".edit-update-timeSheet-model").css("display","block");
        }

        $scope.closeEditUpdateTimepop = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".view-timesheet-determination").css("display","block");
            angular.element(".edit-update-timeSheet-model").css("display","none");
        }

        //resubmit for determination approval
        $scope.reRequestDraft = function(draftDetails){
            reRequestDraft (draftDetails)
        }

        $scope.updateDraftDeter = function(draftData,draftCaseNumber){
            var query = {
                 "caseNumber": draftCaseNumber,
                   "adjudicatorId": $cookies.get('memberId'),
                   "isUseOfExperts": undefinedSetFalse(draftData.isUseOfExperts),
                   "expertDetails":undefinedSetNull(draftData.expertDetails),
                   "isAdjudicatorConferenceMatter":undefinedSetFalse(draftData.isAdjudicatorConferenceMatter),
                   "reason":undefinedSetNull(draftData.reason),
                   "adjudicatedAmount":undefinedSetNull(draftData.adjudicatedAmount),
                   "apportionmentAdjudicationCost ":undefinedSetNull(draftData.apportionmentAdjudicationCost),
                   "isFinialSubmission":undefinedSetFalse(draftData.isFinialSubmission),
                   "document":{
                      "name": $scope.supprtDocumentName,
                    "fileLocation":$scope.supportingDocument
                   }
            }
            DataService.post('UpdateDetrminationRequest',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Detrmination updated successfully');
                   get_progress_caselist();
                   angular.element(".overlay").css("display","none");
                    angular.element(".Submit-Draft-Determination").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function reRequestDraft (draftDetails){
            var query = {
                "caseNumber":draftDetails.caseNumber, 
                "adjudicatorId":$cookies.get('memberId'), 
                "isUseOfExperts":undefinedSetFalse(draftDetails.isUseOfExperts), 
                "expertDetails":draftDetails.expertDetails, 
                "isAdjudicatorConferenceMatter":undefinedSetFalse(draftDetails.isAdjudicatorConferenceMatter), 
                "reason":undefinedSetNull(draftDetails.reason), 
                "adjudicatedAmount":draftDetails.adjudicatedAmount, 
                "apportionmentAdjudicationCost":draftDetails.apportionmentAdjudicationCost, 
                "determinationDate":draftDetails.determinationDate, 
                "isFinialSubmission" : draftDetails.isfinalSubmission,
                "document":{ 
                    "name": $scope.detreSupprtDocumentName,
                    "fileLocation":$scope.detarSupportingDocument
                }
            }
            console.log('query',query)
            DataService.post('ResubmitDetrminationRequest',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                   NotifyFactory.log('success', 'Detrmination resubmitted successfully');
                   get_progress_caselist();
                   angular.element(".overlay").css("display","none");
                    angular.element(".view-timesheet-determination").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //Get Register Vehicle Number
        $scope.getRegisterVehileNo = function(index){
            var GetVehicleNUmberUrl = smcConfig.services.GetVehicleNUmber.url;
            GetVehicleNUmberUrl = GetVehicleNUmberUrl +  $cookies.get('memberId');
            $http.get(GetVehicleNUmberUrl).then(function(data){
                console.log("data",data)
                $scope.schedule.scheduleMeetings[index].vehicleRegNum = data.data.result;
            });
        }


        /* Resignation Proess Functionality */
        $scope.attachResignationStatus = false;
        //Open Resignation Withdraw Adjudicator model
        $scope.openResignationWithdrawPopUp = function (caseDetails,resignCaseType){
            $scope.isRequestInitiated = false;
            $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
            $scope.resignCaseType = resignCaseType;
            $scope.resgPopUpData = {};
            $scope.resgnationApprove = {};

            $scope.gstStatus = $cookies.get("GSTregistered");
            if($scope.gstStatus == "true"){
                $scope.resgnationApprove.gst = true;
            } else {
                $scope.resgnationApprove.gst = false;
            }
            if(caseDetails.resignationRequestStatus){
                $scope.isRequestInitiated = true;
                var ViewAdjudicatorResignUrl = smcConfig.services.ViewResignationRequest.url;
                ViewAdjudicatorResignUrl = ViewAdjudicatorResignUrl + caseDetails.caseNumber;
                $http.get(ViewAdjudicatorResignUrl).then(function (respon) {
                    var data = respon.data;
                    if(data.status == 'SUCCESS'){       
                        $scope.resgPopUpData.reason = data.result.reason;
                        $scope.resignationDocumentName = data.result.document.name;
                        $scope.resignationUploadedDocument = data.result.document.fileLocation;
                        $scope.attachResignationStatus = false;
                        $scope.loginRole = $cookies.get('roleName');
                        
                        if(caseDetails.resignationApproveManagerStatus){
                            angular.element(".overlay").css("display","block");
                            angular.element(".resignation-approve-PopUp-Model").css("display","block");
                        } else {
                            angular.element(".overlay").css("display","block");
                            angular.element(".resignation-withdraw-PopUp-Model").css("display","block");
                        }
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            } else {
                $scope.resignationDocumentName = undefined;
                $scope.resignationUploadedDocument = undefined;
                $scope.attachResignationStatus = false;
                $scope.loginRole = $cookies.get('roleName');
                angular.element(".overlay").css("display","block");
                angular.element(".resignation-withdraw-PopUp-Model").css("display","block");
            }
        }

        //Open Resignation Withdraw Adjudicator model
        $scope.closeResignationWithdrawPopUp = function(){
            $scope.resgPopUpData = {};
            $scope.resignationDocumentName = undefined;
            $scope.resignationUploadedDocument = undefined;
            $scope.attachResignationStatus = false;
            angular.element(".overlay").css("display","none");
            angular.element(".resignation-withdraw-PopUp-Model").css("display","none");
            angular.element(".resignation-approve-PopUp-Model").css("display","none");
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadResignationFile = function(file){
            $scope.resignationDocumentName='';
            $scope.resignationUploadedDocument='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFile(file.name)){
                    $scope.resignationDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.resignationUploadedDocument = data.result;
                        $scope.attachResignationStatus = true;
                    });
                }else{
                    $scope.attachResignationStatus = false;
                    $scope.attachResignationErrorMsg = "You can upload only " + $scope.determinatinFileTypes.toString();
                    NotifyFactory.log('error', $scope.attachResignationErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        // if we want remove upload file
        $scope.uploadResignationRemove = function(){
            $scope.resignationDocumentName = undefined;
            $scope.resignationUploadedDocument = undefined;
            $scope.attachResignationStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#resignation_suport_upload").val("");
        }

        //Submit Adjudicator Resignation
        $scope.adjudicatorResignationSubmit = function(resgPopUpData,CaseNumber){
            var query = {
                "caseNumber":CaseNumber,
                "adjudicatorId":$cookies.get('memberId'),
                "reason":resgPopUpData.reason,
                "document":{
                    "name":$scope.resignationDocumentName,
                    "fileLocation":$scope.resignationUploadedDocument
                }
            }
            console.log('query',query)
            DataService.post('AdjudicatorResignationRequest',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Request submitted successfully,Your withdrawal from appointment is subject to SMC Management’s approval.');
                    angular.element(".overlay").css("display","none");
                    angular.element(".resignation-withdraw-PopUp-Model").css("display","none");
                    get_progress_caselist();
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        $scope.invoiceSoftCopyUploadStatus = false;
        // upload Invoice Soft copy file - before that check file size,valid exetension
        $scope.uploadInvoiceSoftCopyFile = function(file){
            $scope.invoiceSoftCopyName='';
            $scope.invoiceSoftCopyPath='';
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFile(file.name)){
                    $scope.invoiceSoftCopyName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.invoiceSoftCopyPath = data.result;
                        $scope.invoiceSoftCopyUploadStatus = true;
                    });
                }else{
                    $scope.invoiceSoftCopyUploadStatus = false;
                    $scope.invoiceSoftCopyErrorMsg = "You can upload only " + $scope.determinatinFileTypes.toString();
                    NotifyFactory.log('error', $scope.invoiceSoftCopyErrorMsg);
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }

        //Submit Adjudication Time Cost for approval
        $scope.updateResignationInvoiceDetails = function(invoicePopUpData,CaseNumber,resignCaseType){
            var query = buildResignInvoiceQuery(invoicePopUpData,CaseNumber);
            console.log('query',query)
            if(resignCaseType == 'AA Case'){
                DataService.post('AdjudicatorResignationTimeCostSubmit',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success', 'Time Cost submitted successfully');
                        angular.element(".overlay").css("display","none");
                        angular.element(".resignation-approve-PopUp-Model").css("display","none");
                        get_progress_caselist();
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {        
                    NotifyFactory.log('error', error.errorMessage);
                });
            }else if (resignCaseType == 'ARA Case'){
                DataService.post('AdjudicatorARAResignationTimeCostSubmit',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success', 'Time Cost submitted successfully');
                        angular.element(".overlay").css("display","none");
                        angular.element(".resignation-approve-PopUp-Model").css("display","none");
                        get_progress_caselist();
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }
        }

        function buildResignInvoiceQuery(invoicePopUpData,CaseNumber){
             var query = {
                "caseNumber":CaseNumber,
                "adjudicatorId":$cookies.get('memberId'),
                "timeCostOption":invoicePopUpData.confirmationData,
                "invoice":{
                    "isGSTRegistered":invoicePopUpData.gst,
                    "invoiceNumber":invoicePopUpData.invoiceNumber,
                    "invoiceDate":invoicePopUpData.invoiceDate,
                    "invoiceAmount":invoicePopUpData.invoiceAmount,
                    "invoiceDocument":{
                        "name":$scope.invoiceSoftCopyName,
                        "fileLocation":$scope.invoiceSoftCopyPath
                    }
                }
            }
            return query;
        }

        $scope.openPleaseAdvice = function(caseNumber,dateType){
            $scope.dateType = dateType;
            $scope.adviceCaseNumber = caseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".please-advice-date-model").css("display","block");
        }

        $scope.closeAdvicePopup = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".please-advice-date-model").css("display","none");
        }

        $scope.submitAdviceDate = function(adviceDate,caseNumber,dateType){
            var query = {
                "caseNumber":caseNumber,
                "adjudicatorId":$cookies.get('memberId'),
                "dueDate":adviceDate
            }
            if(dateType == 'AR Due Date'){
                var serviceUrl  = 'PleaseAdviceARDueDate'
            }else{
                var serviceUrl  = 'PleaseAdviceDetermineDate'
            }
            var successMsg = dateType + ' submitted successfully';
            DataService.post(serviceUrl,query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', successMsg);
                    angular.element(".overlay").css("display","none");
                    angular.element(".please-advice-date-model").css("display","none");
                    get_progress_caselist();
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
    }
})();


