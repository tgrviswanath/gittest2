(function() {
    'use strict';
    angular
        .module('smc')
        .controller('pendingpaymentsCaseCtrl',pendingpaymentsCaseCtrl);

    pendingpaymentsCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function pendingpaymentsCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'pendingpayments'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $scope.reverseSort = false;
        get_pendingpayments_caselist($scope.pagenumber);//call to determined case list function
        $cookies.put('currentTab','pendingpayments');
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to determined case list function from outside
        $rootScope.pendingpaymentscaselist = function(){
            get_pendingpayments_caselist($cookies.get('pageNumber'));
        } 
        
        // get rejected case list
        function get_pendingpayments_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
            var query = {
                 "pageIndex":$scope.pagenumber,
                 "dataLength":10,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
            }
            DataService.post('GetPendingPaymentsCases',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.pendingpayments_Case_List = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.pendingpayments_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
                }else{
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function(pageNo){
           get_pendingpayments_caselist(pageNo);
        }
    }
})();


