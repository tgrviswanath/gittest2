(function() {
    'use strict';
    angular
        .module('smc')
        .controller('torespondCaseCtrl',torespondCaseCtrl);

    torespondCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function torespondCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'torespond'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.reverseSort = false;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_torespond_caselist($scope.pagenumber);//call to torespond case list function
        $cookies.put('currentTab','torespond');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        $scope.rejectdetail = {};
        $scope.rejectdetail.reason = '';
        $scope.rejectdetail.parties = [];

        //call to torespond case list function from outside
        $rootScope.torespondcaselist = function(){
            get_torespond_caselist($cookies.get('pageNumber'));
        } 

    	// get torespond case list
    	function get_torespond_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
    		}
    		DataService.post('AdjudicatorToRespondList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.torespond_Case_List = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.torespond_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        $scope.goToPageNumber = function(pageNo){
           get_torespond_caselist(pageNo);
        }

        // to open accept the case popup
        $scope.open_accept_popup = function(caseNumber,caseType){
            $scope.case_number = caseNumber;
            $scope.caseType = caseType;
            $scope.annexAform = smcConfig.services.DownloadAnnexAform.url+$scope.case_number;
            $scope.annexFform = smcConfig.services.DownloadAnnexFform.url+$scope.case_number;
            angular.element(".overlay").css("display","block");
            angular.element(".adjudicator-accept-case").css("display","block");
        }
        //to close accept popup
        $scope.cancelaccept = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".adjudicator-accept-case").css("display","none");
        }
        //to oprn reject the case popup
        $scope.open_reject_popup = function(caseNumber){
            $scope.rejectdetail = {};
            $scope.rejectCase = caseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".adjudicator-reject-case").css("display","block");
        }
        //to close reject popup
        $scope.cancelreject = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".adjudicator-reject-case").css("display","none");
        }

        $scope.acceptCase = function(status,caseNumber,caseType){
            var query = {
                "isAccepted" :  undefinedSetFalse(status),
                "adjudicatorId" : $cookies.get('memberId'),
                "caseNumber" : caseNumber
            }
            if(caseType == 'AA Case'){
                DataService.post('AdjudicatorAcceptCase',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success', "Case accepted successfully");
                        get_torespond_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".adjudicator-accept-case").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                })
                .catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });    
            }else if(caseType == 'ARA Case'){
                DataService.post('AdjudicatorAcceptCaseARA',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success', "Case accepted successfully");
                        get_torespond_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".adjudicator-accept-case").css("display","none");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                })
                .catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });    
            }
        }
        function undefinedSetFalse(val){
            if(val){
                return val;
            } else {
                var val = false;
                return val;
            }
            return val;
        }
        //add selected party to list
        $scope.conflictedData = function(data){
            if($scope.rejectdetail.parties == undefined){
                $scope.rejectdetail.parties = [];
                $scope.rejectdetail.parties.push(data);
            }else{
                var findindex = search(data,$scope.rejectdetail.parties);
                if(findindex != undefined){
                    $scope.rejectdetail.parties.splice(findindex,1)
                }else{
                    $scope.rejectdetail.parties.push(data);
                }
            }
        }
        //check already adjudicator in list if return true then delete that adjudicator
        function search(nameKey, myArray){
            for (var index=0; index < myArray.length; index++) {
                if (myArray[index] == nameKey) {
                    return index
                }
            }
        }

        $scope.rejecttheCase =function(rejectData,caseNumber){
            var query = {
                "reasonForRejection":rejectData.reason,
                "dateFrom":rejectData.dateFrom,
                "dateTo":rejectData.dateTo,
                "conflictedParties":rejectData.parties,
                "adjudicatorId" : $cookies.get('memberId'),
                "caseNumber" : caseNumber
            }
            console.log('query',query);
            DataService.post('AdjudicatorRejectCase',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', "Case rejected successfully");
                    get_torespond_caselist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".adjudicator-reject-case").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            })
            .catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });    
        }
    }
})();


