(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorCaseListCtrl',adjudicatorCaseListCtrl);

    adjudicatorCaseListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjudicatorCaseListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        
      // to receive filter case list
        $scope.$on('activeTab', function(event, tabStatus) { 
            $scope.currentTab = tabStatus;
        });
        $scope.ConferenceRate = $cookies.get('ConferenceRate');
        //get acceptance percentage
        var AdjudicatorAcceptanceRateUrl = smcConfig.services.AdjudicatorAcceptanceRate.url;
        AdjudicatorAcceptanceRateUrl = AdjudicatorAcceptanceRateUrl + $cookies.get('memberId');
        $http.get(AdjudicatorAcceptanceRateUrl).then(function(data){
            console.log("data",data)
            $scope.accept_rate = data.data.result;
        });
  	}
})();