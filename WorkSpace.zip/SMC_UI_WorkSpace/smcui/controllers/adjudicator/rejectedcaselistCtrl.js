(function() {
    'use strict';
    angular
        .module('smc')
        .controller('rejectedCaseCtrl',rejectedCaseCtrl);

    rejectedCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function rejectedCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != "adjudicator") {
            $state.go('smclayout.membershiplayout.login');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'progress'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_rejected_caselist($scope.pagenumber);//call to rejected case list function
        $cookies.put('currentTab','rejected');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to rejected case list function from outside
        $rootScope.rejectedcaselist = function(){
            get_rejected_caselist($cookies.get('pageNumber'));
        } 

    	// get rejected case list
    	function get_rejected_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "adjudicatorId":$cookies.get('memberId')
    		}
    		DataService.post('AdjudicatorRejectedCaseList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.rejected_Case_List = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.rejected_Case_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        $scope.goToPageNumber = function(pageNo){
           get_rejected_caselist(pageNo);
        }
    }
})();


