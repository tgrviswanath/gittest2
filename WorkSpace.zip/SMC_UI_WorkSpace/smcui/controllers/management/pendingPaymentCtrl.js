/*This Controller for SMC Management to get pending payment Determined requests list from SMC officers and 
So, SMC Manager Will Check it And Approve Or cancel And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('pendingpaymentCtrl',pendingpaymentCtrl);

    pendingpaymentCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function pendingpaymentCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('moduleName') != 'Adjudication' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.ifSmcManager = $cookies.get('smcManagerStatus');
        if (!$scope.ifSmcManager) {
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getPendingPaymentList($scope.pagenumber);
        $scope.shownodataavailable = false;
        $scope.inviteAdjudicatorId ='';
        $scope.pending_payment_path = "views/management/pendingpaymentmodel.html"
    	// to get pending adjudicator appeovals list
    	function getPendingPaymentList(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
                "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "smcManagerId" : $cookies.get('memberId')
    		}
    		DataService.post('GetPendingPaymentApproval',query).then(function (data) {
    			$scope.paymentcases = data.result.responseData;
                $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                var value= Math.round($scope.max_pagenumber);
                if(value < $scope.max_pagenumber){
                    $scope.max_pagenumber = value+1;
                }else{
                    $scope.max_pagenumber = value;
                }
    		})
    		.catch(function(error){
    			console.log('errorcaselist',error);
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getPendingPaymentList(pageNo);
        }

        //open view payment modal
        $scope.viewPayment = function(caseNumber){
            $rootScope.payment_caseNumber = caseNumber;
            $scope.currentSubTab = 'Management Fees';
            var query = {
                "caseNumber":caseNumber, 
                "tabType":"Management Fee"
            }
            DataService.post('ViewPendingPaymentDetails',query).then(function (data) {
                $scope.paymentDetails = data.result.managementFee;
                $scope.userName = $cookies.get('userName');
                angular.element(".overlay").css("display","block");
                angular.element(".view-payment-pending-approvals").css("display","block");
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });
        }
        //go to another tabs
        $scope.goOtherTab = function(subTab){
            $scope.currentSubTab = subTab;
            switch ($scope.currentSubTab) {
                case 'Management Fees':
                    var query = {
                        "caseNumber":$rootScope.payment_caseNumber, 
                        "tabType":"Management Fee"
                    }
                    DataService.post('ViewPendingPaymentDetails',query).then(function (data) {
                        $scope.paymentDetails = data.result.managementFee;
                    })
                    .catch(function(error){
                        console.log('errorcaselist',error);
                    });
                    break;
                case 'Adjudicator’s Fees':
                    var query = {
                        "caseNumber":$rootScope.payment_caseNumber, 
                        "tabType":"Adjudicator Fee"
                    }
                    DataService.post('ViewPendingPaymentDetails',query).then(function (data) {
                        $scope.paymentDetails = data.result.adjudicatorFee;
                    })
                    .catch(function(error){
                        console.log('errorcaselist',error);
                    });
                    break;
                case 'Invoice to Claimant':
                    var query = {
                        "caseNumber":$rootScope.payment_caseNumber, 
                        "tabType":"Claimant Invoice"
                    }
                    DataService.post('ViewPendingPaymentDetails',query).then(function (data) {
                        $scope.paymentDetails = data.result.claimantInvoice;
                    })
                    .catch(function(error){
                        console.log('errorcaselist',error);
                    });
                    break;
                case 'Refund to Claimant':
                    var query = {
                        "caseNumber":$rootScope.payment_caseNumber, 
                        "tabType":"Claimant Refund"
                    }
                    DataService.post('ViewPendingPaymentDetails',query).then(function (data) {
                        $scope.paymentDetails = data.result.claimantRefund;
                    })
                    .catch(function(error){
                        console.log('errorcaselist',error);
                    });
                    break;
            }
        }

        //close view payment modal
        $scope.closepaymentmodal = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".view-payment-pending-approvals").css("display","none");
        }

        //response for pending payment
        $scope.responseabtpayment = function(paymentData,approveStatus){
            var query = {
                "caseNumber":paymentData.caseNumber, 
                "smcManagerId":$cookies.get('memberId'), 
                "comments":undefinedSetNull(paymentData.comments), 
                "approveStatus":approveStatus
            }
            DataService.post('SubmitResponsePendingPayment',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Response sent successfully');
                    getPendingPaymentList();
                    angular.element(".overlay").css("display","none");
                    angular.element(".view-payment-pending-approvals").css("display","none");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();