/*This Controller for SMC Management to get pending payment Determined requests list from SMC officers and 
So, SMC Manager Will Check it And Approve Or cancel And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('smcManagerResignationCtrl',smcManagerResignationCtrl);

    smcManagerResignationCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function smcManagerResignationCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('moduleName') != 'Adjudication' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.ifSmcManager = $cookies.get('smcManagerStatus');
        if (!$scope.ifSmcManager) {
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getResignationApprovalList($scope.pagenumber);
        $scope.shownodataavailable = false;
        $scope.resignation_withdraw_modal_path = 'views/popups/resignation_withdraw_modal.html';
        $scope.resignation_time_cost_modal_path = 'views/popups/view_adjudicator_management_fee.html';
    	// to get pending adjudicator appeovals list
    	function getResignationApprovalList(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
                "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "smcManagerId" : $cookies.get('memberId')
    		}
    		DataService.post('ViewResignationRequestBySMCManager',query).then(function (data) {
    			$scope.resignationCaseList = data.result.responseData;
                $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                var value= Math.round($scope.max_pagenumber);
                if(value < $scope.max_pagenumber){
                    $scope.max_pagenumber = value+1;
                }else{
                    $scope.max_pagenumber = value;
                }
                for(var index = 0;index<$scope.resignationCaseList.length;index++){
                    $scope.resignationCaseList[index].smcOfficerApproveTimeCostStatus = findStatus($scope.resignationCaseList[index].caseStatus, "SMC Officer Approve Adjudicator Resignation Time Cost");
                    
                }
    		})
    		.catch(function(error){
    			console.log('errorcaselist',error);
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getResignationApprovalList(pageNo);
        }

        
    
        /* Resignation Proess Functionality */
        $scope.attachResignationStatus = false;
        $scope.resignationRequestApproveStatus = false;
        $scope.smcManagerResignationApproveStatus = true;
        //Open Resignation Withdraw Adjudicator model
        $scope.openResignationWithdrawPopUp = function (caseDetails){
            $scope.isRequestInitiated = false;
            var adjResignationRequestApproveStatus = caseDetails.adjResignationRequestApproveStatus;
            $scope.resignationRequestApproveStatus = adjResignationRequestApproveStatus;
            if(!caseDetails.adjResignationRequestStatus){
                $scope.isRequestInitiated = true;
                $scope.downLoadResignationDoc = true;
                var ViewAdjudicatorResignUrl = smcConfig.services.ViewResignationRequest.url;
                ViewAdjudicatorResignUrl = ViewAdjudicatorResignUrl + caseDetails.caseNumber;
                $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                $http.get(ViewAdjudicatorResignUrl).then(function (respon) {
                    var data = respon.data;
                    if(data.status == 'SUCCESS'){
                        $scope.resgPopUpData = {};
                        $scope.resgPopUpData.reason = data.result.reason;
                        $scope.resgPopUpData.comments = data.result.smcOfficerComments
                        $scope.resignationDocumentName = data.result.document.name;
                        $scope.resignationUploadedDocument = data.result.document.fileLocation;
                        $scope.attachResignationStatus = false;
                        $scope.downLoadResignationDocURL = smcConfig.services.DownloadSupportingDocument.url+data.result.document.id;
                        $scope.loginRole = $cookies.get('roleName');
                        angular.element(".overlay").css("display","block");
                        angular.element(".resignation-withdraw-PopUp-Model").css("display","block");
                    }else{
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            } else {
                $scope.resgPopUpData = {};
                $scope.resignationDocumentName = undefined;
                $scope.resignationUploadedDocument = undefined;
                $scope.attachResignationStatus = false;
                $scope.loginRole = $cookies.get('roleName');
                $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                angular.element(".overlay").css("display","block");
                angular.element(".resignation-withdraw-PopUp-Model").css("display","block");
            }
        }

        //Open Resignation Withdraw Adjudicator model
        $scope.closeResignationWithdrawPopUp = function(){
            $scope.resgPopUpData = {};
            $scope.resignationDocumentName = undefined;
            $scope.resignationUploadedDocument = undefined;
            $scope.attachResignationStatus = false;
            angular.element(".overlay").css("display","none");
            angular.element(".resignation-withdraw-PopUp-Model").css("display","none");
        }

        //Approval Adjudicator Resignation
        $scope.adjudicatorResignationSubmit = function(resgPopUpData,statusType,CaseNumber){
            var query = {
                "caseNumber":CaseNumber,
                "smcManagerId":$cookies.get('memberId'),
                "comments":resgPopUpData.comments,
                "actionType": statusType
            }
            var statusMsg = statusType + " successfully";
            console.log('query',query)
            DataService.post('ResignationRequestSubmitSMCManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', statusMsg);
                    angular.element(".overlay").css("display","none");
                    angular.element(".resignation-withdraw-PopUp-Model").css("display","none");
                    getResignationApprovalList();
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //Open Resignation Time Cost Details of Adjudicator
        $scope.openResignationTimeCostPopUp = function (caseDetails){
            $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
            $scope.caseType = caseDetails.caseType;
            getManagementFeeDetails(caseDetails.caseNumber);
            getAdjudicatorFeeDetails(caseDetails.caseNumber);
            angular.element(".overlay").css("display","block");
            angular.element(".resignation-time-cost-PopUp-Model").css("display","block");

        }

        //Close Resignation Time Cost Details of Adjudicator
        $scope.closeResignationTimeCostPopUp = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".resignation-time-cost-PopUp-Model").css("display","none");
        }


        //Get Management fee details
        function getManagementFeeDetails(caseNumber){
            var query = {
                "caseNumber":caseNumber,
                 "tabType":"Management Fee"
            }
            DataService.post('ViewManagementAdjudicatorFees',query).then(function (data) {
                $scope.magementFeeDetails = data.result.managementFee;
            })
            .catch(function(error){
                console.log('errorcaselist',error);
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }
        //Get Adjudicator fee details
        function getAdjudicatorFeeDetails(caseNumber){
            var query = {
                "caseNumber":caseNumber,
                 "tabType":"Adjudicator Fee"
            }
            DataService.post('ViewManagementAdjudicatorFees',query).then(function (data) {
                $scope.adjudicatorFeeDetails = data.result.adjudicatorFee;
            })
            .catch(function(error){
                console.log('errorcaselist',error);
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.adjudicatorResignationTimeCostSubmit = function(action,caseNumber,caseType){
            var query = {
                "caseNumber":caseNumber,
                "smcManagerId":$cookies.get('memberId'),
                 "actionType":action
            }
            var statusMsg = action + " successfully";
            if(caseType == 'AA Case'){
                AASubmitAdjudicatorByManager(query,statusMsg);
            }else if(caseType == 'ARA Case'){
                ARASubmitAdjudicatorByManager(query,statusMsg);
            }
        }

        function AASubmitAdjudicatorByManager(query,statusMsg){
            DataService.post('AdjudicatorResignationTimeCostSubmitBySMCManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', statusMsg);
                    angular.element(".overlay").css("display","none");
                    angular.element(".resignation-withdraw-PopUp-Model").css("display","none");
                    getResignationApprovalList();
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            })
            .catch(function(error){
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function ARASubmitAdjudicatorByManager(query,statusMsg){
            DataService.post('AdjudicatorARAResignationTimeCostSubmitBySMCManager',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', statusMsg);
                    angular.element(".overlay").css("display","none");
                    angular.element(".resignation-withdraw-PopUp-Model").css("display","none");
                    getResignationApprovalList();
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            })
            .catch(function(error){
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        function findStatus(array,action){
            var a = 0; 
            for(var index =0;index<array.length;index++){
                if(array[index] == action){
                    a = 1;
                }
            }
            if(a == 1){
                return true;
            } else{
                return false;
            }

        }
        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();