/*This Controller for SMC Management to get pending payment Determined requests list from SMC officers and 
So, SMC Manager Will Check it And Approve Or cancel And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('pendingrefundCtrl',pendingrefundCtrl);

    pendingrefundCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function pendingrefundCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('moduleName') != 'Adjudication' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.ifSmcManager = $cookies.get('smcManagerStatus');
        if (!$scope.ifSmcManager) {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getPendingrefundList($scope.pagenumber);
        $scope.comments='';
        $scope.shownodataavailable = false;
    	// to get pending refund appeovals list
    	function getPendingrefundList(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
                "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "smcManagerId" : $cookies.get('memberId')
    		}
    		DataService.post('GetRefundApprovalList',query).then(function (data) {
    			$scope.refundcases = data.result.responseData;
                $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                var value= Math.round($scope.max_pagenumber);
                if(value < $scope.max_pagenumber){
                    $scope.max_pagenumber = value+1;
                }else{
                    $scope.max_pagenumber = value;
                }
    		})
    		.catch(function(error){
    			console.log('errorcaselist',error);
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getPendingrefundList(pageNo);
        }

        //open view payment modal
        $scope.viewRefundPayment = function(caseNumber,caseFrom){
            $scope.caseFrom = caseFrom;
            $rootScope.refund_caseNumber = caseNumber;
            var ViewRefundCaseDetailUrl = smcConfig.services.ViewRefundCaseDetail.url;
            ViewRefundCaseDetailUrl = ViewRefundCaseDetailUrl + $rootScope.refund_caseNumber;
            $http.get(ViewRefundCaseDetailUrl).then(function(data){
                console.log("data",data)
                $scope.refundCaseDetails = data.data.result;
                if(!$scope.refundCaseDetails.gstTaxAmount){
                    $scope.refundCaseDetails.gstTaxAmount = 0;
                }
                $scope.userName = $cookies.get('userName');
                $scope.date =  new Date().toJSON().slice(0,10);
                $scope.amountPayable = parseInt($scope.refundCaseDetails.depositPaid)-parseInt($scope.refundCaseDetails.applicationFee)-parseInt($scope.refundCaseDetails.adjudicatorFee)+parseInt($scope.refundCaseDetails.gstTaxAmount);
                angular.element(".overlay").css("display","block");
                angular.element(".approve-refund-modal").css("display","block");
            });
        }

        //response about pending refund
        $scope.responseabtrefund = function(comments,status,caseNumber,caseFrom){
            var query = {
                "caseNumber":caseNumber, 
                "smcManagerId":$cookies.get('memberId'), 
                "comments":comments, 
                "approveStatus":status
            }
            if(caseFrom == 'AA'){
                responseabtAArefund(query);
            }else if(caseFrom){
                responseabtARArefund(query);
            }
             
        }

        //response for AA refund
        function responseabtAArefund(query){
            DataService.post('ResponseAbtRefund',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    
                    NotifyFactory.log('success', 'Refund request approved successfully');
                    getPendingrefundList();
                    angular.element(".overlay").css("display","none");
                    angular.element(".approve-refund-modal").css("display","none");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //response for ARA refund
        function responseabtARArefund(query){
            DataService.post('ResponseAbtARARefund',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Response sent successfully');
                    getPendingrefundList();
                    angular.element(".overlay").css("display","none");
                    angular.element(".approve-refund-modal").css("display","none");
                }
            })
            .catch(function(error){
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        $scope.closerefundmodal = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".approve-refund-modal").css("display","none");
        }
    }
})();