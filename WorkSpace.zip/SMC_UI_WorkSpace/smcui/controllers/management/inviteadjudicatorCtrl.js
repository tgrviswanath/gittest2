/*This Controller for SMC Management to get pending adjudicatoes requests list from SMC officers and 
adjudicators proposal list
So, SMC Manager Will Check it And Approve Or cancel And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('inviteAdjudicatorCtrl',inviteAdjudicatorCtrl);

    inviteAdjudicatorCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function inviteAdjudicatorCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('moduleName') != 'Adjudication' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getPendingList($scope.pagenumber);
        $scope.shownodataavailable = false;
        $scope.inviteAdjudicatorId ='';
        $scope.activeConfirmDelete = false;
    	// to get pending adjudicator appeovals list
    	function getPendingList(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
                "pageIndex":$scope.pagenumber,
                 "dataLength":$scope.dataLength,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "caseStatuses":["Adjudicators Proposed"],
                 "araCaseStatuses":["List of Proposed Review Adjudicator(s) Sent for Approval"]
    		}
    		DataService.post('GetPendingAdjudicators',query).then(function (data) {
    			$scope.pendingList = data.result.responseData;
                $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                var value= Math.round($scope.max_pagenumber);
                if(value < $scope.max_pagenumber){
                    $scope.max_pagenumber = value+1;
                }else{
                    $scope.max_pagenumber = value;
                }
    		})
    		.catch(function(error){
    			console.log('errorcaselist',error);
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getPendingList(pageNo);
        }

    	//to view proposed adjudicator
    	$scope.viewAdjudicator = function(inviteId,caseNumber,caseType){
            $rootScope.adjCaseNumber = caseNumber;
            $scope.inviteAdjudicatorId = inviteId;
            $scope.caseType = caseType;
    		inviteAdjudicators(inviteId);
    	}

        //function invite adjudicators
        function inviteAdjudicators(inviteId){
            $scope.activeConfirmDelete = false;
            var ViewPendingAdjudicatorUrl = smcConfig.services.ViewPendingAdjudicator.url;
            ViewPendingAdjudicatorUrl = ViewPendingAdjudicatorUrl + inviteId;
            $http.get(ViewPendingAdjudicatorUrl).then(function(data){
                console.log("data",data)
                $scope.adjudicatordetails = data.data.result.responseData;
            })
            .catch(function(error){
                console.log('errorcaselist',error)
            });
            var  endvalue;
            var  startvalue;
            $('#selectTable > tbody').sortable({
                update: function( event, ui ) {
                    endvalue = ui.item.index()
                    console.log('end',endvalue)
                    if(startvalue < endvalue){
                        var selectvalue = $scope.adjudicatordetails[startvalue];
                        for(var index =startvalue;index<endvalue;index++){
                            $scope.adjudicatordetails[index] = $scope.adjudicatordetails[index+1];
                        }
                        $scope.adjudicatordetails[endvalue] = selectvalue;
                    }else{
                        var selectvalue = $scope.adjudicatordetails[startvalue];
                         for(var index =startvalue;index>endvalue;index--){
                            $scope.adjudicatordetails[index] = $scope.adjudicatordetails[index-1];
                        }
                        $scope.adjudicatordetails[endvalue] = selectvalue;
                    }
                    console.log('finalArray',$scope.adjudicatordetails);
                    $scope.$apply();
                },
                start: function( event, ui ) {
                    startvalue = ui.item.index()
                    console.log('start',startvalue)
                }
            });
            angular.element(".overlay").css("display","block");
            angular.element(".pending-adjudicator").css("display","block");
        }

    	//to delete proposed adjudicator
    	$scope.deleteAdjudicator = function(adjudicatorCaseId){
            $scope.activeConfirmDelete = false;
    		var query = {
                "adjudicatorCaseId" : adjudicatorCaseId,
                "smcManagerId" : parseInt($cookies.get('memberId'))
            }
			DataService.post('DeletePendingAdjudicator',query).then(function(data){
        		NotifyFactory.log('success','Adjudicator deleted successfully')
                inviteAdjudicators($scope.inviteAdjudicatorId);
                angular.element(".form-submitt-confirm").css("display","none");
        	})
        	.catch(function(error){
    			console.log('errorlist',error)
    		});
    	}

    	// to response pending adjudicator appeovals list
    	$scope.responseAboutAdjudicators=function(comment,status,caseType){
            $scope.activeConfirmDelete = false;
            var query = buildQuery(comment,status,$scope.adjudicatordetails);
            console.log('query',query)
            if(status == 'Approve'){
                var serviceMsg = 'Proposed adjudicator list approved successfully'
            }
            else{
                var serviceMsg = 'Proposed adjudicator list amended successfully'
            }
            if(caseType == 'AA Case'){
                DataService.post('ResponsePendingAdjudicators',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success',serviceMsg);
                        getPendingList();
                        angular.element(".overlay").css("display","none");
                        angular.element(".pending-adjudicator").css("display","none");
                        angular.element(".form-submitt-confirm").css("display","none");
                    }else{
                        NotifyFactory.log('error',data.errorMessage);
                    }
                })
                .catch(function(error){
                    console.log('errorlist',error)
                });
            }else if(caseType == 'ARA Case'){
                DataService.post('ResponsePendingAdjudicatorsARA',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        NotifyFactory.log('success','Response sent successfully');
                        getPendingList();
                        angular.element(".overlay").css("display","none");
                        angular.element(".pending-adjudicator").css("display","none");
                        angular.element(".form-submitt-confirm").css("display","none");
                    }else{
                        NotifyFactory.log('error',data.errorMessage);
                    }
                })
                .catch(function(error){
                    console.log('errorlist',error)
                });
            }
    		
    	}

        //to close adjudicator list popup model
        $scope.closedetailsmodal = function(){
            $scope.activeConfirmDelete = false;
            $scope.inviteAdjudicatorId ='';
            angular.element(".overlay").css("display","none");
            angular.element(".pending-adjudicator").css("display","none");
            angular.element(".form-submitt-confirm").css("display","none");
        }

        // to open popup model for delete adjudicator
        $scope.confirmationdelete = function(adjudicator){
            $scope.activeConfirmDelete = true;
            $scope.adjudicator_name = adjudicator.memberName;
            $scope.adjudicator_Case_Id = adjudicator.adjudicatorCaseId;
            angular.element(".pending-adjudicator").css("display","block");
            angular.element(".form-submitt-confirm").css("display","block");
        }
        // to close popup model for delete adjudicator
        $scope.canceldelete = function(){
            angular.element(".form-submitt-confirm").css("display","none");
            $scope.activeConfirmDelete = false;
        }

        //to build a query for adjudicator list
        function buildQuery(comment,status,adjudicatordetails){
            var query = {};
            query['adjudicatorOrders'] = [];
            if(status == 'Approve'){
                for(var index = 0 ; index<adjudicatordetails.length ; index++){
                    var adj_details = {
                        "adjudicatorCaseId":adjudicatordetails[index].adjudicatorCaseId, 
                        "adjudicatorOrder":index+1
                    }
                    query.adjudicatorOrders.push(adj_details);
                }
            }else if(status == 'Reject'){
                for(var index = 0 ; index<adjudicatordetails.length ; index++){
                    var adj_details = {
                        "adjudicatorCaseId":adjudicatordetails[index].adjudicatorCaseId, 
                        "adjudicatorOrder":adjudicatordetails[index].adjudicatorOrder
                    }
                    query.adjudicatorOrders.push(adj_details);
                }
            }
            query['comments'] = comment;
            query['smcManagementStatus'] = status;
            query['smcManagerId'] = parseInt($cookies.get('memberId'));
            return query
        }
    }
})();