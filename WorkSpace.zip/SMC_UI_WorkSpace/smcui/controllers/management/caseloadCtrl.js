(function() {
    'use strict';
    angular
        .module('smc')
        .controller('caseLoadCtrl',caseLoadCtrl);

    caseLoadCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function caseLoadCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if($cookies.get('moduleName') != 'Adjudication' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'caseload'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_caseload_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','caseload');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to conflicted case list function from outside
        $rootScope.getcaseloadlist = function(){
            get_caseload_list($cookies.get('pageNumber'));
        } 
        get_all_case_officer();
        get_all_assistant_manager();
        // get case officers
    	function get_all_case_officer(){
    		var query = {
    			 "moduleName":"Adjudication", 
                 "roleName":"Case Officer"
    		}
    		DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.case_officers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
    	}

        // get case officers
    	function get_all_assistant_manager(){
    		var query = {
    			"moduleName":"Adjudication",
                "roleName":'Assistant Manager'
    		}
    		DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.assistant_managers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
    	}

    	// get caseload case list
    	function get_caseload_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex": $scope.pagenumber, 
                 "dataLength": $scope.dataLength, 
                 "sortingColumn": null, 
                 "sortDirection": null, 
                 "caseOfficer": null, 
                 "assistantManager":null, 
                 "lodgedDateFrom":null, 
                 "lodgedDateTo": null, 
                 "determineDueDateFrom":null, 
                 "determineDueDateTo":null
    		}
    		DataService.post('GetCaseLoadList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.caseLoadList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.caseLoadList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    

        $scope.goToPageNumber = function(pageNo){
           get_caseload_list(pageNo);
        } 

       

        //search user for admin
            $scope.getOfficer = function(filterDetails){
                var query = {
                    "caseOfficer": undefinedSetNull(filterDetails.caseOfficer), 
                    "assistantManager": undefinedSetNull(filterDetails.assistantManager), 
                    "lodgedDateFrom": undefinedSetNull(filterDetails.lodgedDateFrom), 
                    "lodgedDateTo": undefinedSetNull(filterDetails.lodgedDateTo), 
                    "determineDueDateFrom": undefinedSetNull(filterDetails.determineDueDateFrom), 
                    "determineDueDateTo": undefinedSetNull(filterDetails.determineDueDateTo)
                }
                DataService.post('GetCaseLoadList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.caseLoadList = data.result.responseData
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
                }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                });
            }

            //reset users list
            $scope.resetcases = function(){
                $scope.filter = undefined;
                get_caseload_list(0);
            }


       
        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


