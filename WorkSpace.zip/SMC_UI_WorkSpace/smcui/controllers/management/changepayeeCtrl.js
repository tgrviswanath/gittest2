/*This Controller for SMC Management to get changes payee name requests from SMC officers
So, SMC Manager Will Check it And Approve Or Amand And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('changePayeeCtrl',changePayeeCtrl);

    changePayeeCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function changePayeeCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('moduleName') != 'Adjudication' || $cookies.get('roleName') != 'SMC Management'){
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.ifSmcManager = $cookies.get('smcManagerStatus');
        if (!$scope.ifSmcManager) {
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        if($cookies.get('pageNumber')){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        getchangespayeelist($scope.pagenumber);//call function
        $scope.shownodataavailable = false;
    	//to get Update Payee Name List
        $scope.case_number='';
    	function getchangespayeelist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
    		var query = {
    			"pageIndex":$scope.pagenumber, 
    			"dataLength":$scope.dataLength, 
    			"sortingColumn":null, 
    			"sortDirection":null, 
                "caseStatuses":[ "Update Payee Name Requested" ]
    		}
    		DataService.post('GetChangesPayeeList',query).then(function (data) {
    			 $scope.changesPayeeList = data.result.responseData;
                 $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                var value= Math.round($scope.max_pagenumber);
                if(value < $scope.max_pagenumber){
                    $scope.max_pagenumber = value+1;
                }else{
                    $scope.max_pagenumber = value;
                }
    		})
    		.catch(function(error){
    			console.log('errorlist',error)
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
    		});
    	}

        $scope.goToPageNumber = function(pageNo){
           getchangespayeelist(pageNo);
        }

    	//to get changes of payee name request
    	$scope.changedetails = function(payeeId,caseNumber){
            $scope.case_number = caseNumber;
    		var GetPayeeChangeDetailsUrl = smcConfig.services.GetPayeeChangeDetails.url;
			GetPayeeChangeDetailsUrl = GetPayeeChangeDetailsUrl + payeeId;
			$http.get(GetPayeeChangeDetailsUrl).then(function(data){
        		console.log("data",data)
        		$scope.payeedetails = data.data.result;
        		$scope.payeedetails.supprtDocumentName = $scope.payeedetails.supportingDocument.name;
        		$scope.fileId = $scope.payeedetails.supportingDocument.id;
                //Generate Download URL
                var generateDownloadUrl = smcConfig.services.DownloadSupportingDocument.url;
                $rootScope.downloadUrl = generateDownloadUrl  + $scope.fileId;
        		angular.element(".overlay").css("display","block");
            	angular.element(".change-payee-name").css("display","block");
        	});
    	}

    	//to close view details modal
    	$scope.closedetailsmodal = function(){
    		angular.element(".overlay").css("display","none");
            angular.element(".change-payee-name").css("display","none");
    	}

        //to response for changes in payee details
        $scope.responsechanges = function(change_Date,response){
            var reasonMsgStatus = response;
            var changeQuery = buildChangesQuery(change_Date,response);
            console.log("changeQuery",changeQuery)
            DataService.post('ResponsePayeeChanges',changeQuery).then(function (data) {
                if(data.status == 'SUCCESS'){
                    if(reasonMsgStatus == "To Amend"){
                        NotifyFactory.log('success', 'Update payee request amend successfully');
                    } else {
                        NotifyFactory.log('success', 'Update payee request approved successfully');
                    }
                    getchangespayeelist();
                    angular.element(".overlay").css("display","none");
                    angular.element(".change-payee-name").css("display","none");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            })
            .catch(function(error){
                console.log('errorcaselist',error);
                NotifyFactory.log('error', error);
            });
        }
        // to build query for response send to smc officer
        function buildChangesQuery(payee_Date,response){
            var query = {
                "smcManagementStatus":response, 
                "oldPayeeName":payee_Date.oldPayeeName, 
                "newPayeeName":payee_Date.newPayeeName, 
                "remarks":payee_Date.remarks, 
                "id":payee_Date.id, 
                "smcManagerId":parseInt($cookies.get('memberId')),
                "comments":payee_Date.comments, 
                "caseNumber":$scope.case_number, 
                "supportingDocument": { 
                    "name":payee_Date.supportingDocument.name, 
                    "fileLocation":payee_Date.supportingDocument.fileLocation 
                }
            }
            return query;
        }

        
    }
})();