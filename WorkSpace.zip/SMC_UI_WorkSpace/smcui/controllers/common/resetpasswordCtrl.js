   (function() {
       'use strict';
       angular
           .module('smc')
           .controller('resetPasswordCtrl', resetPasswordCtrl);
       resetPasswordCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$window','$sce','navigateConfig'];

       function resetPasswordCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$window,$sce,navigateConfig) {
         
            $scope.ResetLogin = function(resetdata){
              var query = {
                "userId":resetdata.usermail,     
              }
              DataService.post('ResetPasswordRequest',query).then(function (data) {
                  if(data.status == 'SUCCESS'){
                      NotifyFactory.log('success', 'Password reset requested successfully');
                      if($rootScope.loginType == 'member'){
                         $state.go('smclayout.membershiplayout.memberlogin');
                       }else{
                          $state.go('smclayout.membershiplayout.login');
                       }
                  }
              }).catch(function (error) {
                  NotifyFactory.log('error', error.message);
              });
            }

            $scope.goBack = function(){
              if($rootScope.loginType == 'member'){
                 $state.go('smclayout.membershiplayout.memberlogin');
               }else{
                  $state.go('smclayout.membershiplayout.login');
               }
            }
       }
   })();