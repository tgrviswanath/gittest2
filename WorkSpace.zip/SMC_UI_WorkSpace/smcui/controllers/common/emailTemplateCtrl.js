   (function () {
       'use strict';
       angular
           .module('smc')
           .controller('emailTemplateCtrl', emailTemplateCtrl);
       emailTemplateCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$window', '$sce', 'navigateConfig'];

       function emailTemplateCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, $window, $sce, navigateConfig) {
           if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Admin' ) {
            $state.go('smclayout.membershiplayout.memberlogin');
          }
          
          if($cookies.get("moduleName")){
            $scope.moduleStatus = true;
            $scope.moduleId = $cookies.get("moduleId");
            getTembaltesDefault($scope.moduleId);

            function getTembaltesDefault(moduleId){
              var templatesListAPI = smcConfig.services.GetTemplatesList.url;
              templatesListAPI = templatesListAPI + moduleId + "/EML";
              $http.get(templatesListAPI).then(function(data){
                $scope.templateList = data.data.result.templates;
              });
            }
          } else {
            getTemplateTypes();
            getModuleList();
            // Get template type list
            function getTemplateTypes(){
              DataService.get("GetTemplateTypes").then(function (data) {
                $scope.templateTypeList = data.result.templateTypeDTOs;
              });
            }

            // Get Module List
            function getModuleList(){
              DataService.get("GetModuleList").then(function (data) {
                $scope.moduleList = data.results;
              });
            }

            // Get template list
            $scope.getTemplates = function(formData){
              var templatesListAPI = smcConfig.services.GetTemplatesList.url;
              templatesListAPI = templatesListAPI + formData.module.moduleId + "/EML";
              $http.get(templatesListAPI).then(function(data){
                $scope.templateList = data.data.result.templates;
              });
            }
          }

          $scope.templatePupUpOpen = function(template){
            $scope.templateData = {};
            $scope.updateSelectTemplate = template;
            var templatesDetailAPI = smcConfig.services.GetTemplatesDetail.url;
            templatesDetailAPI = templatesDetailAPI + template.templateId;
            $http.get(templatesDetailAPI).then(function(data){
              $scope.templateDetail = data.data.result;
              $scope.templateData.subject = data.data.result.subject;
              $scope.templateData.content = data.data.result.content;
              angular.element(".overlay").css("display","block");
              angular.element(".update-email-template").css("display","block");
            });
          }

          $scope.templatePupUpClose = function(){
            $scope.updateSelectTemplate = undefined;
            $scope.templateData = undefined;
            angular.element(".overlay").css("display","none");
            angular.element(".update-email-template").css("display","none");
          }

           $scope.updateTemplateData = function (formData) {
              var templateData = $scope.updateSelectTemplate;
               var query = {
                   "loginId": $cookies.get('memberId'),
                   "moduleId": $scope.templateDetail.moduleId,
                   "templateType": $scope.templateDetail.templateType,
                   "templateId": $scope.updateSelectTemplate.templateId,
                   "templateDescription": $scope.templateDetail.templateDescription,
                   "subject": $scope.templateData.subject,
                   "content": $scope.templateData.content
               }
               DataService.post('UpdateTemplatesDetail', query).then(function (data) {
                  $scope.updateSelectTemplate = undefined;
                  $scope.templateData = undefined;
                  if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', 'Template updated successfully.');
                  }
                  angular.element(".overlay").css("display","none");
                  angular.element(".update-email-template").css("display","none");
               }).catch(function (error) {
                  $scope.updateSelectTemplate = undefined;
                  $scope.templateData = undefined;
                  NotifyFactory.log('error', 'Template has not updated.');
                  angular.element(".overlay").css("display","none");
                  angular.element(".update-email-template").css("display","none");
               });
           }

           $scope.options = {
                language: 'en',
                allowedContent: true,
                entities: false,
                toolbar: [
                            { name: 'basicstyles', items: [ 'Bold', 'Italic' ] }
                         ]
            };

          
       }
   })();
