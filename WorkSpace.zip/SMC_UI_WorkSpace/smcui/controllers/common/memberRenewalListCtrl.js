(function () {
    'use strict';
    angular
        .module('smc')
        .controller('memberRenewalListCtrl', memberRenewalListCtrl);

    memberRenewalListCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$window'];

    function memberRenewalListCtrl($rootScope, $scope, $state, $cookies, DataService,
        $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, $window) {
        var roledetails;
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        $scope.attachcopyStatus = false;
        $scope.fullselectid = true;
        $scope.defaultSelectStatus = true;
      
        /**athira*/
        $scope.firstchkd = true;
        $scope.secondckd = true;
        $scope.case_id = [];
        if ($cookies.get('pageNumber')) {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_renewal_case_list($scope.pagenumber); //call to incomplete case list function
        //call to incomplete case list function from outside
        $scope.getRenewalList = function () {
            get_renewal_case_list(0);
        }

        // get incomplete case list
        function get_renewal_case_list(pageNumber) {
                if (pageNumber) {
                    $scope.pagenumber = pageNumber;
                } else {
                    $scope.pagenumber = 0;
                }
                $cookies.put('pageNumber', $scope.pagenumber)
                var sorting = [
                    [0, 0],
                    [1, 0]
                ];
                var query = {
                    "pageIndex": $scope.pagenumber,
                    "dataLength": $scope.dataLength,
                    "sortingColumn": null,
                    "sortDirection": null,
                    "loginId": $cookies.get('memberId')
                }
                getAllIncompleteCases(query);
        }
        //get all incomplete case list 
        function getAllIncompleteCases(query) {
            DataService.post('GetMemberRenewalList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.incomplete_Case_List = data.result.responseData;
                    if(data.result.responseData.length>0){
                       $scope.shownodataavailable = false;
                    }else{
                         $scope.shownodataavailable = true;
                    }
                    $scope.max_pagenumber = data.result.totalPages;
                } else {
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
                $scope.shownodataavailable = true;
            });
        }

        $scope.goToPageNumber = function (pageNo) {
                get_renewal_case_list(pageNo);
            }
            // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'incomplete') {
                get_renewal_case_list(0);
            }
        });
        $scope.invite = function (token) {
            console.log(token)
            var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
            var memberdetailsforTc = termsandconditions + token;
            $http.get(memberdetailsforTc).then(function (tcdata) {
                $scope.tcdata = tcdata.data;
            });
        };

        $scope.acceptTermsandConditions = function (idOfparticipant) {
            var query = {
                "participantId": idOfparticipant,
                "isAccepted": true
            }
            acceptTermsandConditionsfrall(query);

             function acceptTermsandConditionsfrall(query) {
                DataService.post('AcceptTermsandConditionsbyMember', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display", "none");
                        angular.element(".adjudicator-accept-case").css("display", "none");
                        get_renewal_case_list(0);

                    } else {
                        NotifyFactory.log('error', 'Member not Invited');
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', 'Member not Invited');
                });
            }

        };
        $scope.acceptSDRPTermsandConditions = function (idOfparticipant) {
            var query = {
                "participantId": idOfparticipant,
                "isAccepted": true
            }
            acceptTermsandConditionsfrall(query);

             function acceptTermsandConditionsfrall(query) {
                DataService.post('AcceptTermsandConditionsbyMember', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display", "none");
                        angular.element(".sdrp-accept-case").css("display", "none");
                        get_renewal_case_list(0);

                    } else {
                        NotifyFactory.log('error', 'Member not Invited');
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', 'Member not Invited');
                });
            }

        };
        $scope.selectAllAction = function (selectStatus) {
            if (selectStatus == true) {
                $scope.defaultSelectStatus = true;
            } else if (selectStatus == false) {
                $scope.defaultSelectStatus = false;
            }
        }

        // to open accept the case popup
        $scope.open_accept_popup = function (member, caseType) {
                $scope.memberType=member.memberType;
                var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
                var memberdetailsforTc = termsandconditions + member.token;
                $http.get(memberdetailsforTc).then(function (tcdata) {
                    $scope.tcdata = tcdata.data;

                });
                $scope.token = member.token;
                $scope.caseType = caseType;
                $scope.annexAform = smcConfig.services.DownloadAnnexAform.url + $scope.token;
                $scope.annexFform = smcConfig.services.DownloadAnnexFform.url + $scope.token;
                angular.element(".overlay").css("display", "block");
                angular.element(".adjudicator-accept-case").css("display", "block");
            }

            //to close accept popup
            $scope.cancelaccept = function () {
                angular.element(".overlay").css("display", "none");
                angular.element(".adjudicator-accept-case").css("display", "none");
            }


            $scope.opensdrpPopup = function (member) {
                $scope.memberType=member.memberType;
                var termsandconditions = smcConfig.services.MemberDetailsFromToken.url;
                var memberdetailsforTc = termsandconditions + member.token;
                $http.get(memberdetailsforTc).then(function (tcdata) {
                    $scope.tcdata = tcdata.data;
                });
                $scope.token = member.token;
                $scope.annexAform = smcConfig.services.DownloadAnnexAform.url + $scope.token;
                $scope.annexFform = smcConfig.services.DownloadAnnexFform.url + $scope.token;
                angular.element(".overlay").css("display", "block");
                angular.element(".sdrp-accept-case").css("display", "block");
            }
            
            //to close accept popup
            $scope.cancelsdrpPopup = function () {
                angular.element(".overlay").css("display", "none");
                angular.element(".sdrp-accept-case").css("display", "none");
            }


        $scope.tableSorting = function (sortVal) {
            $scope.orderByField = sortVal;
            if (sortVal == $scope.sortValue) {
                if ($scope.reverseSort) {
                    $scope.reverseSort = false;
                } else {
                    $scope.reverseSort = true;
                }
            } else {
                $scope.reverseSort = false;
                $scope.sortValue = sortVal;
            }
        }
        $scope.selectedMemberToPayment = [];
        $scope.getMemberId = function(memberId){
            var findIndex = $scope.selectedMemberToPayment.indexOf(memberId);
            if(findIndex != -1){
                $scope.selectedMemberToPayment.splice(findIndex,1)
            }else{
                $scope.selectedMemberToPayment.push(memberId)
            }
        }

        $scope.confirmPayment = function(selectedMembers){
            $scope.selectedMemberToPayment = selectedMembers;
            angular.element(".overlay").css("display", "block");
            angular.element(".renewal-multi-payment-member").css("display", "block");
        }

        $scope.cancelrenewal = function(){
            angular.element(".overlay").css("display", "none");
            angular.element(".renewal-multi-payment-member").css("display", "none");
        }

        $scope.openPopupToAccept = function(memberId){
            $scope.memberData = {};
            $scope.memberData.memberId = memberId;
            angular.element(".overlay").css("display", "block");
            angular.element(".renewal-accept-member").css("display", "block");
        }

        $scope.cancelAccept = function(){
            angular.element(".overlay").css("display", "none");
            angular.element(".renewal-accept-member").css("display", "none");
        }

        $scope.submitAccept = function(memberData){
            angular.element(".overlay").css("display", "none");
            angular.element(".renewal-accept-member").css("display", "none");
            var query = {
                "loginId": $cookies.get('memberId'),
                "roleIds": [memberData.memberId],
                "termsAcceptance": memberData.isAccepted
            }
            DataService.post('UpdateMemberAcceptenceForRenewal',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Member accept submitted successfully');
                    get_renewal_case_list(0);
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
            });
        }

        $scope.makePayment=function(selectedMemberToPayment){
            angular.element(".overlay").css("display", "none");
            angular.element(".renewal-multi-payment-member").css("display", "none");
            $rootScope.selectedMemberToPayment = selectedMemberToPayment;
            $cookies.put('roleName', member.memberType);
            $cookies.put('currentActionMenu','Payment');
            $state.go('smclayout.contactlayout.mediatorRenewalPayment'); 
        }
    }
})();
