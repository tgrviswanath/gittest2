/*This controller use to a case member after login select role for what role member want login */


(function () {
    'use strict';
    angular
        .module('smc')
        .controller('loginboardCtrl', loginboardCtrl);

    loginboardCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory','navigateConfig'];

    function loginboardCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory,navigateConfig) {
       
        if ($rootScope.loginDetails) {
            dashboardCtrl();
        } else {
            var query = {
                "userId": $cookies.get('userMail'),
                "password": $cookies.get('Password')
            };
            DataService.post('caseMemberLogin', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $rootScope.loginDetails = data.result;
                    dashboardCtrl();
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                }
            }, function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        function dashboardCtrl() {
            if ($rootScope.loginDetails.adjudication) {
                $scope.currentTab = 'adjudication';
                $scope.cases = $rootScope.loginDetails.adjudication;
                $cookies.put('moduleId', $rootScope.loginDetails.adjudication.moduleId)
            } else if ($rootScope.loginDetails.mediation) {
                $scope.currentTab = 'mediation';
                $scope.cases = $rootScope.loginDetails.mediation;
                $cookies.put('moduleId', $rootScope.loginDetails.mediation.moduleId)
            } else if ($rootScope.loginDetails.training) {
                $scope.currentTab = 'training';
                $scope.cases = $rootScope.loginDetails.training;
                $cookies.put('moduleId', $rootScope.loginDetails.training.moduleId)
            }
            $scope.smcMemberId=$rootScope.loginDetails.smcMemberId;
            $scope.paymentPendingRoles=$rootScope.loginDetails.paymentPendingRoles;
            $scope.goAdjudication = function () {
                $scope.currentTab = 'adjudication';
                $scope.cases = $rootScope.loginDetails.adjudication;
                $cookies.put('moduleId', $rootScope.loginDetails.adjudication.moduleId)
            }

            $scope.goMediation = function () {
                $scope.currentTab = 'mediation';
                if($rootScope.loginDetails.mediation){
                    $scope.cases = $rootScope.loginDetails.mediation;
                }else{
                    $scope.cases = undefined;
                }
                $cookies.put('moduleId', $rootScope.loginDetails.mediation.moduleId)
            }

            $scope.goTraining = function () {
                $scope.currentTab = 'trainer';
                if(Object.getOwnPropertyNames($rootScope.loginDetails.training).length !== 0){
                    $scope.cases = $rootScope.loginDetails.training;
                }else{
                    $scope.cases = undefined;
                }
                $cookies.put('moduleId', $rootScope.loginDetails.training.moduleId)
            }

            $scope.goToCaseDetails = function (caseData, key) {
                $cookies.put('caseNumber', caseData);
                $cookies.put('moduleName', 'Adjudication');
                $cookies.put('currentActionMenu', 'Case List')
                $cookies.put('roleName', key);
                switch (key) {
                    case 'claimant':
                        $state.go('smclayout.membershiplayout.lawyercasesummary');
                        break;
                    case 'respondent':
                        $state.go('smclayout.membershiplayout.respondantcasesummary');
                        break;
                    case 'claimantLawyer':
                        $state.go('smclayout.membershiplayout.lawyercasesummary');
                        break;
                    case 'respondentLawyer':
                        $state.go('smclayout.membershiplayout.respondantcasesummary');
                        break;
                    default:
                        $state.go('smclayout.membershiplayout.login');
                }
            }

            $scope.goToMediationCaseDetails = function (caseData, key) {
                $cookies.put('caseNumber', caseData);
                $cookies.put('moduleName', 'Mediation');
                $cookies.put('currentActionMenu', 'Case Summary')
                $cookies.put('roleName', key);
                switch (key) {
                    case 'applicant':
                        $state.go('smclayout.mediationlayout.applicantcasesummary');
                        break;
                    case 'respondent':
                        $state.go('smclayout.mediationlayout.respondantcasesummaries');
                        break;
                    case 'applicantLawyer':
                        $state.go('smclayout.mediationlayout.applicantcasesummary');
                        break;
                    case 'respondentLawyer':
                        $state.go('smclayout.mediationlayout.respondantcasesummaries');
                        break;
                    default:
                        $state.go('smclayout.membershiplayout.login');
                }
            }
            $scope.goTOAdjudicatorPage = function (key, tab) {
                $cookies.put('moduleName', 'Adjudication');
                $cookies.put('currentActionMenu', 'Case List');
                $cookies.put('roleName', key);
                switch (tab) {
                    case 'torespond':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.torespond');
                        break;
                    case 'inprogress':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.inprogress');
                        break;
                    case 'rejected':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.rejected');
                        break;
                    case 'conflicted':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.conflicted');
                        break;
                    case 'determined':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.determined');
                        break;
                    case 'withdrawn':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.withdrawn');
                        break;
                    case 'pendingpayments':
                        $state.go('smclayout.membershiplayout.adjudicatorcaselist.pendingpayments');
                        break;
                    case 'invitelist':
                        $state.go('smclayout.membershiplayout.adjudicatorinvitelist');
                        break;
                    default:
                        $state.go('smclayout.membershiplayout.login');
                }
            }

            $scope.goTOTrainerPage = function (key, tab) {
                $cookies.put('moduleName', 'Training');
                $cookies.put('roleName', key);
                $cookies.put('currentActionMenu', tab)
                switch (tab) {
                    case 'Pending Schedule Approval':
                        $state.go('smclayout.traininglayout.trainerscheduleapproval');
                        break;
                    case 'Training - Accept Terms & Conditions':
                        $state.go('smclayout.traininglayout.traineracceptterms');
                        break;
                    default:
                        $state.go('smclayout.membershiplayout.login');
                }
            }

            $scope.goToMediatorPage = function(key,tab){
                $cookies.put('moduleName', 'Mediation');
                $cookies.put('roleName', key);
                $cookies.put('currentActionMenu', tab)
                for(var menu in navigateConfig.Mediation[key]){
                    if(navigateConfig.Mediation[key][menu].displayName == tab){
                        var navigateUrl = navigateConfig.Mediation[key][menu].url;
                    }
                }
                $state.go(navigateUrl);
            }

            $scope.goToPayment=function(role){
                $cookies.put('moduleName', 'Mediation');
                switch(role){
                    case 'Associate Mediator':
                        $cookies.put('roleName', role);
                        $cookies.put('currentActionMenu','Payment');
                        $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$cookies.get('memberId'), 'smcMemberId': $scope.smcMemberId,'memberRoleName':role}); 
                        break;
                    case 'Principal Mediator':
                        $cookies.put('roleName', role);
                        $cookies.put('currentActionMenu','Payment');
                        $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$cookies.get('memberId'), 'smcMemberId': $scope.smcMemberId,'memberRoleName':role}); 
                        break;
                    case 'CFP':
                        $cookies.put('roleName', role);
                        $cookies.put('currentActionMenu','Payment');
                        $state.go('smclayout.contactlayout.cfpPayment',{'participantId' :  $scope.smcMemberId,'memberRoleName':role});
                        break;
                    case 'Family Panel':
                        $cookies.put('roleName', role);
                        $cookies.put('currentActionMenu','Payment');
                        $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$cookies.get('memberId'), 'smcMemberId': $scope.smcMemberId,'memberRoleName':role}); 
                        break;
                    case 'International Mediator':
                        $cookies.put('roleName', role);
                        $cookies.put('currentActionMenu','Payment');
                        $state.go('smclayout.contactlayout.mediatorRegisterationPayment',{'loginId':$cookies.get('memberId'), 'smcMemberId': $scope.smcMemberId,'memberRoleName':role}); 
                        break;
                    default:
                        $state.go('smclayout.membershiplayout.login');
                }
            }
        }

    }
})();
