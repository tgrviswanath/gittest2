   (function () {
       'use strict';
       angular
           .module('smc')
           .controller('changePasswordCtrl', changePasswordCtrl);
       changePasswordCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$window', '$sce', 'navigateConfig'];

       function changePasswordCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, $window, $sce, navigateConfig) {
            if($cookies.get('userMail')==null){
              $state.go('smclayout.membershiplayout.memberlogin');
            }

           $scope.changeData = {};
           $scope.changeData.userId = $cookies.get('userMail');
           $scope.oldPassword = $cookies.get('Password');


           $scope.changePassword = function (changedata) {
               console.log("challenge anser" + $scope.challengeanswer);
               var query = {
                   "userId": changedata.userId,
                   "newPassword": changedata.newPassword,
                   "oldPassword": changedata.oldPassword,
                   "challengeID": $scope.challengeID,
                   "challengeAnswer": $scope.challengeanswer
               }
               DataService.post('ChangePassword', query).then(function (data) {
                   if (data.status == 'SUCCESS') {
                       NotifyFactory.log('success', 'Password updated successfully, Please re-login to your account');
                       $cookies.put('memberId', null);
                       $scope.memberType = $cookies.get('memberType');
                       $cookies.put('smcOfficerStatus', null);
                       $cookies.put('smcManagerStatus', null);
                       $cookies.put('adjudicatorStatus', null);
                       $cookies.put('userName', null);
                       $cookies.put('caseNumber', null);
                       $cookies.put('userMail', null);
                       $cookies.put('Password', null);
                       $cookies.put('roleName', null);
                       if ($scope.memberType == 'Member') {
                           $state.go('smclayout.membershiplayout.login');
                       } else if ($scope.memberType == 'Staff') {
                           $state.go('smclayout.membershiplayout.memberlogin');
                       }
                   }
               }).catch(function (error) {
                      $http.get(urlForCaptcha).then(function (response) {
                       if (response.data.status == 'SUCCESS') {
                           $scope.captchaData = response.data.result;
                           $scope.challengeID = $scope.captchaData.challengeID;
                           $scope.displayCaptcha = response.data.result.challengeAnswer;
                       }
                       else{
                           NotifyFactory.log('error', 'error')
                       }

                   });

                   if (error.errorMessage == 'Password Doesn\'t match with Old Password') {
                       NotifyFactory.log('error', 'Entered old password is invalid');
                   } else if (error.errorMessage == 'New Password Doesn\'t match with Password Policy') {
                       NotifyFactory.log('error', 'Password should change as per password policy.');
                   } else {
                       NotifyFactory.log('error', error.errorMessage)
                       $http.get(urlForCaptcha).then(function (response) {
                       if (response.data.status == 'SUCCESS') {
                           $scope.captchaData = response.data.result;
                           $scope.challengeID = $scope.captchaData.challengeID;
                           $scope.displayCaptcha = response.data.result.challengeAnswer;
                       }
                       else{
                           NotifyFactory.log('error', 'error')
                       }

                   });

                   }
               });
           }


           /*Get captacha */
           var urlForCaptcha = smcConfig.services.GetTheChallengeIDandAnswer.url;


           $http.get(urlForCaptcha).then(function (response) {
               if (response.data.status == 'SUCCESS') {
                   $scope.captchaData = response.data.result;
                   $scope.challengeID = $scope.captchaData.challengeID;
                   $scope.displayCaptcha = response.data.result.challengeAnswer;
               }
               else{
                   NotifyFactory.log('error', 'error')
               }

           });
       }
   })();
