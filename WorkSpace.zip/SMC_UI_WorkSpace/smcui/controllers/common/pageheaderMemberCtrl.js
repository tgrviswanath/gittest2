(function () {
    'use strict';
    angular
        .module('smc')
        .controller('pageheaderMemberCtrl', pageheaderMemberCtrl);

    pageheaderMemberCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', 'navigateConfig'];

    function pageheaderMemberCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, navigateConfig) {
        $scope.userRole = $cookies.get('roleName');
        $scope.displayRole = $cookies.get('displayRoleName');
        $scope.userName = $cookies.get('userName');
        $scope.passwordStatus = $cookies.get('systemPassword');
        $scope.memberType = $cookies.get('memberType');
        $scope.moduleName = $cookies.get('moduleName');
        $scope.currentActionMenu = $cookies.get('currentActionMenu');
        $scope.logoUrl = navigateConfig.logoUrl[$scope.memberType];
        $scope.currentActionMenu = $cookies.get('currentActionMenu');
        $scope.roleName = $cookies.get('roleName');


        if ($scope.moduleName != 'Dashboard') {
            if ($scope.memberType == 'Staff') {
                $scope.menuList = navigateConfig[$scope.moduleName][$scope.userRole];
            } else if ($scope.memberType == 'Member') {
                $scope.menuList = navigateConfig[$scope.moduleName][$scope.userRole];
                $scope.displayRole = $cookies.get('roleName');
            }
        } else {
            if ($scope.memberType == 'Staff') {
                $scope.menuList = [{
                    displayName: 'Dashboard',
                    url: 'smclayout.membershiplayout.memberdashboard'
                }]
            } else if ($scope.memberType == 'Member') {
                $scope.menuList = [{
                    displayName: 'Dashboard',
                    url: 'smclayout.membershiplayout.membersdashboard'
                }]
                
            }
        }

        for(var menu in $scope.menuList){
            if($scope.menuList[menu].url == $state.current.name){
                $cookies.put('currentActionMenu', $scope.menuList[menu].displayName);
                $scope.currentActionMenu = $scope.menuList[menu].displayName;
            }
        }

        $scope.logout = function (value) {
            $cookies.put('memberId', null);
            $cookies.put('smcOfficerStatus', null);
            $cookies.put('smcManagerStatus', null);
            $cookies.put('adjudicatorStatus', null);
            $cookies.put('userName', null);
            $cookies.put('caseNumber', null);
            $cookies.put('userMail', null);
            $cookies.put('Password', null);
            $cookies.put('roleName', null);
            $cookies.put('pageNumber',null);
            $cookies.put('currentActionMenu',null);
            $cookies.put('currentTab',null);
            $cookies.put('displayRoleName',null);
            $cookies.put('memberType',null);
            $cookies.put('moduleName',null);
            $cookies.put('roleId',null);
            $cookies.put('moduleId',null);
            $cookies.put('systemPassword',null);

            if(value == 'Member') {
                $state.go('smclayout.membershiplayout.login');
            } else if (value == 'Staff') {
                $state.go('smclayout.membershiplayout.memberlogin');
            }
        }
        $scope.goToMenu = function (menu) {
            $cookies.put('currentActionMenu', menu.displayName);
            $state.go(menu.url);
        }
        $scope.goToChangePasswordPage = function () {
            dashboardPageheaderCtrl
            $state.go('smclayout.membershiplayout.changepassword');
        }
        $scope.goToProfilePage = function () {
            $cookies.put('currentActionMenu', 'profile');
            // $state.go('smclayout.contactlayout.profile');
            $state.go('smclayout.contactlayout.smcmemberprofilemenulist.profileinformation');
        }
    }
})();
