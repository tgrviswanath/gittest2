(function () {
    'use strict';
    angular
        .module('smc')
        .controller('defaultPageHeaderCtrl', defaultPageHeaderCtrl);

    defaultPageHeaderCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', 'navigateConfig'];

    function defaultPageHeaderCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, navigateConfig) {
        
        if($state.current.name.indexOf('registerationProcess') != -1){
            $scope.currentServicePage = 'programs';
        }else{
            $scope.currentServicePage = 'home';
        }
    }
})();
