(function() {
    'use strict';
    angular
        .module('smc')
        .controller('dashboardPageheaderCtrl',dashboardPageheaderCtrl);

    dashboardPageheaderCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','navigateConfig'];

    function dashboardPageheaderCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,navigateConfig){
        if ($cookies.get('Password') == null) {
            $state.go('smclayout.membershiplayout.memberlogin');
        }

        $scope.userName = $cookies.get('userName');
        $scope.memberType = $cookies.get('memberType');
        $scope.logout= function(value){
            $cookies.put('memberId',null);
            $cookies.put('smcOfficerStatus',null);
            $cookies.put('smcManagerStatus',null);
            $cookies.put('adjudicatorStatus',null);
            $cookies.put('userName',null);
            $cookies.put('caseNumber',null);
            $cookies.put('userMail',null);
            $cookies.put('Password',null);
            $cookies.put('roleName',null);
            $cookies.put('memberType',null);
            $cookies.put('pageNumber',null);
            $cookies.put('currentActionMenu',null);
            $cookies.put('currentTab',null);
            $cookies.put('displayRoleName',null);
            $cookies.put('memberType',null);
            $cookies.put('moduleName',null);
            $cookies.put('roleId',null);
            $cookies.put('moduleId',null);
            $cookies.put('systemPassword',null);
            
            if(value == 'Member'){
                $state.go('smclayout.membershiplayout.login');
            }else  if(value == 'Staff'){
                $state.go('smclayout.membershiplayout.memberlogin');
            }
        }

        $scope.goToChangePasswordPage = function(){
            $cookies.put('currentActionMenu','Change Password');
            $state.go('smclayout.membershiplayout.changepassword');
        }
        $scope.getInviteList=function(){
            $cookies.put('currentActionMenu','Invite List');
            $cookies.put('moduleName','Dashboard');
            $state.go('smclayout.membershiplayout.adjudicatorinvitelist');
        }
        $scope.getRenewalList=function(){
            $cookies.put('currentActionMenu','Renewal List');
            $cookies.put('moduleName','Dashboard');
            $state.go('smclayout.membershiplayout.memberrenewallist');
        }
  	}
})();