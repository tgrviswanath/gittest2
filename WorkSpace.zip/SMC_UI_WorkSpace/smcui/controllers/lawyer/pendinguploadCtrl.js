(function() {
    'use strict';
    angular
        .module('smc')
        .controller('uploadCtrl',uploadCtrl);

    uploadCtrl.$inject = ['$rootScope','$scope','$interval','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function uploadCtrl($rootScope,$scope,$interval,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
			
    	if ($cookies.get('roleName') != 'claimant' && $cookies.get('roleName') != 'claimantLawyer') {
            $state.go('smclayout.membershiplayout.login');
        }


			$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
			$scope.uploadname = [];
			$scope.termsUploadPath = [];
			$scope.termsUploadPathStatus = [];
			$scope.termsErrorStatus = [];
			$scope.termsUploadErrorMsg = '';
			// upload a file - before that check file size,valid exetension
			$scope.uploadFile = function(file,index){
				var file = file;
				var index = index;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(file.name)){
						$scope.uploadname[index] = file.name;
						console.log('$scope.uploadname',$scope.uploadname);
						var fd= new FormData();
						fd.append('file',file);
						httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
							console.log(data);
							$scope.termsUploadPath[index] = data.result;
							console.log('$scope.termsUploadPath',$scope.termsUploadPath)
							$scope.termsUploadPathStatus[index] = true;
						});
					}
					else{
						var elementIdname = "#uploadname"+index;
						angular.element(elementIdname).addClass("error");
						var allowedExt = $scope.fileUploadTypes;
						$scope.termsUploadErrorMsg = "You can upload only " + allowedExt.toString(); 
						NotifyFactory.log('error',$scope.termsUploadErrorMsg);
					}
				}else{
					NotifyFactory.log('error','Please upload below 5MB file')
				}
			}
			// check valid file by exetension
			function validateUploadFileExtention(val){
				var allowedExt = $scope.fileUploadTypes;

				var ext = val.split('.').pop();
				for(var i = 0; i < allowedExt.length; i++){
					if($scope.fileUploadTypes[i] == ext){
						return true;
					}
				}
			}
			// if we want remove upload file
			$scope.termsUploadRemove = function(index){
				var fileCount = 0;
				$scope.uploadname[index] = undefined;
				$scope.termsUploadPath[index] = undefined;
				for(var count=0;count<$scope.termsUploadPath.length;count++){
					if($scope.termsUploadPath[count] == undefined){
						fileCount = fileCount+1;
					}
				}
				if(fileCount == $scope.termsUploadPath.length){
					$scope.termsUploadPath =[];
				}
				$scope.termsUploadPathStatus[index] = false;
			}
			// to submit upload files
			$scope.submitUploadFile = function(){
				var documentsList = [];
				for(var count=0;count<$scope.termsUploadPath.length;count++){
					var suportfileobject = {};
					if($scope.termsUploadPath[count] == undefined){
						continue;
					}else{
						suportfileobject['name'] = $rootScope.missedDocuments[count];
						suportfileobject['fileLocation'] = $scope.termsUploadPath[count];
					}
					documentsList.push(suportfileobject)
				}
				var query={
					'tempCaseNumber':$cookies.get('caseNumber'),
					'documentsList': documentsList
				}
				console.log('query',query);
				DataService.post('UploadSupportDocuments',query).then(function (data) {
					NotifyFactory.log('success', "File uploaded successfully.");
					$state.go('smclayout.membershiplayout.lawyercasesummary')
	    		})
	    		.catch(function(error){
	    			NotifyFactory.log('error', "File upload Failed");
	    		});

			}
	}
}
)();