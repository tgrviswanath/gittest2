(function() {
    'use strict';
    angular
        .module('smc')
        .controller('loginformCtrl',loginformCtrl);

    loginformCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function loginformCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	$scope.isDisabled=false;
    	if($cookies.get('roleName') == 'Claimant'){
			$state.go('smclayout.membershiplayout.lawyercasesummary')
		}
		else if($cookies.get('roleName') == 'Respondent'){
			$state.go('smclayout.membershiplayout.respondantcasesummary')
		}else{
			
	    	// login as a lawyer into admin page
	    	$rootScope.memberLogin = function(login){
	    		$scope.isDisabled=true;
				angular.element(".overlay").css("display","block");
				angular.element(".loading-container").css("display","block");
	    		$cookies.put('userMail','');
				$cookies.put('Password','');
				$cookies.put('roleName','');
		      	if($scope.login.username && $scope.login.password){
			        var query = {
			            "userId": $scope.login.username,
			            "password": $scope.login.password,
			        };
			        DataService.post('caseMemberLogin',query).then(function (data) {
			        	$scope.isDisabled=false;
			        	if(data.status == 'SUCCESS'){
							$cookies.put('userMail',$scope.login.username);
							$cookies.put('Password',$scope.login.password);
							$cookies.put('memberId',data.result.memberId);
							$cookies.put('memberType','Member');
							$cookies.put('userName',data.result.memberName);
							$rootScope.loginDetails = data.result;
							if(data.result.adjudication){
								if(data.result.adjudication.adjudicator){
									$cookies.put('roleName','adjudicator');
									$cookies.put('GSTregistered',data.result.adjudication.adjudicator.isGSTRegistered);
									$cookies.put('ConferenceRate',data.result.adjudication.adjudicator.conferenceRate);
									$cookies.put('systemPassword',data.result.isSystemGenerated);
									if(data.result.isSystemGenerated){
										$state.go('smclayout.membershiplayout.changepassword')
									}else{
										 $state.go('smclayout.membershiplayout.membersdashboard')
									}
								}else if(data.result.adjudication.claimant || data.result.adjudication.claimantLawyer){
									$cookies.put('roleName','claimant');
									$cookies.put('systemPassword',data.result.isSystemGenerated);
									if(data.result.isSystemGenerated){
										$state.go('smclayout.membershiplayout.changepassword')
									}else{
										 $state.go('smclayout.membershiplayout.membersdashboard')
									}
								}else if(data.result.adjudication.respondent || data.result.adjudication.respondentLawyer){
									$cookies.put('roleName','respondent');
									$cookies.put('systemPassword',data.result.isSystemGenerated);
									if(data.result.isSystemGenerated){
										$state.go('smclayout.membershiplayout.changepassword')
									}else{
										 $state.go('smclayout.membershiplayout.membersdashboard')
									}
								}
							}
							if(data.result.training){
								$cookies.put('roleName','trainer');
								$cookies.put('systemPassword',data.result.isSystemGenerated);
								if(data.result.isSystemGenerated){
									$state.go('smclayout.membershiplayout.changepassword')
								}else{
									 $state.go('smclayout.membershiplayout.membersdashboard')
								}
							}
							if(data.result.mediation){
								if(data.result.mediation.mediator){
									$cookies.put('roleName','mediator');
									$cookies.put('systemPassword',data.result.isSystemGenerated);
									if(data.result.isSystemGenerated){
										$state.go('smclayout.membershiplayout.changepassword')
									}else{
										 $state.go('smclayout.membershiplayout.membersdashboard')
									}
								}else if(data.result.mediation.applicant || data.result.mediation.applicantLawyer){
									$cookies.put('roleName','claimant');
									$cookies.put('systemPassword',data.result.isSystemGenerated);
									if(data.result.isSystemGenerated){
										$state.go('smclayout.membershiplayout.changepassword')
									}else{
										 $state.go('smclayout.membershiplayout.membersdashboard')
									}
								}else if(data.result.mediation.respondent || data.result.mediation.respondentLawyer){
									$cookies.put('roleName','respondent');
									$cookies.put('systemPassword',data.result.isSystemGenerated);
									if(data.result.isSystemGenerated){
										$state.go('smclayout.membershiplayout.changepassword')
									}else{
										 $state.go('smclayout.membershiplayout.membersdashboard')
									}
								}
							}
							angular.element(".overlay").css("display","none");
							angular.element(".loading-container").css("display","none");
							NotifyFactory.log('success', "Logged in successfully.");
			        	}else{
			        		NotifyFactory.log('error', data.errorMessage);
							angular.element(".overlay").css("display","none");
							angular.element(".loading-container").css("display","none");
			        	}
			        }, function (error) {
			        	$scope.isDisabled=false;
						NotifyFactory.log('error', error.errorMessage);
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						if(error.errorMessage == "Your account has been locked"){
							angular.element(".overlay").css("display","block");
							angular.element("#login_locked_information").css("display","block");
						}
			        });
		        }
		    }
		    $scope.goToResetPage = function(){
				$rootScope.loginType = 'notMember';
				$state.go('smclayout.membershiplayout.resetpassword');
			}
			$scope.cancelLogin=function(){
				$scope.login={};
			}
			$scope.closeLoginLock=function(){
				angular.element(".overlay").css("display","none");
				angular.element("#login_locked_information").css("display","none");
			}
		}
    }
 })();