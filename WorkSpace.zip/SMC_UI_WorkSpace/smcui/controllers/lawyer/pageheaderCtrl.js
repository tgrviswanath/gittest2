(function() {
    'use strict';
    angular
        .module('smc')
        .controller('pageheaderCtrl',pageheaderCtrl);

    pageheaderCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','navigateConfig'];

    function pageheaderCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,navigateConfig){
  		$scope.userRole = $cookies.get('roleName');
        $scope.passwordStatus = $cookies.get('systemPassword')
        $scope.userRole = $scope.userRole.replace(' ','_');
        $scope.logoUrl = navigateConfig.logo[$scope.userRole][0].url;
        $scope.menues = navigateConfig.navigation[$scope.userRole];
        $scope.usermenu = navigateConfig.user_action[$scope.userRole];
        $scope.userRole = $scope.userRole.replace('_',' ');
        $scope.userName = $cookies.get('userName');
        $scope.logout= function(){
            var role = $cookies.get('roleName')
            role = role.replace(' ','_');
            $cookies.put('memberId',null);
            $cookies.put('smcOfficerStatus',null);
            $cookies.put('smcManagerStatus',null);
            $cookies.put('adjudicatorStatus',null);
            $cookies.put('userName',null);
            $cookies.put('caseNumber',null);
            $cookies.put('userMail',null);
            $cookies.put('Password',null);
            $cookies.put('roleName',null);
            $state.go("smclayout.membershiplayout.login")
        }
  	}
})();