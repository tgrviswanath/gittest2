(function() {
    'use strict';
    angular
        .module('smc')
        .controller('lawfirmManageCtrl',lawfirmManageCtrl);

    lawfirmManageCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function lawfirmManageCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'lawfirmManage'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_lawfirm_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','lawfirmManage');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to conflicted case list function from outside
        $rootScope.getlawfirmlist = function(){
            get_lawfirm_list($cookies.get('pageNumber'));
        } 

    	// get rejected case list
    	function get_lawfirm_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":$scope.pagenumber, 
                 "dataLength":$scope.dataLength, 
                 "sortingColumn":null, 
                 "sortDirection":null, 
                 "name":null
    		}
    		DataService.post('OfficerGetLawfirmList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.lawfirm_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.lawfirm_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    

        $scope.goToPageNumber = function(pageNo){
           get_lawfirm_list(pageNo);
        } 

        //to open add a lawfirm model
        $scope.addLawfirm = function (){
            $scope.lawfirmData = {};
            angular.element(".overlay").css("display","block");
            angular.element(".officer-add-lawfirm").css("display","block");
        }

        //search lawfirm for admin
            $scope.getLawfirm = function(filterDetails){
                var query = {
                    "name":filterDetails.name
                }
                DataService.post('OfficerGetLawfirmList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                     $scope.shownodataavailable = false;
                    $scope.lawfirm_List = data.result.responseData
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                     $scope.shownodataavailable = true;
                }
                }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                      $scope.shownodataavailable = true;
                });
            }

            //reset users list
            $scope.resetLawfirm = function(){
                $scope.filter = undefined;
                get_lawfirm_list(0);
            }


        //to close add a lawfirm model
        $scope.closeaddcoureiermodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".officer-add-lawfirm").css("display","none");
        }

        // submit add lawfirm 
        $scope.submitAddLawfirm = function(lawfirmData){
            var query = BuildLawfirmQuery(lawfirmData);
            DataService.post('OfficerAddLawfirm',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','Lawfirm added successfully');
                    get_lawfirm_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".officer-add-lawfirm").css("display","none");
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.data.errorMsg)
	        });
        }

        //build lawfirm query
        function BuildLawfirmQuery(lawfirmData){
            var query = {
                "loginId" : $cookies.get('memberId'),
                "lawFirmDetail" : {
                    "id":undefinedSetNull(lawfirmData.id), 
                    "name":lawfirmData.name, 
                    "contactPersonName":lawfirmData.contactPersonName, 
                    "businessAddress":lawfirmData.businessAddress
                }
            }
            

            return query;
        }

        //view a single user details
        $scope.viewLawfirm = function(lawfirm){
            $scope.lawfirmDetails = angular.copy(lawfirm);
            angular.element(".overlay").css("display","block");
            angular.element(".officer-modify-lawfirm").css("display","block");
        }

        $scope.deleteLawfirm = function(lawfirm){
            $scope.lawfirm = lawfirm;
            angular.element(".overlay").css("display","block");
            angular.element(".lawfirm-delete-confirm-modal").css("display","block");            
        }

        $scope.confirmDeleteLawfirm=function(lawfirm){
            var query={
                "loginId":$cookies.get('memberId'),
                "lawFirmId":lawfirm.id
            }
            
              DataService.post('OfficerDeleteLawfirm',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
                     angular.element(".overlay").css("display","none");
                     angular.element(".lawfirm-delete-confirm-modal").css("display","none");   
                    get_lawfirm_list($cookies.get('pageNumber'));
    				NotifyFactory.log('success','Lawfirm deleted successfully');
                    
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.data.errorMsg)
	        });
        }

        $scope.closeConfirmationLawfirm=function(){
            angular.element(".overlay").css("display","none");
            angular.element(".lawfirm-delete-confirm-modal").css("display","none");
        }
        //to close modify a user model
        $scope.closemodifylawfirmmodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".officer-modify-lawfirm").css("display","none");
        }

        //update user status
        $scope.updateLawfirm = function(lawfirmData){
             var query = BuildLawfirmQuery(lawfirmData);
            DataService.post('OfficerUpdateLawfirm',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','Lawfirm updated successfully');
                    get_lawfirm_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".officer-modify-lawfirm").css("display","none");
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.data.errorMsg)
	        });
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


