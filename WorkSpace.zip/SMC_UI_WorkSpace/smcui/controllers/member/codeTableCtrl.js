(function() {
    'use strict';
    angular
        .module('smc')
        .controller('codeTableCtrl',codeTableCtrl);

    codeTableCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function codeTableCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
       if ($cookies.get('roleName') != 'SMC Officer' &&  $cookies.get('roleName') != 'Super Admin' &&  $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName') != 'Adjudication' &&  $cookies.get('moduleName') != 'Admin' &&  $cookies.get('moduleName') != 'Contact' &&  $cookies.get('moduleName') != 'Training') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
    	get_code_table();//call to conflicted case list function
        $cookies.put('currentTab','codeTable');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get code table list
    	function get_code_table(){
    		var query = {
    			 "pageIndex":0, 
                 "dataLength":100, 
                 "sortingColumn":null, 
                 "sortDirection":null, 
                 "moduleName":$cookies.get('moduleName'), 
                 "categoryName":null
    		}
    		DataService.post('OfficerGetCodeList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.code_Table_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    if($scope.code_Table_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

        //search code in code table
            $scope.getCode = function(filterDetails){
                var query = {
                    "moduleName":filterDetails.moduleName, 
                    "categoryName":filterDetails.categoryName
                }
                DataService.post('OfficerGetCodeList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.code_Table_List = data.result.responseData;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
            }

            //reset code list
            $scope.resetcodecases = function(){
                $scope.filter = undefined;
                get_code_table(0);
            }

            //update code if any change in value
            $scope.ifupdatecode = function(codeData){
                var query = JSON.parse(codeData.attributes.changevalue.value);
                console.log('query',query);
                if(query.value){
                    if(query.name == 'Max_ARA_Case_Adjudicator' || query.name == 'Min_ARA_Case_Adjudicator'){
                        checkARAAdjudicatorCount(query);
                    }else if(query.name == 'Max_Invite_Adjudicator' || query.name == 'Min_Iinvite_Adjudicator'){
                        checkInviteAdjudicatorCount(query);
                    }else if(query.name == 'Maximum_Adjudicated_Amount' || query.name == 'Minimum_Adjudicated_Amount'){
                        checkAdjudicatedAmount(query);
                    }else{
                        updateValue(query);
                    }
                }else{
                    NotifyFactory.log('error', 'Enter valid value');
                    document.getElementById(query.name).value = document.getElementById(query.name).oldvalue;
                }
            }

            $scope.ifupdatemode = function(codeData){
                updateValue(codeData);
            }

            function checkARAAdjudicatorCount(query){
                var min_value = document.getElementById('Min_ARA_Case_Adjudicator').value;
                var max_value = document.getElementById('Max_ARA_Case_Adjudicator').value;
                if(parseInt(max_value) < parseInt(min_value)){
                    if(query.name == 'Max_ARA_Case_Adjudicator'){
                        NotifyFactory.log('error', 'Maximum adjudicator\'s count should be higher than Minimum adjudicator\'s count');
                        document.getElementById('Max_ARA_Case_Adjudicator').value = document.getElementById('Max_ARA_Case_Adjudicator').oldvalue;
                    }else if(query.name == 'Min_ARA_Case_Adjudicator'){
                        NotifyFactory.log('error', 'Minimum adjudicator\'s count should be less than Maximum adjudicator\'s count');
                        document.getElementById('Min_ARA_Case_Adjudicator').value = document.getElementById('Min_ARA_Case_Adjudicator').oldvalue;
                    }                    
                }else{
                    updateValue(query);
                }
            }

            function checkInviteAdjudicatorCount(query){
                var min_value = document.getElementById('Min_Iinvite_Adjudicator').value;
                var max_value = document.getElementById('Max_Invite_Adjudicator').value;
                if(parseInt(max_value) < parseInt(min_value)){
                    if(query.name == 'Max_Invite_Adjudicator'){
                        NotifyFactory.log('error', 'Maximum adjudicator\'s count should be higher than Minimum adjudicator\'s count');
                        document.getElementById('Max_Invite_Adjudicator').value = document.getElementById('Max_Invite_Adjudicator').oldvalue;
                    }else if(query.name == 'Min_Iinvite_Adjudicator'){
                        NotifyFactory.log('error', 'Minimum adjudicator\'s count should be less than Maximum adjudicator\'s count');
                        document.getElementById('Min_Iinvite_Adjudicator').value = document.getElementById('Min_Iinvite_Adjudicator').oldvalue;
                    }
                }else{
                    updateValue(query);
                }
            }

            function checkAdjudicatedAmount(query){
                var min_value = document.getElementById('Minimum_Adjudicated_Amount').value;
                var max_value = document.getElementById('Maximum_Adjudicated_Amount').value;
                if(parseInt(max_value) < parseInt(min_value)){
                    if(query.name == 'Maximum_Adjudicated_Amount'){
                        NotifyFactory.log('error', 'Maximum adjudicated amount should be higher than Minimum adjudicated amount');
                        document.getElementById('Maximum_Adjudicated_Amount').value = document.getElementById('Maximum_Adjudicated_Amount').oldvalue;
                    }else if(query.name == 'Minimum_Adjudicated_Amount'){
                        NotifyFactory.log('error', 'Minimum adjudicated amount should be less than Maximum adjudicated amount');
                        document.getElementById('Minimum_Adjudicated_Amount').value = document.getElementById('Minimum_Adjudicated_Amount').oldvalue;
                    }
                }else{
                    updateValue(query);
                }
            }

            function updateValue(query){
                delete query.moduleName;
                DataService.post('updateCodeTableValue',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                     NotifyFactory.log('success', 'Code info value updated successfully');
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
                }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                });
            }
    }
})();


