(function() {
    'use strict';
    angular
        .module('smc')
        .controller('reportsgenerateCtrl',reportsgenerateCtrl);

    reportsgenerateCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function reportsgenerateCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.roleName = $cookies.get('roleName');
        $cookies.put('currentTab','generatereports');
        $scope.shownodataavailable = true;
        $scope.$emit('activeReportTab',$cookies.get('currentTab'));//sent current tab status
    	// to receive filter case list
        $scope.$on('reportCases', function(event, caselist) { 
                $scope.reports = caselist; 
                $scope.shownodataavailable = false;
         });
    }
})();


