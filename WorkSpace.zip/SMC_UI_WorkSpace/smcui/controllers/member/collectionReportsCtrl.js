(function() {
    'use strict';
    angular
        .module('smc')
        .controller('collectionReportsCtrl',collectionReportsCtrl);

    collectionReportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function collectionReportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Adjudication') {
                 $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'collectionReports'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_collection_reports($scope.pagenumber);//call to get panel list function
        $cookies.put('currentTab','collectionReports');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get collection report list
    	function get_collection_reports(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex":$scope.pagenumber,
                "dataLength":$scope.dataLength,
                "sortingColumn":null,
                "sortDirection":null,
                "claimantName":null,
                "respondentname":null,
                "paymentMode":null,
                "paymentFromDate":null,
                "paymentToDate":null,
                "amountFrom":null,
                "amountTo":null,
                "caseNumber":null,
                "paymentType":null,
                "chequeNumber":null,
                "cashierOrderNumber":null,
                "transactionRefNum":null,
                "invoiceNumber":null
    		}
    		getCollectionReports(query);
    	}

    	function getCollectionReports(query){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
    		DataService.post('GetCollectionReports',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.collectionList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if($scope.collectionList.length == 0){
                        $scope.shownodataavailable = true;
                    }else{
                        for(var report in $scope.collectionList){
                            if((($scope.collectionList[report].paymentMode =='Cheque' || $scope.collectionList[report].paymentMode =='Cashier\'s Order') && $scope.collectionList[report].receiptDate == null) || ($scope.collectionList[report].dishonoredStatus == 'Payment Dishonour Request') || ($scope.collectionList[report].dishonoredStatus == 'Payment Dishonour')){
                                $scope.collectionList[report].showmenu = true;
                            }else{
                                $scope.collectionList[report].showmenu = false;
                            }
                        }
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}else{
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
           get_collection_reports(pageNo);
        } 

        //search reports 
        $scope.getReports = function(filterData){
            var query = {
            	"claimantName": undefinedSetNull(filterData.claimantName),
                "respondentname": undefinedSetNull(filterData.respondentname),
                "paymentMode": undefinedSetNull(filterData.paymentMode),
                "paymentFromDate": undefinedSetNull(filterData.paymentFromDate),
                "paymentToDate": undefinedSetNull(filterData.paymentToDate),
                "amountFrom": undefinedSetNull(filterData.amountFrom),
                "amountTo": undefinedSetNull(filterData.amountTo),
                "caseNumber": undefinedSetNull(filterData.caseNumber),
                "paymentType": undefinedSetNull(filterData.paymentType),
                "chequeNumber": undefinedSetNull(filterData.chequeNumber),
                "cashierOrderNumber": undefinedSetNull(filterData.cashierOrderNumber),
                "transactionRefNum": undefinedSetNull(filterData.transactionRefNum),
                "invoiceNumber": undefinedSetNull(filterData.invoiceNumber)
            }
            getCollectionReports(query);
        }

        //reset report list
        $scope.resetreports = function(){
            $scope.filter = undefined;
            get_collection_reports(0);
        }

        $scope.updateAkgmntDate = function(reportId,paymentMode){
            $scope.akgmntData = {};
            $scope.akgmntData.id = reportId;
            $scope.paymentMode = paymentMode;
            angular.element(".overlay").css("display","block");
            angular.element(".update-ackg-date").css("display","block");
        }

        $scope.cancelupdaterecipt = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".update-ackg-date").css("display","none");
        }

        $scope.updateReciptDate = function(reciptData){
            angular.element(".loading-container").css("display","block");
            angular.element(".update-ackg-date").css("display","none");
            reciptData.loginId = $cookies.get('memberId');
            DataService.post('UpdateCollectionReceiptDate',reciptData).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Receipt date updated successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".update-ackg-date").css("display","block");
            });
        }

        //Get Payment Mode List Service
        DataService.get('GetPaymentModes').then(function(data){
            if(data.status == 'SUCCESS'){
                $scope.paymentModes = data.results;
            } else {
                $scope.paymentModes = [];
            }
        });

         //Get Payment Types List Service
        DataService.get('GetPaymentTypes').then(function(data){
            if(data.status == 'SUCCESS'){
                $scope.paymentTypes = [];
                for(var type in data.results){
                    if(data.results[type].name != 'Membership Fee' && data.results[type].name != 'Renewal Fee'){
                        $scope.paymentTypes.push(data.results[type]);
                    }
                }
            } else {
                $scope.paymentTypes = [];
            }
        });

        $scope.addPaymentData = function(report){
            $scope.paymentData = {};
            $scope.paymentData.caseNumber = report.caseNumber;
            $scope.paymentData.payerName = report.claimantName;
            $scope.currentModes = [];
            $scope.currentTypes = [];
            for(var mode in $scope.paymentModes){
                if($scope.paymentModes[mode].name == 'Cash' || $scope.paymentModes[mode].name == 'Cheque' || $scope.paymentModes[mode].name == 'Cashier\'s Order'){
                    $scope.currentModes.push($scope.paymentModes[mode]);
                }
            }
            for(var type in $scope.paymentTypes){
                if($scope.paymentTypes[type].name != 'Membership Fee' && $scope.paymentTypes[type].name != 'Renewal Fee'){
                    $scope.currentTypes.push($scope.paymentTypes[type]);
                }
            }
            var getInvoiceUrl = smcConfig.services.GetFailedInvoices.url + report.caseNumber;
            $http.get(getInvoiceUrl).then(function(data){
                if(data.data.status == 'SUCCESS'){
                    $scope.invoices = data.data.results;
                }
            });
            angular.element(".overlay").css("display","block");
            angular.element(".add-payment-details-officer").css("display","block");
        }

        $scope.canceladdpayment = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".add-payment-details-officer").css("display","none");
        }

        $scope.submitAddPayment = function (paymentData){
            angular.element(".loading-container").css("display","block");
            angular.element(".add-payment-details-officer").css("display","none");
            var query = buildPaymentQuery(paymentData);
            DataService.post('AddPaymentByOfficer',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Payment added successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".add-payment-details-officer").css("display","block");
            });
        }

        function buildPaymentQuery(paymentData){
            var dataQuery = {
                "loginId":$cookies.get('memberId'),
                "caseNumber": undefinedSetNull(paymentData.caseNumber),
                "paymentMode": undefinedSetNull(paymentData.paymentMode),
                "referenceNumber": undefinedSetNull(paymentData.referenceNumber),
                "dateOfOrder": undefinedSetNull(paymentData.dateOfOrder),
                "amount": undefinedSetNull(paymentData.amount),
                "bankName": undefinedSetNull(paymentData.bankName),
                "paymentType": undefinedSetNull(paymentData.paymentType),
                "receiptDate": undefinedSetNull(paymentData.receiptDate),
                "invoiceNumber": undefinedSetNull(paymentData.invoiceNumber),
                "payerName": undefinedSetNull(paymentData.payerName)
            }
            return dataQuery;
        }

        $scope.modeChange = function(data,id){
            $scope.paymentData = {};
            $scope.paymentData.paymentMode = id;
            $scope.paymentData.caseNumber = data.caseNumber;
            $scope.paymentData.payerName = data.payerName;
        }


        $scope.openStatus = function(reportData){
            $scope.updateCqkData = {};
            var viewDataUrl = smcConfig.services.GetPaymentDetailstoView.url + reportData.id;
            $http.get(viewDataUrl).then(function(data){
                if(data.data.status == 'SUCCESS'){
                    $scope.chkData = data.data.result;
                    $scope.updateCqkData.paymentId = $scope.chkData.id;
                    $scope.updateCqkData.referenceNumber = $scope.chkData.chequeNumber;
                    angular.element(".overlay").css("display","block");
                    angular.element(".payment-view-status").css("display","block");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
            });
        }

        $scope.cancelViewStatus = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".payment-view-status").css("display","none"); 
        }

        $scope.updateCheque = function (updatedData){
            angular.element(".loading-container").css("display","block");
            angular.element(".payment-view-status").css("display","none");
            var query = buildUpdateChequeQuery(updatedData);
            DataService.post('UpdateChequeDetails',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success','Cheque updated successfully');
                    get_collection_reports($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error',error.errorMessage);
                angular.element(".loading-container").css("display","none");
                angular.element(".payment-view-status").css("display","block");
            });
        }
        $scope.toDateLimit=0;  
        $scope.changeMinDate=function(){
                var fromDate = $scope.filter.paymentFromDate;         
                $scope.toDateLimit = fromDate;        
                $scope.filter.paymentToDate = '';        
                $( "#paymentTo" ).datepicker( "option", "minDate",fromDate );     
        }


        function buildUpdateChequeQuery(updatedData){
            var query = {
                "paymentId": updatedData.paymentId,
                "loginId": $cookies.get('memberId'),
                "referenceNumber": undefinedSetNull(updatedData.referenceNumber),
                "amount":undefinedSetNull(updatedData.amount),
                "dateOfOrder":undefinedSetNull(updatedData.dateOfOrder),
                "bankName":undefinedSetNull(updatedData.bankName),
                "remarks":undefinedSetNull(updatedData.remarks)
            }

            return query;
        }
    	function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();