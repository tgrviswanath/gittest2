(function() {
    'use strict';
    angular
        .module('smc')
        .controller('determinationslistCtrl',determinationslistCtrl);

    determinationslistCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function determinationslistCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.determineDownload = smcConfig.services.DownloadDetermineDocument.url
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'determinationslist'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));

        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_determinations_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','determinationslist');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to conflicted case list function from outside
        $rootScope.getdeterminationslist = function(){
            get_determinations_list($cookies.get('pageNumber'));
        } 
        
        
    	// get  case list
    	function get_determinations_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex": 0, 
                 "dataLength": 10, 
                 "sortingColumn": null, 
                 "sortDirection": null, 
                 "fromYear": null, 
                 "toYear": null
    		}
    		DataService.post('GetAllDetermineList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.determinationsList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.determinationsList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    

        $scope.goToPageNumber = function(pageNo){
           get_determinations_list(pageNo);
        } 

       

        //search case
            $scope.getOfficer = function(filterDetails){
                var query = {
                    "caseOfficer": filterDetails.caseOfficer, 
                    "assistantManager":filterDetails.assistantManager, 
                }
                DataService.post('GetToDoList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.determinationsList = data.result.responseData
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
                }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                });
            }

            //reset users list
            $scope.resetcases = function(){
                $scope.filter = undefined;
                get_determinations_list(0);
            }
            

       
        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


