(function() {
    'use strict';
    angular
        .module('smc')
        .controller('updateAA1formCtrl',updateAA1formCtrl);

    updateAA1formCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig'];

    function updateAA1formCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig){
    	
    	var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	if (tab == 'submitformprocess'){
	    	if ($cookies.get('roleName') != 'claimant' || $cookies.get('roleName') != 'claimantLawyer') {
	            $state.go('smclayout.membershiplayout.login');
	        }
	    }

	    if(!$rootScope.caseDetailObj){
	    	$state.go("smclayout.membershiplayout.memberdashboard");
	    }


    	var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches

    	//Error Messages
		$scope.pattern = patternConfig;

		//Default Values settings
		$scope.directFormSataus = true;
    	$scope.isPreviewClicked = false;
    	$scope.claiamentStatus = false;
    	$scope.claiamentServiceAddressStatus = true;
    	$scope.claiamentLawFormDetailStatus = true;
    	$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
    	$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
    	$scope.uenOrnric = "Enter the organisation’s UEN";
    	$scope.respondentIndivStatus = false;
		$scope.registeredRespondentName = "Enter the respondent’s registered name";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
		$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.interestRateOfLatePaymentStatus = false;
		$scope.onlineFormSubmissionStatus = true;

		$scope.onlineFormUpdateStatus = false;

		//Form Related Default settings
		$scope.aa1_form1 = {};
		$scope.aa1_form1.claimantInfo = {};
		$scope.aa1_form1.claimantInfo.businessAddress = {};

		$scope.aa1_form1.claimantInfo.lawFirmDto = {};
		$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress = {};

		$scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails = [];
		$scope.aa1_form1.respondentInfo = {};
		$scope.aa1_form1.respondentInfo.businessAddress = {};

		$scope.aa1_form1.respondentInfo.lawFirmDto = {};
		$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress = {};
		$scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails = [];
		$scope.aa1_form1.regulationInfo = {};
		$scope.aa1_form1.regulationInfo.principalName = undefined;
		$scope.aa1_form1.contractInfo = {};
		$scope.aa1_form1.paymentInfo = {};
		$scope.aa1_form1.caseDto = {};


		$scope.aa1_form1.claimantInfo.caseMemberRoleType = "Organisation";
		$scope.aa1_form1.respondentInfo.caseMemberRoleType = "Organisation";
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.claimantLawFirmStatus = true;
		$scope.respondantLawFirmStatus = true;
		$scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress = false;
		$scope.aa1_form1.claimantInfo.isLegallyRepresented = "Yes";
		$scope.aa1_form1.respondentInfo.isLegallyRepresented = "No";
		$scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress = false;
		$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress = false;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.onlineFormUpdateStatus = false;
		$scope.termsUploadPathStatus = false;
		$scope.paymentClaimUploadPathStatus = false;
		$scope.paymentResponseUploadPathStatus = false;
		$scope.intentionNoticeUploadPathStatus = false;
		$scope.otherDocUploadPathStatus = false;
		$scope.termsErrorStatus = false;
		$scope.paymentClaimErrorStatus = false;
		$scope.paymentResponseErrorStatus = false;
		$scope.intentionNoticeErrorStatus = false;
		$scope.otherDocErrorStatus = false;
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.isSubmitted = false;

		$rootScope.tempCaseNumber = null;

		$scope.toDateMinLimit = 0;



		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
				cliamentLegallyRepresentedClick();
				respondentLegallyRepresentedClick();
			} else {
				$scope.lawFirmList = [];
			}
			
        });

        //Get Contract Type List Service
        DataService.get('GetContractTypeList').then(function(data){
			$scope.contractTyoeList = data.results;
        });

        //Get Dispute Nature List Service
        DataService.get('GetDisputeNatureList').then(function(data){
			$scope.disputeNatureList = data.results;
        });

        //Get Mode of Document Submission type
        DataService.get('ModeOfDocumentSubmission').then(function(data){
			$scope.documentSubmissionType = data;
			if(!$rootScope.updateCaseNumberSession){
				$scope.submitdoctype = data.result.value;
				$scope.aa1_form1.caseDto.isOnline = data.result.value;
				$scope.onlineFormSubmissionClick();
			}
			
        });

        //Get Purpose Regulation
        DataService.get('GetPurposeRegulation').then(function(data){
			$scope.regulationPurpose = data.result.value;
        });


        /* Login Form Submit process Session */
		if($rootScope.updateCaseNumberSession){
			$scope.directFormSataus = false;
			$scope.aa1_form1 = $rootScope.caseDetailObj;
			
			$scope.aa1_form1.claimantInfo.reEmail = $scope.aa1_form1.claimantInfo.email;
			$rootScope.tempCaseNumber = $cookies.get('caseNumber');

			if($scope.aa1_form1.claimantInfo.caseMemberRoleType == 'Individual'){
				$scope.claiamentStatus = true;
				$scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
				$scope.uenOrnricLabel = "NRIC/Passport Number";
				$scope.uenOrnric = "Enter your NRIC / Passport No.";
			}
			if($scope.aa1_form1.respondentInfo.caseMemberRoleType == 'Individual'){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			}
			if($rootScope.caseDetailObj.claimantInfo.lawFirmDto){
				$scope.aa1_form1.claimantInfo.lawFirmDto.id = { 'id' : $rootScope.caseDetailObj.claimantInfo.lawFirmDto.id};
			}
			if($rootScope.caseDetailObj.respondentInfo){
				if($rootScope.caseDetailObj.respondentInfo.lawFirmDto){
					$scope.aa1_form1.respondentInfo.lawFirmDto.id = { 'id' : $rootScope.caseDetailObj.respondentInfo.lawFirmDto.id};
				}

				if($scope.aa1_form1.respondentInfo.email){
					$scope.aa1_form1.respondentInfo.reEmail = $scope.aa1_form1.respondentInfo.email;
				}
			}
			if($rootScope.caseDetailObj.contractInfo){
				if($rootScope.caseDetailObj.contractInfo.contractTypeDto){
					if($rootScope.caseDetailObj.contractInfo.contractTypeDto.type == "Construction"){
						$scope.natureOfDistributeStatus = true;
					}
				}
			}
			if($rootScope.caseDetailObj.paymentInfo){
				if($rootScope.caseDetailObj.paymentInfo.latePaymentInterest == true){
					$scope.aa1_form1.paymentInfo.latePaymentInterest = "yes";
					$scope.interestRateOfLatePaymentStatus = true;
				}
				if($rootScope.caseDetailObj.paymentInfo.latePaymentInterest == false){
					$scope.aa1_form1.paymentInfo.latePaymentInterest = "no";
				}
			}
			if($rootScope.caseDetailObj.caseDto){
				
				if($rootScope.caseDetailObj.caseDto.includeGst == true){
					$scope.aa1_form1.caseDto.includeGst = "Yes";
				}
				if($rootScope.caseDetailObj.caseDto.includeGst == false){
					$scope.aa1_form1.caseDto.includeGst = "No";
				}
				if($rootScope.caseDetailObj.caseDto.isOnline == true){
					$scope.aa1_form1.caseDto.isOnline = $scope.submitdoctype = "Online";
					$scope.onlineFormSubmissionStatus = true;

				} else {
					$scope.aa1_form1.caseDto.isOnline = $scope.submitdoctype = "Offline";
					$scope.onlineFormSubmissionStatus = false;
				}
				if($rootScope.caseDetailObj.caseDto.isOnline == false){
					$scope.aa1_form1.caseDto.isOnline = "Offline";
				}
			}
			if($rootScope.caseDetailObj.contractInfo){
				$scope.aa1_form1.contractInfo.contractType = JSON.stringify($rootScope.caseDetailObj.contractInfo.contractTypeDto);
			}
			if($rootScope.caseDetailObj.supportingDocuments){
				loginSupportingDocumentLoad($rootScope.caseDetailObj.supportingDocuments);
				
			}

			if($scope.aa1_form1.respondentInfo.serviceAddress){
            	if($scope.aa1_form1.respondentInfo.serviceAddress.faxNumber){
	                $scope.aa1_form1.respondentInfo.serviceAddress.faxNumber = $scope.aa1_form1.respondentInfo.serviceAddress.faxNumber.substring(3);
	            }
	            if($scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber){
	                $scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber = $scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber.substring(2);
	            }
            }
            if($scope.aa1_form1.claimantInfo.serviceAddress){
            	if($scope.aa1_form1.claimantInfo.serviceAddress.faxNumber){
	                $scope.aa1_form1.claimantInfo.serviceAddress.faxNumber = $scope.aa1_form1.claimantInfo.serviceAddress.faxNumber.substring(3);
	            }
	            if($scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber){
	                $scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber = $scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber.substring(2);
	            }
            }

			if($scope.aa1_form1.respondentInfo.businessAddress.faxNumber){
                $scope.aa1_form1.respondentInfo.businessAddress.faxNumber = $scope.aa1_form1.respondentInfo.businessAddress.faxNumber.substring(3);
            }
            if($scope.aa1_form1.respondentInfo.businessAddress.phoneNumber){
                $scope.aa1_form1.respondentInfo.businessAddress.phoneNumber = $scope.aa1_form1.respondentInfo.businessAddress.phoneNumber.substring(2);
            }
            
            if($scope.aa1_form1.claimantInfo.businessAddress.faxNumber){
                $scope.aa1_form1.claimantInfo.businessAddress.faxNumber = $scope.aa1_form1.claimantInfo.businessAddress.faxNumber.substring(3);
            }
             if($scope.aa1_form1.claimantInfo.businessAddress.phoneNumber){
                $scope.aa1_form1.claimantInfo.businessAddress.phoneNumber = $scope.aa1_form1.claimantInfo.businessAddress.phoneNumber.substring(2);
            }
            
            if($scope.aa1_form1.respondentInfo.lawFirmDto){
                if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber){
                    $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                }
                if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
                    $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                }
                if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress){
                	 if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
                    	$scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                	}
                	if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
                   		 $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
               		}
                }
               
            } 
            if($scope.aa1_form1.claimantInfo.lawFirmDto){
            	if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber){
                    $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                }
                 if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber){
                    $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                }
                if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress){
                	if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber){
	                    $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
	                }
	                if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber){
	                    $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
	                }
                }
            }
            if($scope.aa1_form1.regulationInfo){
            	if($scope.aa1_form1.regulationInfo.ownerAddress){
            		if($scope.aa1_form1.regulationInfo.ownerAddress.faxNumber){
            			$scope.aa1_form1.regulationInfo.ownerAddress.faxNumber = $scope.aa1_form1.regulationInfo.ownerAddress.faxNumber.substring(3);
            		}
            		if($scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber){
            			$scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber = $scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber.substring(2);
            		}
            	}
            	if($scope.aa1_form1.regulationInfo.principalAddress){
            		if($scope.aa1_form1.regulationInfo.principalAddress.faxNumber){
            			$scope.aa1_form1.regulationInfo.principalAddress.faxNumber = $scope.aa1_form1.regulationInfo.principalAddress.faxNumber.substring(3);
            		}
            		if($scope.aa1_form1.regulationInfo.principalAddress.phoneNumber){
            			$scope.aa1_form1.regulationInfo.principalAddress.phoneNumber = $scope.aa1_form1.regulationInfo.principalAddress.phoneNumber.substring(2);
            		}
            	}
            }

			$scope.aa1FormOriginal= angular.copy($scope.aa1_form1);
		}

		function loginSupportingDocumentLoad(documents){
			var documentsLen = documents.length;
			for(var i =0; i < documentsLen; i++){
				if(documents[i].name == "Relevant Contractual Terms and Conditions"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload1 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload1_name = fileName;
						$scope.termsUploadPath = documents[i].fileLocation;
						$scope.termsUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.termsUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Payment Claim"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload2 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload2_name = fileName;
						$scope.paymentClaimUploadPath = documents[i].fileLocation;
						$scope.paymentClaimUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.paymentClaimUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Payment Response Received"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload3 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload3_name = fileName;
						$scope.paymentResponseUploadPath = documents[i].fileLocation;
						$scope.paymentResponseUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.paymentResponseUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Notice of Intention to Apply for Adjudication"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload4 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload4_name = fileName;
						$scope.intentionNoticeUploadPath = documents[i].fileLocation;
						$scope.intentionNoticeUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.intentionNoticeUploadPathStatus = true;
					}
				}
				if(documents[i].name == "Other Relevant Document(s)"){
					if(documents[i].fileLocation){
						$scope.aa1_form1.suport_upload5 = documents[i].id;
						var location = documents[i].fileLocation;
						var fileName = location.split("\\");
						var pathLen = fileName.length;
						fileName = fileName[pathLen-1];
						$scope.aa1_form1.suport_upload5_name = fileName;
						$scope.otherDocUploadPath = documents[i].fileLocation;
						$scope.otherDocUploadUrl = smcConfig.services.DownloadSupportingDocument.url+documents[i].id;
						$scope.aa1_form1.suport_upload5_ref_name = documents[i].documentDescription;
						$scope.otherDocUploadPathStatus = true;
					}
				}
			}
		}

        //Claimant Click Actions
		$scope.cliamentTypeClick = function(){
			$scope.aa1_form1.claimantInfo.applicantUidValue = undefined;
			$scope.aa1_form1.claimantInfo.gender = undefined;
			if($scope.aa1_form1.claimantInfo.caseMemberRoleType == "Individual"){
				$scope.claiamentStatus = true;
				$scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
				$scope.uenOrnricLabel = "NRIC/Passport Number";
				$scope.uenOrnric = "Enter your NRIC / Passport No.";
			} else {
				$scope.claiamentStatus = false;
				$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
				$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnric = "Enter the organisation’s UEN";
			}
		}
		$scope.cliamentServiceAddressClick = function(){

			if($scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress == false){
				$scope.claiamentServiceAddressStatus = true;
			} else {
				$scope.claiamentServiceAddressStatus = false;
			}
		}
		$scope.cliamentLegallyRepresentedClick = function(){

			cliamentLegallyRepresentedClick();
		}
		function cliamentLegallyRepresentedClick(){
			if($scope.aa1_form1.claimantInfo.isLegallyRepresented == "Yes"){
				$scope.claiamentLawFormDetailStatus = true;
				$scope.claimentLegallyRepresentStatus = false;
			} else {
				$scope.claiamentLawFormDetailStatus = false;
				$scope.claimentLegallyRepresentStatus = true;
			}
		}
		$scope.cliamentLawyerServiceAddressClick = function(){

			if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress == false){
				$scope.claiamentLawyerServiceAddressStatus = true;
			} else {
				$scope.claiamentLawyerServiceAddressStatus = false;
			}
		}

		//Claimant Load Law firm details on selecting law firm and reset
		$scope.loadClaimantLawFirmDetails = function(data){
			console.log(data);
			if($scope.aa1_form1.claimantInfo.lawFirmDto == undefined){
				$scope.aa1_form1.claimantInfo.lawFirmDto = {}
			}
			if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress == undefined){
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress = {};
			}
			if(data){
				if(data.name == "Others"){
					$scope.aa1_form1.claimantInfo.lawFirmDto.name = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4 = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = undefined;
					$scope.claimantLawFirmStatus = false;
				} else {
					$scope.claimantLawFirmStatus = true;
					$scope.aa1_form1.claimantInfo.lawFirmDto.name = data.name;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
					$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
				}
			} else {
				$scope.claimantLawFirmStatus = true;
				$scope.aa1_form1.claimantInfo.lawFirmDto.name = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4 = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
				$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber = undefined;
			}
		}



		//Respondent Click Actions
		$scope.respondentTypeClick = function(){
			$scope.aa1_form1.respondentInfo.applicantUidValue = undefined;
			$scope.aa1_form1.respondentInfo.gender = undefined;
			if($scope.aa1_form1.respondentInfo.caseMemberRoleType == "Individual"){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			} else {
				$scope.respondentIndivStatus = false;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
			}
		}

		$scope.respondentServiceAddressClick = function(){

			if($scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress == false){
				$scope.respondentServiceAddressStatus = true;
			} else {
				$scope.respondentServiceAddressStatus = false;
			}
		}

		$scope.respondentLegallyRepresentedClick = function(){

			respondentLegallyRepresentedClick();
		}
		function respondentLegallyRepresentedClick(){
			if($scope.aa1_form1.respondentInfo.isLegallyRepresented == "Yes"){
				$scope.respondentLawFormDetailStatus = true;
				$scope.respondentLegallyRepresentStatus = false;
			} else if ($scope.aa1_form1.respondentInfo.isLegallyRepresented == "No"){
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = true;
			} else {
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = false;
			}
		}
		$scope.respondentLawyerServiceAddressClick = function(){

			if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress == false){
				$scope.respondentLawyerServiceAddressStatus = true;
			} else {
				$scope.respondentLawyerServiceAddressStatus = false;
			}
		}

		//Respondent Load Law firm details on selecting law firm and reset
		$scope.loadRespondantLawFirmDetails = function(data){
			if($scope.aa1_form1.respondentInfo.lawFirmDto == undefined){
				$scope.aa1_form1.respondentInfo.lawFirmDto = {}
			}
			if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress == undefined){
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress = {};
			}
			console.log(data);
			if(data){
				if(data.name == "Others"){
					$scope.aa1_form1.respondentInfo.lawFirmDto.name = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
					$scope.respondantLawFirmStatus = false;
				} else {
					$scope.aa1_form1.respondentInfo.lawFirmDto.name = data.name;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
					$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
					$scope.respondantLawFirmStatus = true;
				}
			} else {
				$scope.aa1_form1.respondentInfo.lawFirmDto.name = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
				$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
				$scope.respondantLawFirmStatus = true;
			}
		}



		$scope.contractTypeClick = function(){
			var contactTypes = JSON.parse($scope.aa1_form1.contractInfo.contractType);
			if(contactTypes.type == "Construction"){
				$scope.natureOfDistributeStatus = true;
			} else {
				$scope.aa1_form1.contractInfo.natureOfDispute = undefined;
				$scope.natureOfDistributeStatus = false;
			}
		}
		$scope.paymentInfoFromDateClick = function(){
			var fromDate = $scope.aa1_form1.paymentInfo.referencePeriodFrom;
			var toDate = $scope.aa1_form1.paymentInfo.referencePeriodTo;
			$scope.toDateMinLimit = fromDate;
			$( "#referencePeriodTo" ).datepicker( "option", "minDate",fromDate );
			if((new Date(fromDate)) > (new Date(toDate))){
				$scope.aa1_form1.paymentInfo.referencePeriodTo = undefined;
			}
		}
		$scope.interestRateOfLatePaymentClick = function(){

			if($scope.aa1_form1.paymentInfo.latePaymentInterest == "yes"){
				$scope.interestRateOfLatePaymentStatus = true;
			} else {
				$scope.interestRateOfLatePaymentStatus = false;
			}
		}

		$scope.onlineFormSubmissionClick = function(){
			if($scope.aa1_form1.caseDto.isOnline == "Online"){
				$scope.onlineFormSubmissionStatus = true;
			} else {
				$scope.onlineFormSubmissionStatus = false;
			}
		}


		/*Document Uploads*/

		$scope.termsUpload = function(event){

			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.termsUploadPathStatus = false;
				$scope.termsErrorStatus = false;
				if ( file.size < 5242881 ){
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload1_name = fileName;
						angular.element("#suport_upload1_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload1_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.termsUploadPath = data.result;
								$scope.termsUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload1_name").addClass("error");
						$scope.termsErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element("#suport_upload1_name").addClass("error");
					$scope.termsErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.termsUploadRemove = function(){
			$scope.aa1_form1.suport_upload1 = undefined;
			$scope.aa1_form1.suport_upload1_name = undefined;
			$scope.termsUploadPath = undefined;
			angular.element("#suport_upload1_name").val("");
			angular.element("#suport_upload1").val("");
			$scope.termsUploadPathStatus = false;
		}

		$scope.paymentClaimUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.paymentClaimErrorStatus = false;
				$scope.paymentClaimUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload2_name = fileName;
						angular.element("#suport_upload2_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload2_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.paymentClaimUploadPath = data.result;
								$scope.paymentClaimUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload2_name").addClass("error");
						$scope.paymentClaimErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element("#suport_upload2_name").addClass("error");
					$scope.paymentClaimErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.paymentClaimUploadRemove = function(){
			$scope.aa1_form1.suport_upload2 = undefined;
			$scope.aa1_form1.suport_upload2_name = undefined;
			$scope.paymentClaimUploadPath = undefined;
			angular.element("#suport_upload2_name").val("");
			angular.element("#suport_upload2").val("");
			$scope.paymentClaimUploadPathStatus = false;
		}

		$scope.paymentResponseUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.paymentResponseErrorStatus = false;
				$scope.paymentResponseUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload3_name = fileName;
						angular.element("#suport_upload3_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload3_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.paymentResponseUploadPath = data.result;
								$scope.paymentResponseUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload3_name").addClass("error");
						$scope.paymentResponseErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element("#suport_upload3_name").addClass("error");
					$scope.paymentResponseErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.paymentResponseUploadRemove = function(){
			$scope.aa1_form1.suport_upload3 = undefined;
			$scope.aa1_form1.suport_upload3_name = undefined;
			$scope.paymentResponseUploadPath = undefined;
			angular.element("#suport_upload3_name").val("");
			angular.element("#suport_upload3").val("");
			$scope.paymentResponseUploadPathStatus = false;
		}

		$scope.intentionNoticeUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.intentionNoticeErrorStatus = false;
				$scope.intentionNoticeUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload4_name = fileName;
						angular.element("#suport_upload4_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload4_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.intentionNoticeUploadPath = data.result;
								$scope.intentionNoticeUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload4_name").addClass("error");
						$scope.intentionNoticeErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element("#suport_upload4_name").addClass("error");
					$scope.intentionNoticeErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.intentionNoticeUploadRemove = function(){
			$scope.aa1_form1.suport_upload4 = undefined;
			$scope.aa1_form1.suport_upload4_name = undefined;
			$scope.intentionNoticeUploadPath = undefined;
			angular.element("#suport_upload4_name").val("");
			angular.element("#suport_upload4").val("");
			$scope.intentionNoticeUploadPathStatus = false;
		}

		$scope.otherDocUpload = function(event){
			console.log(event);
			var file = event.target.files[0];
			var fileName = file.name;
			if(fileName){
				$scope.otherDocErrorStatus = false;
				$scope.otherDocUploadPathStatus = false;
				if ( file.size < 5242881 ) {
					if(validateUploadFileExtention(fileName)){
						$scope.aa1_form1.suport_upload5_name = fileName;
						angular.element("#suport_upload5_name").val(fileName);
						if(fileName){
							angular.element("#suport_upload5_name").removeClass("error");
							var fd= new FormData();
							fd.append('file',file);
							httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
								console.log(data);
								$scope.otherDocUploadPath = data.result;
								$scope.otherDocUploadPathStatus = true;
							});
						}
					} else {
						angular.element("#suport_upload5_name").addClass("error");
						$scope.otherDocErrorStatus = true;
						var allowedExt = $scope.fileUploadTypes;
						var wrongFile ="You are allowed to upload only " + allowedExt.toString();
						NotifyFactory.log('error', wrongFile)
					}
				} else {
					angular.element("#suport_upload5_name").addClass("error");
					$scope.otherDocErrorStatus = true;
					NotifyFactory.log("error","Maximum allowed file size should be 5MB")
				}
			}
		}
		$scope.otherDocUploadRemove = function(){
			$scope.aa1_form1.suport_upload5 = undefined;
			$scope.aa1_form1.suport_upload5_name = undefined;
			$scope.otherDocUploadPath = undefined;
			angular.element("#suport_upload5_name").val("");
			angular.element("#suport_upload5").val("");
			$scope.otherDocUploadPathStatus = false;
		}

		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if(allowedExt[i] == ext){
					return true;
				}
			}
		}


		$scope.confirmSubmit = function(){
			DataService.get('GetConfirmMessageAAform').then(function(data){
				$scope.displayMessage = data.result.displayMessage;
			});
			angular.element(".overlay").css("display","block");
			angular.element(".form-submitt-confirm").css("display","block");
		}

		$scope.cancelSubmit = function(){
			angular.element(".overlay").css("display","none");
			angular.element(".form-submitt-confirm").css("display","none");
		}

		$scope.formAA1UpdateSubmit = function(form){

			$scope.initialComparison= angular.equals($scope.aa1_form1,$scope.aa1FormOriginal);
  			$scope.dataHasChanged= angular.copy($scope.initialComparison);
  			console.log($scope.aa1_form1);
  			console.log($scope.aa1FormOriginal);
  			console.log($scope.dataHasChanged);
  			


			
			angular.element(".form-submitt-confirm").css("display","none");
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");

			$scope.isSubmitted = true;
			//Validate Claimant Details are entered
			var claimentInvalid = angular.element("#updateAAform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;
			var errorMsgCount = angular.element("#updateAAform .help-block:visible").length;
			if(claimentInvalidCount > 0 || errorMsgCount > 0){
				angular.element("#updateAAform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.submitQuery = buildQurey();
				if($scope.submitQuery){
					DataService.post('AAformAuditTrail',$scope.submitQuery).then(function(data){
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						console.log(data);
						if(data.status == "SUCCESS"){
							$scope.isPreviewClicked = false;
							$rootScope.tempCaseNumber = data.result.tempCaseNumber;
							$rootScope.saveResponseDetails = data.result;
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = true;
							$scope.onlineSaveStatus = false;
							$scope.onlineFormUpdateStatus = true;
						}
	        		});
				}
				
			}
		}
		$scope.backToForm = function(){
			$scope.onlineFormUpdateStatus = false;
		}

		

		

		function buildQurey(){
			var claimantInfoQueryNull = claimantInfoQuery();
			var claimantInfoQueryVar = removeNulls(claimantInfoQueryNull);
			var respondentInfoQueryNull = respondentInfoQuery();
			var respondentInfoQueryVar = removeNulls(respondentInfoQueryNull);
			var regulationInfoQueryNull = regulationInfoQuery();
			var regulationInfoQueryVar = removeNulls(regulationInfoQueryNull);
			var contractInfoQueryNull = contractInfoQuery();
			var contractInfoQueryVar = removeNulls(contractInfoQueryNull);
			var paymentInfoQueryNull = paymentInfoQuery();
			var paymentInfoQueryVar = removeNulls(paymentInfoQueryNull);
			if($scope.aa1_form1.caseDto.isOnline == "Online"){
				var supportingDocumentsQueryVar = supportingDocumentsQuery();
			} else {
				var supportingDocumentsQueryVar = null;
			}
			var caseDtoQueryNull = caseDtoQuery();
			var caseDtoQueryVar = removeNulls(caseDtoQueryNull);
			var query = {
				"formType":"AAForm",
				"smcOfficerId":$cookies.get('memberId'),
				"caseNumber":$scope.aa1FormOriginal.tempCaseNumber,
				"claimantInfo":claimantInfoQueryVar,
				"respondentInfo":respondentInfoQueryVar,
				"regulationInfo":regulationInfoQueryVar,
				"contractInfo":contractInfoQueryVar,
				"paymentInfo":paymentInfoQueryVar,
				"supportingDocuments":supportingDocumentsQueryVar,
				"caseDto": caseDtoQueryVar
			}
			return query;
		}
		function claimantInfoQuery(){
			var query = null;
			if($scope.aa1_form1.claimantInfo){
				var query = {};
				var caseMemberRoleType = $scope.aa1_form1.claimantInfo.caseMemberRoleType;
				var applicantUidValue = $scope.aa1_form1.claimantInfo.applicantUidValue;
				var memberName = $scope.aa1_form1.claimantInfo.memberName;
				$rootScope.claimantName = $scope.aa1_form1.claimantInfo.memberName;
				var gender = $scope.aa1_form1.claimantInfo.gender;
				var email = $scope.aa1_form1.claimantInfo.email;
				var authRepresentative = $scope.aa1_form1.claimantInfo.authRepresentative;
				var authRepDesignation = $scope.aa1_form1.claimantInfo.authRepDesignation;
				var payeeName = $scope.aa1_form1.claimantInfo.payeeName;
				var isLegallyRepresented = $scope.aa1_form1.claimantInfo.isLegallyRepresented;
				var businessAddressNull = claimantBusinessAddressQuery();
				var businessAddress = removeNulls(businessAddressNull);
				
				if(isLegallyRepresented == "Yes"){
					var lawFirmDtoNull = claimantlawFirmDtoQuery();
					var lawFirmDto = removeNulls(lawFirmDtoNull);
					var serviceAddress = null; 
				} else{
					var lawFirmDto = null;
					var serviceAddressNull = claimantServiceAddressQuery();
					var serviceAddress = removeNulls(serviceAddressNull);
				}
				var query = { 
					"caseMemberRoleType":compareSetNull(caseMemberRoleType,$scope.aa1FormOriginal.claimantInfo.caseMemberRoleType),
					"applicantUidValue":compareSetNull(applicantUidValue,$scope.aa1FormOriginal.claimantInfo.applicantUidValue),
				    "memberName":compareSetNull(memberName,$scope.aa1FormOriginal.claimantInfo.memberName),
				    "gender":compareSetNull(gender,$scope.aa1FormOriginal.claimantInfo.gender),
				    "businessAddress":businessAddress,
					"serviceAddress":serviceAddress,
				    "email":compareSetNull(email,$scope.aa1FormOriginal.claimantInfo.email),
				    "authRepresentative":compareSetNull(authRepresentative,$scope.aa1FormOriginal.claimantInfo.authRepresentative),
				    "authRepDesignation":compareSetNull(authRepDesignation,$scope.aa1FormOriginal.claimantInfo.authRepDesignation),
				    "payeeName":compareSetNull(payeeName,$scope.aa1FormOriginal.claimantInfo.payeeName),
				    "isLegallyRepresented":isLegallyRepresented,
				    "lawFirmDto":lawFirmDto
				};
			}
			return query;
		}
		function claimantBusinessAddressQuery(){
			var query = null;
			if($scope.aa1_form1.claimantInfo.businessAddress){
				var query = {};
				var address1 = $scope.aa1_form1.claimantInfo.businessAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.businessAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.businessAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.businessAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.businessAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.businessAddress.faxNumber;
				}
				var isLegallyRepresented = $scope.aa1_form1.claimantInfo.isLegallyRepresented;

				if($scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress;
				} else if (isLegallyRepresented == "Yes") {
					var isServiceAddress = null;
				} else {
					var isServiceAddress = false;
				}
				var query = { 
			        "address1":compareSetNull(address1,$scope.aa1FormOriginal.claimantInfo.businessAddress.address1),
					"address2":compareSetNull(address2,$scope.aa1FormOriginal.claimantInfo.businessAddress.address2),
					"address3":compareSetNull(address3,$scope.aa1FormOriginal.claimantInfo.businessAddress.address3),
					"address4":compareSetNull(address4,$scope.aa1FormOriginal.claimantInfo.businessAddress.address4),
			        "postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.claimantInfo.businessAddress.postalCode),
			        "phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.claimantInfo.businessAddress.phoneNumber),
			        "faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.claimantInfo.businessAddress.faxNumber),
			        "isServiceAddress":compareSetNull(isServiceAddress,$scope.aa1FormOriginal.claimantInfo.businessAddress.isServiceAddress)
				};
			}
			return query;
		}
		function claimantServiceAddressQuery(){
			var query = null;
			var claimant_service_address_status = $scope.aa1_form1.claimantInfo.businessAddress.isServiceAddress;
			if(!claimant_service_address_status && $scope.aa1_form1.claimantInfo.serviceAddress != undefined){
				var query = {};
				var address1 = $scope.aa1_form1.claimantInfo.serviceAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.serviceAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.serviceAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.serviceAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.serviceAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.serviceAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.serviceAddress.faxNumber;
				}
				if($scope.aa1FormOriginal.claimantInfo.serviceAddress){
					var query = { 
				        "address1":compareSetNull(address1,$scope.aa1FormOriginal.claimantInfo.serviceAddress.address1),
						"address2":compareSetNull(address2,$scope.aa1FormOriginal.claimantInfo.serviceAddress.address2),
						"address3":compareSetNull(address3,$scope.aa1FormOriginal.claimantInfo.serviceAddress.address3),
						"address4":compareSetNull(address4,$scope.aa1FormOriginal.claimantInfo.serviceAddress.address4),
				        "postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.claimantInfo.serviceAddress.postalCode),
				        "phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.claimantInfo.serviceAddress.phoneNumber),
				        "faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.claimantInfo.serviceAddress.faxNumber)
					};
				}else{
					var query = { 
				        "address1":address1,
						"address2":address2,
						"address3":address3,
						"address4":address4,
				        "postalCode":postalCode,
				        "phoneNumber":phoneNumber,
				        "faxNumber":faxNumber,
					};
				}
					
			};
			return query;
		}
		function claimantlawFirmDtoQuery(){
			var query = null;
			if($scope.aa1_form1.claimantInfo.lawFirmDto){
				var query = {};
				var respresentative_lawfirmId = $scope.aa1_form1.claimantInfo.lawFirmDto.id;
				respresentative_lawfirmId = respresentative_lawfirmId.id;
				var name = $scope.aa1_form1.claimantInfo.lawFirmDto.name;
				var businessAddressNull = claimantlawFirmBusinessAddressQuery();
				var businessAddress = removeNulls(businessAddressNull);
				var serviceAddressNull = claimantlawFirmServiceAddressQuery();
				var serviceAddress = removeNulls(serviceAddressNull);
				var lawyerDetailsNull = claimantlawyersDetailsQuery();
				var lawyerDetails = removeNulls(lawyerDetailsNull);
				var referenceNumber = $scope.aa1_form1.claimantInfo.lawFirmDto.referenceNumber;
				if($scope.aa1FormOriginal.claimantInfo.lawFirmDto){
					var query = { 
						"id":compareSetNull(respresentative_lawfirmId,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.id.id),
				        "name":compareSetNull(name,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.name),
						"businessAddress":businessAddress,
				        "serviceAddress":serviceAddress,
				        "lawyerDetails":lawyerDetails,
						"referenceNumber":compareSetNull(referenceNumber,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.referenceNumber)
					};
				}else{
					var query = { 
						"id":undefinedSetNull(respresentative_lawfirmId),
				        "name":undefinedSetNull(name),
						"businessAddress":businessAddress,
				        "serviceAddress":serviceAddress,
				        "lawyerDetails":lawyerDetails,
						"referenceNumber":undefinedSetNull(referenceNumber)
					};
				}
				
			}
			return query;
		}
		function claimantlawFirmBusinessAddressQuery(){
			var query = null;
			if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress){
				var query = {};
				var isServiceAddress = false;
				var address1 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.faxNumber;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress;
				}
				if($scope.aa1FormOriginal.claimantInfo.lawFirmDto){
					var query = { 
				        "address1":compareSetNull(address1,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.address1),
						"address2":compareSetNull(address2,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.address2),
						"address3":compareSetNull(address3,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.address3),
						"address4":compareSetNull(address4,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.address4),
				        "postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.postalCode),
				        "phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.phoneNumber),
				        "faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.faxNumber),
				        "isServiceAddress":compareSetNull(isServiceAddress,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.businessAddress.isServiceAddress)
					};
				}else{
					var query = {
						"address1":undefinedSetNull(address1),
						"address2":undefinedSetNull(address2),
						"address3":undefinedSetNull(address3),
						"address4":undefinedSetNull(address4),
				        "postalCode":undefinedSetNull(postalCode),
				        "phoneNumber":undefinedSetNull(phoneNumber),
				        "faxNumber":undefinedSetNull(faxNumber),
				        "isServiceAddress":undefinedSetNull(isServiceAddress)
					}
				}
				
			}
			return query;
		}
		function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
		function claimantlawFirmServiceAddressQuery(){
			var query = null;
			var claimant_lawyer_service_address_status = $scope.aa1_form1.claimantInfo.lawFirmDto.businessAddress.isServiceAddress;
			if(!claimant_lawyer_service_address_status){
				var query = {};
				var address1 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address1;
				var address2 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address2;
				var address3 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address3;
				var address4 = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.address4;
				var postalCode = $scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.postalCode;
				if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.phoneNumber;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.claimantInfo.lawFirmDto.serviceAddress.faxNumber;
				}
				var query = { 
			        "address1":compareSetNull(address1,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.address1),
					"address2":compareSetNull(address2,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.address2),
					"address3":compareSetNull(address3,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.address3),
					"address4":compareSetNull(address4,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.address4),
			        "postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.postalCode),
			        "phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.phoneNumber),
			        "faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.serviceAddress.faxNumber)
				};
			}
			return query;
		}
		function claimantlawyersDetailsQuery(){
			var query = null;
			if($scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails){
				var query = [];
				var respresentative_l2name = "";
				var respresentative_l3name = "";
				var respresentative_lname = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[0].lawyerName;
				var respresentative_lemail = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[0].email;
				if($scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[1]){
					var respresentative_l2name = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[1].lawyerName;
					var respresentative_l2email = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[1].email;
				}
				if($scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[2]){
					var respresentative_l3name = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[2].lawyerName;
					var respresentative_l3email = $scope.aa1_form1.claimantInfo.lawFirmDto.lawyerDetails[2].email;
				}
				if(respresentative_lname && respresentative_lemail){
					if($scope.aa1FormOriginal.claimantInfo.lawFirmDto){
						var lawyer1 = { 
							"lawyerName":compareSetNull(respresentative_lname,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.lawyerDetails[0].lawyerName),
							"email":compareSetNull(respresentative_lemail,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.lawyerDetails[0].email),
							"index":0
						};
					}  
					else{
						var lawyer1 = { 
							"lawyerName":undefinedSetNull(respresentative_lname),
							"email":undefinedSetNull(respresentative_lemail),
							"index":0
						};
					}
						   
					query.push(lawyer1);
				}
				if(respresentative_l2name && respresentative_l2email){
					if($scope.aa1FormOriginal.claimantInfo.lawFirmDto){
						var lawyer2 = { 
							"lawyerName":compareSetNull(respresentative_l2name,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.lawyerDetails[1].lawyerName),
							"email":compareSetNull(respresentative_l2email,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.lawyerDetails[1].email),
							"index":0
						};
					}  
					else{
						var lawyer2 = { 
							"lawyerName":undefinedSetNull(respresentative_l2name),
							"email":undefinedSetNull(respresentative_l2email),
							"index":0
						};
					}
					query.push(lawyer2);
				}
				if(respresentative_l3name && respresentative_l3email){
					if($scope.aa1FormOriginal.claimantInfo.lawFirmDto){
						var lawyer3 = { 
							"lawyerName":compareSetNull(respresentative_l3name,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.lawyerDetails[2].lawyerName),
							"email":compareSetNull(respresentative_l3email,$scope.aa1FormOriginal.claimantInfo.lawFirmDto.lawyerDetails[2].email),
							"index":0
						};
					}  
					else{
						var lawyer3 = { 
							"lawyerName":undefinedSetNull(respresentative_l3name),
							"email":undefinedSetNull(respresentative_l3email),
							"index":0
						};
					}
					query.push(lawyer3);
				}
			}
			return query;
		}


		function respondentInfoQuery(){
			var query = null;
			if($scope.aa1_form1.respondentInfo){
				var query = {};
				var caseMemberRoleType = $scope.aa1_form1.respondentInfo.caseMemberRoleType;
				var applicantUidValue = $scope.aa1_form1.respondentInfo.applicantUidValue;
				var memberName = $scope.aa1_form1.respondentInfo.memberName;
				var gender = $scope.aa1_form1.respondentInfo.gender;
				var email = $scope.aa1_form1.respondentInfo.email;
				var authRepresentative = $scope.aa1_form1.respondentInfo.authRepresentative;
				var authRepDesignation = $scope.aa1_form1.respondentInfo.authRepDesignation;
				var isLegallyRepresented = $scope.aa1_form1.respondentInfo.isLegallyRepresented;
				var businessAddressNull = respondentBusinessAddressQuery();
				var businessAddress = removeNulls(businessAddressNull);
				
				
				if(isLegallyRepresented == "Yes"){ 
					var lawFirmDtoNull = respondentlawFirmDtoQuery(); 
					var lawFirmDto = removeNulls(lawFirmDtoNull);
					var serviceAddress = null; 
				} else if(isLegallyRepresented == "No"){
					var serviceAddressNull = respondentServiceAddressQuery();
					var serviceAddress = removeNulls(serviceAddressNull);
					var lawFirmDto = null;
				} else {var serviceAddress = null; var lawFirmDto = null;}
				var query = {
					"caseMemberRoleType":compareSetNull(caseMemberRoleType,$scope.aa1FormOriginal.respondentInfo.caseMemberRoleType),
					"applicantUidValue":compareSetNull(applicantUidValue,$scope.aa1FormOriginal.respondentInfo.applicantUidValue),
					"memberName":compareSetNull(memberName,$scope.aa1FormOriginal.respondentInfo.memberName),
					"gender":compareSetNull(gender,$scope.aa1FormOriginal.respondentInfo.gender),
					"businessAddress":businessAddress,
					"serviceAddress":serviceAddress,
					"email":compareSetNull(email,$scope.aa1FormOriginal.respondentInfo.email),
					"authRepresentative":compareSetNull(authRepresentative,$scope.aa1FormOriginal.respondentInfo.authRepresentative),
					"authRepDesignation":compareSetNull(authRepDesignation,$scope.aa1FormOriginal.respondentInfo.authRepDesignation),
					"isLegallyRepresented":isLegallyRepresented,
					"lawFirmDto":lawFirmDto
				};
			}
			return query;
		}
		function respondentBusinessAddressQuery(){
			var query = null;
			if ($scope.aa1_form1.respondentInfo.businessAddress){
				var query = {};
				var address1 = $scope.aa1_form1.respondentInfo.businessAddress.address1;
				var address2 = $scope.aa1_form1.respondentInfo.businessAddress.address2;
				var address3 = $scope.aa1_form1.respondentInfo.businessAddress.address3;
				var address4 = $scope.aa1_form1.respondentInfo.businessAddress.address4;
				var postalCode = $scope.aa1_form1.respondentInfo.businessAddress.postalCode;
				if($scope.aa1_form1.respondentInfo.businessAddress.phoneNumber){
					var phoneNumber =  '65'+$scope.aa1_form1.respondentInfo.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.respondentInfo.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.businessAddress.faxNumber;
				}
				var isServiceAddress = $scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress;
				if($scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress;
				} else {
					var isServiceAddress = false;
				}
				var query = {
					"address1":compareSetNull(address1,$scope.aa1FormOriginal.respondentInfo.businessAddress.address1),
					"address2":compareSetNull(address2,$scope.aa1FormOriginal.respondentInfo.businessAddress.address2),
					"address3":compareSetNull(address3,$scope.aa1FormOriginal.respondentInfo.businessAddress.address3),
					"address4":compareSetNull(address4,$scope.aa1FormOriginal.respondentInfo.businessAddress.address4),
					"postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.respondentInfo.businessAddress.postalCode),
					"phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.respondentInfo.businessAddress.phoneNumber),
					"faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.respondentInfo.businessAddress.faxNumber),
					"isServiceAddress":compareSetNull(isServiceAddress,$scope.aa1FormOriginal.respondentInfo.businessAddress.isServiceAddress)
				};
			}
			return query;
		}
		function respondentServiceAddressQuery(){
			var query = null;
			if($scope.aa1_form1.respondentInfo.businessAddress){
				var isServiceAddress = $scope.aa1_form1.respondentInfo.businessAddress.isServiceAddress;
				var isLegallyRepresented = $scope.aa1_form1.respondentInfo.isLegallyRepresented;
				if(!isServiceAddress && isLegallyRepresented == "No" && $scope.aa1_form1.respondentInfo.serviceAddress != undefined){
					var query = {};
					var address1 = $scope.aa1_form1.respondentInfo.serviceAddress.address1;
					var address2 = $scope.aa1_form1.respondentInfo.serviceAddress.address2;
					var address3 = $scope.aa1_form1.respondentInfo.serviceAddress.address3;
					var address4 = $scope.aa1_form1.respondentInfo.serviceAddress.address4;
					var postalCode = $scope.aa1_form1.respondentInfo.serviceAddress.postalCode;
					if($scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber){
						var phoneNumber = '65'+$scope.aa1_form1.respondentInfo.serviceAddress.phoneNumber;
					}
					if($scope.aa1_form1.respondentInfo.serviceAddress.faxNumber){
						var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.serviceAddress.faxNumber;
					}
					var query = {
						"address1":compareSetNull(address1,$scope.aa1FormOriginal.respondentInfo.serviceAddress.address1),
						"address2":compareSetNull(address2,$scope.aa1FormOriginal.respondentInfo.serviceAddress.address2),
						"address3":compareSetNull(address3,$scope.aa1FormOriginal.respondentInfo.serviceAddress.address3),
						"address4":compareSetNull(address4,$scope.aa1FormOriginal.respondentInfo.serviceAddress.address4),
						"postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.respondentInfo.serviceAddress.postalCode),
						"phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.respondentInfo.serviceAddress.phoneNumber),
						"faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.respondentInfo.serviceAddress.faxNumber)
					};
				}
			}
			return query;
		}
		function respondentlawFirmDtoQuery(){
			var query = null;
			if($scope.aa1_form1.respondentInfo.lawFirmDto){
				var query = {};
				if($scope.aa1_form1.respondentInfo.lawFirmDto.id){
					var lawerAddressId = $scope.aa1_form1.respondentInfo.lawFirmDto.id;
					lawerAddressId = lawerAddressId.id;
				} else {
					var lawerAddressId = undefined;
				}
				var name = $scope.aa1_form1.respondentInfo.lawFirmDto.name;
				var businessAddressNull = respondentlawFirmBusinessAddressQuery();
				var businessAddress = removeNulls(businessAddressNull);
				var serviceAddressNull = respondentlawFirmServiceAddressQuery();
				var serviceAddress = removeNulls(serviceAddressNull);
				var lawyerDetailsNull = respondentlawyersDetailsQuery();
				var lawyerDetails = removeNulls(lawyerDetailsNull);
				var referenceNumber = $scope.aa1_form1.respondentInfo.lawFirmDto.referenceNumber;
				if($scope.aa1FormOriginal.respondentInfo.lawFirmDto){
					var query = {
						"id":compareSetNull(lawerAddressId,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.id.id),
						"name":compareSetNull(name,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.name),
						"businessAddress":businessAddress,
				        "serviceAddress":serviceAddress,
						"lawyerDetails":lawyerDetails,
						"referenceNumber":compareSetNull(referenceNumber,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.referenceNumber)
					};
				}else{
					var query = {
						"id":lawerAddressId,
						"name":name,
						"businessAddress":businessAddress,
				        "serviceAddress":serviceAddress,
						"lawyerDetails":lawyerDetails,
						"referenceNumber":referenceNumber,
					};
				}
				
			}
			return query;
		}
		function respondentlawFirmBusinessAddressQuery(){
			var query = null;
			if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress){
				var query = {};
				var address1 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address1;
				var address2 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address2;
				var address3 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address3;
				var address4 = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.address4;
				var postalCode = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber;
				}
				var isServiceAddress = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
				} else {
					var isServiceAddress = false;
				}
				if($scope.aa1FormOriginal.respondentInfo.lawFirmDto){
					var query = { 
				        "address1":compareSetNull(address1,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.address1),
						"address2":compareSetNull(address2,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.address2),
						"address3":compareSetNull(address3,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.address3),
						"address4":compareSetNull(address4,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.address4),
				        "postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.postalCode),
				        "phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.phoneNumber),
				        "faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.faxNumber),
				        "isServiceAddress":compareSetNull(isServiceAddress,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.businessAddress.isServiceAddress)
					};
				}else{
					var query = { 
				        "address1":address1,
						"address2":address2,
						"address3":address3,
						"address4":address4,
				        "postalCode":postalCode,
				        "phoneNumber":phoneNumber,
				        "faxNumber":faxNumber,
				        "isServiceAddress":isServiceAddress,
					};
				}
				
			}
			return query;
		}
		function respondentlawFirmServiceAddressQuery(){
			var query = null;
			var isServiceAddress = $scope.aa1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
			if(!isServiceAddress && $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress != undefined){
				var query = {};
				var address1 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address1;
				var address2 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address2;
				var address3 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address3;
				var address4 = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.address4;
				var postalCode = $scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.postalCode;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber;
				}
				if($scope.aa1FormOriginal.respondentInfo.lawFirmDto){
					var query = { 
				        "address1":compareSetNull(address1,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.address1),
						"address2":compareSetNull(address2,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.address2),
						"address3":compareSetNull(address3,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.address3),
						"address4":compareSetNull(address4,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.address4),
				        "postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.postalCode),
				        "phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.phoneNumber),
				        "faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.serviceAddress.faxNumber)
					};
				}else{
					var query = { 
				        "address1":address1,
						"address2":address2,
						"address3":address3,
						"address4":address4,
				        "postalCode":postalCode,
				        "phoneNumber":phoneNumber,
				        "faxNumber":faxNumber,
					};
				}
								
			}
			return query;
		}

		function respondentlawyersDetailsQuery(){
			var query = null;
			if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails){
				var query = [];
				var respondent_l2name = "";
				var respondent_l3name = "";
				var respondent_lname = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[0].lawyerName;
				var respondent_lemail = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[0].email;
				if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[1]){
					var respondent_l2name = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[1].lawyerName;
					var respondent_l2email = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[1].email;
				}
				if($scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[2]){
					var respondent_l3name = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[2].lawyerName;
					var respondent_l3email = $scope.aa1_form1.respondentInfo.lawFirmDto.lawyerDetails[2].email;
				}
				if($scope.aa1FormOriginal.respondentInfo.lawFirmDto){
					if(respondent_lname && respondent_lemail){
						var lawyer1 = {
							"lawyerName":compareSetNull(respondent_lname,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.lawyerDetails[0].lawyerName),
							"email":compareSetNull(respondent_lemail,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.lawyerDetails[0].email),
							"index":0
						};
						query.push(lawyer1);
					}
					if(respondent_l2name && respondent_l2email){
						var lawyer2 = {
							"lawyerName":compareSetNull(respondent_l2name,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.lawyerDetails[1].lawyerName),
							"email":compareSetNull(respondent_l2email,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.lawyerDetails[1].email),
							"index":1
						}
						query.push(lawyer2);
					}
					if(respondent_l3name && respondent_l3email){
						var lawyer3 = {
							"lawyerName":compareSetNull(respondent_l3name,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.lawyerDetails[2].lawyerName),
							"email":compareSetNull(respondent_l3email,$scope.aa1FormOriginal.respondentInfo.lawFirmDto.lawyerDetails[2].email),
							"index":2
						}
						query.push(lawyer3);
					}
				}else{
					if(respondent_lname && respondent_lemail){
						var lawyer1 = {
							"lawyerName":respondent_lname,
							"email":respondent_lemail,
							"index":0
						};
						query.push(lawyer1);
					}
					if(respondent_l2name && respondent_l2email){
						var lawyer2 = {
							"lawyerName":respondent_l2name,
							"email":respondent_l2email,
							"index":1
						}
						query.push(lawyer2);
					}
					if(respondent_l3name && respondent_l3email){
						var lawyer3 = {
							"lawyerName":respondent_l3name,
							"email":respondent_l3email,
							"index":2
						}
						query.push(lawyer3);
					}
				}
			}
			return query;
		}


		function regulationInfoQuery(){
			var query = null;
			if($scope.aa1_form1.regulationInfo){
				var query = {};
				var principalName = $scope.aa1_form1.regulationInfo.principalName;
				var principalContactPerson = $scope.aa1_form1.regulationInfo.principalContactPerson;
				var principalRefNumber = $scope.aa1_form1.regulationInfo.principalRefNumber;
				var principalAddressNull = principleServiceAddressQuery();
				var principalAddress = removeNulls(principalAddressNull);
				var principalEmail = $scope.aa1_form1.regulationInfo.principalEmail;
				var ownerName = $scope.aa1_form1.regulationInfo.ownerName;
				var ownerContactPerson = $scope.aa1_form1.regulationInfo.ownerContactPerson;
				var ownerRefNumber = $scope.aa1_form1.regulationInfo.ownerRefNumber;
				var ownerAddressNull = ownerServiceAddressQuery();
				var ownerAddress = removeNulls(ownerAddressNull);
				var ownerEmail = $scope.aa1_form1.regulationInfo.ownerEmail;
				if(!$scope.aa1FormOriginal.regulationInfo){
					$scope.aa1FormOriginal.regulationInfo = {};
				}
				var query = {
					"principalName":compareSetNull(principalName,$scope.aa1FormOriginal.regulationInfo.principalName),
					"principalAddress":principalAddress,
					"principalContactPerson":compareSetNull(principalContactPerson,$scope.aa1FormOriginal.regulationInfo.principalContactPerson),
					"principalRefNumber":compareSetNull(principalRefNumber,$scope.aa1FormOriginal.regulationInfo.principalRefNumber),
					"principalEmail":compareSetNull(principalEmail,$scope.aa1FormOriginal.regulationInfo.principalEmail),
					"ownerName":compareSetNull(ownerName,$scope.aa1FormOriginal.regulationInfo.ownerName),
					"ownerAddress":ownerAddress,
					"ownerContactPerson":compareSetNull(ownerContactPerson,$scope.aa1FormOriginal.regulationInfo.ownerContactPerson),
					"ownerRefNumber":compareSetNull(ownerRefNumber,$scope.aa1FormOriginal.regulationInfo.ownerRefNumber),
					"ownerEmail":compareSetNull(ownerEmail,$scope.aa1FormOriginal.regulationInfo.ownerEmail),
				};
			}
			return query;
		}
		function principleServiceAddressQuery(){
			var query = null;
			if(!$scope.aa1FormOriginal.regulationInfo){
					$scope.aa1FormOriginal.regulationInfo = {};
			} else {
				if(!$scope.aa1FormOriginal.regulationInfo.principalAddress){
					$scope.aa1FormOriginal.regulationInfo.principalAddress = {};
				}
			}
			if($scope.aa1_form1.regulationInfo.principalAddress){
				var query = {};
				var address1 = $scope.aa1_form1.regulationInfo.principalAddress.address1;
				var postalCode = $scope.aa1_form1.regulationInfo.principalAddress.postalCode;
				if($scope.aa1_form1.regulationInfo.principalAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.regulationInfo.principalAddress.phoneNumber;
				}
				if($scope.aa1_form1.regulationInfo.principalAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.regulationInfo.principalAddress.faxNumber;
				}
				var query = {
					"address1":compareSetNull(address1,$scope.aa1FormOriginal.regulationInfo.principalAddress.address1),
					"postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.regulationInfo.principalAddress.postalCode),
					"phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.regulationInfo.principalAddress.phoneNumber),
					"faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.regulationInfo.principalAddress.faxNumber)
				};
			}
			return query;
		}
		function ownerServiceAddressQuery(){
			var query = null;
			if(!$scope.aa1FormOriginal.regulationInfo){
					$scope.aa1FormOriginal.regulationInfo = {};
			} else {
				if(!$scope.aa1FormOriginal.regulationInfo.ownerAddress){
					$scope.aa1FormOriginal.regulationInfo.ownerAddress = {};
				}
			}
			if($scope.aa1_form1.regulationInfo.ownerAddress){
				var query = {};
				var address1 = $scope.aa1_form1.regulationInfo.ownerAddress.address1;
				var postalCode = $scope.aa1_form1.regulationInfo.ownerAddress.postalCode;
				if($scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber){
					var phoneNumber = '65'+$scope.aa1_form1.regulationInfo.ownerAddress.phoneNumber;
				}
				if($scope.aa1_form1.regulationInfo.ownerAddress.faxNumber){
					var faxNumber = '+65'+$scope.aa1_form1.regulationInfo.ownerAddress.faxNumber;
				}
				
				var query = {
					"address1":compareSetNull(address1,$scope.aa1FormOriginal.regulationInfo.ownerAddress.address1),
					"postalCode":compareSetNull(postalCode,$scope.aa1FormOriginal.regulationInfo.ownerAddress.postalCode),
					"phoneNumber":compareSetNull(phoneNumber,$scope.aa1FormOriginal.regulationInfo.ownerAddress.phoneNumber),
					"faxNumber":compareSetNull(faxNumber,$scope.aa1FormOriginal.regulationInfo.ownerAddress.faxNumber)
				};
			}
			return query;
		}

		function contractInfoQuery(){
			var query = null;
			if($scope.aa1_form1.contractInfo){
				var query = {};
				var projectReference = $scope.aa1_form1.contractInfo.projectReference;
				var contractNumber = $scope.aa1_form1.contractInfo.contractNumber;
				if($scope.aa1_form1.contractInfo.contractType && $scope.aa1_form1.contractInfo.contractType != "null"){
					var contractType = JSON.parse($scope.aa1_form1.contractInfo.contractType);
					contractType = contractType.id;
				} else {
					var contractType = undefined;
				}
				
				var natureOfDispute = $scope.aa1_form1.contractInfo.natureOfDispute;
				var contractMadeOn = $scope.aa1_form1.contractInfo.contractMadeOn;
				var mainContractMadeOn = $scope.aa1_form1.contractInfo.mainContractMadeOn;
				var query = {
					"projectReference":compareSetNull(projectReference,$scope.aa1FormOriginal.contractInfo.projectReference),
					"contractNumber":compareSetNull(contractNumber,$scope.aa1FormOriginal.contractInfo.contractNumber),
					"contractType":compareSetNull(contractType,$scope.aa1FormOriginal.contractInfo.contractType),
					"natureOfDispute":compareSetNull(natureOfDispute,$scope.aa1FormOriginal.contractInfo.natureOfDispute),
					"contractMadeOn":compareSetNull(contractMadeOn,$scope.aa1FormOriginal.contractInfo.contractMadeOn),
					"mainContractMadeOn":compareSetNull(mainContractMadeOn,$scope.aa1FormOriginal.contractInfo.mainContractMadeOn)
				};
			}
			return query;
		}
		function paymentInfoQuery(){
			var query = null;
			if($scope.aa1_form1.paymentInfo){
				var query = {};
				var latePaymentInterest = false;
				var claimRefNumber = $scope.aa1_form1.paymentInfo.claimRefNumber;
				var referencePeriodFrom = $scope.aa1_form1.paymentInfo.referencePeriodFrom;
				var referencePeriodTo = $scope.aa1_form1.paymentInfo.referencePeriodTo;
				var paymentClaimedDate = $scope.aa1_form1.paymentInfo.paymentClaimedDate;
				var claimAmount = $scope.aa1_form1.paymentInfo.claimAmountStr;
				var latePaymentInterestOrg = $scope.aa1_form1.paymentInfo.latePaymentInterest;
				if(latePaymentInterestOrg ==  "yes"){latePaymentInterest = true;}
				if(latePaymentInterestOrg ==  "no"){latePaymentInterest = false;}
				var latePaymentInterestRate = $scope.aa1_form1.paymentInfo.latePaymentInterestRateStr;
				var referenceResponseNumber = $scope.aa1_form1.paymentInfo.referenceResponseNumber;
				var responseDueDate = $scope.aa1_form1.paymentInfo.responseDueDate;
				var paymentClaimClaimant = $scope.aa1_form1.paymentInfo.paymentClaimClaimantStr;
				var responseAmount = $scope.aa1_form1.paymentInfo.responseAmountStr;
				var paymentDueDate = $scope.aa1_form1.paymentInfo.paymentDueDate;
				var respondentPaymentDate = $scope.aa1_form1.paymentInfo.respondentPaymentDate;
				var paymentByRespondent = $scope.aa1_form1.paymentInfo.paymentByRespondentStr;
				var query = {
					"claimRefNumber":compareSetNull(claimRefNumber,$scope.aa1FormOriginal.paymentInfo.claimRefNumber),
					"referencePeriodFrom":compareSetNull(referencePeriodFrom,$scope.aa1FormOriginal.paymentInfo.referencePeriodFrom),
					"referencePeriodTo":compareSetNull(referencePeriodTo,$scope.aa1FormOriginal.paymentInfo.referencePeriodTo),
					"paymentClaimedDate":compareSetNull(paymentClaimedDate,$scope.aa1FormOriginal.paymentInfo.paymentClaimedDate),
					"claimAmount":compareSetNull(claimAmount,$scope.aa1FormOriginal.paymentInfo.claimAmount),
					"latePaymentInterest":compareSetNull(latePaymentInterest,$scope.aa1FormOriginal.paymentInfo.latePaymentInterest),
					"latePaymentInterestRate":compareSetNull(latePaymentInterestRate,$scope.aa1FormOriginal.paymentInfo.latePaymentInterestRate),
					"referenceResponseNumber":compareSetNull(referenceResponseNumber,$scope.aa1FormOriginal.paymentInfo.referenceResponseNumber),
					"responseDueDate":compareSetNull(responseDueDate,$scope.aa1FormOriginal.paymentInfo.responseDueDate),
					"paymentClaimClaimant":compareSetNull(paymentClaimClaimant,$scope.aa1FormOriginal.paymentInfo.paymentClaimClaimant),
					"responseAmount":compareSetNull(responseAmount,$scope.aa1FormOriginal.paymentInfo.responseAmount),
					"paymentDueDate":compareSetNull(paymentDueDate,$scope.aa1FormOriginal.paymentInfo.paymentDueDate),
					"respondentPaymentDate":compareSetNull(respondentPaymentDate,$scope.aa1FormOriginal.paymentInfo.respondentPaymentDate),
					"paymentByRespondent":compareSetNull(paymentByRespondent,$scope.aa1FormOriginal.paymentInfo.paymentByRespondent)
				};
			}
			return query;
		}
		function supportingDocumentsQuery(){
			var query = null;
		}
		/*function supportingDocumentsQuery(){
			var query = [];
			var termsFilePath = $scope.termsUploadPath;
			var paymentClaimFilePath = $scope.paymentClaimUploadPath;
			var paymentResponseFilePath = $scope.paymentResponseUploadPath;
			var intentionNoticeFilePath = $scope.intentionNoticeUploadPath;
			var otherFilePath = $scope.otherDocUploadPath;
			if(termsFilePath){
				var filepath1 = {
					"fileLocation":termsFilePath
				}
				query.push(filepath1);
			}
			if(paymentClaimFilePath){
				var filepath2 = {
					"fileLocation":paymentClaimFilePath
				}
				query.push(filepath2);
			}
			if(paymentResponseFilePath){
				var filepath3 = {
					"fileLocation":paymentResponseFilePath
				}
				query.push(filepath3);
			}
			if(intentionNoticeFilePath){
				var filepath4 = {
					"fileLocation":intentionNoticeFilePath
				}
				query.push(filepath4);
			}
			if(otherFilePath){
				var filepath5 = {
					"documentDescription":$scope.aa1_form1.suport_upload5_ref_name,
					"fileLocation":otherFilePath
				}
				query.push(filepath5);
			}
			return query;
		}*/
		function caseDtoQuery(){
			var query = null;
			if($scope.aa1_form1.caseDto){
				var query = {};
				var claimAmount = $scope.aa1_form1.caseDto.claimAmountStr;
				if($scope.aa1_form1.caseDto.includeGst == "Yes"){
					var includeGst = true;
				} else if($scope.aa1_form1.caseDto.includeGst == "No"){
					var includeGst = false;
				}
				var authPerson = $scope.aa1_form1.caseDto.authPerson;
				var authPersonRef = $scope.aa1_form1.caseDto.authPersonRef;
				var query = {
					"claimAmount":compareSetNull(claimAmount,$scope.aa1FormOriginal.caseDto.claimAmount),
					"includeGst":compareSetNull(includeGst,$scope.aa1FormOriginal.caseDto.includeGst),
					"isOnline":compareSetNull($scope.onlineFormSubmissionStatus,$scope.aa1FormOriginal.caseDto.isOnline),
					"authPerson":compareSetNull(authPerson,$scope.aa1FormOriginal.caseDto.authPerson),
					"authPersonRef":compareSetNull(authPersonRef,$scope.aa1FormOriginal.caseDto.authPersonRef)
				};
			}
			return query;
		}

		if($rootScope.caseDetailObj){
			if($rootScope.caseDetailObj.caseNumber){
				var caseNo = $rootScope.caseDetailObj.caseNumber;
			} else {
				var caseNo = $rootScope.caseDetailObj.tempCaseNumber;
			}
			
			$rootScope.pdfCaseNumber = caseNo;
		} else if($cookies.get('caseNumber')){
			var caseNo = $cookies.get('caseNumber');
			$rootScope.pdfCaseNumber = caseNo;
		}

		//Generate Download URL
		var generateDownloadUrl = smcConfig.services.DownloadAAForm.url;
		$rootScope.downloadUrl = generateDownloadUrl + $rootScope.pdfCaseNumber;
		
		$scope.openPrintPdf = function(){
			angular.element(".downloadLink").html(" ");
			var generatePdfUrl = smcConfig.services.DownloadAAForm.url;
            generatePdfUrl = generatePdfUrl + "/" + $rootScope.pdfCaseNumber;
			// Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'AA Form';
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="UpdateAACase.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element(".overlay").css("display","block");
					angular.element("#aa_pdf_view").css("display","block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                     angular.element(".overlay").css("display","block");
					angular.element("#aa_pdf_view").css("display","block");
                }
            });
		}
		$scope.closePrintPdf = function(formId){
			angular.element(".overlay").css("display","none");
			angular.element("#"+formId).css("display","none");
		}
		$scope.openAuditTrialPopup=function(){
			angular.element('.audit-trial-modal').css("display","block");
			angular.element(".overlay").css("display","block");
			var query = {
						"caseNumber":$rootScope.auditTrialCaseNumber,
						"formName":"AAForm"				
						};
			DataService.post('AuditTrialData', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                	$scope.shownodataavailable=false;
                    $scope.auditTrialData=data.result.responseData;
                }
            }).catch(function (error) {
                $scope.shownodataavailable=true;
                NotifyFactory.log('error', error.errorMessage);
            });
		}
		
		$scope.closeAuditTrial=function () {
			angular.element('.audit-trial-modal').css("display","none");
			angular.element(".overlay").css("display","none");
		}


		function compareSetNull(val,org){
			if(org){
				if(val){
					if(val === org){
						var val = null;
					}
				} else {
					var val = null;	
				}
			}
			return val;
		}
		function removeNulls(obj) {
		  var isArray = obj instanceof Array;
		  for (var k in obj) {
		    if (obj[k] === null) isArray ? obj.splice(k, 1) : delete obj[k];
		    else if (typeof obj[k] == "object") removeNulls(obj[k]);
		    if (isArray && obj.length == k) removeNulls(obj);
		  }
		  return obj;
		}
 	}
 })();