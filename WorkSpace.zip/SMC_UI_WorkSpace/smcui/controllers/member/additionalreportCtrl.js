(function() {
    'use strict';
    angular
        .module('smc')
        .controller('additionalReportsCtrl',additionalReportsCtrl);

    additionalReportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function additionalReportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        $scope.roleName = $cookies.get('roleName');
        $cookies.put('currentTab','addtionalreports');
        $scope.shownodataavailable = true;
        $scope.$emit('activeReportTab',$cookies.get('currentTab'));//sent current tab status
    	// to receive filter case list
        $scope.$on('additionalReportCases', function(event, caselist) { 
                $scope.addtionalreports = caselist; 
                $scope.shownodataavailable = false;
         });
    }
})();


