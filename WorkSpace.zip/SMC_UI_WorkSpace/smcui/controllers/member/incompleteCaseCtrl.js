(function () {
    'use strict';
    angular
        .module('smc')
        .controller('incompleteCaseCtrl', incompleteCaseCtrl);

    incompleteCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory','healthCheckConfig'];

    function incompleteCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory,healthCheckConfig) {
        if (($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management') || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.ack = {};
        $scope.ack.isCurrentDate = true;
        $scope.shownodataavailable = false;;
        $scope.missedlist = [];
        $scope.canceldetail = {};
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf", "jpg", "jpeg", "png"];
        $scope.casestatus_modal_path = 'views/member/case-status.html';
        $scope.eMailLogModelPath = 'views/member/email-log.html';

        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'incomplete') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_incomplete_caselist($scope.pagenumber); //call to incomplete case list function
        $cookies.put('currentTab', 'incomplete');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status
        $scope.update_payeename_modal_path = 'views/member/update-payeename-modal.html'
        $scope.cancel_application_modal_path = 'views/member/cancel-application.html'
            //call to incomplete case list function from outside
        $rootScope.incompletecaselist = function () {
            get_incomplete_caselist($cookies.get('pageNumber'));
        }

        // get incomplete case list
        function get_incomplete_caselist(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": pageNumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "claimantName": null,
                "respondentName": null,
                "tempCaseNumber": null,
                "claimedAmountFrom": null,
                "claimedAmountTo": null,
                "dateFrom": null,
                "dateTo": null,
            }
            getAllIncompleteCases(query);
        }
        //get all incomplete case list 
        function getAllIncompleteCases(query) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            DataService.post('GetIncompleteCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                    }
                    angular.element(".loading-container").css("display","none");
                    $scope.shownodataavailable = false;                   
                    $scope.incomplete_Case_List = data.result.responseData;
                    console.log("incomplete case list" + JSON.stringify($scope.incomplete_Case_List))
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    for (var index = 0; index < $scope.incomplete_Case_List.length; index++) {
                        if ($scope.incomplete_Case_List[index].caseStatus) {
                            $scope.caseNo = $scope.incomplete_Case_List[index].caseNumber;
                            $scope.incomplete_Case_List[index].documentPendingStatus = findStatus($scope.incomplete_Case_List[index].caseStatus, "Document Pending");
                            console.log($scope.incomplete_Case_List);
                        }
                    }
                } else {
                    if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                    }
			        angular.element(".loading-container").css("display","none");
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                    }
			    angular.element(".loading-container").css("display","none");
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_incomplete_caselist(pageNo);
        }
       
        // to receive filter case list
        $scope.$on('filterCases', function (event, filter) {
          
            if ($cookies.get('currentTab') == 'incomplete') {
                var query = {
                    "claimantName": undefinedSetNull(filter.claimantName),
                    "respondentName": undefinedSetNull(filter.respondentName),
                    "tempCaseNumber": undefinedSetNull(filter.caseNumber),
                    "claimedAmountFrom": undefinedSetNull(filter.claimedAmountFrom),
                    "claimedAmountTo": undefinedSetNull(filter.claimedAmountTo),
                    "dateFrom": undefinedSetNull(filter.dateFrom),
                    "dateTo": undefinedSetNull(filter.dateTo),
                }
                getAllIncompleteCases(query);
            }
        });

        // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'incomplete') {
                get_incomplete_caselist(0);
            }
        });
       

        //show acknowledgement popup
        $scope.Acknowledgement_date = function (caseNumber, submit_date) {
            $scope.ack = {};
            $scope.ack_Date = undefined;
            $scope.submitDate = submit_date;
            $scope.ack.caseNumber = caseNumber;
            $scope.ack.receipt_date = undefined;
            $scope.ack.isCurrentDate = true;
            getMissedDocs();
            angular.element(".overlay").css("display", "block");
            angular.element(".form-submitt-confirm").css("display", "block");
        }

        //choosse current date other wise show datepicker
        $scope.dateClick = function (date_set) {
                if (date_set == 'yes') {
                    $scope.ack.isCurrentDate = true;
                } else {
                    $scope.ack.isCurrentDate = false;
                }
            }
            //cancel acknowledgement popup
        $scope.cancelAck = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".form-submitt-confirm").css("display", "none");
        }

        //submit acknowledgement
        $scope.ack_Submit = function (ack_Date) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            console.log("ack_Date", ack_Date);
            var query = {
                'caseNumber': ack_Date.caseNumber,
                "acknowledgeDocuments": [{
                    "documentName": "Relevant Contractual Terms and Conditions",
                    "receiptDate": ack_Date.relevant_date
                }, {
                    "documentName": "Payment Claim",
                    "receiptDate": ack_Date.payment_date
                }, {
                    "documentName": "Payment Response Received",
                    "receiptDate": ack_Date.response_date
                }, {
                    "documentName": "Notice of Intention to Apply for Adjudication",
                    "receiptDate": ack_Date.notice_date
                }],
                'receiptedBy': $cookies.get('memberId'),
                "isCurrentDate": ack_Date.isCurrentDate,
                "lodgementDate": ack_Date.lodgment_date
            }
            console.log('query', query)
            DataService.post('AcknowledgementUpdate', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('success', 'Acknowledgement date submitted successfully');
                    angular.element(".overlay").css("display", "none");
                    angular.element(".form-submitt-confirm").css("display", "none");
                    get_incomplete_caselist();
                } else {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //get missed documents
        function getMissedDocs() {
            var serviceGetMissedDocumentsUrl = smcConfig.services.GetMissedDocuments.url;
            serviceGetMissedDocumentsUrl = serviceGetMissedDocumentsUrl + "/" + $scope.ack.caseNumber;
            $http.get(serviceGetMissedDocumentsUrl).then(function (data) {
                for (var documentIndex in data.data.results) {
                    $scope.missedlist.push(data.data.results[documentIndex].documentName);
                }
            });
        }
        //assign case to case officer
        $scope.assignCase = function (caseNumber) {
                $rootScope.casedetailNumber = caseNumber;
                $rootScope.casedetail.caseOfficerId = undefined;
                $rootScope.casedetail.assistantManagerId = undefined;
                angular.element(".overlay").css("display", "block");
                angular.element(".case-submitt-confirm").css("display", "block");
            }
            //to open update payee name modal
        $scope.updatePayeeModal = function (caseNumber) {      
            $rootScope.payeeCaseNumber = caseNumber;
            $rootScope.payeedetails = {};
            $rootScope.supprtDocumentName = null;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-payee-name").css("display", "block");
            $rootScope.getPayeeName(); //call function
        }

        $scope.goNextInEmailLog=function(casenumber,pageNumber){
            getEmailLogList(casenumber,pageNumber)
        }
        // show email log 
        $scope.showEmailLog=function(casenumber,pageNumber){  
            getEmailLogList(casenumber,pageNumber)
        }

        function getEmailLogList(casenumber,pageNumber){
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            $scope.eMailLogCaseNumber = casenumber;
             if(pageNumber){
                $scope.emailLogPagenumber = pageNumber;
            }else{
                $scope.emailLogPagenumber = 0;
            }
            var query={
                    "caseNumber":casenumber,
                    "pageIndex":$scope.emailLogPagenumber,
                    "dataLength":10,
                    "sortingColumn":null,
                    "sortDirection":null
            }                           
            DataService.post('GetEmailLogDetail', query).then(function (data) {
                if (data.status == 'SUCCESS') {
			            angular.element(".loading-container").css("display","none");
                        angular.element(".overlay").css("display", "block");
                        angular.element(".show-email-log").css("display", "block");
                        $scope.EmailLogdata=data.result.responseData; 
                        $scope.max_EmailLog_Pagenumber  =  data.result.totalPages;
                } else {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
            });
        }

        $scope.viewEmailLog=function(data){
            $scope.goingToEdit=data;
             $scope.disableEmailContent=true;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.editEmailLog=function(index){
            $scope.updateIndexContent = index;
            if($scope.EmailLogdata[index].updateContent){
                $scope.goingToEdit = $scope.EmailLogdata[index].updateContent;
            }else{
                $scope.goingToEdit = $scope.EmailLogdata[index].content;
            }
            $scope.disableEmailContent=false;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.resendEmailLog=function(data,index){ 
                         
                if(data.updateContent){
                   var contentData=data.updateContent;
                }else{
                    var contentData=data.content;
                }
                var query={
                    "id":data.id,
                    "content":contentData
                }
                angular.element(".overlay").css("display","block");
			    angular.element(".loading-container").css("display","block");
                DataService.post('ResendEmailLogDetail', query).then(function (data) {                                   
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
			             angular.element(".loading-container").css("display","none");
                        $scope.EmailLogdata[index] = data.result;
                        NotifyFactory.log('success', 'Mail sent successfully');
                    } else {
                        angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
        }
           
        $scope.cancelModCaseLog=function(){
            angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        $scope.closelistLog=function(){
            angular.element(".overlay").css("display", "none");
            angular.element(".show-email-log").css("display", "none");      
        }

        $scope.updateContent = function(updatedContent, index){
            if($scope.EmailLogdata[index].updateContent){
                if($scope.EmailLogdata[index].updateContent!= updatedContent){
                    $scope.EmailLogdata[index].updateContent = updatedContent
                }
            }
            else if($scope.EmailLogdata[index].content != updatedContent){
                $scope.EmailLogdata[index].updateContent = updatedContent;
            }
            angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        //to close update payee name modal
        $scope.closepayeepop = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-payee-name").css("display", "none");
        }

        // to open modal for cancel application
        $scope.open_cancel_modal = function (cases, caseFrom) {
                $scope.caseFrom = caseFrom;
                $rootScope.cancelCaseNumber = cases.caseNumber;
                $scope.canceldetail = {};
                $scope.attachcopyStatus = false;
                DataService.get('GetCancelApplicationReasons').then(function (data) {
                    if (data.status == 'SUCCESS') {
                        $scope.reasons = data.results;
                    } else {
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
                angular.element(".overlay").css("display", "block");
                angular.element(".cancel-application-modal").css("display", "block");
            }
            // to close modal for cancel application
        $scope.closecancelmodal = function () {
            $scope.canceldetail = {};
            $scope.supprtDocumentName = '';
            $scope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "none");
            angular.element(".cancel-application-modal").css("display", "none");
        }

        $rootScope.updateCaseNumberSession = false;
        $scope.updateAA1Form = function (casenumber) {
            $cookies.put('currentActionMenu', 'Update AA-1 Form');
            var casenumber = casenumber;
            getCaseDetail(casenumber);
        }


        // get single case list based on case number 
        function getCaseDetail(casenumber) {
            var serviceGetSingleCaseListUrl = smcConfig.services.GetSingleCaseList.url;
            serviceGetSingleCaseListUrl = serviceGetSingleCaseListUrl + "/" + casenumber;
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            $http.get(serviceGetSingleCaseListUrl).then(function (data) {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    console.log('Case Details', data.data.result);
                    $rootScope.caseDetailObj = {};
                    $rootScope.caseDetailObj = data.data.result;
                    $rootScope.updateCaseNumberSession = true;
                    $rootScope.auditTrialCaseNumber=casenumber;
                    $state.go("smclayout.membershiplayout.updateaa1");
                })
                .catch(function (error) {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    console.log('errorcaselist', error);
                });
        }

        //to get int type month for datepicker min date to select acknowledgement
        function getIntType(month) {
            var months = {
                "Jan": 1,
                "Feb": 2,
                "Mar": 3,
                "Apr": 4,
                "May": 5,
                "Jun": 6,
                "Jul": 7,
                "Aug": 8,
                "Sep": 9,
                "Oct": 10,
                "Nov": 11,
                "Dec": 12
            }
            return months[month];
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadCancelFile = function (file, index) {
                var file = file;
                if (file.size < 5242881) {
                    if (validateUploadFileExtention(file.name)) {
                        $scope.supprtDocumentName = file.name;

                        $scope.canceldetail.fileName = $scope.supprtDocumentName;
                        var fd = new FormData();
                        fd.append('file', file);
                        httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                            console.log(data);
                            $scope.canceldetail.supportFilePath = data.result;
                            $scope.attachcopyStatus = true;
                        });
                    } else {
                        $scope.attachcopyStatus = true;
                        $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                    }
                } else {
                    NotifyFactory.log('error', "Please select below 5MB file");
                }
            }
            // check valid file by exetension
        function validateUploadFileExtention(val) {
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for (var i = 0; i < allowedExt.length; i++) {
                if ($scope.fileUploadTypes[i] == ext) {
                    return true;
                }
            }
        }
        // if we want remove upload file
        $scope.cancelattachcopyRemove = function () {
                $scope.supprtDocumentName = undefined;
                $scope.canceldetail.fileName = undefined;
                $scope.canceldetail.supportFilePath = undefined;
                $scope.attachcopyStatus = false;
                angular.element("#supprt_document_name").val("");
                angular.element("#cancel_suport_upload").val("");
            }
            // Submit Cancel Apllication
        $scope.submitCancel = function (cancelData, caseNumber, caseFrom, isRefundApllicable) {
            var query = buildQuery(cancelData, caseNumber);
            console.log('query', query);
            if (caseFrom == 'AA') {
                cancelAAapplication(query, isRefundApllicable);
            } else if (caseFrom == 'ARA') {
                cancelARAapplication(query, isRefundApllicable);
            }
        }

        //cancel aa application
        function cancelAAapplication(query, isRefundApllicable) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            DataService.post('CancelApplication', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('success', 'Application cancelled successfully');
                    get_incomplete_caselist();
                    if(!data.result.isRefundApplicable){
                        angular.element(".overlay").css("display", "none");
                        angular.element(".cancel-application-modal").css("display", "none");
                    } else {
                        $scope.isRefundOverlay = true
                        angular.element(".overlay").css("display", "block");
                        angular.element(".refund-notify-modal").css("display", "block");
                        angular.element(".cancel-application-modal").css("display", "none");
                    }

                } else {
                    if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                        angular.element(".loading-container").css("display","none");
                    }
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                        angular.element(".loading-container").css("display","none");
                    }
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //close refund notify popup
        $scope.closeRefundnotifyPopup = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".refund-notify-modal").css("display", "none");
        }


        //cancel ara application
        function cancelARAapplication(query) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            DataService.post('CancelARAApplication', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('success', 'Application cancelled successfully');
                    if(!data.result.isRefundApplicable){
                        angular.element(".overlay").css("display", "none");
                        angular.element(".cancel-application-modal").css("display", "none");
                    } else {
                        $scope.isRefundOverlay = true
                        angular.element(".overlay").css("display", "block");
                        angular.element(".refund-notify-modal").css("display", "block");
                        angular.element(".cancel-application-modal").css("display", "none");
                    }
                    get_incomplete_caselist();
                } else {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.errorMessage);
            });
        }


        function findStatus(array, action) {
            var a = 0;
            for (var index = 0; index < array.length; index++) {
                if (array[index] == action) {
                    a = 1;
                }
            }
            if (a == 1) {
                return true;
            } else {
                return false;
            }

        }
        // build query for cancel application
        function buildQuery(cancelData, caseNumber) {
            var query = {
                "caseNumber": caseNumber,
                "requesterRole": cancelData.requestedRole,
                "requestedDate": cancelData.request_date,
                "smcOfficerId": $cookies.get('memberId'),
                "supportingDocument": {
                    "name": cancelData.fileName,
                    "fileLocation": cancelData.supportFilePath
                }
            }
            if (cancelData.reason != 'Others') {
                query['reason'] = cancelData.reason;
            } else {
                query['reason'] = cancelData.stateReason;
            }

            return query;
        }

        function undefinedSetNull(val) {
             if (val) {
                 return val;
             } else {
                 var val = null;
                 return val;
             }
             return val;
         }


        $scope.caseStatusPopup = function (index, caseNo, caseType) {
                $scope.loading = true;
                //function that sets the value of selectedRow to current index
                $scope.selectedRow = index;

                /*Getting full status list */
                if (caseType == 'AA Case') {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.AACaseStatusList;
                } else {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.ARACaseStatusList;
                }

                console.log("caseNO" + caseNo);
                $scope.missedStatus = false;
                var healthCheck = smcConfig.services.GetHealthCheckForAdjudicationCase.url;
                var healthCheckUrl = healthCheck + caseNo;
                $http.get(healthCheckUrl).then(function (healthData) {
                    if (healthData.data.status == 'SUCCESS') {
                        $scope.loading = false;
                        $scope.yetToProcessStatusList = healthData.data.result.yetToProcessStatusList;
                        $scope.missedStatusList = healthData.data.result.missedStatusList;
                        $scope.processStatusList = healthData.data.result.processStatusList;
                        angular.element(".overlay").css("display", "block");
                        angular.element(".case_status_modal").css("display", "block");

                    } else {
                        NotifyFactory.log('error', "error");
                    }
                });


            }
            //close refund notify popup
        $scope.caseStatusPopupClose = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case_status_modal").css("display", "none");
        }
        $scope.options = {
            readOnly : true,
            toolbar: []
        };

    }
})();
