(function () {
    'use strict';
    angular
        .module('smc')
        .controller('cancelledCaseCtrl', cancelledCaseCtrl);

    cancelledCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory', '$sce','healthCheckConfig'];

    function cancelledCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory, $sce,healthCheckConfig) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.shownodataavailable = false;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'cancelled') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_cancelled_caselist($scope.pagenumber); //call to incomplete case list function
        $cookies.put('currentTab', 'cancelled');
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status
        $scope.casestatus_modal_path = 'views/member/case-status.html';
        $scope.eMailLogModelPath = 'views/member/email-log.html';
        $scope.eFaxModelPath = 'views/member/e-fax.html';
        $scope.eFaxViewModelPath = 'views/member/e-fax-view.html';

        //Generate Download URL
        $scope.generateDownloadUrl = smcConfig.services.DownloadSupportingDocument.url;
        //Get Approved memo Url
        $scope.downloadApprovedMemo = smcConfig.services.DownloadApprovedMemo.url;
        //call to incomplete case list function from outside
        $rootScope.cancelledcaselist = function () {
            get_cancelled_caselist($cookies.get('pageNumber'));
        }

        // get incomplete case list
        function get_cancelled_caselist(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "claimantName": null,
                "respondentName": null,
                "tempCaseNumber": null,
                "claimedAmountFrom": null,
                "claimedAmountTo": null,
                "dateFrom": null,
                "dateTo": null
            }
            getAllInCancelledCases(query);
        }

        function getAllInCancelledCases(query) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            DataService.post('GetCancelledCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    $scope.cancelled_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    for (var index = 0; index < $scope.cancelled_Case_List.length; index++) {
                        $scope.caseNo = $scope.cancelled_Case_List[index].caseNumber;
                        var result = $scope.caseNo;
                        result = result.search("SOP");
                        if (result == 0) {
                            $scope.cancelled_Case_List[index].pattern_CaseNo = $scope.caseNo.substring(0, 3) + ' ' + $scope.caseNo.substring(3, 5) + ' ' + $scope.caseNo.substring(5, 9) + ' of ' + $scope.caseNo.substring(9, 13);
                        } else {
                            $scope.cancelled_Case_List[index].pattern_CaseNo = $scope.caseNo;
                        }
                    }
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    for (var index = 0; index < $scope.cancelled_Case_List.length; index++) {
                        if ($scope.cancelled_Case_List[index].caseStatus) {
                            $scope.cancelled_Case_List[index].appointAdjudicatorStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "Adjudicator Appointed");
                            $scope.cancelled_Case_List[index].timesheetSubmitStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "Time Sheet Submitted");
                            $scope.cancelled_Case_List[index].additionalPaymentStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "Additional Deposit Paid / Deposit is Sufficient");
                            $scope.cancelled_Case_List[index].aaLodgedStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "Lodged");
                            $scope.cancelled_Case_List[index].arSubmitedStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "AR Submitted");
                            $scope.cancelled_Case_List[index].aaPaymentStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "Payment Completed");
                            $scope.cancelled_Case_List[index].aaProcessRefundStatus = findStatus($scope.cancelled_Case_List[index].caseStatus, "Payment Refund Sent for Management Approval");
                        }else if($scope.cancelled_Case_List[index].araCaseStatus){

                            $scope.cancelled_Case_List[index].araLodgedStatus = findStatus($scope.cancelled_Case_List[index].araCaseStatus, "ARA Lodged");
                            $scope.cancelled_Case_List[index].araProcessRefundStatus = findStatus($scope.cancelled_Case_List[index].araCaseStatus, "ARA Payment Refund Sent for Management Approval");
                            $scope.cancelled_Case_List[index].araadditionalPaymentStatus = findStatus($scope.cancelled_Case_List[index].araCaseStatus, "Additional Deposit Paid / Deposit is Sufficient");
                            $scope.withdraw_Case_List[index].aratimesheetSubmitStatus = findStatus($scope.withdraw_Case_List[index].araCaseStatus, "ARA Time Sheet Submitted");
                        }
                    }
                } else {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.goToPageNumber = function (pageNo) {
            get_cancelled_caselist(pageNo);
        }

        // to receive filter case list
        $scope.$on('filterCases', function (event, filter) {
            
            if ($cookies.get('currentTab') == 'cancelled') {
                
                var query = {
                    "claimantName": undefinedSetNull(filter.claimantName),
                    "respondentName": undefinedSetNull(filter.respondentName),
                    "tempCaseNumber": undefinedSetNull(filter.caseNumber),
                    "claimedAmountFrom": undefinedSetNull(filter.claimedAmountFrom),
                    "claimedAmountTo": undefinedSetNull(filter.claimedAmountTo),
                    "dateFrom": undefinedSetNull(filter.dateFrom),
                    "dateTo": undefinedSetNull(filter.dateTo)
                }
                getAllInCancelledCases(query);
            }
        });

        // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'cancelled') {
                get_cancelled_caselist(0);
            }
        });


        //get generate memo
        $scope.getViewMemo = function (caseNumber) {
            $scope.memoCaseNumber = caseNumber;
            var GetViewGenerateMemoUrl = smcConfig.services.GetViewGenerateMemo.url;
            GetViewGenerateMemoUrl = GetViewGenerateMemoUrl + $scope.memoCaseNumber;
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            $http.get(GetViewGenerateMemoUrl).then(function (data) {
                    $scope.paymentMemoData = data.data.result;
                    $scope.convertedAmnt = $scope.paymentMemoData.claimedAmount/10;
			        angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display", "block");
                    angular.element(".case-generate-memo").css("display", "block");
                })
                .catch(function (error) {
                    NotifyFactory.log('error', error.data.errorMessage);
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                });
        }

        $scope.convertClaimedAmnt = function(amnt){
            $scope.convertedAmnt = amnt/10;
        }

        //close generate memo
        $scope.cancelMemo = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case-generate-memo").css("display", "none");
        }

        //sent approval to management
        $scope.sendApproval = function (sentData, caseNumber) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            var query = buildApprovalQuery(sentData, caseNumber)
            DataService.post('SentDeterminedApproval', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                     angular.element(".overlay").css("display","none");
			         angular.element(".loading-container").css("display","bone");
                    NotifyFactory.log('success', 'Memo sent for approval successfully');
                    get_cancelled_caselist();
                    angular.element(".overlay").css("display", "none");
                    angular.element(".case-generate-memo").css("display", "none");
                }
            }).catch(function (error) {
                 angular.element(".overlay").css("display","none");
			     angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function buildApprovalQuery(sentData, caseNumber) {
            var query = {
                "caseNumber": caseNumber,
                "smcOfficerId": $cookies.get('memberId'),
                "claimedAmount": undefinedSetNull(sentData.claimedAmount),
                "depositAmount": undefinedSetNull(sentData.depositAmount),
                "adjudicatorFee": undefinedSetNull(sentData.adjudicatorFee),
                "invoiceNumber": undefinedSetNull(sentData.invoiceNumber),
                "smcManagementFee": undefinedSetNull(sentData.smcManagementFee),
                "paymentDueToAdjudicator": undefinedSetNull(sentData.paymentDueToAdjudicator),
                "adjudicationCost": undefinedSetNull(sentData.adjudicationCost),
                "amountPaidByClaimant": undefinedSetNull(sentData.amountPaidByClaimant),
                "amountRefund": undefinedSetNull(sentData.amountRefund),
                "claimantPayableAmount": undefinedSetNull(sentData.claimantPayableAmount)
            }

            return query
        }

        function findStatus(array, action) {
            var a = 0;
            for (var index = 0; index < array.length; index++) {
                if (array[index] == action) {
                    a = 1;
                }
            }
            if (a == 1) {
                return true;
            } else {
                return false;
            }

        }

        // to receive filter case list
        $scope.$on('filterCases', function (event, caselist) {
            if ($cookies.get('currentTab') == 'cancelled') {
                $scope.cancelled_Case_List = caselist;
                console.log($scope.cancelled_Case_List);
            }
        });

        $scope.goNextInEmailLog=function(casenumber,pageNumber){
            getEmailLogList(casenumber,pageNumber)
        }
         $scope.showEmailLog=function(casenumber,pageNumber){  
            getEmailLogList(casenumber,pageNumber)
        }

        function getEmailLogList(casenumber,pageNumber){
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            $scope.eMailLogCaseNumber = casenumber;
             if(pageNumber){
                $scope.emailLogPagenumber = pageNumber;
            }else{
                $scope.emailLogPagenumber = 0;
            }
            var query={
                    "caseNumber":casenumber,
                    "pageIndex":$scope.emailLogPagenumber,
                    "dataLength":10,
                    "sortingColumn":null,
                    "sortDirection":null
            }                           
            DataService.post('GetEmailLogDetail', query).then(function (data) {
                if (data.status == 'SUCCESS') {
						angular.element(".loading-container").css("display","none");
                        angular.element(".overlay").css("display", "block");
                        angular.element(".show-email-log").css("display", "block");
                        $scope.EmailLogdata=data.result.responseData; 
                        $scope.max_EmailLog_Pagenumber  =  data.result.totalPages;
                } else {
                    angular.element(".overlay").css("display","none");
					angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                angular.element(".overlay").css("display","none");
				angular.element(".loading-container").css("display","none");
            });
        }

        $scope.viewEmailLog=function(data){
            $scope.goingToEdit=data;
             $scope.disableEmailContent=true;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.editEmailLog=function(index){
            $scope.updateIndexContent = index;
            if($scope.EmailLogdata[index].updateContent){
                $scope.goingToEdit = $scope.EmailLogdata[index].updateContent;
            }else{
                $scope.goingToEdit = $scope.EmailLogdata[index].content;
            }
            $scope.disableEmailContent=false;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.resendEmailLog=function(data,index){ 
                 angular.element(".overlay").css("display","block");
			     angular.element(".loading-container").css("display","block");      
                if(data.updateContent){
                   var contentData=data.updateContent;
                }else{
                    var contentData=data.content;
                }
                var query={
                    "id":data.id,
                    "content":contentData
                }
                DataService.post('ResendEmailLogDetail', query).then(function (data) {                                   
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                        $scope.EmailLogdata[index] = data.result;
                        NotifyFactory.log('success', 'Mail sent successfully');
                    } else {
                        NotifyFactory.log('error', data.errorMessage);
                         angular.element(".overlay").css("display","none");
			             angular.element(".loading-container").css("display","none");
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                     angular.element(".overlay").css("display","none");
			         angular.element(".loading-container").css("display","none");
                });
        }
           
        $scope.cancelModCaseLog=function(){
            angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        $scope.closelistLog=function(){
            angular.element(".overlay").css("display", "none");
            angular.element(".show-email-log").css("display", "none");      
        }

         $scope.updateContent = function(updatedContent, index){
            if($scope.EmailLogdata[index].updateContent){
                if($scope.EmailLogdata[index].updateContent!= updatedContent){
                    $scope.EmailLogdata[index].updateContent = updatedContent
                }
            }
            else if($scope.EmailLogdata[index].content != updatedContent){
                $scope.EmailLogdata[index].updateContent = updatedContent;
            }
            angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

         //E-Fax
       $scope.viewEfaxStatus=function(caseNumber,pageNumber){
             $scope.eFaxCaseNumber =caseNumber;
             viewFaxData(pageNumber);
        } 

        $scope.nextEfax=function(pageNumber){
            viewFaxData(pageNumber);
        }

        function viewFaxData(pageNumber){
             if(pageNumber){
                     $scope.eFaxPagenumber  = pageNumber;
                }else{
                    $scope.eFaxPagenumber  = 0;
                }

              var query = {
                "pageIndex": pageNumber,
                "dataLength": 10,
                "sortingColumn": null,
                "sortDirection": null,
                "caseNumber": $scope.eFaxCaseNumber
                }

                DataService.post('ViewFaxLog', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        if(data.result.totalData>0){
                            $scope.ifEfaxnoAvailable=false;
                        }else{
                            $scope.ifEfaxnoAvailable=true;
                        }
                        $scope.faxData=data.result.responseData;
                        $scope.max_Efax_Pagenumber  =  data.result.totalPages;
                        angular.element(".overlay").css("display","block");
                        angular.element(".eFax-status").css("display","block"); 
                    }
                }).catch(function (error) {
                    $scope.ifEfaxnoAvailable=true;
                    NotifyFactory.log('error', error.errorMessage);
                }); 
        }

       

        $scope.closeEfaxPopup=function(){
             angular.element(".overlay").css("display","none");
             angular.element(".eFax-status").css("display","none");
         }

         $scope.viewFaxDetail=function(faxId){
            $scope.faxId=faxId;
            var getFaxDetail = smcConfig.services.GetFaxDetail.url;
            var getFaxDetailUrl = getFaxDetail + faxId;
            var downloadFaxDetail = smcConfig.services.DownloadFaxData.url;
            $http.get(getFaxDetailUrl).then(function(data){
                $scope.faxDetailsView=data.data.result;
                angular.element(".overlay").css("display","block");
                angular.element(".eFax-status").css("display","none");
                angular.element("#view_fax").css("display", "block");
                
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });

         }

         $scope.closeViewfax=function(){
            angular.element("#view_fax").css("display", "none");
            angular.element(".eFax-status").css("display","block");

         }
        //view cancelleation details
        $scope.viewCancellationDetails = function (caseNumber) {
            var GetCancellationDetailsUrl = smcConfig.services.GetCancellationDetails.url;
            GetCancellationDetailsUrl = GetCancellationDetailsUrl + caseNumber;
            $http.get(GetCancellationDetailsUrl).then(function (data) {
                console.log("data", data)
                if (data.data.status == 'SUCCESS') {
                    $scope.cancellationData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".cancellation-details").css("display", "block");
                }
            });
        }

        //close cancelleation details
        $scope.closecanceldetailmodal = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".cancellation-details").css("display", "none");
        }

        //view Refund details
        $scope.viewRefundDetails = function (caseNumber, caseFrom) {
            $scope.caseFrom = caseFrom;
            if (caseFrom == 'AA') {
                viewAARefundDetails(caseNumber);
            } else if (caseFrom == 'ARA') {
                viewARARefundDetails(caseNumber);
            }
        }

        //view AA Refund details
        function viewAARefundDetails(caseNumber) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            var GetRefundDataUrl = smcConfig.services.GetRefundData.url;
            GetRefundDataUrl = GetRefundDataUrl + caseNumber;
            $http.get(GetRefundDataUrl).then(function (data) {
                console.log("data", data)
                if (data.data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    $scope.refundData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".refund-process").css("display", "block");
                } else {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.data.errorMessage);
            });
        }

        //view ARA Refund details
        function viewARARefundDetails(caseNumber) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            var GetARARefundDataUrl = smcConfig.services.GetARARefundData.url;
            GetARARefundDataUrl = GetARARefundDataUrl + caseNumber;
            $http.get(GetARARefundDataUrl).then(function (data) {
                console.log("data", data)
                if (data.data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    $scope.refundData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".refund-process").css("display", "block");
                } else {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.data.errorMessage);
            });
        }

        //close Refund details
        $scope.closerefundmodal = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".refund-process").css("display", "none");
        }

        //send refund request to management
        $scope.refundrequest = function (refundData, caseFrom) {
            var query = refundQueryData(refundData);
            if (caseFrom == 'AA') {
                angular.element(".overlay").css("display","block");
			    angular.element(".loading-container").css("display","block");
                DataService.post('requestRefundData', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('success', "Process refund requested successfully");
                        get_cancelled_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".refund-process").css("display","none");
                    }else{
                        angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
            } else if (caseFrom == 'ARA') {
                angular.element(".overlay").css("display","block");
			    angular.element(".loading-container").css("display","block");
                DataService.post('requestARARefundData', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('success', "Process refund requested successfully");
                        get_cancelled_caselist();
                        angular.element(".overlay").css("display","none");
                        angular.element(".refund-process").css("display","none");
                    }else{
                        angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
            }

        }

        //build query for refund approval
        function refundQueryData(refundData) {
            var query = {
                "filingFee": refundData.filingFee,
                "depositFeeOfAdjudicator": refundData.depositFeeOfAdjudicator,
                "timeCostOfAdjudicator": refundData.timeCostOfAdjudicator,
                "amountRefund": refundData.amountRefund,
                "caseNumber": refundData.caseNumber,
                "smcOfficerId": parseInt($cookies.get('memberId'))
            }
            return query;
        }

           function undefinedSetNull(val) {
             if (val) {
                 return val;
             } else {
                 var val = null;
                 return val;
             }
             return val;
         }

        $scope.openPrintPdf = function (docs) {
            
            angular.element(".downloadLink").html(" ");
            $scope.imgViewUrl = '';
            $scope.pdfFileData = '';
            var generatePdfUrl = $scope.generateDownloadUrl + docs.id;
            if (docs.name.split('.')[1] == 'pdf' || docs.name.indexOf('pdf') != -1) {
                angular.element(".downloadLink").html(" ");
                // Internet Explorer 6-11
                var isIE = /*@cc_on!@*/false || !!document.documentMode;
                // Edge 20+
                var isEdge = !isIE && !!window.StyleMedia;
                $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                    if(isIE || isEdge){
                        $scope.IEBrowserStatus = true;
                        $scope.downLoadTitle = 'Cancel Case Data';
                         var downloadfile = new Blob([data], {
                             type: 'attachment/pdf'
                         });
                         var link=document.createElement('a');
                        link.href=window.URL.createObjectURL(downloadfile);
                        link.download="cancelCaseData.pdf";
                        angular.element(".downloadLink").append(link);
                        angular.element(".downloadLink a").html("Download PDF");
                        angular.element(".downloadLink a").addClass("btn");
                        angular.element(".downloadLink a").addClass("btn-primary");
                        angular.element(".overlay").css("display", "block");
                        angular.element(".cancellation-details").css("display", "none");
                        angular.element("#cancel_document_view").css("display", "block");
                    } else {
                        var file = new Blob([data], {
                             type: 'application/pdf'
                        });
                        var fileURL = URL.createObjectURL(file);
                         $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                         angular.element(".overlay").css("display", "block");
                        angular.element(".cancellation-details").css("display", "none");
                        angular.element("#cancel_document_view").css("display", "block");
                    }
                });
            } else {
                $http
                    .get(generatePdfUrl, {
                        responseType: 'arraybuffer'
                    })
                    .success(function (data) {
                        var file = new Blob([data], {
                            type: 'application/image'
                        });
                        $scope.imgViewUrl = URL.createObjectURL(file);
                        angular.element(".overlay").css("display", "block");
                        angular.element(".cancellation-details").css("display", "none");
                        angular.element("#cancel_document_view").css("display", "block");
                    });
                $scope.imgView = true;
            }

        }
        $scope.closePrintPdf = function (formId) {
            angular.element(".overlay").css("display", "block");
            angular.element(".cancellation-details").css("display", "block");
            angular.element("#" + formId).css("display", "none");
        }


        //view time Sheet
        $scope.viewTimeSheet = function (caseData) {
            $scope.goingToApporve = false;
                $scope.ClaimantName = caseData.claimantName;
                $scope.Respond = caseData.respondentName;
                $scope.timesheetNumber = caseData.caseNumber;
                if(caseData.caseType == 'AA Case'){
                    if(caseData.caseStatus.indexOf('Adjudicator Time Cost Request') != -1 && caseData.caseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') == -1 && caseData.caseStatus.indexOf('SMC Officer Approve Adjudicator Time Sheet') == -1){
                        $scope.goingToApporve = true;
                    }else if(caseData.caseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') != -1 && caseData.caseStatus.indexOf('Time Sheet ReSubmitted') != -1){
                        $scope.goingToApporve = true;
                    }
                    getAATimesheet(caseData.caseNumber)
                }else{
                    if(caseData.araCaseStatus.indexOf('Adjudicator Time Cost Request') != -1 && caseData.araCaseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') == -1 && caseData.araCaseStatus.indexOf('SMC Officer Approve Adjudicator Time Sheet') == -1){
                        $scope.goingToApporve = true;
                    }else if(caseData.araCaseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') != -1 && caseData.araCaseStatus.indexOf('Time Sheet ReSubmitted') != -1){
                        $scope.goingToApporve = true;
                    }
                    getARATimeSheet(caseData.caseNumber)
                }
        }

        function getAATimesheet(caseNo){
            var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
                GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNo;
                angular.element(".overlay").css("display","block");
                angular.element(".loading-container").css("display","block");
                $http.get(GetTimeSheetDataUrl).then(function (data) {
                    console.log("data", data)
                    angular.element(".overlay").css("display","block");
                    angular.element(".loading-container").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                    $scope.timeSheetData = data.data.result;
                    if ($scope.timeSheetData.supportingDocument) {
                        $scope.supprtDocumentName = $scope.timeSheetData.supportingDocument.name;
                        $scope.supportingDocument = $scope.timeSheetData.supportingDocument.fileLocation;
                        $scope.attachcopyStatus = true;
                    }
                    $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
        }

        function getARATimeSheet(caseNo){
            var GetTimeSheetDataUrl = smcConfig.services.ViewARATimeSheetOfficer.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNo;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 angular.element(".overlay").css("display","block");
                    angular.element(".loading-container").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                 $scope.fullTimeSheetData = data.data.result.timeSheetDTOs;
                 $scope.timeSheetData = data.data.result.timeSheetDTOs[0];
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
                 if (data.data.result.timeSheetDTOs[1]) {
                     $scope.timeSheetData1 = data.data.result.timeSheetDTOs[1];
                     if ($scope.timeSheetData1.workedHours) {
                         $scope.workingDatas1 = $scope.timeSheetData1.workedHours;
                     }
                 }
                 if (data.data.result.timeSheetDTOs[2]) {
                     $scope.timeSheetData2 = data.data.result.timeSheetDTOs[2];
                     if ($scope.timeSheetData2.workedHours) {
                         $scope.workingDatas2 = $scope.timeSheetData2.workedHours;
                     }
                 }
             });
        }
        //close time sheet
        $scope.closetimesheetpopup = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".timeSheet-progress-modal").css("display", "none");
        }

        $scope.sendResponseTimeSheet = function(caseNumber,timeSheetDetail,status){
            var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(timeSheetDetail.comments),
                 "actionType": status
             }
             DataService.post('OfficerResponseToTimeSheet', query).then(function (data) {
                if(status == "Approve"){
                    var suc_msg = "Time sheet approved successfully"
                }else{
                    var suc_msg = "Time sheet requested for change successfully"
                }
                NotifyFactory.log('success',suc_msg);
                get_cancelled_caselist();
                angular.element(".overlay").css("display", "none");
                angular.element(".timeSheet-progress-modal").css("display", "none");

             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
        }

        $rootScope.updateCaseNumberSession = false;
        $scope.updateAA1Form = function (casenumber) {
            var casenumber = casenumber;
            getCaseDetail(casenumber);
        }

        $scope.updateARForm = function (casenumber) {
            $rootScope.casenumber = casenumber;
            $state.go("smclayout.membershiplayout.updatear");
        }


        // get single case list based on case number 
        function getCaseDetail(casenumber) {
            angular.element(".overlay").css("display", "block");
            angular.element(".timeSheet-progress-modal").css("display", "block");
            var serviceGetSingleCaseListUrl = smcConfig.services.GetSingleCaseList.url;
            serviceGetSingleCaseListUrl = serviceGetSingleCaseListUrl + "/" + casenumber;
            $http.get(serviceGetSingleCaseListUrl).then(function (data) {
                    angular.element(".overlay").css("display", "none");
                    angular.element(".timeSheet-progress-modal").css("display", "none");
                    console.log('Case Details', data.data.result);
                    $rootScope.caseDetailObj = {};
                    $rootScope.caseDetailObj = data.data.result;
                    $rootScope.updateCaseNumberSession = true;
                    $state.go("smclayout.membershiplayout.updateaa1");
                })
                .catch(function (error) {
                    angular.element(".overlay").css("display", "none");
                    angular.element(".timeSheet-progress-modal").css("display", "none");
                    console.log('errorcaselist', error);
                });
        }
        $scope.caseStatusPopup = function (index, caseNo, caseType) { //function that sets the value of selectedRow to current index
                $scope.loading = true;
                $scope.selectedRow = index;
                $scope.caseStatusCaseNo = caseNo;
               /*Getting full status list */
                if (caseType == 'AA Case') {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.AACaseStatusList;
                } else {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.ARACaseStatusList;
                }


                console.log("caseNO" + caseNo);
                $scope.missedStatus = false;
                var healthCheck = smcConfig.services.GetHealthCheckForAdjudicationCase.url;
                var healthCheckUrl = healthCheck + caseNo;
                $http.get(healthCheckUrl).then(function (healthData) {
                    if (healthData.data.status == 'SUCCESS') {
                        $scope.loading = false;
                        $scope.yetToProcessStatusList = healthData.data.result.yetToProcessStatusList;
                        $scope.missedStatusList = healthData.data.result.missedStatusList;
                        $scope.processStatusList = healthData.data.result.processStatusList;
                        angular.element(".overlay").css("display", "block");
                        angular.element(".case_status_modal").css("display", "block");

                    } else {
                        NotifyFactory.log('error', "error");
                    }
                });






            }
            //close refund notify popup
        $scope.caseStatusPopupClose = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case_status_modal").css("display", "none");
        }
        $scope.options = {
            readOnly : true,
            toolbar: []
        };
    }
})();
