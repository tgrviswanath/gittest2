(function() {
    'use strict';
    angular
        .module('smc')
        .controller('memberCaseListCtrl',memberCaseListCtrl);

    memberCaseListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function memberCaseListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
       if (($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management') || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
      $scope.changedFromDate=0;
      $scope.fromDateChange=function(){
          var fromDate=$scope.filter.dateFrom;
          var toDate=$scope.filter.dateTo;
            $scope.changedFromDate=fromDate;
            $( "#filteToDtae" ).datepicker( "option", "minDate",fromDate );			
            if((new Date(fromDate)) > (new Date(toDate)))
              {				
                $scope.filter.dateTo = undefined;
              }
      }
      $scope.userRole = $cookies.get('roleName');
      $scope.filter = {};
      // to receive filter case list
        $scope.$on('activeTab', function(event, tabStatus) { 
            $scope.currentTab = tabStatus;
        });

      // this function filter case list by query value
      $scope.getFilterCeses = function(filter){
       
        $scope.$broadcast('filterCases',filter);
      }
     

      // to get all values
      $scope.resetcases = function(){
        $scope.filter = {};
       $scope.$broadcast('resetCases','reset');
      }

      
  	}
})();