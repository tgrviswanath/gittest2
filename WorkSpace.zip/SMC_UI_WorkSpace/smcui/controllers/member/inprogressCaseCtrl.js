 (function() {
    'use strict';
    angular
        .module('smc')
        .controller('inprogressCaseCtrl',inprogressCaseCtrl);

    inprogressCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','$window','$sce','healthCheckConfig'];

    function inprogressCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,$window,$sce,healthCheckConfig){
        $scope.casestatus_modal_path = 'views/member/case-status.html';
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.roleName = $cookies.get('roleName');
        $scope.reverseSort = false;
        $scope.pattern = patternConfig;
        $scope.canceldetail = {};
        $rootScope.casedetail={};
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'inprogress'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber') );
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_inprogress_caselist($scope.pagenumber);//call to inprogress case list function
        $cookies.put('currentTab','inprogress')
        $scope.$emit('activeTab',$cookies.get('currentTab'));//sent current tab status
        $scope.receipt = {};
        $scope.shownodataavailable = false;
        $scope.downloadUrl = smcConfig.services.DownloadSupportingDocument.url;
        $scope.downloadServiceUrl = smcConfig.services.DownloadSupportingDocument.url;
        $scope.update_payeename_modal_path = 'views/member/update-payeename-modal.html';
        $scope.schedule_templatefile = 'views/common/case-schedule.html';
        $scope.message_window_Path = 'views/adjudicator/messagewindow.html';
        $scope.cancel_application_modal_path = 'views/member/cancel-application.html'
        $scope.withdraw_application_modal_path = 'views/member/withdraw-application.html'
        $scope.request_deposit_modal_path = 'views/member/request_deposit.html';
        $scope.review_Determination_Path = 'views/member/reviewdetermination.html';
        $scope.resignation_withdraw_modal_path = 'views/popups/resignation_withdraw_modal.html';
        $scope.resignation_timecost_Path = 'views/popups/resignation_timecost_modal.html';
        $scope.eMailLogModelPath = 'views/member/email-log.html';
        $scope.eFaxModelPath = 'views/member/e-fax.html';
        $scope.eFaxViewModelPath = 'views/member/e-fax-view.html';

        $scope.smcManagerResignationApproveStatus = false;
        
        $rootScope.inprocesscaselist = function(){
            get_inprogress_caselist($cookies.get('pageNumber'));
        } 
        //get inprogress case list
        function get_inprogress_caselist(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber) 
            var query = {
                "pageIndex":$scope.pagenumber, 
                "dataLength":$scope.dataLength, 
                "sortingColumn":null, 
                "sortDirection":null, 
                "claimantName":null, 
                "respondentName":null, 
                "tempCaseNumber":null, 
                "claimedAmountFrom":null, 
                "claimedAmountTo":null, 
                "dateFrom":null, 
                "dateTo":null,  
            }
            getAllInProgressCases(query);
        }

        //get all in-progress cases
        function getAllInProgressCases(query){
             angular.element(".overlay").css("display","block");
		     angular.element(".loading-container").css("display","block");
            DataService.post('GetInprogressCaseList',query).then(function (data) {              
                if(data.status == 'SUCCESS'){
                    if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                    }
                    angular.element(".loading-container").css("display","none");
                    $scope.inprogress_Case_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    for(var index = 0;index<$scope.inprogress_Case_List.length;index++){
                        if($scope.inprogress_Case_List[index].caseStatus){
                            $scope.caseNo=$scope.inprogress_Case_List[index].caseNumber;
                            $scope.inprogress_Case_List[index].pattern_CaseNo=$scope.caseNo.substring(0, 3)+' '+$scope.caseNo.substring(3, 5)+' '+$scope.caseNo.substring(5, 9)+' of '+$scope.caseNo.substring(9, 13);
                            
                            $scope.inprogress_Case_List[index].arSubmittedStatus = findStatus($scope.inprogress_Case_List[index].caseStatus, "AR Submitted");
                            $scope.inprogress_Case_List[index].lodgedStatus = findStatus($scope.inprogress_Case_List[index].caseStatus, "AR Lodged");
                            $scope.inprogress_Case_List[index].inviteStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicators Proposed');
                            $scope.inprogress_Case_List[index].approveStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Shortlisted Adjudicators Approved');
                            $scope.inprogress_Case_List[index].adjudicatorChangeStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Shortlisted Adjudicators Approved');
                            $scope.inprogress_Case_List[index].contactStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Shortlisted Adjudicators Invited');
                            $scope.inprogress_Case_List[index].rejectStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Mgt Rejected Shortlisted Adjudicators');
                            $scope.inprogress_Case_List[index].payeeRequest= findStatus($scope.inprogress_Case_List[index].caseStatus,'Update Payee Name Requested');
                            $scope.inprogress_Case_List[index].adjudicatorAppointedStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicator Appointed');
                            $scope.inprogress_Case_List[index].scheduleStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicator Advised On Timeline');
                            $scope.inprogress_Case_List[index].messageStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicator Initialised Message');
                            $scope.inprogress_Case_List[index].timesheetSubmitStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Time Sheet Submitted');
                            $scope.inprogress_Case_List[index].draftRequestStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Draft Determination Requested');
                            $scope.inprogress_Case_List[index].adjpaymentRequestStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicator Request Additional Deposit');
                            $scope.inprogress_Case_List[index].officerPaymentRequestStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'SMC Officer Request Additional Deposit');

                            $scope.inprogress_Case_List[index].adjResignationRequestStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicator Resignation Request');
                            $scope.inprogress_Case_List[index].adjResignationRequestApproveStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'SMC Officer Approved Adjudicator Resignation');
                            $scope.inprogress_Case_List[index].adjResignationRejectManagerStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'SMC Manager Reject Adjudicator Resignation');
                            $scope.inprogress_Case_List[index].adjResignationApproveManagerStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'SMC Manager Approve Adjudicator Resignation');
                            $scope.inprogress_Case_List[index].adjResignationTimeCostRequestStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Adjudicator Time Cost Request');
                            

                            $scope.inprogress_Case_List[index].withdrawofficerStatus= findStatus($scope.inprogress_Case_List[index].caseStatus,'Ack of Withdrawal Sent to Parties and Adju');
                        }
                        if($scope.inprogress_Case_List[index].araCaseStatus){
                            $scope.inprogress_Case_List[index].araLodgedStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "ARA Lodged");
                            $scope.inprogress_Case_List[index].araAdjApprovedStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "List of Proposed Review Adjudicator(s) Approved");
                            $scope.inprogress_Case_List[index].araInviteAdjStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "List of Proposed Review Adjudicator(s) Sent for Approval");
                            $scope.inprogress_Case_List[index].araContactStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "Proposed Review Adjudicator(s) Contacted");
                            $scope.inprogress_Case_List[index].araadjudicatorAppointedStatus= findStatus($scope.inprogress_Case_List[index].araCaseStatus,'Review Adjudicator(s) Appointed');
                            $scope.inprogress_Case_List[index].araDraftStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "ARA Draft Determination Requested");
                            $scope.inprogress_Case_List[index].araWithDrawStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "ARA Adjudicator Withdrawn Request");
                            $scope.inprogress_Case_List[index].araChangeInviteStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus, "List of Proposed Review Adjudicator(s) Rejected");
                            $scope.inprogress_Case_List[index].adjResignationRequestStatus= findStatus($scope.inprogress_Case_List[index].araCaseStatus,'Adjudicator Resignation Request');
                            $scope.inprogress_Case_List[index].adjResignationRequestApproveStatus= findStatus($scope.inprogress_Case_List[index].araCaseStatus,'SMC Officer Approved Adjudicator Resignation');
                            $scope.inprogress_Case_List[index].arawithdrawofficerStatus = findStatus($scope.inprogress_Case_List[index].araCaseStatus,'Ack of Withdrawal Sent to Parties and Adju');
                        }
                        if($scope.inprogress_Case_List[index].courierCaseDTO){
                            if($scope.inprogress_Case_List[index].courierCaseDTO.deliveryStatus == null){
                                $scope.inprogress_Case_List[index].clipColor = 'fontRed'
                            }else{
                                $scope.inprogress_Case_List[index].clipColor = 'green'
                            }
                        }else{
                            $scope.inprogress_Case_List[index].clipColor = 'grey'
                        }
                    }

                }else{
                     if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                    }
                    angular.element(".loading-container").css("display","none");
                    $scope.shownodataavailable = true;
                }
            }).catch(function (error) {
                  if($scope.isRefundOverlay != true){
                        angular.element(".overlay").css("display","none");
                    }
                    angular.element(".loading-container").css("display","none");
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
            });
        }

          $scope.viewCourierStatus=function(clipColor,id){
              $scope.courierDetailId=id;
              if(clipColor=='green'){   
                    angular.element(".overlay").css("display","block");
		            angular.element(".loading-container").css("display","block");           
                    var viewCourierStatusData = smcConfig.services.ViewCourierStatus.url; 
                    var viewCourierStatusUrl = viewCourierStatusData + id;
                    $http.get(viewCourierStatusUrl).then(function(data){
                            angular.element(".overlay").css("display","none");
		                    angular.element(".loading-container").css("display","none");                        
                            angular.element(".courier-details").css("display","block");
                            angular.element(".overlay").css("display","block");
                            $rootScope.viewCourierStatusDetails = data.data.result;
                            if($rootScope.viewCourierStatusDetails.serviceAcknowledgement==null){
                               $scope.serviceAcknowledgement="Processing";
                            }else{
                                 $scope.serviceAcknowledgement=$rootScope.viewCourierStatusDetails.serviceAcknowledgement;
                            }
                    })
                    .catch(function(error){
                        console.log('errorcaselist',error);
                        angular.element(".overlay").css("display","none");
		                angular.element(".loading-container").css("display","none");
                    });
              }            
        }
         $scope.cancelModCase = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".courier-details").css("display","none");
        }

        //E-Fax

        $scope.viewEfaxStatus=function(caseNumber,pageNumber){
             $scope.eFaxCaseNumber =caseNumber;
             viewFaxData(pageNumber);
        } 

        $scope.nextEfax=function(pageNumber){
            viewFaxData(pageNumber);
        }

        function viewFaxData(pageNumber){
             if(pageNumber){
                     $scope.eFaxPagenumber  = pageNumber;
                }else{
                    $scope.eFaxPagenumber  = 0;
                }

              var query = {
                "pageIndex": pageNumber,
                "dataLength": 10,
                "sortingColumn": null,
                "sortDirection": null,
                "caseNumber": $scope.eFaxCaseNumber
                }

                DataService.post('ViewFaxLog', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        if(data.result.totalData>0){
                            $scope.ifEfaxnoAvailable=false;
                        }else{
                            $scope.ifEfaxnoAvailable=true;
                        }
                        
                        $scope.faxData=data.result.responseData;
                        $scope.max_Efax_Pagenumber  =  data.result.totalPages;
                        angular.element(".overlay").css("display","block");
                        angular.element(".eFax-status").css("display","block"); 
                    }
                }).catch(function (error) {
                   $scope.ifEfaxnoAvailable=true;
                    NotifyFactory.log('error', error.errorMessage);
                }); 
        }

       

        $scope.closeEfaxPopup=function(){
             angular.element(".overlay").css("display","none");
             angular.element(".eFax-status").css("display","none");
         }

         $scope.viewFaxDetail=function(faxId){
            $scope.faxId=faxId;
            var getFaxDetail = smcConfig.services.GetFaxDetail.url;
            var getFaxDetailUrl = getFaxDetail + faxId;
            $scope.downloadFaxDetail = smcConfig.services.DownloadFaxData.url;
            $http.get(getFaxDetailUrl).then(function(data){
                $scope.faxDetailsView=data.data.result;
                angular.element(".overlay").css("display","block");
                angular.element(".eFax-status").css("display","none");
                angular.element("#view_fax").css("display", "block");
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });

         }
         $scope.closeViewfax=function(){
             angular.element("#view_fax").css("display", "none");
             angular.element(".overlay").css("display","none");
         }
        $scope.uploadCourierFile = function (file) {  
                 var file = file;
                 if (file.size < 5242881) {
                     if (validateUploadFileExtention(file.name)) {
                         $scope.courierdetailfileName = file.name;                  
                         var fd = new FormData();
                         fd.append('file', file);
                         httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                             console.log(data);
                             $scope.courierdetailsupportFilePath = data.result;
                             $scope.attachcopyStatus = true;
                         });
                     } else {
                         $scope.attachcopyStatus = true;
                         $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                     }
                 } else {
                     NotifyFactory.log('error', "Please select below 5MB file");
                 }
        }
        $scope.submitCourierData=function(){           
                var query={
                      "id": $scope.courierDetailId,
                      "document": {
	                            "name":$scope.courierdetailfileName,
                                "fileLocation":$scope.courierdetailsupportFilePath
                                },
                                "smcOfficerId": $cookies.get('memberId')
                        }
                        angular.element(".overlay").css("display","block");
		                angular.element(".loading-container").css("display","block");     
                        DataService.post('UploadCourierDetail',query).then(function (data) {
                                angular.element(".overlay").css("display","none");
		                        angular.element(".loading-container").css("display","none");
                                if(data.status == 'SUCCESS'){
                                  $scope.cancelModCase();
                                  NotifyFactory.log('success', "Courier details submitted successfully");
                                }
                            }).catch(function (error) {
                                angular.element(".overlay").css("display","none");
		                        angular.element(".loading-container").css("display","none");
                                if(error.errorCode == 100){
                                  NotifyFactory.log('error', error.errorMessage);
                                }
                            });
            }

              $scope.courierattachcopyRemove = function () {
                 $scope.courierdetailfileName = undefined;
                 $scope.courierdetailsupportFilePath = undefined;
                 $scope.attachcopyStatus = false;
                 angular.element("#courierSupport_document_name").val("");
                 angular.element("#courier_suport_upload").val("");
             }

        $scope.goToPageNumber = function(pageNo){
           get_inprogress_caselist(pageNo);
        }

        // to receive filter case list
        $scope.$on('filterCases', function(event, filter) {   
            if($cookies.get('currentTab') == 'inprogress'){
                var query = {
                    "claimantName":undefinedSetNull(filter.claimantName), 
                    "respondentName":undefinedSetNull(filter.respondentName), 
                    "tempCaseNumber":undefinedSetNull(filter.caseNumber), 
                    "claimedAmountFrom":undefinedSetNull(filter.claimedAmountFrom), 
                    "claimedAmountTo":undefinedSetNull(filter.claimedAmountTo), 
                    "dateFrom":undefinedSetNull(filter.dateFrom), 
                    "dateTo":undefinedSetNull(filter.dateTo),
                    "adjudicatorName" : undefinedSetNull(filter.adjudicatorName),
                }
                getAllInProgressCases(query);             
            }
        });

        // to receive reset action 
        $scope.$on('resetCases', function(event, reset) { 
            if($cookies.get('currentTab') == 'inprogress'){
                get_inprogress_caselist(0);
            }
        });

        //show update date of receipt popup
        $scope.update_date_recepit = function(caseNumber){
            $scope.receipt.caseNumber = caseNumber;
            angular.element(".overlay").css("display","block");
            angular.element(".form-submitt-confirm").css("display","block");
        } 

        //assign case to case officer
        $scope.assignCase = function(caseNumber){
            $rootScope.casedetailNumber = caseNumber;
            $rootScope.casedetail.caseOfficerId = undefined;
            $rootScope.casedetail.assistantManagerId = undefined;
            angular.element(".overlay").css("display","block");
            angular.element(".case-submitt-confirm").css("display","block");
        }

        //submit update Recepit date
        $scope.receipt_Submit = function(receiptdetail){
            console.log('receiptdetail',receiptdetail);
            var query = {
                'caseNumber' : receiptdetail.caseNumber,
                'receiptDate' : receiptdetail.receipt_date,
            }
            console.log('query',query)
            angular.element(".overlay").css("display","block");
		    angular.element(".loading-container").css("display","block");
            DataService.post('UpdateReceiptDate',query).then(function (data) {
                if(data.status == 'SUCCESS'){
		            angular.element(".loading-container").css("display","none");
                    angular.element(".overlay").css("display","none");
                    angular.element(".form-submitt-confirm").css("display","none");
                    NotifyFactory.log('success', 'Date Updated Successfully');
                }else{
                    angular.element(".overlay").css("display","none");
		            angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
		        angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //cancel update Recepit date
        $scope.cancelreceipt = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".form-submitt-confirm").css("display","none");
        }

        //to open invite adjudicator modal 
        $scope.inviteAdjudicator = function(caseNumber,caseFromForInvite){
            $rootScope.adjdetail = {};
            $rootScope.adjdetail.adjudicator_list = [];
            $rootScope.memberName = [];
            angular.element(".adjudicator_checkbox").attr('checked', false);
            $rootScope.caseFromForInvite = caseFromForInvite;
            $rootScope.adjudiCaseNumber = caseNumber;
            $rootScope.getInviteAdjudicatorList(0,caseNumber);
            angular.element(".overlay").css("display","block");
            angular.element(".Adjudicators-modal").css("display","block");
        }
        //to close invite adjudicator modal
        $scope.closeadjudi = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".Adjudicators-modal").css("display","none");
        }

        $scope.goNextInEmailLog=function(casenumber,pageNumber){
            getEmailLogList(casenumber,pageNumber)
        }
          // show email log 
        $scope.showEmailLog=function(casenumber,pageNumber){  
            getEmailLogList(casenumber,pageNumber)
        }

        function getEmailLogList(casenumber,pageNumber){
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            $scope.eMailLogCaseNumber = casenumber;
            if(pageNumber){
                $scope.emailLogPagenumber = pageNumber;
            }else{
                $scope.emailLogPagenumber = 0;
            }
            var query={
                    "caseNumber":casenumber,
                    "pageIndex":$scope.emailLogPagenumber,
                    "dataLength":10,
                    "sortingColumn":null,
                    "sortDirection":null
            }                           
            DataService.post('GetEmailLogDetail', query).then(function (data) {
                if (data.status == 'SUCCESS') {
			            angular.element(".loading-container").css("display","none");
                        angular.element(".overlay").css("display", "block");
                        angular.element(".show-email-log").css("display", "block");
                        $scope.EmailLogdata=data.result.responseData; 
                        $scope.max_EmailLog_Pagenumber  =  data.result.totalPages;
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
            });
        }

        $scope.viewEmailLog=function(data){
            
            $scope.goingToEdit=data;
            $scope.disableEmailContent=true;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.editEmailLog=function(index){
            $scope.updateIndexContent = index;
            if($scope.EmailLogdata[index].updateContent){
                $scope.goingToEdit = $scope.EmailLogdata[index].updateContent;
            }else{
                $scope.goingToEdit = $scope.EmailLogdata[index].content;
            }
            $scope.disableEmailContent=false;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.resendEmailLog=function(data,index){ 
                         
                if(data.updateContent){
                   var contentData=data.updateContent;
                }else{
                    var contentData=data.content;
                }
                var query={
                    "id":data.id,
                    "content":contentData
                }
                angular.element(".overlay").css("display","block");
		        angular.element(".loading-container").css("display","block");
                DataService.post('ResendEmailLogDetail', query).then(function (data) {                                   
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
		                angular.element(".loading-container").css("display","none");
                        $scope.EmailLogdata[index] = data.result;
                        NotifyFactory.log('success', 'Mail sent successfully');
                    } else {
                        angular.element(".overlay").css("display","none");
		                angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
		            angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
        }
           
        $scope.cancelModCaseLog=function(){
             angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        $scope.closelistLog=function(){
            angular.element(".overlay").css("display", "none");
            angular.element(".show-email-log").css("display", "none");      
        }

         $scope.updateContent = function(updatedContent, index){
            if($scope.EmailLogdata[index].updateContent){
                if($scope.EmailLogdata[index].updateContent!= updatedContent){
                    $scope.EmailLogdata[index].updateContent = updatedContent
                }
            }
            else if($scope.EmailLogdata[index].content != updatedContent){
                $scope.EmailLogdata[index].updateContent = updatedContent;
            }
            angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        //to open update payee name modal
        $scope.updatePayeeModal = function(caseNumber){
            $rootScope.payeeCaseNumber = caseNumber;
            $rootScope.payeedetails = {};
            $rootScope.supprtDocumentName = null;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display","block");
            angular.element(".update-payee-name").css("display","block");
            $rootScope.getPayeeName();//call function
        }

        //to close update payee name modal
        $scope.closepayeepop = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".update-payee-name").css("display","none");
        }

        //get amend update payee details
        $scope.getUpdatePayeeDetails = function(caseNumber){
            $rootScope.payeeCaseNumber = caseNumber;
            var getAmendPayeeData = smcConfig.services.GetAmendPayeeData.url;
            var getAmendPayeeDataUrl = getAmendPayeeData + caseNumber;
            $http.get(getAmendPayeeDataUrl).then(function(data){
                $rootScope.payeedetails = data.data.result;
                if($rootScope.payeedetails.supportingDocument){
                    $rootScope.supprtDocumentName = $rootScope.payeedetails.supportingDocument.name;
                    $rootScope.payeedetails.fileName = $rootScope.supprtDocumentName;
                    $rootScope.payeedetails.supportFilePath = $rootScope.payeedetails.supportingDocument.fileLocation;
                    $rootScope.attachcopyStatus = true;
                }
                angular.element(".overlay").css("display","block");
                angular.element(".update-payee-name").css("display","block");
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });
        }

        //to open proposed list model
        $scope.openProposedlist = function(casedata,caseType){
             angular.element(".overlay").css("display","block");
			 angular.element(".loading-container").css("display","block");
             $scope.showInviteBtn = false;
             $scope.showAddAdjBtn = false;
             $scope.proposedList = [];
             $scope.deletedList = [];
             $scope.proposedListNames = [];
             $scope.ifOfficerAddNewAdjudicator = false;
             $scope.managementData = {};
             $scope.contactStatus = casedata.contactStatus;
             $scope.araContactStatus = casedata.araContactStatus;
             $scope.caseStatus = casedata.status;
             if(casedata.caseStatus){
                var caseFullStatus = casedata.caseStatus;
            }else{
                var caseFullStatus = casedata.araCaseStatus;
            }
            if(caseFullStatus.indexOf('Shortlisted Adjudicators Approved') != -1 || caseFullStatus.indexOf('List of Proposed Review Adjudicator(s) Approved') != -1 ){
                if(caseFullStatus.indexOf('Shortlisted Adjudicators Invited') == -1 && caseFullStatus.indexOf('Proposed Review Adjudicator(s) Contacted') == -1){
                    $scope.showInviteBtn = true;
                }else{
                    $scope.showInviteBtn = false;
                }
            }else if(caseFullStatus.indexOf('Mgt Rejected Shortlisted Adjudicators') != -1 || caseFullStatus.indexOf('List of Proposed Review Adjudicator(s) Rejected') != -1){
                if(caseFullStatus.indexOf('Shortlisted Adjudicators Invited') == -1 && caseFullStatus.indexOf('Proposed Review Adjudicator(s) Contacted') == -1){
                    if($scope.caseStatus != 'Adjudicators Proposed' && $scope.caseStatus != 'List of Proposed Review Adjudicator(s) Sent for Approval'){
                        $scope.showAddAdjBtn = true;
                    }else{
                        $scope.showAddAdjBtn = false;
                    }
                }else{
                    $scope.showAddAdjBtn = false;
                }
            }
             $rootScope.proposedCaseNumber = casedata.caseNumber;
             $scope.caseType = caseType;
             var query = {
                 "caseNumber": $rootScope.proposedCaseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId'))
             }
             DataService.post('GetProposedAdjudicators', query).then(function (data) {
			        angular.element(".loading-container").css("display","none");
                     angular.element(".overlay").css("display", "block");
                     angular.element(".proposed-list-modal").css("display", "block");
                     $scope.proposedList = data.result.proposedAdjudicators;
                     for (var proAdj in $scope.proposedList) {
                         $scope.proposedListNames.push($scope.proposedList[proAdj].memberName)
                     }
                     $scope.deletedList = data.result.deletedAdjudicators;
                     $scope.managementData = data.result.memberAction;
                     if($scope.managementData.timeOfAction){
                        var time = $scope.managementData.timeOfAction.split(' ');
                        $scope.managementData.timeOfAction = time[0].split(':')[0] + ':' + time[0].split(':')[1] + ' ' + time[1];
                     }
                 })
                 .catch(function (error) {
                     angular.element(".overlay").css("display","none");
			         angular.element(".loading-container").css("display","none");
                     console.log('errorcaselist', error)
                 });
         }
         $scope.closelist = function () {
                 angular.element(".overlay").css("display", "none");
                 angular.element(".proposed-list-modal").css("display", "none");
             }
             //select adjudicators invite type
         $scope.invite_type = function (status, case_number, caseType) {
             var query = {
                 "caseNumber": case_number,
                 "inviteType": status
             }
             if (caseType == 'AA') {
                 DataService.post('InviteTypeAdjudicators', query).then(function (data) {
                         NotifyFactory.log('success', 'Adjudicator\'s invited successfully');     
                         angular.element(".overlay").css("display", "none");
                         angular.element(".proposed-list-modal").css("display", "none");
                         get_inprogress_caselist();
                     })
                     .catch(function (error) {
                         console.log('errorcaselist', error)
                     });
             } else if (caseType == 'ARA') {
                 DataService.post('InviteTypeAdjudicatorsARA', query).then(function (data) {
                         NotifyFactory.log('success', 'Adjudicator\'s invited successfully');  
                         angular.element(".overlay").css("display", "none");
                         angular.element(".proposed-list-modal").css("display", "none");
                         get_inprogress_caselist();
                     })
                     .catch(function (error) {
                         console.log('errorcaselist', error)
                     });
             }
         }

         // to open popup model for delete adjudicator
         $scope.confirmationdelete = function (index) {
                 $scope.adjIndex = index;
                 angular.element(".proposed-list-modal").css("display", "none");
                 angular.element(".form-submitt-confirm").css("display", "block");
             }
             // to close popup model for delete adjudicator
         $scope.canceldelete = function () {
                 angular.element(".form-submitt-confirm").css("display", "none");
                 angular.element(".proposed-list-modal").css("display", "block");
             }
             //remove adjudicator from proposed list
         $scope.removeAdjudicator = function (adjIndex) {
             $scope.proposedList.splice(adjIndex, 1);
             $scope.proposedListNames.splice(adjIndex, 1);
             angular.element(".form-submitt-confirm").css("display", "none");
             angular.element(".proposed-list-modal").css("display", "block");
         }

         //if SMC Officer want add new adjudicators in proposed
         $scope.AddNewAdjudicators = function (caseNo) {
             getAdjudicatorList(0, caseNo, 'reSend')
             $scope.ifOfficerAddNewAdjudicator = true;
         }

         $scope.addadjudicatorinProposed = function (adjudicator) {
             $scope.proposedList.push(adjudicator);
         }

         $scope.closeAddAdjudicators = function () {
             $scope.ifOfficerAddNewAdjudicator = false;
         }

         $scope.resendAdjToManagement = function (caseNo, listOfAdj, caseType) {
             var query = {
                 "caseNumber": caseNo,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "adjudicatorIds": getAdjudicatorIds(listOfAdj)
             }
             if (caseType == 'AA') {
                 var serviceUrl = 'GenerateAdjudicators';
             } else if (caseType == 'ARA') {
                 var serviceUrl = 'GenerateAdjudicatorsARA';
             }
             resubmitAdjtoManager(query, serviceUrl);
         }

         function getAdjudicatorIds(listOfAdj) {
             var ids = [];
             for (var mem in listOfAdj) {
                 ids.push(listOfAdj[mem].memberId);
             }
             return ids;
         }

         function resubmitAdjtoManager(query, serviceUrl) {
             DataService.post(serviceUrl, query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Adjudicator list proposed successfully');
                     get_inprogress_caselist();
                     angular.element(".overlay").css("display", "none");
                     angular.element(".proposed-list-modal").css("display", "none");
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         $scope.getInviteAdjudicatorPageList = function (pageNo, caseNo) {
             getAdjudicatorList(pageNo, caseNo);
         }

         //to open appoint model popup
         $scope.openAppointModel = function (caseDetail) {
             getApntAdjudicatorList(0, caseDetail.caseNumber);
             $scope.filtername = undefined;
             $scope.filterType = 'All';
             $scope.supprtDocumentName = undefined;
             $rootScope.attachcopyStatus = false;
             $rootScope.appointNumber = caseDetail.caseNumber;
             $scope.appointAdjStatus = caseDetail.caseType;
             $rootScope.appoint = {};
             if(caseDetail.caseType == 'ARA Case'){
                $scope.noOfAdjAccept = caseDetail.numOfAppointedAdjudicators;
                $rootScope.appoint.selectedAdj = [];
             }
             $rootScope.appoint.adjudicatorId = '';
             angular.element(".overlay").css("display", "block");
             angular.element(".appoint-Adjudicators-Modal").css("display", "block");
         }

         function getApntAdjudicatorList(pageNumber, caseNumber) {
             angular.element(".overlay").css("display","block");
             angular.element(".loading-container").css("display","block");
             $scope.appointDataLength = 10;
             if (pageNumber) {
                 $scope.appointPagenumber = pageNumber;
             } else {
                 $scope.appointPagenumber = 0;
             }
             var query = {
                 "pageIndex": $scope.appointPagenumber,
                 "dataLength": $scope.appointDataLength,
                 "sortingColumn": null,
                 "sortDirection": null,
                 "name": null,
                 "category": 'All',
             }
             DataService.post('GetAllAdjudicatorList', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     angular.element(".loading-container").css("display","none");
                     $scope.adjudicators = data.result.responseData;
                     $scope.max_Appoint_Pagenumber = data.result.totalData / $scope.dataLength;
                     var value = Math.round($scope.max_Appoint_Pagenumber);
                     if (value < $scope.max_Invite_Pagenumber) {
                         $scope.max_Appoint_Pagenumber = value + 1;
                     } else {
                         $scope.max_Appoint_Pagenumber = value;
                     }
                 } else {
                     angular.element(".overlay").css("display","none");
                     angular.element(".loading-container").css("display","none");
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 angular.element(".overlay").css("display","none");
                 angular.element(".loading-container").css("display","none");
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

             //to close appoint model popup
         $scope.closeappoint = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".appoint-Adjudicators-Modal").css("display", "none");
         }

         $scope.addAdjToApont = function(adjId){
            if($rootScope.appoint.selectedAdj.indexOf(adjId) == -1){
                $rootScope.appoint.selectedAdj.push(adjId);
            }else{
                $rootScope.appoint.selectedAdj.splice($rootScope.appoint.selectedAdj.indexOf(adjId) , 1);
            }
         }

         $rootScope.updateCaseNumberSession = false;
         $scope.updateAA1Form = function (casenumber) {
                $cookies.put('currentActionMenu', 'Update AA-1 Form');
             var casenumber = casenumber;
             $rootScope.auditTrialCaseNumber=casenumber;
             getCaseDetail(casenumber);
         }
         $scope.updateARForm = function (casenumber) {
                $cookies.put('currentActionMenu', 'Update AR Form');
             $rootScope.casenumber = casenumber;
             $state.go("smclayout.membershiplayout.updatear");
         }


         // load AR or AA form for update
         function getCaseDetail(casenumber) {
             var serviceGetSingleCaseListUrl = smcConfig.services.GetSingleCaseList.url;
             serviceGetSingleCaseListUrl = serviceGetSingleCaseListUrl + "/" + casenumber;
             $http.get(serviceGetSingleCaseListUrl).then(function (data) {
                     console.log('Case Details', data.data.result);
                     $rootScope.caseDetailObj = {};
                     $rootScope.caseDetailObj = data.data.result;
                     $rootScope.updateCaseNumberSession = true;
                     $state.go("smclayout.membershiplayout.updateaa1");

                 })
                 .catch(function (error) {
                     console.log('errorcaselist', error);
                 });
         }
         //to open invite adjudicator popup
         $scope.openviewinvites = function (casedata) {
                angular.element(".overlay").css("display","block");
			    angular.element(".loading-container").css("display","block");
                 $scope.inviteCaseNumber = casedata.caseNumber;
                 var query = {
                     "pageIndex": 0,
                     "dataLength": 10,
                     "sortingColumn": null,
                     "sortDirection": null,
                     "caseNumber": $scope.inviteCaseNumber
                 }
                 DataService.post('ViewInviteAdjudicator', query).then(function (data) {
                         if (data.status == 'SUCCESS') {
                             angular.element(".overlay").css("display","none");
			                 angular.element(".loading-container").css("display","none");
                             $scope.inviteList = data.result.responseData;
                             angular.element(".overlay").css("display", "block");
                             angular.element(".view-invite-list-modal").css("display", "block");
                         } else {
                             angular.element(".overlay").css("display","none");
			                angular.element(".loading-container").css("display","none");
                             NotifyFactory.log('error', data.errorMessage);
                         }
                     })
                     .catch(function (error) {
                         angular.element(".overlay").css("display","none");
			            angular.element(".loading-container").css("display","none");
                         NotifyFactory.log('error', error.errorMessage);
                     });
             }
             //to open invite adjudicator popup
         $scope.closeinvitelist = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".view-invite-list-modal").css("display", "none");
         }

         $scope.openGenerateLetterList = function (caseDetail) {
             $scope.generateLetterCaseNumber = caseDetail.caseNumber;
             $scope.adjudicatorAppointedStaus = caseDetail.adjudicatorAppointedStatus ? caseDetail.adjudicatorAppointedStatus : caseDetail.araadjudicatorAppointedStatus;
             $scope.letterCaseType = caseDetail.caseType;
             angular.element(".overlay").css("display", "block");
             angular.element("#generte_pdf_list").css("display", "block");
         }
         $scope.IEBrowserStatus = false;
         $scope.generateRespondantLetter = function (casenumber) {
            angular.element(".downloadLink").html(" ");
            var generatePdfUrl = smcConfig.services.DownloadAnnexCRespondent.url;
            generatePdfUrl = generatePdfUrl + "/" + $scope.generateLetterCaseNumber;
            // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
           
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'AA Served on Respondent Letter';
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="generateLetter.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element("#generte_pdf").css("display", "block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                     angular.element("#generte_pdf").css("display", "block");
                }
            });
         }
         $scope.generateClaimantLetter = function (casenumber) {
            angular.element(".downloadLink").html(" ");
             var generatePdfUrl = smcConfig.services.DownloadAnnexCClaimant.url;
             generatePdfUrl = generatePdfUrl + "/" + casenumber;
            // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'ARA Served on Claimant Letter';
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="generateLetter.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element("#generte_pdf").css("display", "block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                     angular.element("#generte_pdf").css("display", "block");
                }
            });
         }
         $scope.generateRegulationLetter = function (casenumber) {
            angular.element(".downloadLink").html(" ");
             var generatePdfUrl = smcConfig.services.DownloadAnnexCRegulation.url;
             generatePdfUrl = generatePdfUrl + "/" + $scope.generateLetterCaseNumber;
             // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'AA Served on Principal and/or Owner Letter';
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="generateLetter.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element("#generte_pdf").css("display", "block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                     angular.element("#generte_pdf").css("display", "block");
                }
            });
         }
         $scope.generateAdjudicatorLetter = function (casenumber) {
            angular.element(".downloadLink").html(" ");
             var generatePdfUrl = smcConfig.services.DownloadAnnexGAppointment.url;
             generatePdfUrl = generatePdfUrl + "/" + $scope.generateLetterCaseNumber;
             // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            $http.get(generatePdfUrl,{responseType: 'arraybuffer'}).success(function (data) {
                if(isIE || isEdge){
                    $scope.IEBrowserStatus = true;
                    $scope.downLoadTitle = 'Letter of Confirmation of Appointment to Adjudicator';
                     var downloadfile = new Blob([data], {
                         type: 'attachment/pdf'
                     });
                     var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(downloadfile);
                    link.download="generateLetter.pdf";
                    angular.element(".downloadLink").append(link);
                    angular.element(".downloadLink a").html("Download PDF");
                    angular.element(".downloadLink a").addClass("btn");
                    angular.element(".downloadLink a").addClass("btn-primary");
                    angular.element("#generte_pdf").css("display", "block");
                } else {
                    var file = new Blob([data], {
                         type: 'application/pdf'
                    });
                    var fileURL = URL.createObjectURL(file);
                     $scope.generatedLetterData = $sce.trustAsResourceUrl(fileURL);
                     angular.element("#generte_pdf").css("display", "block");
                }
            });
         }

         $scope.closePopUp = function (popupId) {
             $scope.generateLetterCaseNumber = undefined;
             angular.element("#generte_pdf").css("display", "none");
             angular.element(".overlay").css("display", "none");
             angular.element("#" + popupId).css("display", "none");
         }

         $scope.closeOverPopUp = function (popupId) {
             angular.element("#" + popupId).css("display", "none");
             $scope.IEBrowserStatus = false;
         }

         function findStatus(array, action) {
             var a = 0;
             for (var index = 0; index < array.length; index++) {
                 if (array[index] == action) {
                     a = 1;
                 }
             }
             if (a == 1) {
                 return false;
             } else {
                 return true;
             }

         }
           // to view date of service
         $scope.viewDateOfSerice=function(caseNumber){ 
                             
              var viewDateOfSericeUrl = smcConfig.services.ViewDateOfServices.url;
             viewDateOfSericeUrl = viewDateOfSericeUrl + caseNumber;
             $http.get(viewDateOfSericeUrl).then(function (data) {
                 if(data.data.status=="SUCCESS"){
                     $scope.viewDateOfSericeData=data.data.result;
                     angular.element(".overlay").css("display", "block");
                     angular.element(".view-date-of-service-model").css("display", "block");
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
                 angular.element(".overlay").css("display", "none");
                 angular.element(".view-date-of-service-model").css("display", "none");
             });
         }
         $scope.closeViewDatepopup=function(){
              angular.element(".overlay").css("display", "none");
              angular.element(".view-date-of-service-model").css("display", "none");
         }
         //Update Cheque POsted date
         $scope.updateChequePostedDate =function(caseNumber,caseType){
            $scope.caseType=caseType;
            var viewDateOfSericeUrl = smcConfig.services.ViewChequePostedDate.url;
             viewDateOfSericeUrl = viewDateOfSericeUrl + caseNumber;   
             $http.get(viewDateOfSericeUrl).then(function (data) {                  
                 if(data.data.status=="SUCCESS"){
                   $scope.chequePostedDate=data.data.result.adjudicatorPostedDate;                     
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
                
             });
            $scope.updateCheckNumber=caseNumber;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-cheque-posted-date-model").css("display", "block"); 
                                
         }
         $scope.submitChequePostedDate=function(updateDate,caseNumber){

              var query = {
                     "caseNumber": caseNumber,
                     "smcOfficerId": parseInt($cookies.get('memberId')),
                     "claimantPostedDate": null,
                      "tabType": "Inprogress",
                     "adjudicatorPostedDate": updateDate    
                 }
                  if ($scope.caseType == 'AA Case') {
                       DataService.post('UpdateChequePostedDate', query).then(function (data) {
                         if (data.status == 'SUCCESS') {
                            angular.element(".overlay").css("display", "none");
                            angular.element(".update-cheque-posted-date-model").css("display", "none");   
                            NotifyFactory.log('success', 'Cheque posted date updated');
                         } else {
                             NotifyFactory.log('error', data.errorMessage);
                         }
                     })
                     .catch(function (error) {
                         NotifyFactory.log('error', error.errorMessage);
                     });
                  }else if($scope.caseType == 'ARA Case'){
                        DataService.post('UpdateChequePostedDateARA', query).then(function (data) {
                         if (data.status == 'SUCCESS') {
                            angular.element(".overlay").css("display", "none");
                            angular.element(".update-cheque-posted-date-model").css("display", "none");   
                            NotifyFactory.log('success', 'Cheque posted date updated');
                         } else {
                             NotifyFactory.log('error', data.errorMessage);
                         }
                     })
                     .catch(function (error) {
                         NotifyFactory.log('error', error.errorMessage);
                     });
                  }
              
         }
         $scope.closeUpdateChequepopup=function(){
             $scope.chequePostedDate=null;
             angular.element(".overlay").css("display", "none");
             angular.element(".update-cheque-posted-date-model").css("display", "none");
         }

         //view schedule detail
         $scope.getCaseSchedule = function (caseNumber) {
             $scope.schedulenumber = caseNumber;
             $scope.cancelSchedule = {};
             $scope.applyCost = [];
             var GetCaseScheduleUrl = smcConfig.services.GetCaseSchedule.url;
             GetCaseScheduleUrl = GetCaseScheduleUrl + $scope.schedulenumber;
             $http.get(GetCaseScheduleUrl).then(function (data) {
                 console.log("data", data)
                 $scope.schedule = data.data.result;
                 $scope.conferencelist = [];
                 if($scope.schedule.scheduleMeetings.length != 0){
                     for (var con in $scope.schedule.scheduleMeetings) {
                         $scope.conferencelist.push(true);
                         if ($scope.schedule.scheduleMeetings[con].isParkingRequired == true) {
                             $scope.schedule.scheduleMeetings[con].isParkingRequired = "Yes";
                         } else {
                             $scope.schedule.scheduleMeetings[con].isParkingRequired = "No";
                         }
                         $scope.applyCost.push(false)
                     }
                }else{
                    $scope.conferencelist = [true];
                }
                 if ($scope.schedule.isRoomRequired == true) {
                     $scope.schedule.isRoomRequired = "Yes";
                 } else {
                     $scope.schedule.isRoomRequired = "No";
                 }
                 angular.element(".overlay").css("display", "block");
                 angular.element(".case-schedule-officer-model").css("display", "block");
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //Get Register Vehicle Number
         $scope.getRegisterVehileNo = function (index) {
             var GetVehicleNUmberUrl = smcConfig.services.GetVehicleNUmber.url;
             GetVehicleNUmberUrl = GetVehicleNUmberUrl + $cookies.get('memberId');
             $http.get(GetVehicleNUmberUrl).then(function (data) {
                 console.log("data", data)
                 $scope.schedule.scheduleMeetings[index].vehicleRegNum = data.data.result;
             });
         }

         $scope.closeSchedulepopup = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".case-schedule-officer-model").css("display", "none");
         }

         $scope.updateSchedule = function (scheduleDetail, caseNumber) {
             console.log('schedule', scheduleDetail);
             if(scheduleDetail.scheduleMeetings.length != 0){
                for (var times in scheduleDetail.scheduleMeetings) {
                     scheduleDetail.scheduleMeetings[times].meetingStartTime = document.getElementById("startTime" + times).value;
                     scheduleDetail.scheduleMeetings[times].meetingEndTime = document.getElementById("endTime" + times).value;
                     var start_time = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[0];
                     var start_hour = start_time.split(':')[0];
                     var start_mini = start_time.split(':')[1];
                     var start_Sched = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[1];
                     var end_time = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[0];
                     var end_hour = end_time.split(':')[0];
                     var end_mini = end_time.split(':')[1];
                     var end_Sched = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[1];
                     if (start_Sched == 'am' && end_Sched == 'pm') {
                         update_schedule(scheduleDetail, caseNumber);
                     } else if (start_Sched == 'pm' && end_Sched == 'am') {
                         NotifyFactory.log('error', 'Start time should be less than end time');
                     } else if (start_Sched == end_Sched) {
                        if(start_hour == '12' && start_Sched == 'pm'){
                            update_schedule(scheduleDetail, caseNumber);
                        }
                         else if (start_hour < end_hour) {
                             update_schedule(scheduleDetail, caseNumber);
                         } else if (start_hour == start_hour) {
                             if (start_mini < end_mini) {
                                 update_schedule(scheduleDetail, caseNumber);
                             } else if (start_mini == end_mini) {
                                 NotifyFactory.log('error', 'Start time and end time should not be same');
                             } else {
                                 NotifyFactory.log('error', 'Start time should be less than end time');
                             }
                         } else if (start_hour > start_hour) {
                             NotifyFactory.log('error', 'Start time should be less than end time');
                         }
                     }
                 }
             }else{
                update_schedule(scheduleDetail, caseNumber);
             }
             
         }

         function update_schedule(scheduleDetail, caseNumber) {
             var query = BuildScheduleQuery(scheduleDetail, caseNumber)
             console.log('query', query);
             DataService.post('OfficerUpdateSchedule', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Schedule updated successfully');
                     get_inprogress_caselist($cookies.get('pageNumber'))
                     angular.element(".overlay").css("display", "none");
                     angular.element(".case-schedule-officer-model").css("display", "none");
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         $scope.isMeetingCanceled = function () {
             if ($scope.cancelSchedule.isMeetingCancel) {
                 for (var meet in $scope.schedule.scheduleMeetings) {
                     $scope.schedule.scheduleMeetings[meet].numberOfAttendees = 0;
                     $scope.schedule.scheduleMeetings[meet].cost = 0;
                 }
                 $scope.cancelSchedule.cancellationCost = null;
             } else {
                 for (var meet in $scope.schedule.scheduleMeetings) {
                     $scope.schedule.scheduleMeetings[meet].numberOfAttendees = null;
                     $scope.schedule.scheduleMeetings[meet].cost = null;
                 }
             }
         }


         $scope.applyMeetingCost = function (value, index) {
             if (value) {
                 if ($scope.cancelSchedule.cancellationCost) {
                     $scope.schedule.scheduleMeetings[index].cost = $scope.cancelSchedule.cancellationCost;
                 } else {
                     $scope.schedule.scheduleMeetings[index].cost = 0;
                 }
             } else {
                 $scope.schedule.scheduleMeetings[index].cost = 0;
             }
         }

         $scope.changeCancellationCost = function () {
             for (var index in $scope.applyCost) {
                 if ($scope.applyCost[index]) {
                     if ($scope.cancelSchedule.cancellationCost) {
                         $scope.schedule.scheduleMeetings[index].cost = $scope.cancelSchedule.cancellationCost;
                     } else {
                         $scope.schedule.scheduleMeetings[index].cost = 0;
                     }
                 } else {
                     $scope.schedule.scheduleMeetings[index].cost = 0;
                 }
             }
         }

         function setvalue(value) {
             if (value == 'Yes') {
                 return true;
             } else {
                 return false;
             }

         }

         //build query for schedule
         function BuildScheduleQuery(scheduleDetail, caseNumber) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "arLodgedDueDate": undefinedSetNull(scheduleDetail.arLodgedDueDate),
                 "commencementDate": scheduleDetail.commencementDate,
                 "determineDuedate": scheduleDetail.determineDuedate,
                 "claimantReplyDeadline": undefinedSetNull(scheduleDetail.claimantReplyDeadline),
                 "respondentResponseDeadline": undefinedSetNull(scheduleDetail.respondentResponseDeadline),
                 "claimantFinalReplyDeadline": undefinedSetNull(scheduleDetail.claimantFinalReplyDeadline),
                 "isRoomRequired": setvalue(scheduleDetail.isRoomRequired),
             }
             query.scheduleMeetings = [];
             for (var meet in scheduleDetail.scheduleMeetings) {
                 var meetings = {
                     "id": scheduleDetail.scheduleMeetings[meet].id,
                     "meetingDate": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingDate),
                     "meetingStartTime": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingStartTime),
                     "meetingEndTime": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingEndTime),
                     "isParkingRequired": setvalue(scheduleDetail.scheduleMeetings[meet].isParkingRequired),
                     "vehicleRegNum": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].vehicleRegNum),
                     "venue": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].venue),
                     "cost": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].cost),
                     "numberOfAttendees": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].numberOfAttendees),
                 }
                 query.scheduleMeetings.push(meetings)
             }
             return query;
         }



         // to open modal for cancel application
         $scope.open_cancel_modal = function (caseNumber, caseFrom) {
                 $scope.caseFrom = caseFrom;
                 $rootScope.cancelCaseNumber = caseNumber;
                 $scope.canceldetail = {};
                 $scope.supprtDocumentName = '';
                 document.getElementById('suport_upload').value = '';
                 $scope.canceldetail.supportFilePath = '';
                 $scope.attachcopyStatus = false;
                 getReasons();
                 angular.element(".overlay").css("display", "block");
                 angular.element(".cancel-application-modal").css("display", "block");
             }
             // to close modal for cancel application
         $scope.closecancelmodal = function () {
             $scope.canceldetail = {};
             $scope.supprtDocumentName = '';
             $scope.attachcopyStatus = false;
             angular.element(".overlay").css("display", "none");
             angular.element(".cancel-application-modal").css("display", "none");
         }

         // upload a file - before that check file size,valid exetension
         $scope.uploadCancelFile = function (file) {
                 var file = file;
                 if (file.size < 5242881) {
                     if (validateUploadFileExtention(file.name)) {
                         $scope.supprtDocumentName = file.name;

                         $scope.canceldetail.fileName = $scope.supprtDocumentName;
                         var fd = new FormData();
                         fd.append('file', file);
                         httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                             console.log(data);
                             $scope.canceldetail.supportFilePath = data.result;
                             $scope.attachcopyStatus = true;
                         });
                     } else {
                         $scope.attachcopyStatus = true;
                         $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                     }
                 } else {
                     NotifyFactory.log('error', "Please select below 5MB file");
                 }
             }
             // check valid file by exetension
         function validateUploadFileExtention(val) {
             var allowedExt = $scope.fileUploadTypes;

             var ext = val.split('.').pop();
             for (var i = 0; i < allowedExt.length; i++) {
                 if ($scope.fileUploadTypes[i] == ext) {
                     return true;
                 }
             }
         }
         // if we want remove upload file
         $scope.cancelattachcopyRemove = function () {
                 $scope.supprtDocumentName = undefined;
                 $scope.canceldetail.fileName = undefined;
                 $scope.canceldetail.supportFilePath = undefined;
                 $scope.attachcopyStatus = false;
                 angular.element("#supprt_document_name").val("");
                 angular.element("#cancel_suport_upload").val("");
             }
             // Submit Cancel Apllication
         $scope.submitCancel = function (cancelData, caseNumber, caseFrom) {
             var query = buildQuery(cancelData, caseNumber);
             console.log('query', query);
             if (caseFrom == 'AA') {
                 cancelAAapplication(query);
             } else if (caseFrom == 'ARA') {
                 cancelARAapplication(query);
             }
         }

         //cancel aa application
         function cancelAAapplication(query) {
             DataService.post('CancelApplication', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Cancel application submitted successfully');
                     if(data.result.isRefundApplicable){
                        $scope.isRefundOverlay = true;
                        angular.element(".overlay").css("display", "block");
                         angular.element(".refund-notify-modal").css("display", "block");
                         angular.element(".cancel-application-modal").css("display", "none");
                     }else{
                        angular.element(".overlay").css("display", "none");
                        angular.element(".cancel-application-modal").css("display", "none");
                     }
                     get_inprogress_caselist($cookies.get('pageNumber'));
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //close refund notify popup
         $scope.closeRefundnotifyPopup = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".refund-notify-modal").css("display", "none");
         }

         //cancel ara application
         function cancelARAapplication(query) {
             DataService.post('CancelARAApplication', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Cancel application submitted successfully');
                     if(data.result.isRefundApplicable){
                        $scope.isRefundOverlay = true;
                        angular.element(".overlay").css("display", "block");
                         angular.element(".refund-notify-modal").css("display", "block");
                         angular.element(".cancel-application-modal").css("display", "none");
                     }else{
                        angular.element(".overlay").css("display", "none");
                        angular.element(".cancel-application-modal").css("display", "none");
                     }
                     get_inprogress_caselist($cookies.get('pageNumber'));
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }
         // build query for cancel application
         function buildQuery(cancelData, caseNumber) {
             var query = {
                 "caseNumber": caseNumber,
                 "requesterRole": cancelData.requestedRole,
                 "requestedDate": cancelData.request_date,
                 "smcOfficerId": $cookies.get('memberId'),
                 "supportingDocument": {
                     "name": cancelData.fileName,
                     "fileLocation": cancelData.supportFilePath
                 }
             }
             if (cancelData.reason != 'Others') {
                 query['reason'] = cancelData.reason;
             } else {
                 query['reason'] = cancelData.stateReason;
             }

             return query;
         }

         //open request TopUp model
         $scope.openRequestDeposit = function (caseNumber, topUpCaseType) {
             $scope.loginRole = $cookies.get('roleName');
             $scope.topUpCaseNumber = caseNumber;
             $scope.topUpCaseType = topUpCaseType;
             var viewAdditionalDepositUrl = smcConfig.services.viewAdditionalDeposits.url;
             viewAdditionalDepositUrl = viewAdditionalDepositUrl + caseNumber;
             $http.get(viewAdditionalDepositUrl).then(function (data) {
                 console.log("data", data)
                 $scope.topUpData = data.data.results[data.data.results.length - 1];
             });
             angular.element(".overlay").css("display", "block");
             angular.element(".Request-TopUp-Model").css("display", "block");
         }

         //close Messaging window between claimant/respondent and adjudicator
         $scope.closerequestTopUp = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".Request-TopUp-Model").css("display", "none");
         }

         // To Submit Request for additional deposit
         $scope.submitTopUpRequest = function (requestData, caseNumber, topUpCaseType) {
             var query = buildtopUpQuery(requestData, caseNumber);
             if (topUpCaseType == 'AA Case') {
                 DataService.post('SentDepositRequestClaimant', query).then(function (data) {
                     if (data.status == 'SUCCESS') {
                         NotifyFactory.log('success', 'Topup request approved successfully');
                         get_inprogress_caselist();
                         angular.element(".overlay").css("display", "none");
                         angular.element(".Request-TopUp-Model").css("display", "none");
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             } else if (topUpCaseType == 'ARA Case') {
                 DataService.post('SentARADepositRequestClaimant', query).then(function (data) {
                     if (data.status == 'SUCCESS') {
                         NotifyFactory.log('success', 'Topup request approved successfully');
                         get_inprogress_caselist();
                         angular.element(".overlay").css("display", "none");
                         angular.element(".Request-TopUp-Model").css("display", "none");
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             }

         }

         function buildtopUpQuery(requestData, caseNumber) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "amount": requestData.amount,
                 "dueDateDetermination": requestData.determineDueDate,
                 "depositDeadLine": requestData.depositDeadline
             }
             return query;
         }
         //view all messages
         $scope.viewMessages = function (caseNumber) {
             $scope.sendData = {}
             $scope.supprtDocumentName = '';
             $scope.sendData.caseNumber = caseNumber;
             var loginRole = $cookies.get('roleName');
             $rootScope.loginRole = loginRole[0].toUpperCase() + loginRole.slice(1);
             var query = {
                 "caseNumber": caseNumber,
                 "searchRole": null,
                 "memberRole": $rootScope.loginRole
             }
             DataService.post('ViewMessages', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     $scope.messages = data.results;
                     angular.element(".overlay").css("display", "block");
                     angular.element(".messaging-view-modal").css("display", "block");
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //close Messaging window between claimant/respondent and adjudicator
         $scope.closeMessageWindow = function () {
                 angular.element(".overlay").css("display", "none");
                 angular.element(".messaging-view-modal").css("display", "none");
             }
             // open and review timesheet and determination
         $scope.openDeterminationSheet = function (caseNumber, determineCaseType) {
             $scope.viewCaseNumber = caseNumber;
             $scope.determineCaseType = determineCaseType;
             $rootScope.reviewComment = {};
             if (determineCaseType == 'AA Case') {
                 gettimesheetList($scope.viewCaseNumber);
             } else if (determineCaseType == 'ARA Case') {
                 getARAtimesheetList($scope.viewCaseNumber);
             }
             getDeterminationList($scope.viewCaseNumber);
             angular.element(".overlay").css("display", "block");
             angular.element(".view-timesheet-determination").css("display", "block");
         }

         // close and review timesheet and determination
         $scope.closeDeterminationSheet = function (caseNumber) {
             angular.element(".overlay").css("display", "none");
             angular.element(".view-timesheet-determination").css("display", "none");
         }

         //get all determination list
         function getDeterminationList(caseNumber) {
             var GetDeterminationListUrl = smcConfig.services.GetDeterminationList.url;
             GetDeterminationListUrl = GetDeterminationListUrl + caseNumber;
             $http.get(GetDeterminationListUrl).then(function (data) {
                 console.log("data", data)
                 $scope.DeterminationList = data.data.result;
                 $scope.determinations = $scope.DeterminationList.determinationVersions;
             });
         }
         //get AA all timesheet list
         function gettimesheetList(caseNumber) {
             var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNumber;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 $scope.timeSheetData = data.data.result;
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
             });
         }

         //get ARA all timesheet list
         function getARAtimesheetList(caseNumber) {
             var GetTimeSheetDataUrl = smcConfig.services.ViewARATimeSheetOfficer.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNumber;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 $scope.fullTimeSheetData = data.data.result.timeSheetDTOs;
                 $scope.timeSheetData = data.data.result.timeSheetDTOs[0];
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
                 if (data.data.result.timeSheetDTOs[1]) {
                     $scope.timeSheetData1 = data.data.result.timeSheetDTOs[1];
                     if ($scope.timeSheetData1.workedHours) {
                         $scope.workingDatas1 = $scope.timeSheetData1.workedHours;
                     }
                 }
                 if (data.data.result.timeSheetDTOs[2]) {
                     $scope.timeSheetData2 = data.data.result.timeSheetDTOs[2];
                     if ($scope.timeSheetData2.workedHours) {
                         $scope.workingDatas2 = $scope.timeSheetData2.workedHours;
                     }
                 }
             });
         }

         //response for determonation & time shreet
         $scope.sendResponse = function (response, caseNumber, determination, versionId, determineCaseType,fullTimeSheetData) {
             if (determineCaseType == 'AA Case') {
                    timesheetResponse(response, caseNumber, determination,versionId);
                 
                 angular.element(".overlay").css("display", "none");
                 angular.element(".view-timesheet-determination").css("display", "none");
             } else if (determineCaseType == 'ARA Case') {
                 ARAtimesheetResponse(response, caseNumber, determination,versionId,fullTimeSheetData);
                 angular.element(".overlay").css("display", "none");
                 angular.element(".view-timesheet-determination").css("display", "none");
             }
         }

         //response for AA determination
         function determinationResponse(response, caseNumber, determination, versionId) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(determination.determinationComment),
                 "versionId": versionId,
                 "versionStatus": response
             }
             if(response == 'Changes Required'){
                var requestMsg = "Determination requested for change successfully"
             }else{
                var requestMsg = "Determination request approved successfully"
             }
             DataService.post('OfficerResponseToDetermination', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', requestMsg);
                     get_inprogress_caselist();
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //response for ARA determination
         function ARAdeterminationResponse(response, caseNumber, determination, versionId) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(determination.determinationComment),
                 "versionId": versionId,
                 "versionStatus": response
             }
             if(response=="Approve"){
                var successMsg="Determination request approved successfully";
             }else{
                 var successMsg="Determination requested for change successfully";
             }
             DataService.post('OfficerResponseToARADetermination', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', successMsg);
                     get_inprogress_caselist();
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         // response for AA timesheet
         function timesheetResponse(response, caseNumber, determination,versionId) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(determination.timeSheetComment),
                 "actionType": response
             }
             DataService.post('OfficerResponseToTimeSheet', query).then(function (data) {
                 console.log('data', data);
                 determinationResponse(response, caseNumber, determination, versionId);
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         // response for ARA timesheet
         function ARAtimesheetResponse(response, caseNumber, determination,versionId,fullTimeSheetData) {
                var query = {
                     "caseNumber": caseNumber,
                     "smcOfficerId": parseInt($cookies.get('memberId')),
                     "comments": undefinedSetNull(determination.timeSheetComment),
                     "actionType": response
                 }
                 DataService.post('SubmitARATimeSheetofficer', query).then(function (data) {
                        ARAdeterminationResponse(response, caseNumber, determination, versionId);
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
         }

         //cancel schedule process
         $scope.cancelScheduleSubmit = function (caseNumber, scheduleId, cancelData) {
             var query = {
                 "scheduleId": scheduleId,
                 "caseNumber": caseNumber,
                 "isMeetingCancel": cancelData.isMeetingCancel,
                 "cancellationCost": undefinedSetNull(cancelData.cancellationCost)
             }
             DataService.post('CancelSchedule', query).then(function (data) {
                 get_inprogress_caselist();
                 NotifyFactory.log('success', 'Schedule cancelled successfully');
                 angular.element(".overlay").css("display", "none");
                 angular.element(".case-schedule-officer-model").css("display", "none");
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //open withdraw application modal
         $scope.openWithdrawmodal = function (caseData) {
                 $scope.withdrawCaseNumber = caseData.caseNumber;
                 $scope.withdrawCaseType = caseData.caseType;
                 if(caseData.determineDueDate){
                    $scope.finalDatetoDeter = caseData.determineDueDate;
                 }
                 $scope.startDateofDeter = caseData.lodgedDate;
                 $scope.withdrawdetail = {};
                 $scope.supprtDocumentName = '';
                 $scope.canceldetail.supportFilePath = '';
                 $scope.attachcopyStatus = false;
                 var GetWithDrawDetailsUrl = smcConfig.services.GetWithDrawDetails.url;
                 GetWithDrawDetailsUrl = GetWithDrawDetailsUrl + $scope.withdrawCaseNumber;
                 $http.get(GetWithDrawDetailsUrl).then(function (data) {
                     console.log("data", data)
                     $scope.withdrawdetail = data.data.result;
                     if ($scope.withdrawdetail.reason) {
                         $scope.withdrawdetail.stateReason = $scope.withdrawdetail.reason;
                         $scope.withdrawdetail.reason = 'Others';
                     }
                 });
                 getReasons();
                 angular.element(".overlay").css("display", "block");
                 angular.element(".withdraw-application-modal").css("display", "block");
             }
             //close withdraw application modal
         $scope.closewithdrawmodal = function () {
                angular.element("#supprt_document_name").val("");
                 angular.element("#suport_upload").val("");
             angular.element(".overlay").css("display", "none");
             angular.element(".withdraw-application-modal").css("display", "none");
         }

         //submit withdraw application 
         $scope.submitWithdraw = function (withdrawData, caseNumber, withdrawCaseType) {
             var query = buildWithDrawQuery(withdrawData, caseNumber);
             
             if (withdrawCaseType == 'AA Case') {
                 DataService.post('SubmitWithDrawByOfficer', query).then(function (data) {
                     if (data.status == 'SUCCESS') {
                         NotifyFactory.log('success', 'Withdraw request approved successfully');
                         get_inprogress_caselist();
                         angular.element(".overlay").css("display", "none");
                         angular.element(".withdraw-application-modal").css("display", "none");
                     } else {
                         NotifyFactory.log('error', data.data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             } else if (withdrawCaseType == 'ARA Case') {
                 DataService.post('SubmitARAWithDrawByOfficer', query).then(function (data) {
                     if (data.status == 'SUCCESS') {
                         NotifyFactory.log('success', 'Withdraw request approved successfully');
                         get_inprogress_caselist();
                         angular.element(".overlay").css("display", "none");
                         angular.element(".withdraw-application-modal").css("display", "none");
                     } else {
                         NotifyFactory.log('error', data.data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             }
         }

         //build withDraw query
         function buildWithDrawQuery(withdrawData, caseNumber) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "requesterRole": withdrawData.requesterRole ? withdrawData.requesterRole : "SMC Officer",
                 "reason": (withdrawData.reason == 'Others') ? withdrawData.stateReason : withdrawData.reason,
                 "requestedDate": withdrawData.requestedDate,
                 "document": {
                     "name": withdrawData.document ? withdrawData.document.name : $scope.supprtDocumentName,
                     "fileLocation": withdrawData.document ? withdrawData.document.fileLocation : $scope.supportingDocument
                 }
             }

             return query;
         }

         //get cancel or withDeaw reason
         function getReasons() {
             DataService.get('GetCancelApplicationReasons').then(function (data) {
                 if (data.status == 'SUCCESS') {
                     $scope.reasons = data.results;
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         /* Resignation Proess Functionality */
         $scope.attachResignationStatus = false;
         //Open Resignation Withdraw Adjudicator model
         $scope.openResignationWithdrawPopUp = function (caseDetails) {
             $scope.isRequestInitiated = false;
             var adjResignationRequestApproveStatus = caseDetails.adjResignationRequestApproveStatus;
             $scope.resignationRequestApproveStatus = adjResignationRequestApproveStatus;
             if (!caseDetails.adjResignationRequestStatus) {
                 $scope.isRequestInitiated = true;
                 $scope.downLoadResignationDoc = true;
                 var ViewAdjudicatorResignUrl = smcConfig.services.ViewResignationRequest.url;
                 ViewAdjudicatorResignUrl = ViewAdjudicatorResignUrl + caseDetails.caseNumber;
                 $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                 $http.get(ViewAdjudicatorResignUrl).then(function (respon) {
                     var data = respon.data;
                     if (data.status == 'SUCCESS') {
                         $scope.resgPopUpData = {};
                         $scope.resgPopUpData.reason = data.result.reason;
                         $scope.resignationDocumentName = data.result.document.name;
                         $scope.resignationUploadedDocument = data.result.document.fileLocation;
                         $scope.attachResignationStatus = false;
                         $scope.downLoadResignationDocURL = smcConfig.services.DownloadSupportingDocument.url + data.result.document.id;
                         $scope.loginRole = $cookies.get('roleName');
                         angular.element(".overlay").css("display", "block");
                         angular.element(".resignation-withdraw-PopUp-Model").css("display", "block");
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             } else {
                 $scope.resgPopUpData = {};
                 $scope.resignationDocumentName = undefined;
                 $scope.resignationUploadedDocument = undefined;
                 $scope.attachResignationStatus = false;
                 $scope.loginRole = $cookies.get('roleName');
                 $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                 angular.element(".overlay").css("display", "block");
                 angular.element(".resignation-withdraw-PopUp-Model").css("display", "block");
             }
         }

         //Open Resignation Withdraw Adjudicator model
         $scope.closeResignationWithdrawPopUp = function () {
             $scope.resgPopUpData = {};
             $scope.resignationDocumentName = undefined;
             $scope.resignationUploadedDocument = undefined;
             $scope.attachResignationStatus = false;
             angular.element(".overlay").css("display", "none");
             angular.element(".resignation-withdraw-PopUp-Model").css("display", "none");
         }



         //Submit Approval Adjudicator Resignation
         $scope.adjudicatorResignationSubmit = function (resgPopUpData, CaseNumber) {
             var query = {
                 "caseNumber": CaseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "comments": resgPopUpData.comments
             }
             console.log('query', query)
             DataService.post('ApproveResignationRequest', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Request submitted successfully');
                     angular.element(".overlay").css("display", "none");
                     angular.element(".resignation-withdraw-PopUp-Model").css("display", "none");
                     get_inprogress_caselist();
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         // Open and review resignation timesheet
         $scope.openResignationTimeCostPopUp = function (caseDetails) {
             $scope.viewCaseNumber = caseDetails.caseNumber;
             $scope.resignCaseFrom = caseDetails.caseType;
             $scope.viewResignationTimeSheet = true;
             $scope.viewResignationCost = false;
             $rootScope.reviewComment = {};
             gettimesheetList(caseDetails.caseNumber);
             angular.element(".overlay").css("display", "block");
             angular.element(".view-timesheet-resignation").css("display", "block");
         }

         // close and review resignation timesheet
         $scope.closeResignationTimeSheet = function (caseNumber) {
             angular.element(".overlay").css("display", "none");
             angular.element(".view-timesheet-resignation").css("display", "none");
         }

         //go to resignation another tab
         $scope.goResingationOtherTab = function (tab) {
             if (tab == 'timeSheet') {
                 gettimesheetList($scope.viewCaseNumber);
                 $scope.viewResignationTimeSheet = true;
                 $scope.viewResignationCost = false;
             } else {
                 getResignationTimeCost($scope.viewCaseNumber);
                 $scope.viewResignationCost = true;
                 $scope.viewResignationTimeSheet = false;
             }
         }

         //get all timesheet list
         function getResignationTimeCost(caseNumber) {
             var GetTimeSheetDataUrl = smcConfig.services.ViewAdjudicatorResignationTimeCost.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNumber;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 $scope.resignationTimeSheetData = data.data.result.invoiceResponseDTO;

             });
         }

         //response for Resignation time sheet
         $scope.sendResignationTimeCostSubmit = function (response, caseNumber, comments, resignCaseFrom) {
             if (resignCaseFrom == 'AA Case') {
                 resignationTimeCostSubmit(response, caseNumber, comments);
             } else if (resignCaseFrom == 'ARA Case') {
                 ARAresignationTimeCostSubmit(response, caseNumber, comments);
             }
             angular.element(".overlay").css("display", "none");
             angular.element(".view-timesheet-resignation").css("display", "none");
         }

         //response for AA Resignation
         function resignationTimeCostSubmit(response, caseNumber, comments) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(comments.resignationTimeCost),
                 "actionType": response
             }
            if(response=="Approve"){
                var successMsg="Resignation time cost approved successfully";
             }else{
                 var successMsg="Resignation time cost requested for change successfully";
             }
             DataService.post('AdjudicatorResignationTimeCostSubmitToSMCManager', query).then(function (data) {
                 get_inprogress_caselist();
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', successMsg);
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //response for ARA Resignation
         function ARAresignationTimeCostSubmit(response, caseNumber, comments) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(comments.resignationTimeCost),
                 "actionType": response
             }
             if(response=="Approve"){
                var successMsg="Resignation time cost approved successfully";
             }else{
                 var successMsg="Resignation time cost requested for change successfully";
             }
             DataService.post('AdjudicatorResignationARATimeCostSubmitToSMCManager', query).then(function (data) {
                 get_inprogress_caselist();
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', successMsg);
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }


         /* Appoint Adjudicator Functionality */


         $scope.attachcopyStatus = false;
         $scope.fileUploadTypes = ["pdf", "jpg", "jpeg", "png"];
         $scope.filterType = 'All';
         $scope.dataLength = 10;

         //to get Adjudicator list
         function getAdjudicatorList(pageNumber, caseNumber ,reSend) {
             angular.element(".overlay").css("display","block");
		     angular.element(".loading-container").css("display","block");
             $scope.appointDataLength = 10;
             if (pageNumber) {
                 $scope.appointPagenumber = pageNumber;
             } else {
                 $scope.appointPagenumber = 0;
             }
             var query = {
                 "pageIndex": $scope.appointPagenumber,
                 "dataLength": $scope.appointDataLength,
                 "sortingColumn": null,
                 "sortDirection": null,
                 "name": null,
                 "category": 'All',
             }
             DataService.post('GetAllAdjudicatorList', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
		             angular.element(".loading-container").css("display","none");
                     if(reSend != 'reSend'){
                        angular.element(".Adjudicators-modal").css("display","block");
                     }
                     $scope.adjudicators = data.result.responseData;
                     $scope.max_Appoint_Pagenumber = data.result.totalData / $scope.dataLength;
                     var value = Math.round($scope.max_Appoint_Pagenumber);
                     if (value < $scope.max_Invite_Pagenumber) {
                         $scope.max_Appoint_Pagenumber = value + 1;
                     } else {
                         $scope.max_Appoint_Pagenumber = value;
                     }
                 } else {
                     angular.element(".overlay").css("display","none");
		             angular.element(".loading-container").css("display","none");
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 angular.element(".overlay").css("display","none");
		         angular.element(".loading-container").css("display","none");
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         $scope.getAppointAdjudicatorPageList = function (pageNo, caseNo) {
             getApntAdjudicatorList(pageNo, caseNo);
         }

         //to appoint one adjudicator to case
         $scope.appointAdjudicator = function (adjudicator_detail) {
             var query = {
                 "caseNumber": $rootScope.appointNumber,
                 "adjudicatorIdList": adjudicator_detail.adjudicatorId ? [parseInt(adjudicator_detail.adjudicatorId)] : adjudicator_detail.selectedAdj,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "reason": adjudicator_detail.reason,
                 "documents": {
                     "name": $scope.supprtDocumentName,
                     "fileLocation": $scope.supportingDocument
                 }
             }
             DataService.post('AppointAdjudicator', query).then(function (data) {
                     NotifyFactory.log('success', 'Adjudicator appointed successfully');
                     get_inprogress_caselist($cookies.get('pageNumber'));
                     angular.element(".overlay").css("display", "none");
                     angular.element(".appoint-Adjudicators-Modal").css("display", "none");
                 })
                 .catch(function (error) {
                     console.log('errorcaselist', error);
                     NotifyFactory.log('error', error.errorMessage)
                 });
         }

         // upload a file - before that check file size,valid exetension
         $scope.uploadFile = function (file) {
            angular.element(".withdraw-application-modal").css("display","none");
            angular.element(".loading-container").css("display","block");
            angular.element(".overlay").css("display","block");
                 var file = file;
                 if (file.size < 5242881) {
                     if (validateUploadFileExtention(file.name)) {
                         var fd = new FormData();
                         fd.append('file', file);
                         httpPostFactory(smcConfig.services.UploadFileSubmisson.url, fd, function (data) {
                             console.log(data);
                             $scope.supprtDocumentName = file.name;
                             $scope.supportingDocument = data.result;
                             $scope.attachcopyStatus = true;
                             angular.element(".overlay").css("display","block");
                             angular.element(".loading-container").css("display","none");
                             angular.element(".withdraw-application-modal").css("display","block");
                         });
                     } else {
                         $scope.attachcopyStatus = true;
                         $scope.attachcopyErrorMsg = "You can upload only " + $scope.fileUploadTypes.toString();
                         NotifyFactory.log('error', $scope.attachcopyErrorMsg);
                         angular.element(".overlay").css("display","block");
                         angular.element(".loading-container").css("display","none");
                         angular.element(".withdraw-application-modal").css("display","block");
                     }
                 } else {
                     NotifyFactory.log('error', "Please select below 5MB file");
                     angular.element(".overlay").css("display","block");
                     angular.element(".loading-container").css("display","none");
                     angular.element(".withdraw-application-modal").css("display","block");
                 }
             }
             // check valid file by exetension
         function validateUploadFileExtention(val) {
             var allowedExt = $scope.fileUploadTypes;

             var ext = val.split('.').pop();
             for (var type = 0; type < allowedExt.length; type++) {
                 if ($scope.fileUploadTypes[type] == ext) {
                     return true;
                 }
             }
         }
         // if we want remove upload file
         $scope.attachcopyRemove = function () {
                 $rootScope.supprtDocumentName = undefined;
                 $rootScope.supportingDocument = undefined;
                 $scope.attachcopyStatus = false;
                 angular.element("#supprt_document_name").val("");
                 angular.element("#suport_upload").val("");
             }
             //to get cases by filter
         $scope.getfiltercases = function (filter_type, data_length, filter_name, caseNo) {
             var query = {
                 "pageIndex": 0,
                 "dataLength": setNumber(data_length),
                 "sortingColumn": null,
                 "sortDirection": null,
                 "name": undefinedSetNull(filter_name),
                 "category": undefinedSetNull(filter_type),
             }
             DataService.post('GetAllAdjudicatorList', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     $scope.adjudicators = data.result.responseData;
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         $scope.viewARAForm = function(caseNumber){
            $rootScope.araCaseNumber = caseNumber;
            $cookies.put('currentActionMenu', 'View ARA Form');
            $state.go('smclayout.membershiplayout.viewARAForm');
        }




         $scope.tableSorting = function (sortVal) {
             $scope.orderByField = sortVal;
             if (sortVal == $scope.sortValue) {
                 if ($scope.reverseSort) {
                     $scope.reverseSort = false;
                 } else {
                     $scope.reverseSort = true;
                 }
             } else {
                 $scope.reverseSort = false;
                 $scope.sortValue = sortVal;
             }
         }

         function undefinedSetNull(val) {
             if (val) {
                 return val;
             } else {
                 var val = null;
                 return val;
             }
             return val;
         }

         // set default length
         function setNumber(length) {
             if (length == null) {
                 return $scope.dataLength;
             }
             return length;
         }

         $scope.caseStatusPopup = function (caseNo, caseType) { 
          
             $scope.caseStatusCaseNo = caseNo;
                $scope.loading = true;
                /*Getting full status list */
                if (caseType == 'AA Case') {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.AACaseStatusList;
                } else {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.ARACaseStatusList;
                }


                console.log("caseNO" + caseType);
                $scope.missedStatus = false;
                var healthCheck = smcConfig.services.GetHealthCheckForAdjudicationCase.url;
                var healthCheckUrl = healthCheck + caseNo;
                $http.get(healthCheckUrl).then(function (healthData) {
                    if (healthData.data.status == 'SUCCESS') {
                        $scope.loading = false;
                        $scope.yetToProcessStatusList = healthData.data.result.yetToProcessStatusList;
                        $scope.missedStatusList = healthData.data.result.missedStatusList;
                        $scope.processStatusList = healthData.data.result.processStatusList;
                        console.log("$scope.missedStatusList" + $scope.processStatusList);
                        angular.element(".overlay").css("display", "block");
                        angular.element(".case_status_modal").css("display", "block");

                    } else {
                        NotifyFactory.log('error', "error");
                    }
                });


            }
            //close refund notify popup
        $scope.caseStatusPopupClose = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case_status_modal").css("display", "none");
        }

        $scope.options = {
            readOnly : true,
            toolbar: []
        };

        




     }
 })();
