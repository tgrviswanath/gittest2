(function() {
    'use strict';
    angular
        .module('smc')
        .controller('adjudicatorListCtrl',adjudicatorListCtrl);

    adjudicatorListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function adjudicatorListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        $scope.dataLength = 10;
        $scope.filterType = 'All';

        $rootScope.adjdetail = {};
        $rootScope.memberName = [];
        $rootScope.adjdetail.adjudicator_list =[];

        //getAdjudicatorList(0);
        $scope.number = $scope.dataLength;
        $scope.getNumber = function(num) {
            return new Array(num);   
        }

        $rootScope.getInviteAdjudicatorList = function(pageNumber,caseNumber){
            getInviteAdjudicatorList (pageNumber,caseNumber)
        }

        //to get Adjudicator list
    	function getInviteAdjudicatorList (pageNumber,caseNumber){
             if(pageNumber){
                $scope.invitePagenumber = pageNumber;
            }else{
                $scope.invitePagenumber = 0;
            }
    		var query = {
    			"pageIndex": $scope.invitePagenumber, 
                "dataLength":$scope.dataLength, 
                "sortingColumn":null, 
                "sortDirection":null, 
                "name":null,
                "category": 'All',
                "caseNumber": caseNumber
    		}
    		DataService.post('GetAdjudicatorsList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.adjudicators = data.result.responseData;
                    $scope.max_Invite_Pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_Invite_Pagenumber);
                    if(value < $scope.max_Invite_Pagenumber){
                        $scope.max_Invite_Pagenumber = value+1;
                    }else{
                        $scope.max_Invite_Pagenumber = value;
                    }
    			}else{
    				NotifyFactory.log('error', data.errorMessage);
    			}
    		}).catch(function (error) {
				NotifyFactory.log('error', error.errorMessage);
	        });
    	}

         $scope.getInviteAdjudicatorPageList = function(pageNo,caseNo){
           getInviteAdjudicatorList(pageNo,caseNo);
        }


    	//to invite adjudicators 
    	$scope.inviteAdjudicators = function(adj_details,caseFromForInvite){
    		var query = {
    			"caseNumber": $rootScope.adjudiCaseNumber,
                "smcOfficerId" : parseInt($cookies.get('memberId')),
    			"adjudicatorIds": adj_details.adjudicator_list
    		}
            console.log("query",query)
            if(caseFromForInvite == 'AA'){
                inviteAdjudicatorsForAA(query);
            }else if(caseFromForInvite == 'ARA'){
                inviteAdjudicatorsForARA(query);
            }
    	}
        // invite adjudicators for AA
        function inviteAdjudicatorsForAA(query){
            DataService.post('GenerateAdjudicators',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','Adjudicator list proposed successfully');
                    angular.element(".overlay").css("display","none");
                    angular.element(".Adjudicators-modal").css("display","none");
                    if($cookies.get('currentTab') == 'inprogress'){
                        $rootScope.inprocesscaselist();
                    } else {
                        $rootScope.gettodolist();
                    }
    			}else{
    				NotifyFactory.log('error', data.errorMessage);
    			}
    		}).catch(function (error) {
				NotifyFactory.log('error', error.errorMessage);
	        });
        }

        // invite adjudicators for ARA
        function inviteAdjudicatorsForARA(query){
            DataService.post('GenerateAdjudicatorsARA',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','Adjudicator list proposed successfully');
                    if($cookies.get('currentTab') == 'inprogress'){
                        $rootScope.inprocesscaselist();
                    } else {
                        $rootScope.gettodolist();
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".Adjudicators-modal").css("display","none");
    			}else{
    				NotifyFactory.log('error', data.errorMessage);
    			}
    		}).catch(function (error) {
				NotifyFactory.log('error', error.errorMessage);
	        });
        }

        //cancel assign popup
        $scope.cancelModAdj = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".Adjudicators-modal").css("display","none");
        }
        //add selected adjudicator to list
        $scope.addadjudicator = function(adjId){
            if($rootScope.adjdetail.adjudicator_list == 0){
                $rootScope.memberName.push(adjId.memberName);
                $rootScope.adjdetail.adjudicator_list.push(adjId.memberId);
            }else{
                var findindex = search(adjId.memberId,$rootScope.adjdetail.adjudicator_list);
                if(findindex != undefined){
                    $rootScope.adjdetail.adjudicator_list.splice(findindex,1)
                    $rootScope.memberName.splice(findindex,1);
                }else{
                    $rootScope.memberName.push(adjId.memberName);
                    $rootScope.adjdetail.adjudicator_list.push(adjId.memberId);
                }
            }
            console.log('adj_details',$rootScope.adjdetail.adjudicator_list)
        }
        //check already adjudicator in list if return true then delete that adjudicator
        function search(nameKey, myArray){
            for (var index=0; index < myArray.length; index++) {
                if (myArray[index] == nameKey) {
                    return index
                }
            }
        }

        //to get cases by filter
        $scope.getfiltercases = function(filter_type,data_length,caseNo){
            var query = {
                "pageIndex":0, 
                "dataLength":setNumber(data_length), 
                "sortingColumn":null, 
                "sortDirection":null, 
                "name":null,
                "category": filter_type,
                "caseNumber": caseNo
            }
            DataService.post('GetAdjudicatorsList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.adjudicators = data.result.responseData;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        // set default length
        function setNumber(length){
            if(length == null){
                return $scope.dataLength;
            }
            return length;
        }
   	}
})();
