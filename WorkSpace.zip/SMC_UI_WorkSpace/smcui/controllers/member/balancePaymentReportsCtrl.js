(function() {
    'use strict';
    angular
        .module('smc')
        .controller('blncePaymentReportsCtrl',blncePaymentReportsCtrl);

    blncePaymentReportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function blncePaymentReportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') != "SMC Officer" && $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'blncePaymentReports'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_balance_payment_reports($scope.pagenumber);//call to get balance list function
        $cookies.put('currentTab','blncePaymentReports');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get balance report list
    	function get_balance_payment_reports(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":0,
                 "dataLength":10,
                 "sortingColumn":null,
                 "sortDirection":null,
                 "sopCaseNumber":null,
                 "nameOfClaimant":null,
                 "nameOfRespondent":null,
                 "nameOfAdjudicator":null,
                 "determinationDueDateFrom":null,
                 "determinationDueDateTo":null,
                 "lodgedDateFrom":null,
                 "lodgedDateTo":null
    		}
    		getBalanceReports(query);
    	}

    	function getBalanceReports(query){
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
    		DataService.post('GetBalancePaymentReports',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.balanceList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalPages;
                    var value= Math.round($scope.max_pagenumber);
                    if($scope.balanceList.length == 0){
                        $scope.shownodataavailable = true;
                    }
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}else{
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                }
	        });
    	}

    	$scope.goToPageNumber = function(pageNo){
           get_balance_payment_reports(pageNo);
        } 

        //search reports 
        $scope.getReports = function(filterData){
            var query = {
            	"sopCaseNumber":null,
                "nameOfClaimant":null,
                "nameOfRespondent":null,
                "nameOfAdjudicator":null,
                "determinationDueDateFrom":null,
                "determinationDueDateTo":null,
                "lodgedDateFrom":null,
                "lodgedDateTo":null
            }
            getBalanceReports(query);
        }

        //reset report list
        $scope.resetreports = function(){
            $scope.filter = undefined;
            get_balance_payment_reports(0);
        }
    }
})();