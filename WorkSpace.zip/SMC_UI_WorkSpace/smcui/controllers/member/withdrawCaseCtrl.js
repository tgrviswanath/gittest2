(function () {
    'use strict';
    angular
        .module('smc')
        .controller('withdrawCaseCtrl', withdrawCaseCtrl);

    withdrawCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory','healthCheckConfig'];

    function withdrawCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory,healthCheckConfig) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.roleName = $cookies.get('roleName');

        $scope.shownodataavailable = false;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'withdraw') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.reverseSort = false;
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_withdraw_caselist($scope.pagenumber); //call to withdraw case list function
        $cookies.put('currentTab', 'withdraw');
        $scope.downloadUrl = smcConfig.services.DownloadSupportingDocument.url;
        $scope.downloadAckgServiceUrl = smcConfig.services.DownloadWithDrawAck.url;
        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status
        $scope.casestatus_modal_path = 'views/member/case-status.html';
        $scope.eFaxModelPath = 'views/member/e-fax.html';
        $scope.eFaxViewModelPath = 'views/member/e-fax-view.html';

        //call to withdraw case list function from outside
        $rootScope.withdrawcaselist = function () {
            get_withdraw_caselist($cookies.get('pageNumber'));
        }

        // get incomplete case list
        function get_withdraw_caselist(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": $scope.pagenumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "claimantName": null,
                "respondentName": null,
                "tempCaseNumber": null,
                "claimedAmountFrom": null,
                "claimedAmountTo": null,
                "dateFrom": null,
                "dateTo": null,
                "adjudicatorName": null,
                "withdrawnDate": null
            }
            getAllInWithdrawCases(query);
        }

        function getAllInWithdrawCases(query) {
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            DataService.post('GetWithDrawCaseList', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    $scope.shownodataavailable = false;
                    $scope.withdraw_Case_List = data.result.responseData;
                    for (var index = 0; index < $scope.withdraw_Case_List.length; index++) {
                        $scope.caseNo = $scope.withdraw_Case_List[index].caseNumber;
                        var result = $scope.caseNo;
                        result = result.search("SOP");
                        if (result == 0) {
                            $scope.withdraw_Case_List[index].pattern_CaseNo = $scope.caseNo.substring(0, 3) + ' ' + $scope.caseNo.substring(3, 5) + ' ' + $scope.caseNo.substring(5, 9) + ' of ' + $scope.caseNo.substring(9, 13);
                        } else {
                            $scope.withdraw_Case_List[index].pattern_CaseNo = $scope.caseNo;
                        }
                    }
                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                    for (var index = 0; index < $scope.withdraw_Case_List.length; index++) {
                        if ($scope.withdraw_Case_List[index].caseStatus) {
                            $scope.withdraw_Case_List[index].appointAdjudicatorStatus = findStatus($scope.withdraw_Case_List[index].caseStatus, "Adjudicator Appointed");
                            $scope.withdraw_Case_List[index].timesheetSubmitStatus = findStatus($scope.withdraw_Case_List[index].caseStatus, "Time Sheet Submitted");
                            $scope.withdraw_Case_List[index].additionalPaymentStatus = findStatus($scope.withdraw_Case_List[index].caseStatus, "Additional Deposit Paid / Deposit is Sufficient");
                        } else if ($scope.withdraw_Case_List[index].araCaseStatus) {
                            $scope.withdraw_Case_List[index].araappointAdjudicatorStatus = findStatus($scope.withdraw_Case_List[index].araCaseStatus, "Review Adjudicator(s) Appointed");
                            $scope.withdraw_Case_List[index].aratimesheetSubmitStatus = findStatus($scope.withdraw_Case_List[index].araCaseStatus, "ARA Time Sheet Submitted");
                            $scope.withdraw_Case_List[index].araadditionalPaymentStatus = findStatus($scope.withdraw_Case_List[index].araCaseStatus, "Additional Deposit Paid / Deposit is Sufficient");
                        }
                    }
                } else {
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
            });
        }


        $scope.goToPageNumber = function (pageNo) {
            get_withdraw_caselist(pageNo);
        }

        // to receive filter case list
        $scope.$on('filterCases', function (event, filter) {
            if ($cookies.get('currentTab') == 'withdraw') {
                var query = {
                    "claimantName": undefinedSetNull(filter.claimantName),
                    "respondentName": undefinedSetNull(filter.respondentName),
                    "tempCaseNumber": undefinedSetNull(filter.caseNumber),
                    "claimedAmountFrom": undefinedSetNull(filter.claimedAmountFrom),
                    "claimedAmountTo": undefinedSetNull(filter.claimedAmountTo),
                    "dateFrom": undefinedSetNull(filter.dateFrom),
                    "dateTo": undefinedSetNull(filter.dateTo),
                    "adjudicatorName": undefinedSetNull(filter.adjudicatorName),
                    "withdrawnDate": undefinedSetNull(filter.withdrawnDate)
                }
                getAllInWithdrawCases(query);
            }
        });

        // to receive reset action 
        $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'withdraw') {
                get_withdraw_caselist(0);
            }
        });

        //get generate memo
        $scope.getViewMemo = function (caseNumber) {
            $scope.memoCaseNumber = caseNumber;
            var GetViewGenerateMemoUrl = smcConfig.services.GetViewGenerateMemo.url;
            GetViewGenerateMemoUrl = GetViewGenerateMemoUrl + $scope.memoCaseNumber;
            $http.get(GetViewGenerateMemoUrl).then(function (data) {
                    $scope.paymentMemoData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".case-generate-memo").css("display", "block");
                })
                .catch(function (error) {
                    NotifyFactory.log('error', error.data.errorMessage);
                });
        }

        //close generate memo
        $scope.cancelMemo = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case-generate-memo").css("display", "none");
        }

        //sent approval to management
        $scope.sendApproval = function (sentData, caseNumber) {
            var query = buildApprovalQuery(sentData, caseNumber)
            DataService.post('SentDeterminedApproval', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', 'Memo sent for approval successfully');
                    get_withdraw_caselist();
                    angular.element(".overlay").css("display", "none");
                    angular.element(".case-generate-memo").css("display", "none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function buildApprovalQuery(sentData, caseNumber) {
            var query = {
                "caseNumber": caseNumber,
                "smcOfficerId": $cookies.get('memberId'),
                "claimedAmount": undefinedSetNull(sentData.claimedAmount),
                "depositAmount": undefinedSetNull(sentData.depositAmount),
                "adjudicatorFee": undefinedSetNull(sentData.adjudicatorFee),
                "invoiceNumber": undefinedSetNull(sentData.invoiceNumber),
                "smcManagementFee": undefinedSetNull(sentData.smcManagementFee),
                "paymentDueToAdjudicator": undefinedSetNull(sentData.paymentDueToAdjudicator),
                "adjudicationCost": undefinedSetNull(sentData.adjudicationCost),
                "amountPaidByClaimant": undefinedSetNull(sentData.amountPaidByClaimant),
                "amountRefund": undefinedSetNull(sentData.amountRefund),
                "claimantPayableAmount": undefinedSetNull(sentData.claimantPayableAmount)
            }

            return query
        }

        function findStatus(array, action) {
            var a = 0;
            for (var index = 0; index < array.length; index++) {
                if (array[index] == action) {
                    a = 1;
                }
            }
            if (a == 1) {
                return true;
            } else {
                return false;
            }

        }
        // to receive filter case list
        $scope.$on('filterCases', function (event, caselist) {
            if ($cookies.get('currentTab') == 'withdraw') {
                $scope.withdraw_Case_List = caselist;
            }
        });

        $rootScope.updateCaseNumberSession = false;
        $scope.updateAA1Form = function (casenumber) {
            var casenumber = casenumber;
            getCaseDetail(casenumber);
        }
        $scope.updateARForm = function (casenumber) {
            $rootScope.casenumber = casenumber;
            $state.go("smclayout.membershiplayout.updatear");
        }


        // load AR or AA form for update
        function getCaseDetail(casenumber) {
            var serviceGetSingleCaseListUrl = smcConfig.services.GetSingleCaseList.url;
            serviceGetSingleCaseListUrl = serviceGetSingleCaseListUrl + "/" + casenumber;
            $http.get(serviceGetSingleCaseListUrl).then(function (data) {
                    console.log('Case Details', data.data.result);
                    $rootScope.caseDetailObj = {};
                    $rootScope.caseDetailObj = data.data.result;
                    $rootScope.updateCaseNumberSession = true;
                    $state.go("smclayout.membershiplayout.updateaa1");

                })
                .catch(function (error) {
                    console.log('errorcaselist', error);
                });
        }

//view time Sheet
        //view time Sheet
        $scope.viewTimeSheet = function (caseData) {
            $scope.goingToApporve = false;
                $scope.ClaimantName = caseData.claimantName;
                $scope.Respond = caseData.respondentName;
                $scope.timesheetNumber = caseData.caseNumber;
                if(caseData.caseType == 'AA Case'){
                    if(caseData.caseStatus.indexOf('Adjudicator Time Cost Request') != -1 && caseData.caseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') == -1 && caseData.caseStatus.indexOf('SMC Officer Approve Adjudicator Time Sheet') == -1){
                        $scope.goingToApporve = true;
                    }else if(caseData.caseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') != -1 && caseData.caseStatus.indexOf('Time Sheet ReSubmitted') != -1){
                        $scope.goingToApporve = true;
                    }
                    getAATimesheet(caseData.caseNumber)
                }else{
                    if(caseData.araCaseStatus.indexOf('Adjudicator Time Cost Request') != -1 && caseData.araCaseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') == -1 && caseData.araCaseStatus.indexOf('SMC Officer Approve Adjudicator Time Sheet') == -1){
                        $scope.goingToApporve = true;
                    }else if(caseData.araCaseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') != -1 && caseData.araCaseStatus.indexOf('Time Sheet ReSubmitted') != -1){
                        $scope.goingToApporve = true;
                    }
                    getARATimeSheet(caseData.caseNumber)
                }
        }

        function getAATimesheet(caseNo){
            var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
                GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNo;
                angular.element(".overlay").css("display","block");
                angular.element(".loading-container").css("display","block");
                $http.get(GetTimeSheetDataUrl).then(function (data) {
                    console.log("data", data)
                    angular.element(".overlay").css("display","block");
                    angular.element(".loading-container").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                    $scope.timeSheetData = data.data.result;
                    if ($scope.timeSheetData.supportingDocument) {
                        $scope.supprtDocumentName = $scope.timeSheetData.supportingDocument.name;
                        $scope.supportingDocument = $scope.timeSheetData.supportingDocument.fileLocation;
                        $scope.attachcopyStatus = true;
                    }
                    $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
        }

        function getARATimeSheet(caseNo){
            var GetTimeSheetDataUrl = smcConfig.services.ViewARATimeSheetOfficer.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNo;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 angular.element(".overlay").css("display","block");
                    angular.element(".loading-container").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                 $scope.fullTimeSheetData = data.data.result.timeSheetDTOs;
                 $scope.timeSheetData = data.data.result.timeSheetDTOs[0];
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
                 if (data.data.result.timeSheetDTOs[1]) {
                     $scope.timeSheetData1 = data.data.result.timeSheetDTOs[1];
                     if ($scope.timeSheetData1.workedHours) {
                         $scope.workingDatas1 = $scope.timeSheetData1.workedHours;
                     }
                 }
                 if (data.data.result.timeSheetDTOs[2]) {
                     $scope.timeSheetData2 = data.data.result.timeSheetDTOs[2];
                     if ($scope.timeSheetData2.workedHours) {
                         $scope.workingDatas2 = $scope.timeSheetData2.workedHours;
                     }
                 }
             });
        }
            //close time sheet
        $scope.closetimesheetpopup = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".timeSheet-progress-modal").css("display", "none");
        }
         //E-Fax
        $scope.viewEfaxStatus=function(caseNumber,pageNumber){
             $scope.eFaxCaseNumber =caseNumber;
             viewFaxData(pageNumber);
        } 

        $scope.nextEfax=function(pageNumber){
            viewFaxData(pageNumber);
        }

        function viewFaxData(pageNumber){
             if(pageNumber){
                     $scope.eFaxPagenumber  = pageNumber;
                }else{
                    $scope.eFaxPagenumber  = 0;
                }

              var query = {
                "pageIndex": pageNumber,
                "dataLength": 10,
                "sortingColumn": null,
                "sortDirection": null,
                "caseNumber": $scope.eFaxCaseNumber
                }

                DataService.post('ViewFaxLog', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        if(data.result.totalData>0){
                            $scope.ifEfaxnoAvailable=false;                              
                        }else{
                            $scope.ifEfaxnoAvailable=true;
                        }
                        $scope.faxData=data.result.responseData;
                        $scope.max_Efax_Pagenumber  =  data.result.totalPages;
                        angular.element(".overlay").css("display","block");
                        angular.element(".eFax-status").css("display","block"); 
                    }
                }).catch(function (error) {
                    $scope.ifEfaxnoAvailable=true;
                    NotifyFactory.log('error', error.errorMessage);
                }); 
        }

       
        $scope.closeEfaxPopup=function(){
             angular.element(".overlay").css("display","none");
             angular.element(".eFax-status").css("display","none");
         }

         $scope.viewFaxDetail=function(faxId){
            $scope.faxId=faxId;
            var getFaxDetail = smcConfig.services.GetFaxDetail.url;
            var getFaxDetailUrl = getFaxDetail + faxId;
            var downloadFaxDetail = smcConfig.services.DownloadFaxData.url;
            $http.get(getFaxDetailUrl).then(function(data){
                $scope.faxDetailsView=data.data.result;
                angular.element(".overlay").css("display","block");
                angular.element(".eFax-status").css("display","none");
                angular.element("#view_fax").css("display", "block");
                
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });

         }

         $scope.closeViewfax=function(){
            angular.element("#view_fax").css("display", "none");
            angular.element(".eFax-status").css("display","block");

         }

        $scope.sendResponseTimeSheet = function(caseNumber,timeSheetDetail,status){
            var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(timeSheetDetail.comments),
                 "actionType": status
             }
             DataService.post('OfficerResponseToTimeSheet', query).then(function (data) {
                if(status == "Approve"){
                    var suc_msg = "Time sheet approved successfully"
                }else{
                    var suc_msg = "Time sheet requested for change successfully"
                }
                NotifyFactory.log('success',suc_msg);
                get_withdraw_caselist();
                angular.element(".overlay").css("display", "none");
                angular.element(".timeSheet-progress-modal").css("display", "none");

             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
        }

        function undefinedSetNull(val) {

            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }



        $scope.caseStatusPopup = function (index, caseNo, caseType) { //function that sets the value of selectedRow to current index
                $scope.loading = true;
                $scope.selectedRow = index;
                $scope.caseStatusCaseNo = caseNo;
  /*Getting full status list */
                if (caseType == 'AA Case') {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.AACaseStatusList;
                } else {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.ARACaseStatusList;
                }


                console.log("caseNO" + caseNo);

                var healthCheck = smcConfig.services.GetHealthCheckForAdjudicationCase.url;
                var healthCheckUrl = healthCheck + caseNo;
                $http.get(healthCheckUrl).then(function (healthData) {
                    if (healthData.data.status == 'SUCCESS') {
                        $scope.loading = false;
                        $scope.yetToProcessStatusList = healthData.data.result.yetToProcessStatusList;
                        $scope.missedStatusList = healthData.data.result.missedStatusList;
                        $scope.processStatusList = healthData.data.result.processStatusList;
                        console.log("success" + $scope.processStatusList);
                        angular.element(".overlay").css("display", "block");
                        angular.element(".case_status_modal").css("display", "block");
                    } else {
                        NotifyFactory.log('error', "error");
                    }
                });





            }
            //close refund notify popup
        $scope.caseStatusPopupClose = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case_status_modal").css("display", "none");
        }
        $scope.options = {
            readOnly : true,
            toolbar: []
        };
    }
})();
