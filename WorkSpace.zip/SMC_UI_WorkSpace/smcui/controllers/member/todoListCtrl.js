(function() {
    'use strict';
    angular
        .module('smc')
        .controller('todolistCtrl',todolistCtrl);

    todolistCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function todolistCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'toDoList'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.reverseSort = false;
        $scope.dataLength = 10;
        $scope.request_deposit_modal_path = 'views/member/request_deposit.html';
        $scope.review_Determination_Path = 'views/member/reviewdetermination.html';
        $scope.resignation_withdraw_modal_path = 'views/popups/resignation_withdraw_modal.html';
        $scope.max_pagenumber = '';
    	get_todo_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','toDoList');
        $scope.currentTab = 'toDoList';
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to conflicted case list function from outside
        $rootScope.gettodolist = function(){
            get_todo_list($cookies.get('pageNumber'));
        } 
        get_all_case_officer();
        get_all_assistant_manager();
        // get case officers
    	function get_all_case_officer(){
    		var query = {
    			 "moduleName":"Adjudication", 
                 "roleName":"Case Officer"
    		}
    		DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.case_officers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
    	}

        // get case officers
    	function get_all_assistant_manager(){
    		var query = {
    			"moduleName":"Adjudication",
                "roleName":'Assistant Manager'
    		}
    		DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.assistant_managers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
    	}

    	// get caseload case list
    	function get_todo_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex": $scope.pagenumber, 
                "dataLength": $scope.dataLength, 
                "sortingColumn": null, 
                "sortDirection": null, 
                "loginId": $cookies.get('memberId'),
                "caseOfficerId":null,
                "assistantManagerId":null
    		}
    		DataService.post('GetToDoList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.toDoList = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.toDoList.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    

        $scope.goToPageNumber = function(pageNo){
           get_todo_list(pageNo);
        } 

       

        //search case
            $scope.getCase = function(filterDetails){
                var query = {
                    "pageIndex": $scope.pagenumber, 
                    "dataLength": $scope.dataLength, 
                    "sortingColumn": null, 
                    "sortDirection": null, 
                    "loginId": $cookies.get('memberId'),
                    "caseOfficerId": filterDetails.caseOfficer, 
                    "assistantManagerId":filterDetails.assistantManager, 
                }
                DataService.post('GetToDoList',query).then(function (data) {
                    if(data.status == 'SUCCESS'){
                        $scope.toDoList = data.result.responseData; 
                        $scope.shownodataavailable = false;
                    }else{
                        $scope.shownodataavailable = true;
                        NotifyFactory.log('error', data.errorMessage);
                    }
                    }).catch(function (error) {
                        $scope.shownodataavailable = true;
                        NotifyFactory.log('error', error.errorMessage);
                    });
            }

            //reset users list
            $scope.resetcases = function(){
                $scope.filter = undefined;
                get_todo_list(0);
            }


            $scope.goToAction = function (caseData, action) {
                switch(action){
                    case "Arrange for Courier Service" :
                        $cookies.put('currentActionMenu', action);
                        $state.go('smclayout.membershiplayout.courierservicemanagement');
                        break;
                    case "Invite Adjudicator" : 
                        inviteAdjudicator (caseData.caseNumber,caseData.caseType);
                        break;
                    case "Process Refund" : 
                        viewRefundDetails (caseData.caseNumber,caseData.caseType);
                        break;
                    case "Request Additional Deposit" : 
                        openRequestDeposit (caseData.caseNumber,caseData.caseType);
                        break;
                    case "View adjudicator's schedule" : 
                        getCaseSchedule (caseData.caseNumber);
                        break;
                    case "View Determination & Timesheet" :
                        openDeterminationSheet(caseData.caseNumber,caseData.caseType);
                         break;
                    case "Memo to SMC management for adjudicator resignation":
                        openResignationWithdrawPopUp(caseData);
                        break;
                    default :
                        NotifyFactory.log('error','Unknown action detected')
                }
            }

            /* Resignation Proess Functionality */
            $scope.attachResignationStatus = false;
            //Open Resignation Withdraw Adjudicator model
            function openResignationWithdrawPopUp(caseDetails) {
             $scope.isRequestInitiated = false;
             var adjResignationRequestApproveStatus = caseDetails.caseStatus.indexOf('SMC Officer Approved Adjudicator Resignation') != -1 ? false : true;;
             $scope.resignationRequestApproveStatus = adjResignationRequestApproveStatus;
             if (caseDetails.caseStatus.indexOf('Adjudicator Resignation Request') != -1) {
                 $scope.isRequestInitiated = true;
                 $scope.downLoadResignationDoc = true;
                 var ViewAdjudicatorResignUrl = smcConfig.services.ViewResignationRequest.url;
                 ViewAdjudicatorResignUrl = ViewAdjudicatorResignUrl + caseDetails.caseNumber;
                 $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                 $http.get(ViewAdjudicatorResignUrl).then(function (respon) {
                     var data = respon.data;
                     if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display", "block");
                         angular.element(".resignation-withdraw-PopUp-Model").css("display", "block");
                         $scope.resgPopUpData = {};
                         $scope.resgPopUpData.reason = data.result.reason;
                         $scope.resignationDocumentName = data.result.document.name;
                         $scope.resignationUploadedDocument = data.result.document.fileLocation;
                         $scope.attachResignationStatus = false;
                         $scope.downLoadResignationDocURL = smcConfig.services.DownloadSupportingDocument.url + data.result.document.id;
                         $scope.loginRole = $cookies.get('roleName');
                         
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             } else {
                 angular.element(".overlay").css("display", "block");
                 angular.element(".resignation-withdraw-PopUp-Model").css("display", "block");
                 $scope.resgPopUpData = {};
                 $scope.resignationDocumentName = undefined;
                 $scope.resignationUploadedDocument = undefined;
                 $scope.attachResignationStatus = false;
                 $scope.loginRole = $cookies.get('roleName');
                 $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                
             }
         }

          $scope.closeResignationWithdrawPopUp = function () {
             $scope.resgPopUpData = {};
             $scope.resignationDocumentName = undefined;
             $scope.resignationUploadedDocument = undefined;
             $scope.attachResignationStatus = false;
             angular.element(".overlay").css("display", "none");
             angular.element(".resignation-withdraw-PopUp-Model").css("display", "none");
         }

         //Submit Approval Adjudicator Resignation
         $scope.adjudicatorResignationSubmit = function (resgPopUpData, CaseNumber) {
             var query = {
                 "caseNumber": CaseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "comments": resgPopUpData.comments
             }
             console.log('query', query)
             DataService.post('ApproveResignationRequest', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Request sent for management apporoval successfully');
                     angular.element(".overlay").css("display", "none");
                     angular.element(".resignation-withdraw-PopUp-Model").css("display", "none");
                     get_todo_list();
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }
            //to open invite adjudicator modal 
            function inviteAdjudicator (caseNumber,caseFromForInvite){
                getAdjudicatorList(0,caseNumber);
                $rootScope.adjdetail = {};
                $rootScope.adjdetail.adjudicator_list = [];
                $rootScope.memberName = [];
                angular.element(".adjudicator_checkbox").attr('checked', false);
                $rootScope.caseFromForInvite = caseFromForInvite;
                $rootScope.adjudiCaseNumber = caseNumber;
            }
            //to close invite adjudicator modal
            $scope.closeadjudi = function(){
                angular.element(".overlay").css("display","none");
                angular.element(".Adjudicators-modal").css("display","none");
            }

            //to get Adjudicator list
         function getAdjudicatorList(pageNumber, caseNumber ,reSend) {
             angular.element(".overlay").css("display","block");
             angular.element(".loading-container").css("display","block");
             $scope.appointDataLength = 10;
             if (pageNumber) {
                 $scope.appointPagenumber = pageNumber;
             } else {
                 $scope.appointPagenumber = 0;
             }
             var query = {
                 "pageIndex": $scope.appointPagenumber,
                 "dataLength": $scope.appointDataLength,
                 "sortingColumn": null,
                 "sortDirection": null,
                 "name": null,
                 "category": 'All',
                 "caseNumber": caseNumber
             }
             DataService.post('GetAdjudicatorsList', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     angular.element(".loading-container").css("display","none");
                     if(reSend != 'reSend'){
                        angular.element(".Adjudicators-modal").css("display","block");
                     }
                     $scope.adjudicators = data.result.responseData;
                     $scope.max_Appoint_Pagenumber = data.result.totalData / $scope.dataLength;
                     var value = Math.round($scope.max_Appoint_Pagenumber);
                     if (value < $scope.max_Invite_Pagenumber) {
                         $scope.max_Appoint_Pagenumber = value + 1;
                     } else {
                         $scope.max_Appoint_Pagenumber = value;
                     }
                 } else {
                     angular.element(".overlay").css("display","none");
                     angular.element(".loading-container").css("display","none");
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 angular.element(".overlay").css("display","none");
                 angular.element(".loading-container").css("display","none");
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //view Refund details
        function viewRefundDetails(caseNumber, caseFrom) {
            $scope.caseFrom = caseFrom;
            if (caseFrom == 'AA') {
                viewAARefundDetails(caseNumber);
            } else if (caseFrom == 'ARA') {
                viewARARefundDetails(caseNumber);
            }
        }

        //view AA Refund details
        function viewAARefundDetails(caseNumber) {
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var GetRefundDataUrl = smcConfig.services.GetRefundData.url;
            GetRefundDataUrl = GetRefundDataUrl + caseNumber;
            $http.get(GetRefundDataUrl).then(function (data) {
                console.log("data", data)
                if (data.data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    $scope.refundData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".refund-process").css("display", "block");
                } else {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.data.errorMessage);
            });
        }

        //view ARA Refund details
        function viewARARefundDetails(caseNumber) {
            angular.element(".overlay").css("display","block");
            angular.element(".loading-container").css("display","block");
            var GetARARefundDataUrl = smcConfig.services.GetARARefundData.url;
            GetARARefundDataUrl = GetARARefundDataUrl + caseNumber;
            $http.get(GetARARefundDataUrl).then(function (data) {
                console.log("data", data)
                if (data.data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    $scope.refundData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".refund-process").css("display", "block");
                } else {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
                angular.element(".loading-container").css("display","none");
                NotifyFactory.log('error', error.data.errorMessage);
            });
        }

        //close Refund details
        $scope.closerefundmodal = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".refund-process").css("display", "none");
        }

        //send refund request to management
        $scope.refundrequest = function (refundData, caseFrom) {
            var query = refundQueryData(refundData);
            if (caseFrom == 'AA') {
                angular.element(".overlay").css("display","block");
                angular.element(".loading-container").css("display","block");
                DataService.post('requestRefundData', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
                        angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('success', "Process refund requested successfully");
                        get_todo_list(0);
                        angular.element(".overlay").css("display","none");
                        angular.element(".refund-process").css("display","none");
                    }else{
                        angular.element(".overlay").css("display","none");
                        angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
            } else if (caseFrom == 'ARA') {
                angular.element(".overlay").css("display","block");
                angular.element(".loading-container").css("display","block");
                DataService.post('requestARARefundData', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        angular.element(".overlay").css("display","none");
                        angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('success', "Process refund requested successfully");
                        get_todo_list(0);
                        angular.element(".overlay").css("display","none");
                        angular.element(".refund-process").css("display","none");
                    }else{
                        angular.element(".overlay").css("display","none");
                        angular.element(".loading-container").css("display","none");
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
            }

        }

        //build query for refund approval
        function refundQueryData(refundData) {
            var query = {
                "filingFee": refundData.filingFee,
                "depositFeeOfAdjudicator": refundData.depositFeeOfAdjudicator,
                "timeCostOfAdjudicator": refundData.timeCostOfAdjudicator,
                "amountRefund": refundData.amountRefund,
                "caseNumber": refundData.caseNumber,
                "smcOfficerId": parseInt($cookies.get('memberId'))
            }
            return query;
        }

        //open request TopUp model
         function openRequestDeposit (caseNumber, topUpCaseType) {
             $scope.loginRole = $cookies.get('roleName');
             $scope.topUpCaseNumber = caseNumber;
             $scope.topUpCaseType = topUpCaseType;
             var viewAdditionalDepositUrl = smcConfig.services.viewAdditionalDeposits.url;
             viewAdditionalDepositUrl = viewAdditionalDepositUrl + caseNumber;
             $http.get(viewAdditionalDepositUrl).then(function (data) {
                 console.log("data", data)
                 $scope.topUpData = data.data.results[data.data.results.length - 1];
             });
             angular.element(".overlay").css("display", "block");
             angular.element(".Request-TopUp-Model").css("display", "block");
         }

         //close Messaging window between claimant/respondent and adjudicator
         $scope.closerequestTopUp = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".Request-TopUp-Model").css("display", "none");
         }

         // To Submit Request for additional deposit
         $scope.submitTopUpRequest = function (requestData, caseNumber, topUpCaseType) {
             var query = buildtopUpQuery(requestData, caseNumber);
             if (topUpCaseType == 'AA') {
                 DataService.post('SentDepositRequestClaimant', query).then(function (data) {
                     if (data.status == 'SUCCESS') {
                         NotifyFactory.log('success', 'Topup request approved successfully');
                         get_todo_list(0);
                         angular.element(".overlay").css("display", "none");
                         angular.element(".Request-TopUp-Model").css("display", "none");
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             } else if (topUpCaseType == 'ARA') {
                 DataService.post('SentARADepositRequestClaimant', query).then(function (data) {
                     if (data.status == 'SUCCESS') {
                         NotifyFactory.log('success', 'Topup request approved successfully');
                         get_todo_list(0);
                         angular.element(".overlay").css("display", "none");
                         angular.element(".Request-TopUp-Model").css("display", "none");
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             }

         }

         function buildtopUpQuery(requestData, caseNumber) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "amount": requestData.amount,
                 "dueDateDetermination": requestData.determineDueDate,
                 "depositDeadLine": requestData.depositDeadline
             }
             return query;
         }



         //view schedule detail
         function getCaseSchedule (caseNumber) {
             $scope.schedulenumber = caseNumber;
             $scope.cancelSchedule = {};
             $scope.applyCost = [];
             var GetCaseScheduleUrl = smcConfig.services.GetCaseSchedule.url;
             GetCaseScheduleUrl = GetCaseScheduleUrl + $scope.schedulenumber;
             $http.get(GetCaseScheduleUrl).then(function (data) {
                 console.log("data", data)
                 $scope.schedule = data.data.result;
                 $scope.conferencelist = [];
                 if($scope.schedule.scheduleMeetings.length != 0){
                     for (var con in $scope.schedule.scheduleMeetings) {
                         $scope.conferencelist.push(true);
                         if ($scope.schedule.scheduleMeetings[con].isParkingRequired == true) {
                             $scope.schedule.scheduleMeetings[con].isParkingRequired = "Yes";
                         } else {
                             $scope.schedule.scheduleMeetings[con].isParkingRequired = "No";
                         }
                         $scope.applyCost.push(false)
                     }
                }else{
                    $scope.conferencelist = [true];
                }
                 if ($scope.schedule.isRoomRequired == true) {
                     $scope.schedule.isRoomRequired = "Yes";
                 } else {
                     $scope.schedule.isRoomRequired = "No";
                 }
                 angular.element(".overlay").css("display", "block");
                 angular.element(".case-schedule-officer-model").css("display", "block");
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //Get Register Vehicle Number
         $scope.getRegisterVehileNo = function (index) {
             var GetVehicleNUmberUrl = smcConfig.services.GetVehicleNUmber.url;
             GetVehicleNUmberUrl = GetVehicleNUmberUrl + $cookies.get('memberId');
             $http.get(GetVehicleNUmberUrl).then(function (data) {
                 console.log("data", data)
                 $scope.schedule.scheduleMeetings[index].vehicleRegNum = data.data.result;
             });
         }

         $scope.closeSchedulepopup = function () {
             angular.element(".overlay").css("display", "none");
             angular.element(".case-schedule-officer-model").css("display", "none");
         }

         $scope.updateSchedule = function (scheduleDetail, caseNumber) {
             console.log('schedule', scheduleDetail);
             if(scheduleDetail.scheduleMeetings.length != 0){
                for (var times in scheduleDetail.scheduleMeetings) {
                     scheduleDetail.scheduleMeetings[times].meetingStartTime = document.getElementById("startTime" + times).value;
                     scheduleDetail.scheduleMeetings[times].meetingEndTime = document.getElementById("endTime" + times).value;
                     var start_time = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[0];
                     var start_hour = start_time.split(':')[0];
                     var start_mini = start_time.split(':')[1];
                     var start_Sched = scheduleDetail.scheduleMeetings[times].meetingStartTime.split(' ')[1];
                     var end_time = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[0];
                     var end_hour = end_time.split(':')[0];
                     var end_mini = end_time.split(':')[1];
                     var end_Sched = scheduleDetail.scheduleMeetings[times].meetingEndTime.split(' ')[1];
                     if (start_Sched == 'am' && end_Sched == 'pm') {
                         update_schedule(scheduleDetail, caseNumber);
                     } else if (start_Sched == 'pm' && end_Sched == 'am') {
                         NotifyFactory.log('error', 'Start time should be less than end time');
                     } else if (start_Sched == end_Sched) {
                        if(start_hour == '12' && start_Sched == 'pm'){
                            update_schedule(scheduleDetail, caseNumber);
                        }
                         else if (start_hour < end_hour) {
                             update_schedule(scheduleDetail, caseNumber);
                         } else if (start_hour == start_hour) {
                             if (start_mini < end_mini) {
                                 update_schedule(scheduleDetail, caseNumber);
                             } else if (start_mini == end_mini) {
                                 NotifyFactory.log('error', 'Start time and end time should not be same');
                             } else {
                                 NotifyFactory.log('error', 'Start time should be less than end time');
                             }
                         } else if (start_hour > start_hour) {
                             NotifyFactory.log('error', 'Start time should be less than end time');
                         }
                     }
                 }
             }else{
                update_schedule(scheduleDetail, caseNumber);
             }
         }

         function update_schedule(scheduleDetail, caseNumber) {
             var query = BuildScheduleQuery(scheduleDetail, caseNumber)
             console.log('query', query);
             DataService.post('OfficerUpdateSchedule', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Schedule updated successfully');
                     get_todo_list($cookies.get('pageNumber'))
                     angular.element(".overlay").css("display", "none");
                     angular.element(".case-schedule-officer-model").css("display", "none");
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         $scope.isMeetingCanceled = function () {
             if ($scope.cancelSchedule.isMeetingCancel) {
                 for (var meet in $scope.schedule.scheduleMeetings) {
                     $scope.schedule.scheduleMeetings[meet].numberOfAttendees = 0;
                     $scope.schedule.scheduleMeetings[meet].cost = 0;
                 }
                 $scope.cancelSchedule.cancellationCost = null;
             } else {
                 for (var meet in $scope.schedule.scheduleMeetings) {
                     $scope.schedule.scheduleMeetings[meet].numberOfAttendees = null;
                     $scope.schedule.scheduleMeetings[meet].cost = null;
                 }
             }
         }


         $scope.applyMeetingCost = function (value, index) {
             if (value) {
                 if ($scope.cancelSchedule.cancellationCost) {
                     $scope.schedule.scheduleMeetings[index].cost = $scope.cancelSchedule.cancellationCost;
                 } else {
                     $scope.schedule.scheduleMeetings[index].cost = 0;
                 }
             } else {
                 $scope.schedule.scheduleMeetings[index].cost = 0;
             }
         }

         $scope.changeCancellationCost = function () {
             for (var index in $scope.applyCost) {
                 if ($scope.applyCost[index]) {
                     if ($scope.cancelSchedule.cancellationCost) {
                         $scope.schedule.scheduleMeetings[index].cost = $scope.cancelSchedule.cancellationCost;
                     } else {
                         $scope.schedule.scheduleMeetings[index].cost = 0;
                     }
                 } else {
                     $scope.schedule.scheduleMeetings[index].cost = 0;
                 }
             }
         }

         function setvalue(value) {
             if (value == 'Yes') {
                 return true;
             } else {
                 return false;
             }

         }

         //build query for schedule
         function BuildScheduleQuery(scheduleDetail, caseNumber) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "arLodgedDueDate": undefinedSetNull(scheduleDetail.arLodgedDueDate),
                 "commencementDate": scheduleDetail.commencementDate,
                 "determineDuedate": scheduleDetail.determineDuedate,
                 "claimantReplyDeadline": undefinedSetNull(scheduleDetail.claimantReplyDeadline),
                 "respondentResponseDeadline": undefinedSetNull(scheduleDetail.respondentResponseDeadline),
                 "claimantFinalReplyDeadline": undefinedSetNull(scheduleDetail.claimantFinalReplyDeadline),
                 "isRoomRequired": setvalue(scheduleDetail.isRoomRequired),
             }
             query.scheduleMeetings = [];
             for (var meet in scheduleDetail.scheduleMeetings) {
                 var meetings = {
                     "id": scheduleDetail.scheduleMeetings[meet].id,
                     "meetingDate": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingDate),
                     "meetingStartTime": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingStartTime),
                     "meetingEndTime": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].meetingEndTime),
                     "isParkingRequired": setvalue(scheduleDetail.scheduleMeetings[meet].isParkingRequired),
                     "vehicleRegNum": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].vehicleRegNum),
                     "venue": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].venue),
                     "cost": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].cost),
                     "numberOfAttendees": undefinedSetNull(scheduleDetail.scheduleMeetings[meet].numberOfAttendees),
                 }
                 query.scheduleMeetings.push(meetings)
             }
             return query;
         }


             // open and review timesheet and determination
         function openDeterminationSheet (caseNumber, determineCaseType) {
             $scope.viewCaseNumber = caseNumber;
             $scope.determineCaseType = determineCaseType;
             $rootScope.reviewComment = {};
             if (determineCaseType == 'AA') {
                 gettimesheetList($scope.viewCaseNumber);
             } else if (determineCaseType == 'ARA') {
                 getARAtimesheetList($scope.viewCaseNumber);
             }
             getDeterminationList($scope.viewCaseNumber);
             angular.element(".overlay").css("display", "block");
             angular.element(".view-timesheet-determination").css("display", "block");
         }

         // close and review timesheet and determination
         $scope.closeDeterminationSheet = function (caseNumber) {
             angular.element(".overlay").css("display", "none");
             angular.element(".view-timesheet-determination").css("display", "none");
         }

         //get all determination list
         function getDeterminationList(caseNumber) {
             var GetDeterminationListUrl = smcConfig.services.GetDeterminationList.url;
             GetDeterminationListUrl = GetDeterminationListUrl + caseNumber;
             $http.get(GetDeterminationListUrl).then(function (data) {
                 console.log("data", data)
                 $scope.DeterminationList = data.data.result;
                 $scope.determinations = $scope.DeterminationList.determinationVersions;
             });
         }
         //get AA all timesheet list
         function gettimesheetList(caseNumber) {
             var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNumber;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 $scope.timeSheetData = data.data.result;
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
             });
         }

         //get ARA all timesheet list
         function getARAtimesheetList(caseNumber) {
             var GetTimeSheetDataUrl = smcConfig.services.ViewARATimeSheetOfficer.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNumber;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 $scope.fullTimeSheetData = data.data.result.timeSheetDTOs;
                 $scope.timeSheetData = data.data.result.timeSheetDTOs[0];
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
                 if (data.data.result.timeSheetDTOs[1]) {
                     $scope.timeSheetData1 = data.data.result.timeSheetDTOs[1];
                     if ($scope.timeSheetData1.workedHours) {
                         $scope.workingDatas1 = $scope.timeSheetData1.workedHours;
                     }
                 }
                 if (data.data.result.timeSheetDTOs[2]) {
                     $scope.timeSheetData2 = data.data.result.timeSheetDTOs[2];
                     if ($scope.timeSheetData2.workedHours) {
                         $scope.workingDatas2 = $scope.timeSheetData2.workedHours;
                     }
                 }
             });
         }

         //response for determonation & time shreet
         $scope.sendResponse = function (response, caseNumber, determination, versionId, determineCaseType,fullTimeSheetData) {
             if (determineCaseType == 'AA') {
                    timesheetResponse(response, caseNumber, determination,versionId);
                 
                 angular.element(".overlay").css("display", "none");
                 angular.element(".view-timesheet-determination").css("display", "none");
             } else if (determineCaseType == 'ARA') {
                 ARAtimesheetResponse(response, caseNumber, determination,versionId,fullTimeSheetData);
                 angular.element(".overlay").css("display", "none");
                 angular.element(".view-timesheet-determination").css("display", "none");
             }
         }

         //response for AA determination
         function determinationResponse(response, caseNumber, determination, versionId) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(determination.determinationComment),
                 "versionId": versionId,
                 "versionStatus": response
             }
             if(response == 'Changes Required'){
                var requestMsg = "Determination requested for change successfully"
             }else{
                var requestMsg = "Determination request approved successfully"
             }
             DataService.post('OfficerResponseToDetermination', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', requestMsg);
                     get_todo_list();
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //response for ARA determination
         function ARAdeterminationResponse(response, caseNumber, determination, versionId) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(determination.determinationComment),
                 "versionId": versionId,
                 "versionStatus": response
             }
             if(response=="Approve"){
                var successMsg="Determination request approved successfully";
             }else{
                 var successMsg="Determination requested for change successfully";
             }
             DataService.post('OfficerResponseToARADetermination', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', successMsg);
                     get_todo_list(0);
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         // response for AA timesheet
         function timesheetResponse(response, caseNumber, determination,versionId) {
             var query = {
                 "caseNumber": caseNumber,
                 "smcOfficerId": parseInt($cookies.get('memberId')),
                 "comments": undefinedSetNull(determination.timeSheetComment),
                 "actionType": response
             }
             DataService.post('OfficerResponseToTimeSheet', query).then(function (data) {
                 console.log('data', data);
                 determinationResponse(response, caseNumber, determination, versionId);
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         // response for ARA timesheet
         function ARAtimesheetResponse(response, caseNumber, determination,versionId,fullTimeSheetData) {
             for(var timeSheetId in fullTimeSheetData){
                var query = {
                     "id": fullTimeSheetData[timeSheetId].id,
                     "caseNumber": caseNumber,
                     "smcOfficerId": parseInt($cookies.get('memberId')),
                     "comments": undefinedSetNull(determination.timeSheetComment),
                     "actionType": response
                 }
                 DataService.post('SubmitARATimeSheetofficer', query).then(function (data) {
                     if(timeSheetId == fullTimeSheetData.length-1){
                        ARAdeterminationResponse(response, caseNumber, determination, versionId);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             }
         }

         //cancel schedule process
         $scope.cancelScheduleSubmit = function (caseNumber, scheduleId, cancelData) {
             var query = {
                 "scheduleId": scheduleId,
                 "caseNumber": caseNumber,
                 "isMeetingCancel": cancelData.isMeetingCancel,
                 "cancellationCost": undefinedSetNull(cancelData.cancellationCost)
             }
             DataService.post('CancelSchedule', query).then(function (data) {
                 get_todo_list(0);
                 NotifyFactory.log('success', 'Schedule cancelled successfully');
                 angular.element(".overlay").css("display", "none");
                 angular.element(".case-schedule-officer-model").css("display", "none");
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }


       
        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


