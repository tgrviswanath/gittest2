(function() {
    'use strict';
    angular
        .module('smc')
        .controller('listAdjudicatorCtrl',listAdjudicatorCtrl);

    listAdjudicatorCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function listAdjudicatorCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName')!='Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'adjudicatorlist'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        $scope.downloadAdjudicatorList = smcConfig.services.ExportAdjudicatorList.url;
    	get_adjudicator_list($scope.pagenumber);//call to adjudicator list function
        $cookies.put('currentTab','adjudicatorlist');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to rejected case list function from outside
        $rootScope.rejectedcaselist = function(){
            get_adjudicator_list($cookies.get('pageNumber'));
        } 

    	// get rejected case list
    	function get_adjudicator_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			"pageIndex": $scope.pagenumber, 
                "dataLength":$scope.dataLength, 
                "sortingColumn":null, 
                "sortDirection":null, 
                "name":null,
                "category": 'All'
    		}
    		getAdjudicarList(query)
    	}

        function getAdjudicarList(query){
            DataService.post('GetAllAdjudicatorList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.adjudicators = data.result.responseData;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
    			}else{
    				NotifyFactory.log('error', data.errorMessage);
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
				NotifyFactory.log('error', error.errorMessage);
                $scope.shownodataavailable = true;
	        });
        }

        $scope.goToPageNumber = function(pageNo){
           get_adjudicator_list(pageNo);
        }

        //get filter adjudicator list
        $scope.getadjudicators = function(filter){
            var query = {
                "name":filter.name,
                "category": filter.category
    		}
    		getAdjudicarList(query)
        }

        //reset to get all adjudicators
        $scope.resetadjudicatorlist = function(){
            get_adjudicator_list(0);
        }

        

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


