(function() {
    'use strict';
    angular
        .module('smc')
        .controller('courierManageCtrl',courierManageCtrl);

    courierManageCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function courierManageCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
       if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
        if($cookies.get('pageNumber') && $cookies.get('currentTab') == 'courierManage'){
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        }else{
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
    	get_courier_list($scope.pagenumber);//call to conflicted case list function
        $cookies.put('currentTab','courierManage');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        //call to conflicted case list function from outside
        $rootScope.getcourierlist = function(){
            get_courier_list($cookies.get('pageNumber'));
        } 

    	// get rejected case list
    	function get_courier_list(pageNumber){
            if(pageNumber){
                $scope.pagenumber = pageNumber;
            }else{
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber',$scope.pagenumber)
    		var query = {
    			 "pageIndex":$scope.pagenumber, 
                 "dataLength":$scope.dataLength, 
                 "sortingColumn":null, 
                 "sortDirection":null, 
                 "companyName":null, 
                 "contactNumber":null
    		}
    		DataService.post('OfficerGetCourierList',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.courier_List = data.result.responseData;
                    $scope.shownodataavailable = false;
                    $scope.max_pagenumber = data.result.totalData/$scope.dataLength;
                    var value= Math.round($scope.max_pagenumber);
                    if(value < $scope.max_pagenumber){
                        $scope.max_pagenumber = value+1;
                    }else{
                        $scope.max_pagenumber = value;
                    }
                    if($scope.courier_List.length == 0){
                        $scope.shownodataavailable = true;
                    }
    			}else{
                    $scope.shownodataavailable = true;
    			}
    		}).catch(function (error) {
                if(error.errorCode == 100){
                    $scope.shownodataavailable = true;
                }
	        });
    	}

    

        $scope.goToPageNumber = function(pageNo){
           get_courier_list(pageNo);
        } 

        //to open add a courier model
        $scope.addCourier = function (){
            $scope.courierData = {};
            angular.element(".overlay").css("display","block");
            angular.element(".officer-add-courier").css("display","block");
        }

        //search courier for admin
            $scope.getCourier = function(filterDetails){
                var query = {
                "companyName":filterDetails.companyName, 
                 "contactNumber":'65'+filterDetails.contactNumber
                }
                DataService.post('OfficerGetCourierList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.courier_List = data.result.responseData
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
                }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                });
            }

            //reset users list
            $scope.resetcouriercases = function(){
                $scope.filter = undefined;
                get_courier_list(0);
            }


        //to close add a courier model
        $scope.closeaddcoureiermodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".officer-add-courier").css("display","none");
        }

        // submit add courier 
        $scope.submitAddCourier = function(courierData){
            var query = BuildCourierQuery(courierData);
            DataService.post('OfficerAddCourier',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','Courier added successfully');
                    get_courier_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".officer-add-courier").css("display","none");
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.data.errorMsg)
	        });
        }

        //build courier query
        function BuildCourierQuery(courierData){
            if(courierData.businessAddress){
                if(courierData.businessAddress.phoneNumber){
                    courierData.businessAddress.phoneNumber='65'+courierData.businessAddress.phoneNumber;
                }
                if(courierData.businessAddress.faxNumber){
                    courierData.businessAddress.faxNumber='+65'+courierData.businessAddress.faxNumber;
                }
            }
            var query = {
                "id":undefinedSetNull(courierData.id), 
                "companyName":courierData.companyName, 
                "contactPersonName":courierData.contactPersonName, 
                "businessAddress":courierData.businessAddress, 
                "createdUserId":$cookies.get('memberId')
            }

            return query;
        }

        //view a single user details
        $scope.viewCourier = function(courierId){
            var GetSingleCourierDetailsUrl = smcConfig.services.GetSingleCourierDetails.url;
            GetSingleCourierDetailsUrl = GetSingleCourierDetailsUrl +  courierId;
            $http.get(GetSingleCourierDetailsUrl).then(function(data){
                console.log("data",data);
                $scope.courierDetails = data.data.result;
                if($scope.courierDetails.businessAddress){
                    if($scope.courierDetails.businessAddress.faxNumber){
                        $scope.courierDetails.businessAddress.faxNumber=$scope.courierDetails.businessAddress.faxNumber.substring(3);
                    }

                    if($scope.courierDetails.businessAddress.phoneNumber){
                        $scope.courierDetails.businessAddress.phoneNumber=$scope.courierDetails.businessAddress.phoneNumber.substring(2);
                    }
                }
                angular.element(".overlay").css("display","block");
                angular.element(".officer-modify-courier").css("display","block");
            });
        }

        //to close modify a user model
        $scope.closemodifycouriermodel = function (){
            angular.element(".overlay").css("display","none");
            angular.element(".officer-modify-courier").css("display","none");
        }

        //update user status
        $scope.updateCourier = function(courierData){
             var query = BuildCourierQuery(courierData);
            DataService.post('OfficerUpdateCourier',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success','Courier status updated successfully');
                    get_courier_list($cookies.get('pageNumber'));
                    angular.element(".overlay").css("display","none");
                    angular.element(".officer-modify-courier").css("display","none");
    			}
    		}).catch(function (error) {
               NotifyFactory.log('error',error.data.errorMsg)
	        });
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


