(function() {
    'use strict';
    angular
        .module('smc')
        .controller('generatereportsCtrl',generatereportsCtrl);

    generatereportsCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function generatereportsCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.roleName = $cookies.get('roleName');
        $scope.DownloadReportsDocumentUrl = smcConfig.services.DownloadReportsDocument.url;
        // to receive filter case list
        $scope.$on('activeReportTab', function(event, tabStatus) { 
            $scope.currentTab = tabStatus;
        });
    	 $scope.get_reports_list=function(selectedDate){
    		var query = {
    			 "fromDate": selectedDate.selectedFromMonth+'-'+selectedDate.selectedFromYear, 
                 "toDate": selectedDate.selectedToMonth+'-'+selectedDate.selectedToYear
    		}
            get_adjudicate_reports(query);
            get_additional_reports(query);
    		
    	}
        
        $scope.monthnames = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ]
        $scope.filterDate = {};

        var currentYear = new Date().getFullYear();
        var minYear = currentYear-5;
        var maxYear = currentYear+5;
        $scope.yearList = [];
        for (var yearNo = minYear; yearNo <= maxYear; yearNo++) {
            $scope.yearList.push(yearNo);
        }

        $scope.buildDownloadUrl = function(filterDate){
            if(filterDate.selectedFromMonth && filterDate.selectedFromYear && filterDate.selectedToMonth && filterDate.selectedToYear){
                $scope.DownloadReportsDocumentUrl = $scope.DownloadReportsDocumentUrl + '/' + filterDate.selectedFromMonth+'-'+filterDate.selectedFromYear+'/'+filterDate.selectedToMonth+'-'+filterDate.selectedToYear;
            }
        }
        
        $scope.buildToYearArray = function(fromYear){
            $scope.toYearList = [];
            var fromYear = fromYear+1;
            var fromYearNO = fromYear+10;
            for (var yearNo = fromYear; yearNo <= fromYearNO; yearNo++) {
                $scope.toYearList.push(yearNo);
            }
            $scope.filterDate.selectedToYear = '';
        }

    

        $scope.fromDateClick = function(){
            $scope.fromMonthDownload = setMonth(this.value);
            console.log($scope.fromMonthDownload)
            var fromMonth = $scope.filterDate.fromMonth;
            var toMonth = $scope.filterDate.toMonth;
            $scope.toMonthMinLimit = fromMonth;
            $( "#referencePeriodTo" ).datepicker( "option", "minMonth",$scope.toMonthMinLimit );
            
        }

        function get_adjudicate_reports(query){
            DataService.post('GetAllGenetateReports',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.$broadcast('reportCases',data.result);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', data.errorMessage);
            });
        }
        function get_additional_reports (query){
    		DataService.post('GetAdditionalReports',query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				$scope.$broadcast('additionalReportCases',data.results);
    			}
    		}).catch(function (error) {
                NotifyFactory.log('error', data.errorMessage);
	        });
        }
    }
})();


