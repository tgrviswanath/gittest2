(function() {
    'use strict';
    angular
        .module('smc')
        .controller('reassignCaseCtrl',reassignCaseCtrl);

    reassignCaseCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function reassignCaseCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        if ($cookies.get('roleName') != 'SMC Officer' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.shownodataavailable = false;
        $scope.roleName = $cookies.get('roleName');
    	get_all_case_officer();
        get_all_assistant_manager();
        $scope.attachcopyStatus = false;
        $scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
        $cookies.put('currentTab','reassign');
        $scope.$emit('activeTab',$cookies.get('currentTab'));//send current tab status
        
    	// get case officers
    	function get_all_case_officer(){
    		var query = {
    			 "moduleName":"Adjudication", 
                 "roleName":"Case Officer"
    		}
    		DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.case_officers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
    	}

        // get case officers
    	function get_all_assistant_manager(){
    		var query = {
    			"moduleName":"Adjudication",
                "roleName":'Assistant Manager'
    		}
    		DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.assistant_managers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
    	}

        //get other officer 
        $scope.getOtherOfficers = function(memberId,roleName){
           var query = {
               "moduleName":"Adjudication", 
                "roleName":roleName, 
                "staffId":memberId
           } 
           DataService.post('GetUnassignedMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    if(roleName == 'Case Officer'){
                        $scope.unassigned_case_officers = data.results;
                        $scope.oldOfficer = memberId;
                    }else{
                        $scope.unassigned_assistant_managers = data.results;
                        $scope.oldManager = memberId;
                    }
                    if($scope.oldOfficer && $scope.oldManager){
                        getCaseList($scope.oldOfficer,$scope.oldManager)
                    }
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function getCaseList(officerId,managerId){
            var query = {
                "caseOfficerId" : officerId, 
                "assistantManagerId" :managerId
            }
            DataService.post('GetAssignedCaseList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.case_list = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                    $scope.case_list = undefined;
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                $scope.case_list = undefined;
            });
        }

        // upload a file - before that check file size,valid exetension
        $scope.uploadFile = function(file,index){
            var file = file;
            if ( file.size < 5242881 ){
                if(validateUploadFileExtention(file.name)){
                    $scope.supprtDocumentName = file.name;
                    var fd= new FormData();
                    fd.append('file',file);
                    httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
                        console.log(data);
                        $scope.supportFilePath = data.result;
                        $scope.attachcopyStatus = true;
                    });
                }else{
                    $scope.attachcopyStatus = true;
                    $scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
                }
            }else{
                NotifyFactory.log('error', "Please select below 5MB file");
            }
        }
        // check valid file by exetension
        function validateUploadFileExtention(val){
            var allowedExt = $scope.fileUploadTypes;

            var ext = val.split('.').pop();
            for(var i = 0; i < allowedExt.length; i++){
                if($scope.fileUploadTypes[i] == ext){
                    return true;
                }
            }
        }
        // if we want remove upload file
        $scope.attachcopyRemove = function(){
            $scope.supprtDocumentName = undefined;
            $scope.supportFilePath = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
        }

        $scope.resetvalues = function(){
            $scope.supprtDocumentName = undefined;
            $scope.supportFilePath = undefined;
            $scope.attachcopyStatus = false;
            angular.element("#supprt_document_name").val("");
            angular.element("#suport_upload").val("");
            $scope.case_list = undefined;
        }

        $scope.submitreassign = function(reassignData){
            var query = {
                "caseOfficerId":reassignData.newCaseOfficer, 
                "assistantManagerId":reassignData.newAssistantManager, 
                "caseNumbers":reassignData.caselist, 
                "reassignedBy":$cookies.get('memberId'), 
                "remarks":reassignData.remarks, 
                "oldCaseOfficerId":reassignData.oldCaseOfficer, 
                "oldAssistantManagerId":reassignData.oldAssistantManager
            }
            if($scope.supportFilePath){
                query.reassignDocument = {
                    "name":$scope.supprtDocumentName.split('.')[0], 
                    "fileLocation":$scope.supportFilePath 
                }
            }
            DataService.post('SubmitReassignedCaseList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', 'Case(s) reassigned successfully');
                    $scope.reassign = {};
                    $scope.case_list = [];
                    $scope.oldOfficer=undefined;
                    $scope.oldManager=undefined;
                    $scope.supprtDocumentName = undefined;
                    $scope.supportFilePath = undefined;
                    $scope.attachcopyStatus = false;
                    angular.element("#supprt_document_name").val("");
                    angular.element("#suport_upload").val("");
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }
    }
})();


