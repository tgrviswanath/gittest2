(function() {
    'use strict';
    angular
        .module('smc')
        .controller('memberListCtrl',memberListCtrl);

    memberListCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function memberListCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
        
        getManagerList();
        getOfficerList();
        $rootScope.casedetail = {};
        //to get Assistant managers list
        function getManagerList (){
            var query = {
                "moduleName":"Adjudication",
                "roleName":'Assistant Manager'
            }
            DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.managers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        //to get SMC Officer list
        function getOfficerList (){
            var query = {
                "moduleName":"Adjudication",
                "roleName":'Case Officer'
            }
            DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.officers = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //to assign case to case officer 
        $scope.assignCasetoOfficer = function(case_details){
            var query = {
                "caseNumber": $rootScope.casedetailNumber,
                "caseOfficerId":parseInt(case_details.caseOfficerId),
                "assistantManagerId":parseInt(case_details.assistantManagerId)
            }
            console.log("query",query)
            DataService.post('AssignCaseToOfficer',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    NotifyFactory.log('success', "Case assigned successfully");
                    angular.element(".overlay").css("display","none");
                    angular.element(".case-submitt-confirm").css("display","none");
                    if($cookies.get('currentTab') == 'incomplete'){
                        $rootScope.incompletecaselist();
                    }else if ($cookies.get('currentTab') == 'inprogress') {
                        $rootScope.inprocesscaselist();
                    }
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        //cancel assign popup
        $scope.cancelModCase = function(){
            angular.element(".overlay").css("display","none");
            angular.element(".case-submitt-confirm").css("display","none");
        }
    }
})();