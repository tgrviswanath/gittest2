(function() {
    'use strict';
    angular
        .module('smc')
        .controller('viewaraformCtrl',viewaraformCtrl);

    viewaraformCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','navigateConfig','$window','$sce'];

    function viewaraformCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,navigateConfig,$window,$sce){

       
        if(!$rootScope.araCaseNumber){
            $state.go('smclayout.membershiplayout.membercaselist.inprogress');
        }
    	
    	var current_fs, next_fs, previous_fs; //fieldsets
		var left, opacity, scale; //fieldset properties which we will animate
		var animating; //flag to prevent quick multi-click glitches

    	//Error Messages
		$scope.pattern = patternConfig;
		//Default Values settings
		$scope.directFormSataus = true;
    	$scope.isPreviewClicked = false;
    	$scope.claiamentStatus = false;
    	$scope.claiamentServiceAddressStatus = true;
    	$scope.claiamentLawFormDetailStatus = true;
    	$scope.registeredClaimantName = "Enter your name as reflected in your business profile";
    	$scope.uenOrnricLabel = "Unique Entity Number (UEN)";
    	$scope.uenOrnric = "Enter the organisation’s UEN";
    	$scope.respondentIndivStatus = false;
		$scope.registeredRespondentName = "Enter the respondent’s registered name";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
		$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.interestRateOfLatePaymentStatus = false;
		$scope.onlineFormSubmissionStatus = true;
		$scope.onlineFileUploadStatus = false;
		$scope.claimentLegallyRepresentStatus = false;
		$scope.respondentLegallyRepresentStatus = true;
		$scope.claiamentLawyerServiceAddressStatus = true;
        $scope.roleName=$cookies.get('roleName'); 


		//Form Related Default settings
		$scope.araform = {};
		$scope.araform.claimantInfo = {};
		$scope.araform.claimantInfo.businessAddress = {};

		$scope.araform.claimantInfo.lawFirmDto = {};
		$scope.araform.claimantInfo.lawFirmDto.businessAddress = {};

		$scope.araform.claimantInfo.lawFirmDto.lawyerDetails = [];
		$scope.araform.respondentInfo = {};
		$scope.araform.respondentInfo.businessAddress = {};

		$scope.araform.respondentInfo.lawFirmDto = {};
		$scope.araform.respondentInfo.lawFirmDto.businessAddress = {};
		$scope.araform.respondentInfo.lawFirmDto.lawyerDetails = [];
		$scope.araform.regulationInfo = {};
		$scope.araform.regulationInfo.principalName = undefined;
		$scope.araform.contractInfo = {};
		$scope.araform.paymentInfo = {};
		$scope.araform.caseDto = {};

        GetARAFormDetails();
		$scope.araform.claimantInfo.caseMemberRoleType = "Organisation";
		$scope.araform.respondentInfo.caseMemberRoleType = "Organisation";
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.claimantLawFirmStatus = true;
		$scope.respondantLawFirmStatus = true;
		$scope.araform.claimantInfo.businessAddress.isServiceAddress = false;
		$scope.araform.claimantInfo.isLegallyRepresented = "Yes";
		$scope.araform.respondentInfo.isLegallyRepresented = "No";
		$scope.araform.respondentInfo.businessAddress.isServiceAddress = false;
		$scope.araform.respondentInfo.lawFirmDto.businessAddress.isServiceAddress = false;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.termsUploadPathStatus = false;
		$scope.paymentClaimUploadPathStatus = false;
		$scope.paymentResponseUploadPathStatus = false;
		$scope.intentionNoticeUploadPathStatus = false;
		$scope.otherDocUploadPathStatus = false;
		$scope.termsErrorStatus = false;
		$scope.paymentClaimErrorStatus = false;
		$scope.paymentResponseErrorStatus = false;
		$scope.intentionNoticeErrorStatus = false;
		$scope.otherDocErrorStatus = false;
		$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
		$scope.isSubmitted = false;
        
		$rootScope.tempCaseNumber = null;

		$scope.toDateMinLimit = 0;

        //Generate Download URL
        $scope.generateDownloadUrl = smcConfig.services.DownloadSupportingDocument.url;

		//get ARA Form Details
        function GetARAFormDetails(){
            var GetARAFormDetailsUrl = smcConfig.services.GetARAFormDetails.url;
				GetARAFormDetailsUrl = GetARAFormDetailsUrl + $rootScope.araCaseNumber;
				$http.get(GetARAFormDetailsUrl).then(function(data){
	        		console.log("ara-data",data)
	        		$scope.araform = data.data.result;
                    $scope.araform.changeRespondentDeatils = true;
                    if($scope.araform.claimantInfo.caseMemberRoleType == "Individual"){
                        $scope.claiamentStatus = true;
                        $scope.registeredClaimantName = "Enter your name as reflected in your NRIC / Passport No.";
                        $scope.uenOrnricLabel = "NRIC/Passport Number";
                        $scope.uenOrnric = "Enter your NRIC / Passport No.";
                    } else {
                        $scope.claiamentStatus = false;
                        $scope.registeredClaimantName = "Enter your name as reflected in your business profile";
                        $scope.uenOrnricLabel = "Unique Entity Number (UEN)";
                        $scope.uenOrnric = "Enter the organisation’s UEN";
                    }

                    if($scope.araform.claimantInfo.businessAddress.isServiceAddress == false){
                        $scope.claiamentServiceAddressStatus = true;
                    } else {
                        $scope.claiamentServiceAddressStatus = false;
                    }
                    $rootScope.respondentName = $scope.araform.respondentInfo.memberName;
                    if($scope.araform.claimantInfo.isLegallyRepresented == "Yes"){
                        $scope.claiamentLawFormDetailStatus = true;
                        $scope.claimentLegallyRepresentStatus = false;
                    } else {
                        $scope.claiamentLawFormDetailStatus = false;
                        $scope.claimentLegallyRepresentStatus = true;
                    }
                    if($scope.araform.claimantInfo.lawFirmDto){
                        if($scope.araform.claimantInfo.lawFirmDto.businessAddress.isServiceAddress == false){
                            $scope.claiamentLawyerServiceAddressStatus = true;
                        } else {
                            $scope.claiamentLawyerServiceAddressStatus = false;
                        }
                    }
                    

                    if($scope.araform.respondentInfo.caseMemberRoleType == "Individual"){
                        $scope.respondentIndivStatus = true;
                        $scope.registeredRespondentName = "Enter the respondent’s registered name";
                        $scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
                        $scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
                    } else {
                        $scope.respondentIndivStatus = false;
                        $scope.registeredRespondentName = "Enter the respondent’s registered name";
                        $scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
                        $scope.uenOrnricRespondent = "Enter the organisation’s UEN";
                    }

                    if($scope.araform.respondentInfo.businessAddress.isServiceAddress == false){
                        $scope.respondentServiceAddressStatus = true;
                    } else {
                        $scope.respondentServiceAddressStatus = false;
                    }

                    if($scope.araform.respondentInfo.isLegallyRepresented == "Yes"){
                        $scope.respondentLawFormDetailStatus = true;
                        $scope.respondentLegallyRepresentStatus = false;
                    } else if ($scope.araform.respondentInfo.isLegallyRepresented == "No"){
                        $scope.respondentLawFormDetailStatus = false;
                        $scope.respondentLegallyRepresentStatus = true;
                    } else {
                        $scope.respondentLawFormDetailStatus = false;
                        $scope.respondentLegallyRepresentStatus = false;
                    }
                    if($scope.araform.respondentInfo.lawFirmDto){
                        if($scope.araform.respondentInfo.lawFirmDto.businessAddress.isServiceAddress == false){
                            $scope.respondentLawyerServiceAddressStatus = true;
                        } else {
                            $scope.respondentLawyerServiceAddressStatus = false;
                        }
                    }

                    if($scope.araform.respondentInfo.serviceAddress){
                        if($scope.araform.respondentInfo.serviceAddress.faxNumber){
                            $scope.araform.respondentInfo.serviceAddress.faxNumber = $scope.araform.respondentInfo.serviceAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.respondentInfo.serviceAddress.phoneNumber){
                            $scope.araform.respondentInfo.serviceAddress.phoneNumber = $scope.araform.respondentInfo.serviceAddress.phoneNumber.substring(2);
                        }
                    }
                    if($scope.araform.claimantInfo.serviceAddress){
                        if($scope.araform.claimantInfo.serviceAddress.faxNumber){
                            $scope.araform.claimantInfo.serviceAddress.faxNumber = $scope.araform.claimantInfo.serviceAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.claimantInfo.serviceAddress.phoneNumber){
                            $scope.araform.claimantInfo.serviceAddress.phoneNumber = $scope.araform.claimantInfo.serviceAddress.phoneNumber.substring(2);
                        }
                    }
                    if($scope.araform.respondentInfo.businessAddress.faxNumber){
                        $scope.araform.respondentInfo.businessAddress.faxNumber = $scope.araform.respondentInfo.businessAddress.faxNumber.substring(3);
                    }
                    if($scope.araform.respondentInfo.businessAddress.phoneNumber){
                        $scope.araform.respondentInfo.businessAddress.phoneNumber = $scope.araform.respondentInfo.businessAddress.phoneNumber.substring(2);
                    }
                    
                    if($scope.araform.claimantInfo.businessAddress.faxNumber){
                        $scope.araform.claimantInfo.businessAddress.faxNumber = $scope.araform.claimantInfo.businessAddress.faxNumber.substring(3);
                    }

                    if($scope.araform.claimantInfo.businessAddress.phoneNumber){
                        $scope.araform.claimantInfo.businessAddress.phoneNumber = $scope.araform.claimantInfo.businessAddress.phoneNumber.substring(2);
                    }
                    
                    if($scope.araform.respondentInfo.lawFirmDto){
                        if($scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber){
                            $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber = $scope.araform.respondentInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
                            $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber = $scope.araform.respondentInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                        }
                        if($scope.araform.respondentInfo.lawFirmDto.serviceAddress){
                            if($scope.araform.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
                                $scope.araform.respondentInfo.lawFirmDto.serviceAddress.faxNumber = $scope.araform.respondentInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                            }
                            if($scope.araform.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
                                $scope.araform.respondentInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.araform.respondentInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
                            }
                        }
                    }
                    if($scope.araform.claimantInfo.lawFirmDto){
                        if($scope.araform.claimantInfo.lawFirmDto.businessAddress.faxNumber){
                            $scope.araform.claimantInfo.lawFirmDto.businessAddress.faxNumber = $scope.araform.claimantInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                        }
                        if($scope.araform.claimantInfo.lawFirmDto.businessAddress.phoneNumber){
                            $scope.araform.claimantInfo.lawFirmDto.businessAddress.phoneNumber = $scope.araform.claimantInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                        }
                        if($scope.araform.claimantInfo.lawFirmDto.serviceAddress){
                            if($scope.araform.claimantInfo.lawFirmDto.serviceAddress.faxNumber){
                                $scope.araform.claimantInfo.lawFirmDto.serviceAddress.faxNumber = $scope.araform.claimantInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                            }
                            if($scope.araform.claimantInfo.lawFirmDto.serviceAddress.phoneNumber){
                                $scope.araform.claimantInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.araform.claimantInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
                            }
                        }
                    }
                    
					if($scope.araform.supportingDocuments){
						if($scope.araform.supportingDocuments[0]){
                            var splitedDocNames1 = $scope.araform.supportingDocuments[0].fileLocation.split("\\");
							$scope.araform.relevantProofDocs_name = splitedDocNames1[splitedDocNames1.length-1];
                            $scope.araform.relevantProofDocs_id = $scope.araform.supportingDocuments[0].id;
						}
						if($scope.araform.supportingDocuments[1]){
                            var splitedDocNames2 = $scope.araform.supportingDocuments[1].fileLocation.split("\\");
							$scope.araform.adjudicationDeterminationDocs_name = splitedDocNames2[splitedDocNames2.length-1];
                            $scope.araform.adjudicationDeterminationDocs_id = $scope.araform.supportingDocuments[1].id;
						}
						if($scope.araform.supportingDocuments[2]){
                            var splitedDocNames3 = $scope.araform.supportingDocuments[2].fileLocation.split("\\");
							$scope.araform.adjudicationApplicationDocs_name = splitedDocNames3[splitedDocNames3.length-1];
                            $scope.araform.adjudicationApplicationDocs_id = $scope.araform.supportingDocuments[2].fileLocation;
						}
						
					}
                    
	        	})
                .catch(function(error){
                    console.log('errorcaselist',error);
                });;
        }

        $scope.openAuditTrialPopup=function(){
            angular.element('.audit-trial-modal').css("display","block");
            angular.element(".overlay").css("display","block");
            var query = {
                        "caseNumber":$cookies.get('caseNumber'),
                        "formName":"ARForm"             
                        };
            DataService.post('AuditTrialData', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    $scope.shownodataavailable=false;
                    $scope.auditTrialData=data.result.responseData;
                }
            }).catch(function (error) {
                $scope.shownodataavailable=true;
                NotifyFactory.log('error', error.errorMessage);
            });
        }
        
        $scope.closeAuditTrial=function () {
            angular.element('.audit-trial-modal').css("display","none");
            angular.element(".overlay").css("display","none");
        }
 	}
 })();