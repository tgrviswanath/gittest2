(function() {
    'use strict';
    angular
        .module('smc')
        .controller('updatePayeeCtrl',updatePayeeCtrl);

    updatePayeeCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function updatePayeeCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	$rootScope.payeedetails = {};
    	$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
    	getSmcManagerList(); //to call function
    	// get which payee name want to updated
    	$rootScope.getPayeeName = function(){
    		if($cookies.get('moduleName') == 'Adjudication'){
    			var serviceGetPayeeNameUrl = smcConfig.services.GetPayeeName.url;
				serviceGetPayeeNameUrl = serviceGetPayeeNameUrl + "/" + $rootScope.payeeCaseNumber;
				$http.get(serviceGetPayeeNameUrl).then(function(data){
	        		console.log("data",data)
	        		$scope.payeedetails.oldPayeeName = data.data.result;
	        	});
    		}else{
    			var serviceGetPayeeNameUrl = smcConfig.services.GetMediationPayeeName.url;
				serviceGetPayeeNameUrl = serviceGetPayeeNameUrl + "/" + $rootScope.payeeCaseNumber;
				$http.get(serviceGetPayeeNameUrl).then(function(data){
	        		console.log("data",data)
	        		$scope.payeedetails.oldPayeeName = data.data.results[0];
	        	});
    		}
    	}

		// upload a file - before that check file size,valid exetension
		$scope.uploadFile = function(file,index){
			var file = file;
			if ( file.size < 5242881 ){
				if(validateUploadFileExtention(file.name)){
					$rootScope.supprtDocumentName = file.name;

					$scope.payeedetails.fileName = $rootScope.supprtDocumentName.split('.')[0];
					var fd= new FormData();
					fd.append('file',file);
					httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
						console.log(data);
						$rootScope.payeedetails.supportFilePath = data.result;
						$scope.attachcopyStatus = true;
					});
				}else{
					$scope.attachcopyStatus = true;
					$scope.attachcopyErrorMsg = "You are allowed to upload only " + $scope.fileUploadTypes.toString();
				}
			}else{
				NotifyFactory.log('error', "Please select below 5MB file");
			}
		}
		// check valid file by exetension
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if($scope.fileUploadTypes[i] == ext){
					return true;
				}
			}
		}
		// if we want remove upload file
		$scope.attachcopyRemove = function(){
			$rootScope.supprtDocumentName = undefined;
			$rootScope.payeedetails.supportFilePath = undefined;
			$scope.attachcopyStatus = false;
			angular.element("#supprt_document_name").val("");
			angular.element("#suport_upload").val("");
		}
		//to update payee name function
		$scope.updatePayeeName = function(payee_detail){
			var query = {
				"oldPayeeName" : payee_detail.oldPayeeName,
				"newPayeeName" : payee_detail.newPayeeName,
				"remarks" : payee_detail.remarks,
				"smcOfficerId" : parseInt($cookies.get('memberId')),
				"caseNumber" : $rootScope.payeeCaseNumber,
				"supportingDocument" : {
					"name" : payee_detail.fileName
				}
			}
			console.log("query",query);
			if($cookies.get('moduleName') == 'Adjudication'){
				var urlPath = 'UpdatePayeeName';
				query.supportingDocument.fileLocation = payee_detail.supportFilePath;
			}else{
				var urlPath = 'UpdateMediationPayeeName';
				query.supportingDocument.location = payee_detail.supportFilePath;
			}
			DataService.post(urlPath,query).then(function (data) {
    			if(data.status == 'SUCCESS'){
    				NotifyFactory.log('success', "Update payee name requested Successfully");
    				$rootScope.payeedetails = {};
    				if($cookies.get('moduleName') == 'Adjudication'){
	    				if($cookies.get('currentTab') == 'inprogress'){
	    					$rootScope.inprocesscaselist();
	    				}else if($cookies.get('currentTab') == 'determined'){
	    					$rootScope.determinedcaselist();
	    				}else if($cookies.get('currentTab') == 'outgoingpayment'){
	    					$rootScope.outgoingpaymentcaselist();
	    				}
	    			}else{
	    				if($cookies.get('currentTab') == 'incomplete'){
	    					$rootScope.mediationincompletecaselist();
	    				}
	    			}
    				$rootScope.supprtDocumentName = null;
    				$rootScope.attachcopyStatus = false;
    				angular.element(".update-payee-name").css("display","none");
    				angular.element(".overlay").css("display","none");
    			}else{
    				NotifyFactory.log('error', data.errorMessage);
    			}
    		}).catch(function (error) {
				NotifyFactory.log('error', error.errorMessage);
	        });
		}

		//to get smc manager list to select for submisson
		function getSmcManagerList(){
			 var query = {
                "moduleName":"Adjudication",
                "roleName":'SMC Management'
            }
            DataService.post('GetMemberList',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    $scope.smc_manager_list = data.results;
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
		}
    }
})();