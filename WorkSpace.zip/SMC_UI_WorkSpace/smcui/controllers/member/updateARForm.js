
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('updateARformCtrl',updateARformCtrl);

    updateARformCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig'];

    function updateARformCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig){

    	var currentUrl = window.location.href.split('/');
    	var tab = currentUrl[currentUrl.length-1];
    	if (tab == 'submitformprocess'){
	    	if ($cookies.get('roleName') != 'claimant' || $cookies.get('roleName') != 'claimantLawyer') {
	            $state.go('smclayout.membershiplayout.login');
	        }
	    }

	    if(!$rootScope.casenumber){
	    	$state.go("smclayout.membershiplayout.memberdashboard");
	    }

    	$scope.registeredRespondentName = "Enter your name as reflected in your business profile";
		$scope.uenOrnricRespondentLabel = "Unique Entity Number";
		$scope.uenOrnricRespondent = "Enter the respondent's identification number";
		$rootScope.caseNumber = $cookies.get('caseNumber');
		$scope.respondentIndivStatus = false;
		$scope.respondentServiceAddressStatus = true;
		$scope.respondentLawFormDetailStatus = false;
		$scope.natureOfDistributeStatus = false;
		$scope.respondentLegallyRepresentStatus = true;
		$scope.respondentLawyerServiceAddressStatus = true;
		$scope.ar1_form1 = {};
		$scope.ar1_form1.respondentInfo = {};
		$scope.ar1_form1.respondentInfo.businessAddress = {};
		$scope.ar1_form1.respondentInfo.lawFirmDto = {};
		$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress = {};
		$scope.ar1_form1.respondentInfo.caseMemberRoleType = "Organisation";
		$scope.ar1_form1.respondentInfo.isLegallyRepresented = "No";
		$scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress = false;
		$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress = false;
		$scope.otherDocErrorStatus = false;
		$scope.attachcopyStatus = false;
		$scope.onlineFormActiveStatus = true;
		$scope.onlineSubmitStatus = false;
		$scope.onlineSaveStatus = false;
    	$scope.fileUploadTypes = ["pdf","jpg","jpeg","png"];
    	$scope.documents = [true];
    	$scope.documentname = [];
		$scope.documentPath = [];
		$scope.documentUrl = [];
		$scope.termsUploadPathStatus = [];
    	//Error Messages
		$scope.pattern = patternConfig;

		$scope.arFormUpdateStatus = false;

		/*---------- Initial Service Calls Data for Form Elements --------------*/
		//Get Law Firm List Service
        DataService.get('GetLawFirmList').then(function(data){
        	if(data.errorCode == 0){
				$scope.lawFirmList = data.results;
				$scope.respondentLegallyRepresentedClick();
			} else {
				$scope.lawFirmList = [];
			}
			
        });

        //Get Contract Type List Service
        DataService.get('GetContractTypeList').then(function(data){
			$scope.contractTyoeList = data.results;
        });

        //Get Dispute Nature List Service
        DataService.get('GetDisputeNatureList').then(function(data){
			$scope.disputeNatureList = data.results;
        });


        //Respondent Click Actions
		$scope.respondentTypeClick = function(){
			$scope.ar1_form1.respondentInfo.applicantUidValue = undefined;
			$scope.ar1_form1.respondentInfo.gender = undefined;
			if($scope.ar1_form1.respondentInfo.caseMemberRoleType == "Individual"){
				$scope.respondentIndivStatus = true;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
				$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
			} else {
				$scope.respondentIndivStatus = false;
				$scope.registeredRespondentName = "Enter the respondent’s registered name";
				$scope.uenOrnricRespondentLabel = "Unique Entity Number (UEN)";
				$scope.uenOrnricRespondent = "Enter the organisation’s UEN";
			}
		}

		$scope.respondentServiceAddressClick = function(){

			if($scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress == false){
				$scope.respondentServiceAddressStatus = true;
			} else {
				$scope.respondentServiceAddressStatus = false;
			}
		}

		$scope.respondentLegallyRepresentedClick = function(){

			if($scope.ar1_form1.respondentInfo.isLegallyRepresented == "Yes"){
				$scope.respondentLawFormDetailStatus = true;
				$scope.respondentLegallyRepresentStatus = false; 
			} else {
				$scope.respondentLawFormDetailStatus = false;
				$scope.respondentLegallyRepresentStatus = true;
			}
		}

		$scope.respondentLawyerServiceAddressClick = function(){

			if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress == false){
				$scope.respondentLawyerServiceAddressStatus = true;
			} else {
				$scope.respondentLawyerServiceAddressStatus = false;
			}
		}

		//Respondent Load Law firm details on selecting law firm and reset
		$scope.loadRespondantLawFirmDetails = function(data){
			if($scope.ar1_form1.respondentInfo.lawFirmDto == undefined){
				$scope.ar1_form1.respondentInfo.lawFirmDto = {}
			}
			if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress == undefined){
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress = {};
			}
			console.log(data);
			if(data){
				if(data.name == "Others"){
					$scope.ar1_form1.respondentInfo.lawFirmDto.name = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
					$scope.respondantLawFirmStatus = false;
				} else {
					$scope.ar1_form1.respondentInfo.lawFirmDto.name = data.name;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = data.businessAddress.address1;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = data.businessAddress.address2;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = data.businessAddress.address3;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = data.businessAddress.address4;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = data.businessAddress.postalCode;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = data.businessAddress.phoneNumber;
					$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = data.businessAddress.faxNumber;
					$scope.respondantLawFirmStatus = true;
				}
			} else {
				$scope.ar1_form1.respondentInfo.lawFirmDto.name = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4 = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = undefined;
				$scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = undefined;
				$scope.respondantLawFirmStatus = true;
			}
		}



		$scope.contractTypeClick = function(){
			var contactTypes = JSON.parse($scope.ar1_form1.contractInfo.contractType);
			if(contactTypes.type == "Construction"){
				$scope.natureOfDistributeStatus = true;
			} else {
				$scope.ar1_form1.contractInfo.natureOfDispute = undefined;
				$scope.natureOfDistributeStatus = false;
			}
		}

		getAR1_Form_Details();//call function
		//to get AR form Details
		function getAR1_Form_Details(){
			var serviceGetARformDetailsUrl = smcConfig.services.GetARformDetails.url;
			serviceGetARformDetailsUrl = serviceGetARformDetailsUrl + "/" + $rootScope.casenumber;
			$http.get(serviceGetARformDetailsUrl).then(function(data){
				$scope.ar1_form1 = data.data.result;
				if($scope.ar1_form1.contractInfo){
					if($scope.ar1_form1.contractInfo.contractTypeDto){
						$scope.ar1_form1.contractInfo.contractType = JSON.stringify($scope.ar1_form1.contractInfo.contractTypeDto);
						if($scope.ar1_form1.contractInfo.contractTypeDto.type == "Construction"){
							$scope.natureOfDistributeStatus = true;
						}
					}
					if($scope.ar1_form1.respondentInfo){
						if($scope.ar1_form1.respondentInfo.lawFirmDto){
							$scope.ar1_form1.respondentInfo.lawFirmDto.id = { 'id' : $scope.ar1_form1.respondentInfo.lawFirmDto.id};
						}
					}
				}
				if($scope.ar1_form1.respondentInfo.caseMemberRoleType == 'Individual'){
					$scope.respondentIndivStatus = true;
					$scope.registeredRespondentName = "Enter the respondent’s registered name";
					$scope.uenOrnricRespondentLabel = "NRIC/Passport Number";
					$scope.uenOrnricRespondent = "Enter your NRIC / Passport No.";
				} 
				for(var doc in $scope.ar1_form1.supportingDocuments){
					$scope.documents[doc]=true;
					$scope.termsUploadPathStatus[doc] = true;
					$scope.documentname[doc] = $scope.ar1_form1.supportingDocuments[doc].name;
					$scope.documentPath[doc] = $scope.ar1_form1.supportingDocuments[doc].fileLocation;
					$scope.documentUrl[doc] = smcConfig.services.DownloadSupportingDocument.url+$scope.ar1_form1.supportingDocuments[doc].id;
				}
				if($scope.ar1_form1.respondentInfo.isLegallyRepresented != "No"){
	    			$scope.respondentLegallyRepresentStatus = false;
	    		}

	    		if($scope.ar1_form1.respondentInfo.serviceAddress){
	            	if($scope.ar1_form1.respondentInfo.serviceAddress.faxNumber){
		                $scope.ar1_form1.respondentInfo.serviceAddress.faxNumber = $scope.ar1_form1.respondentInfo.serviceAddress.faxNumber.substring(3);
		            }
		            if($scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber){
		                $scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber = $scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber.substring(2);
		            }
	            }
	            

	    		if($scope.ar1_form1.respondentInfo.businessAddress.faxNumber){
                    $scope.ar1_form1.respondentInfo.businessAddress.faxNumber = $scope.ar1_form1.respondentInfo.businessAddress.faxNumber.substring(3);
                }
                
                if($scope.ar1_form1.respondentInfo.businessAddress.phoneNumber){
                	$scope.ar1_form1.respondentInfo.businessAddress.phoneNumber = $scope.ar1_form1.respondentInfo.businessAddress.phoneNumber.substring(2)
                }
                
                
                if($scope.ar1_form1.respondentInfo.lawFirmDto){
                    if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber.substring(3);
                    }
                    if($scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber.substring(3);
                    }

                    if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber.substring(2);
                    }
                    if($scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber){
                        $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber.substring(2);
                    }
                }

                if($scope.ar1_form1.regulationInfo){
	            	if($scope.ar1_form1.regulationInfo.ownerAddress){
	            		if($scope.ar1_form1.regulationInfo.ownerAddress.faxNumber){
	            			$scope.ar1_form1.regulationInfo.ownerAddress.faxNumber = $scope.ar1_form1.regulationInfo.ownerAddress.faxNumber.substring(3);
	            		}
	            	}
	            	if($scope.ar1_form1.regulationInfo.principalAddress){
	            		if($scope.ar1_form1.regulationInfo.principalAddress.faxNumber){
	            			$scope.ar1_form1.regulationInfo.principalAddress.faxNumber = $scope.ar1_form1.regulationInfo.principalAddress.faxNumber.substring(3);
	            		}
	            	}
	            }

				$scope.arFormOriginal = angular.copy($scope.ar1_form1);
			});
		}

		$scope.supportingDocYes = function(){
			if($scope.ar1_form1.respondentInfo.anySupportingDocument == true){
				angular.element(".overlay").css("display","block");
				angular.element("#supportingDocPopup").css("display","block");
			}
		}


		$scope.supportingDocNotificationPopup = function(){
			angular.element(".overlay").css("display","none");
			angular.element("#supportingDocPopup").css("display","none");
		}

		$scope.confirmSubmit = function(){
			DataService.get('GetConfirmMessageARform').then(function(data){
				$scope.displayARMessage = data.result.displayMessage;
			});
			angular.element(".overlay").css("display","block");
			angular.element("#submitFormconfirmPopup").css("display","block");
		}

		$scope.cancelSubmit = function(){
			angular.element(".overlay").css("display","none");
			angular.element("#submitFormconfirmPopup").css("display","none");
		}

		$scope.formARUpdateSubmit = function(form){

			$scope.initialComparison= angular.equals($scope.ar1_form1,$scope.arFormOriginal);
  			$scope.dataHasChanged= angular.copy($scope.initialComparison);
  			console.log($scope.ar1_form1);
  			console.log($scope.arFormOriginal);
  			console.log($scope.dataHasChanged);
  			


			
			angular.element(".form-submitt-confirm").css("display","none");
			angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");

			$scope.isSubmitted = true;
			//Validate Claimant Details are entered
			var claimentInvalid = angular.element("#updateARform .ng-invalid");
			var claimentInvalidCount = claimentInvalid.length;
			var errorMsgCount = angular.element("#updateARform .help-block:visible").length;
			if(claimentInvalidCount > 0 || errorMsgCount > 0){
				angular.element("#updateARform .ng-invalid").addClass("error");
				claimentInvalid[0].focus();
			} else{
				$scope.submitQuery = buildQurey();
				if($scope.submitQuery){
					DataService.post('ARformAuditTrail',$scope.submitQuery).then(function(data){
						if($scope.ar1_form1.respondentInfo.anySupportingDocument){
							var dateOfReceipt = $scope.ar1_form1.updateDateOfReceipt;
							var receiptQuery = {
								"caseNumber":$rootScope.casenumber,
								"receiptDate":dateOfReceipt
							};
							DataService.post('UpdateReceiptDate',receiptQuery).then(function(data){
								console.log(data);
							});
						}
						angular.element(".overlay").css("display","none");
						angular.element(".loading-container").css("display","none");
						console.log(data);
						if(data.status == "SUCCESS"){
							$scope.isPreviewClicked = false;
							$rootScope.tempCaseNumber = data.result.tempCaseNumber;
							$rootScope.saveResponseDetails = data.result;
							$scope.onlineFormActiveStatus = false;
							$scope.onlineSubmitStatus = true;
							$scope.onlineSaveStatus = false;
							$scope.arFormUpdateStatus = true;
							$rootScope.callFuntion();
						}
	        		});
				}
				
			}
		}


		

		function buildQurey(){
			var respondentInfoQueryNull = respondentInfoQuery();
			var respondentInfoQueryVar = removeNulls(respondentInfoQueryNull);
			var contractInfoQueryNull = contractInfoQuery();
			var contractInfoQueryVar = removeNulls(contractInfoQueryNull);
			var supportingDocumentsQueryVar = supportingDocumentsQuery();
			var caseDtoQueryNull = caseDtoQuery();
			var caseDtoQueryVar = removeNulls(caseDtoQueryNull);
			var query = {
				"formType":"ARForm",
				"smcOfficerId":$cookies.get('memberId'),
				"caseNumber":$rootScope.casenumber,
				"respondentInfo":respondentInfoQueryVar,
				"contractInfo":contractInfoQueryVar,
				"supportingDocuments":supportingDocumentsQueryVar,
				"caseDto": caseDtoQueryVar
			}
			return query;
		}
		
		function respondentInfoQuery(){
			var query = null;
			if($scope.ar1_form1.respondentInfo){
				var query = {};
				var caseMemberRoleType = $scope.ar1_form1.respondentInfo.caseMemberRoleType;
				var applicantUidValue = $scope.ar1_form1.respondentInfo.applicantUidValue;
				var memberName = $scope.ar1_form1.respondentInfo.memberName;
				var gender = $scope.ar1_form1.respondentInfo.gender;
				var email = $scope.ar1_form1.respondentInfo.email;
				var authRepresentative = $scope.ar1_form1.respondentInfo.authRepresentative;
				var authRepDesignation = $scope.ar1_form1.respondentInfo.authRepDesignation;
				var payeeName = $scope.ar1_form1.respondentInfo.payeeName;
				var isLegallyRepresented = $scope.ar1_form1.respondentInfo.isLegallyRepresented;
				var businessAddressNull = respondentBusinessAddressQuery();
				var businessAddress = removeNulls(businessAddressNull);
				var anySupportingDocument = $scope.ar1_form1.respondentInfo.anySupportingDocument;
				
				if(isLegallyRepresented == "Yes"){ 
					var lawFirmDtoNull = respondentlawFirmDtoQuery(); 
					var lawFirmDto = removeNulls(lawFirmDtoNull);
					var serviceAddress = null; 
				} else if(isLegallyRepresented == "No"){
					var serviceAddressNull = respondentServiceAddressQuery();
					var serviceAddress = removeNulls(serviceAddressNull);
					var lawFirmDto = null;
				} else {var serviceAddress = null; var lawFirmDto = null;}
				var query = {
					"caseMemberRoleType":compareSetNull(caseMemberRoleType,$scope.arFormOriginal.respondentInfo.caseMemberRoleType),
					"applicantUidValue":compareSetNull(applicantUidValue,$scope.arFormOriginal.respondentInfo.applicantUidValue),
					"memberName":compareSetNull(memberName,$scope.arFormOriginal.respondentInfo.memberName),
					"gender":compareSetNull(gender,$scope.arFormOriginal.respondentInfo.gender),
					"businessAddress":businessAddress,
					"serviceAddress":serviceAddress,
					"email":compareSetNull(email,$scope.arFormOriginal.respondentInfo.email),
					"authRepresentative":compareSetNull(authRepresentative,$scope.arFormOriginal.respondentInfo.authRepresentative),
					"authRepDesignation":compareSetNull(authRepDesignation,$scope.arFormOriginal.respondentInfo.authRepDesignation),
					"payeeName":compareSetNull(payeeName,$scope.arFormOriginal.respondentInfo.payeeName),
					"isLegallyRepresented":compareSetNull(isLegallyRepresented,$scope.arFormOriginal.respondentInfo.isLegallyRepresented),
					"lawFirmDto":lawFirmDto,
					"anySupportingDocument": compareSetNull(anySupportingDocument,$scope.arFormOriginal.respondentInfo.anySupportingDocument)
				};
			}
			return query;
		}
		function respondentBusinessAddressQuery(){
			var query = null;
			if ($scope.ar1_form1.respondentInfo.businessAddress){
				var query = {};
				var address1 = $scope.ar1_form1.respondentInfo.businessAddress.address1;
				var address2 = $scope.ar1_form1.respondentInfo.businessAddress.address2;
				var address3 = $scope.ar1_form1.respondentInfo.businessAddress.address3;
				var address4 = $scope.ar1_form1.respondentInfo.businessAddress.address4;
				var postalCode = $scope.ar1_form1.respondentInfo.businessAddress.postalCode;
				if($scope.ar1_form1.respondentInfo.businessAddress.phoneNumber){
					var phoneNumber = '65' + $scope.ar1_form1.respondentInfo.businessAddress.phoneNumber;
				}
				if($scope.ar1_form1.respondentInfo.businessAddress.faxNumber){
					var faxNumber = '+65'+ $scope.ar1_form1.respondentInfo.businessAddress.faxNumber;
				}
				
				if($scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress;
				} else {
					var isServiceAddress = false;
				}
				var query = {
					"address1":compareSetNull(address1,$scope.arFormOriginal.respondentInfo.businessAddress.address1),
					"address2":compareSetNull(address2,$scope.arFormOriginal.respondentInfo.businessAddress.address2),
					"address3":compareSetNull(address3,$scope.arFormOriginal.respondentInfo.businessAddress.address3),
					"address4":compareSetNull(address4,$scope.arFormOriginal.respondentInfo.businessAddress.address4),
					"postalCode":compareSetNull(postalCode,$scope.arFormOriginal.respondentInfo.businessAddress.postalCode),
					"phoneNumber":compareSetNull(phoneNumber,$scope.arFormOriginal.respondentInfo.businessAddress.phoneNumber),
					"faxNumber":compareSetNull(faxNumber,$scope.arFormOriginal.respondentInfo.businessAddress.faxNumber),
					"isServiceAddress":compareSetNull(isServiceAddress,$scope.arFormOriginal.respondentInfo.businessAddress.isServiceAddress)
				};
			}
			return query;
		}
		function respondentServiceAddressQuery(){
			var query = null;
			if($scope.ar1_form1.respondentInfo.businessAddress){
				var isServiceAddress = $scope.ar1_form1.respondentInfo.businessAddress.isServiceAddress;
				var isLegallyRepresented = $scope.ar1_form1.respondentInfo.isLegallyRepresented;
				if(!isServiceAddress && isLegallyRepresented == "No" && $scope.ar1_form1.respondentInfo.serviceAddress != undefined){
					var query = {};
					var address1 = $scope.ar1_form1.respondentInfo.serviceAddress.address1;
					var address2 = $scope.ar1_form1.respondentInfo.serviceAddress.address2;
					var address3 = $scope.ar1_form1.respondentInfo.serviceAddress.address3;
					var address4 = $scope.ar1_form1.respondentInfo.serviceAddress.address4;
					var postalCode = $scope.ar1_form1.respondentInfo.serviceAddress.postalCode;
					if($scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber){
						var phoneNumber = '65' + $scope.ar1_form1.respondentInfo.serviceAddress.phoneNumber;
					}
					if($scope.ar1_form1.respondentInfo.serviceAddress.faxNumber){
						var faxNumber = '+65'+ $scope.ar1_form1.respondentInfo.serviceAddress.faxNumber;
					}
					var query = {
						"address1":compareSetNull(address1,$scope.arFormOriginal.respondentInfo.serviceAddress.address1),
						"address2":compareSetNull(address2,$scope.arFormOriginal.respondentInfo.serviceAddress.address2),
						"address3":compareSetNull(address3,$scope.arFormOriginal.respondentInfo.serviceAddress.address3),
						"address4":compareSetNull(address4,$scope.arFormOriginal.respondentInfo.serviceAddress.address4),
						"postalCode":compareSetNull(postalCode,$scope.arFormOriginal.respondentInfo.serviceAddress.postalCode),
						"phoneNumber":compareSetNull(phoneNumber,$scope.arFormOriginal.respondentInfo.serviceAddress.phoneNumber),
						"faxNumber":compareSetNull(faxNumber,$scope.arFormOriginal.respondentInfo.serviceAddress.faxNumber)
					};
				}
			}
			return query;
		}
		function respondentlawFirmDtoQuery(){
			var query = null;
			if($scope.ar1_form1.respondentInfo.lawFirmDto){
				var query = {};
				if($scope.ar1_form1.respondentInfo.lawFirmDto.id){
					var lawerAddressId = $scope.ar1_form1.respondentInfo.lawFirmDto.id;
					lawerAddressId = lawerAddressId.id;
				} else {
					var lawerAddressId = undefined;
				}
				var name = $scope.ar1_form1.respondentInfo.lawFirmDto.name;
				var businessAddressNull = respondentlawFirmBusinessAddressQuery();
				var businessAddress = removeNulls(businessAddressNull);
				var serviceAddressNull = respondentlawFirmServiceAddressQuery();
				var serviceAddress = removeNulls(serviceAddressNull);
				var lawyerDetailsNull = respondentlawyersDetailsQuery();
				var lawyerDetails = removeNulls(lawyerDetailsNull);
				var referenceNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.referenceNumber;
				if($scope.arFormOriginal.respondentInfo.lawFirmDto){
					var query = {
						"id":compareSetNull(lawerAddressId,$scope.arFormOriginal.respondentInfo.lawFirmDto.id.id),
						"name":compareSetNull(name,$scope.arFormOriginal.respondentInfo.lawFirmDto.name),
						"businessAddress":businessAddress,
				        "serviceAddress":serviceAddress,
						"lawyerDetails":lawyerDetails,
						"referenceNumber":compareSetNull(referenceNumber,$scope.arFormOriginal.respondentInfo.lawFirmDto.referenceNumber)
					};
				}else{
					var query = {
						"id":undefinedSetNull(lawerAddressId),
						"name":undefinedSetNull(name),
						"businessAddress":businessAddress,
				        "serviceAddress":serviceAddress,
						"lawyerDetails":lawyerDetails,
						"referenceNumber":undefinedSetNull(referenceNumber)
					};
				}
			}
			return query;
		}
		function respondentlawFirmBusinessAddressQuery(){
			var query = null;
			if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress){
				var query = {};
				var address1 = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address1;
				var address2 = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address2;
				var address3 = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address3;
				var address4 = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.address4;
				var postalCode = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.postalCode;
				var phoneNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.phoneNumber;
				var faxNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.faxNumber;
				var isServiceAddress = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
				if($scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress){
					var isServiceAddress = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
				} else {
					var isServiceAddress = false;
				}
				if($scope.arFormOriginal.respondentInfo.lawFirmDto){
					var query = { 
				        "address1":compareSetNull(address1,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.address1),
						"address2":compareSetNull(address2,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.address2),
						"address3":compareSetNull(address3,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.address3),
						"address4":compareSetNull(address4,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.address4),
				        "postalCode":compareSetNull(postalCode,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.postalCode),
				        "phoneNumber":compareSetNull(phoneNumber,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.phoneNumber),
				        "faxNumber":compareSetNull(faxNumber,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.faxNumber),
				        "isServiceAddress":compareSetNull(isServiceAddress,$scope.arFormOriginal.respondentInfo.lawFirmDto.businessAddress.isServiceAddress)
					};
				}else{
					var query = { 
				        "address1":undefinedSetNull(address1),
						"address2":undefinedSetNull(address2),
						"address3":undefinedSetNull(address3),
						"address4":undefinedSetNull(address4),
				        "postalCode":undefinedSetNull(postalCode),
				        "phoneNumber":undefinedSetNull(phoneNumber),
				        "faxNumber":undefinedSetNull(faxNumber),
				        "isServiceAddress":undefinedSetNull(isServiceAddress)
					};
				}
				
			}
			return query;
		}

		function undefinedSetNull(val){
            if(val){
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

		function respondentlawFirmServiceAddressQuery(){
			var query = null;
			var isServiceAddress = $scope.ar1_form1.respondentInfo.lawFirmDto.businessAddress.isServiceAddress;
			if(!isServiceAddress && $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress != undefined){
				var query = {};
				var address1 = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.address1;
				var address2 = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.address2;
				var address3 = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.address3;
				var address4 = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.address4;
				var postalCode = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.postalCode;
				var phoneNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.phoneNumber;
				var faxNumber = $scope.ar1_form1.respondentInfo.lawFirmDto.serviceAddress.faxNumber;
				if($scope.arFormOriginal.respondentInfo.lawFirmDto){
					var query = { 
				        "address1":compareSetNull(address1,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.address1),
						"address2":compareSetNull(address2,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.address2),
						"address3":compareSetNull(address3,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.address3),
						"address4":compareSetNull(address4,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.address4),
				        "postalCode":compareSetNull(postalCode,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.postalCode),
				        "phoneNumber":compareSetNull(phoneNumber,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.phoneNumber),
				        "faxNumber":compareSetNull(faxNumber,$scope.arFormOriginal.respondentInfo.lawFirmDto.serviceAddress.faxNumber)
					};
				}else{
					var query = { 
				        "address1":undefinedSetNull(address1),
						"address2":undefinedSetNull(address2),
						"address3":undefinedSetNull(address3),
						"address4":undefinedSetNull(address4),
				        "postalCode":undefinedSetNull(postalCode),
				        "phoneNumber":undefinedSetNull(phoneNumber),
				        "faxNumber":undefinedSetNull(faxNumber)
					};
				}
				
			}
			return query;
		}

		function respondentlawyersDetailsQuery(){
			var query = null;
			if($scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails){
				var query = [];
				var respondent_l2name = "";
				var respondent_l3name = "";
				var respondent_lname = $scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[0].lawyerName;
				var respondent_lemail = $scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[0].email;
				if($scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[1]){
					var respondent_l2name = $scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[1].lawyerName;
					var respondent_l2email = $scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[1].email;
				}
				if($scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[2]){
					var respondent_l3name = $scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[2].lawyerName;
					var respondent_l3email = $scope.ar1_form1.respondentInfo.lawFirmDto.lawyerDetails[2].email;
				}
				if(respondent_lname && respondent_lemail){
					if($scope.arFormOriginal.respondentInfo.lawFirmDto){
						var lawyer1 = {
							"lawyerName":compareSetNull(respondent_lname,$scope.arFormOriginal.respondentInfo.lawFirmDto.lawyerDetails[0].lawyerName),
							"email":compareSetNull(respondent_lemail,$scope.arFormOriginal.respondentInfo.lawFirmDto.lawyerDetails[0].email),
							"index":0
						};
						query.push(lawyer1);
					}else{
						var lawyer1 = {
							"lawyerName":undefinedSetNull(respondent_lname),
							"email":undefinedSetNull(respondent_lemail),
							"index":0
						};
						query.push(lawyer1);
					}
				}
				if(respondent_l2name && respondent_l2email){
					if($scope.arFormOriginal.respondentInfo.lawFirmDto){
						var lawyer2 = {
							"lawyerName":compareSetNull(respondent_l2name,$scope.arFormOriginal.respondentInfo.lawFirmDto.lawyerDetails[1].lawyerName),
							"email":compareSetNull(respondent_l2email,$scope.arFormOriginal.respondentInfo.lawFirmDto.lawyerDetails[1].email),
							"index":1
						}
						query.push(lawyer2);
					}else{
						var lawyer2 = {
							"lawyerName":undefinedSetNull(respondent_l2name),
							"email":undefinedSetNull(respondent_l2email),
							"index":1
						}
						query.push(lawyer2);
					}
				}
				if(respondent_l3name && respondent_l3email){
					if($scope.arFormOriginal.respondentInfo.lawFirmDto){
						var lawyer3 = {
							"lawyerName":compareSetNull(respondent_l3name,$scope.arFormOriginal.respondentInfo.lawFirmDto.lawyerDetails[2].lawyerName),
							"email":compareSetNull(respondent_l3email,$scope.arFormOriginal.respondentInfo.lawFirmDto.lawyerDetails[2].email),
							"index":2
						}
						query.push(lawyer3);
					}else{
						var lawyer3 = {
							"lawyerName":undefinedSetNull(respondent_l3name),
							"email":undefinedSetNull(respondent_l3email),
							"index":2
						}
						query.push(lawyer3);
					}
				}
			}
			return query;
		}

		function contractInfoQuery(){
			var query = null;
			if($scope.ar1_form1.contractInfo){
				var query = {};
				var projectReference = $scope.ar1_form1.contractInfo.projectReference;
				var contractNumber = $scope.ar1_form1.contractInfo.contractNumber;
				if($scope.ar1_form1.contractInfo.contractType && $scope.ar1_form1.contractInfo.contractType != "null"){
					var contractType = $scope.ar1_form1.contractInfo.contractType;
					contractType = contractType.id;
				} else {
					var contractType = undefined;
				}
				
				var natureOfDispute = $scope.ar1_form1.contractInfo.natureOfDispute;
				var contractMadeOn = $scope.ar1_form1.contractInfo.contractMadeOn;
				var mainContractMadeOn = $scope.ar1_form1.contractInfo.mainContractMadeOn;
				var query = {
					"projectReference":compareSetNull(projectReference,$scope.arFormOriginal.contractInfo.projectReference),
					"contractNumber":compareSetNull(contractNumber,$scope.arFormOriginal.contractInfo.contractNumber),
					"contractType":compareSetNull(contractType,$scope.arFormOriginal.contractInfo.contractType),
					"natureOfDispute":compareSetNull(natureOfDispute,$scope.arFormOriginal.contractInfo.natureOfDispute),
					"contractMadeOn":compareSetNull(contractMadeOn,$scope.arFormOriginal.contractInfo.contractMadeOn),
					"mainContractMadeOn":compareSetNull(mainContractMadeOn,$scope.arFormOriginal.contractInfo.mainContractMadeOn)
				};
			}
			return query;
		}
		
		function supportingDocumentsQuery(){
			var documentQuery = [];
			
			if($scope.documentPath.length != 0){
				for(var index = 0;index<$scope.documentPath.length;index++){
					if($scope.documentname[index]){
						var query = {
							 "index":index,
					         "status":true,
					         "name":$scope.documentname[index],
							 "fileLocation":$scope.documentPath[index]
						};
					}else{
						var query = {
					        "index":index,
					         "status":false
					      }
					}
					
					documentQuery.push(query);
				}
			}
			return documentQuery
		}
		
		function caseDtoQuery(){
			var query = null;
			if($scope.ar1_form1.caseDto){
				var query = {};
				var resAuthPerson = $scope.ar1_form1.caseDto.resAuthPerson;
				var resAuthPersonRef = $scope.ar1_form1.caseDto.resAuthPersonRef;
				var constitutingDocResponse = $scope.ar1_form1.caseDto.constitutingDocResponse;
				var query = {
					"resAuthPerson":compareSetNull(resAuthPerson,$scope.arFormOriginal.caseDto.resAuthPerson),
					"resAuthPersonRef":compareSetNull(resAuthPersonRef,$scope.arFormOriginal.caseDto.resAuthPersonRef),
					"constitutingDocResponse":compareSetNull(constitutingDocResponse,$scope.arFormOriginal.caseDto.constitutingDocResponse)
				};
			}
			return query;
		}

		function compareSetNull(val,org){
			if(val){
				if(val === org){
					var val = null;
				}
			} else {
				var val = null;	
			}
			return val;
		}
		function removeNulls(obj) {
		  var isArray = obj instanceof Array;
		  for (var k in obj) {
		    if (obj[k] === null) isArray ? obj.splice(k, 1) : delete obj[k];
		    else if (typeof obj[k] == "object") removeNulls(obj[k]);
		    if (isArray && obj.length == k) removeNulls(obj);
		  }
		  if(obj == {}){
		  	obj = null;
		  }

		  return obj;
		}

		// upload a file - before that check file size,valid exetension
		$scope.uploadFile = function(file,index){
			var file = file;
			var index = index;
			if ( file.size < 5242881 ){
				if(validateUploadFileExtention(file.name)){
					$scope.documentname[index] = file.name;
					console.log('$scope.uploadname',$scope.documentname);
					var fd= new FormData();
					fd.append('file',file);
					httpPostFactory(smcConfig.services.UploadFileSubmisson.url,fd,function (data){
						console.log(data);
						$scope.documentPath[index] = data.result;
						console.log('$scope.documentPath',$scope.documentPath)
						$scope.termsUploadPathStatus[index] = true;
					});
				}
				else{
					var elementIdname = "#uploadname"+index;
					angular.element(elementIdname).addClass("error");
					var allowedExt = $scope.fileUploadTypes;
					$scope.termsUploadErrorMsg = "You are allowed to upload only " + allowedExt.toString(); 
					NotifyFactory.log('error',$scope.termsUploadErrorMsg);
				}
			}else{
				NotifyFactory.log('error','Please upload below 5MB file')
			}
		}
		// check valid file by exetension
		function validateUploadFileExtention(val){
			var allowedExt = $scope.fileUploadTypes;

			var ext = val.split('.').pop();
			for(var i = 0; i < allowedExt.length; i++){
				if($scope.fileUploadTypes[i] == ext){
					return true;
				}
			}
		}
		$scope.openAuditTrialPopup=function(){
			angular.element('.audit-trial-modal').css("display","block");
			angular.element(".overlay").css("display","block");
			var query = {
						"caseNumber":$cookies.get('caseNumber'),
						"formName":"AAForm"				
						};
			DataService.post('AuditTrialData', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                	$scope.shownodataavailable=false;
                    $scope.auditTrialData=data.result.responseData;
                }
            }).catch(function (error) {
                $scope.shownodataavailable=true;
                NotifyFactory.log('error', error.errorMessage);
            });
		}
		
		$scope.closeAuditTrial=function () {
			angular.element('.audit-trial-modal').css("display","none");
			angular.element(".overlay").css("display","none");
		}

		// if we want remove upload file
		$scope.termsUploadRemove = function(index){
			var fileCount = 0;
			$scope.documentname[index] = undefined;
			$scope.documentPath[index] = undefined;
			for(var count=0;count<$scope.documentPath.length;count++){
				if($scope.documentPath[count] == undefined){
					fileCount = fileCount+1;
				}
			}
			if(fileCount == $scope.documentPath.length){
				$scope.documentPath =[];
				$scope.documentname = [];
			}
			$scope.termsUploadPathStatus[index] = false;
		}
		// back to form from acknowledgement
		$scope.backToForm = function(){
			$scope.onlineFormActiveStatus = true;
			$scope.onlineSubmitStatus = false;
			$scope.onlineSaveStatus = false;
		}
		// add one more element to upload document
		$scope.addonemoredocument = function(){
			if($scope.documents.length<5){
				$scope.documents.push(true);
			}else{
				NotifyFactory.log('error','limit only 5 documents')
			}
		}
		// remove one more element to upload document
		$scope.removeonemoredocument = function(){
			$scope.documents.pop()
		}

		$scope.backToForm=function(){
			console.log("Backtoform");
			$scope.arFormUpdateStatus = false;
		}
 	}
 })();