/*This Controller for SMC Management to get changes payee name requests from SMC officers
So, SMC Manager Will Check it And Approve Or Amand And give valuable reason*/
(function() {
    'use strict';
    angular
        .module('smc')
        .controller('memberDashboardCtrl',memberDashboardCtrl);

    memberDashboardCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory','navigateConfig'];

    function memberDashboardCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory,navigateConfig){
        if($rootScope.loginModuleRoles){
           memberdashboardcheck();
        }
        else{
            var query = {
                "userId": $cookies.get('userMail'),
                "password": $cookies.get('Password')
            };
            DataService.post('SmcMemberLogin',query).then(function (data) {
                if(data.status == 'SUCCESS'){
                    
                    $rootScope.loginModuleRoles = data.result.moduleRoles;
                    memberdashboardcheck();
                }else{
                    NotifyFactory.log('error', data.errorMessage);
                }
            }, function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        $cookies.put('moduleName','Dashboard');

        function memberdashboardcheck(){
            $rootScope.modules = [{'moduleName' : 'Adjudication'},{'moduleName' : 'Mediation'},{'moduleName' : 'Training'},{'moduleName' : 'Contact'},{'moduleName' : 'Admin'}]
            for(var role in $rootScope.modules){
                for(var module in $rootScope.loginModuleRoles){
                    if($rootScope.modules[role].moduleName == $rootScope.loginModuleRoles[module].moduleName){
                        $rootScope.modules[role].roleName = $rootScope.loginModuleRoles[module].roleName;
                        $rootScope.modules[role].moduleId = $rootScope.loginModuleRoles[module].moduleId;
                        $rootScope.modules[role].roleId = $rootScope.loginModuleRoles[module].roleId;
                    }
                }
                if($rootScope.modules[role].roleName == 'Case Officer' || $rootScope.modules[role].roleName == 'Assistant Manager' || $rootScope.modules[role].roleName == 'Training Officer' || $rootScope.modules[role].roleName == 'Contact Officer'){
                    $rootScope.modules[role].roleRights = 'SMC Officer';
                }else{
                    $rootScope.modules[role].roleRights = $rootScope.modules[role].roleName;
                }

                if($rootScope.modules[role].roleRights){
                    $rootScope.modules[role].userMenu = navigateConfig[$rootScope.modules[role].moduleName][$rootScope.modules[role].roleRights];
                }
            }
        }

        $scope.goToPage = function(pageUrl, module){
            $cookies.put('roleName',module.roleRights);
            $cookies.put('moduleName',module.moduleName);
            $cookies.put('moduleId',module.moduleId);
            $cookies.put('roleId',module.roleId);
            $cookies.put('displayRoleName',module.roleName);
            $cookies.put('currentActionMenu',pageUrl.displayName);
            $state.go(pageUrl.url);
        }
    }
})();	