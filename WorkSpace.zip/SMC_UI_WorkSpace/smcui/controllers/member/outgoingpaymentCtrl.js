(function () {
    'use strict';
    angular
        .module('smc')
        .controller('outgoingpaymentCaseCtrl', outgoingpaymentCaseCtrl);

    outgoingpaymentCaseCtrl.$inject = ['$rootScope', '$scope', '$state', '$cookies', 'DataService', '$http', 'patternConfig', 'httpPostFactory', 'smcConfig', 'NotifyFactory','healthCheckConfig'];

    function outgoingpaymentCaseCtrl($rootScope, $scope, $state, $cookies, DataService, $http, patternConfig, httpPostFactory, smcConfig, NotifyFactory,healthCheckConfig) {
        if ($cookies.get('roleName') != 'SMC Officer' && $cookies.get('roleName') != 'SMC Management' || $cookies.get('moduleName') != 'Adjudication') {
            $state.go('smclayout.membershiplayout.memberlogin');
        }
        $scope.reverseSort = false;
        $scope.roleName = $cookies.get('roleName');
        $scope.casestatus_modal_path = 'views/member/case-status.html';
        $scope.casestatus_modal_path = 'views/member/case-status.html';
        $scope.eFaxModelPath = 'views/member/e-fax.html';
        $scope.eFaxViewModelPath = 'views/member/e-fax-view.html';
        $scope.eMailLogModelPath = 'views/member/email-log.html';

        $scope.shownodataavailable = false;
        if ($cookies.get('pageNumber') && $cookies.get('currentTab') == 'outgoingpayment') {
            $scope.pagenumber = parseInt($cookies.get('pageNumber'));
        } else {
            $scope.pagenumber = 0;
        }
        $scope.dataLength = 10;
        $scope.max_pagenumber = '';
        get_outgoingpayment_caselist($scope.pagenumber); //call to incomplete case list function
        $cookies.put('currentTab', 'outgoingpayment');
        $scope.update_payeename_modal_path = 'views/member/update-payeename-modal.html';
        $scope.resignation_withdraw_modal_path = 'views/popups/resignation_withdraw_modal.html';
        $scope.casestatus_modal_path = 'views/member/case-status.html';

        $scope.$emit('activeTab', $cookies.get('currentTab')); //sent current tab status

        //Get Approved memo Url
        $scope.downloadApprovedMemo = smcConfig.services.DownloadApprovedMemo.url;
        $scope.generateDownloadDeterUrl = smcConfig.services.DownloadDetermineDocument.url;
        $scope.generateDownloadUrl = smcConfig.services.DownloadSupportingDocument.url;

        //call to incomplete case list function from outside
        $rootScope.outgoingpaymentcaselist = function (pageNo) {
                get_outgoingpayment_caselist(pageNo);
            }
            // get incomplete case list
        function get_outgoingpayment_caselist(pageNumber) {
            if (pageNumber) {
                $scope.pagenumber = pageNumber;
            } else {
                $scope.pagenumber = 0;
            }
            $cookies.put('pageNumber', $scope.pagenumber)
            var sorting = [
                [0, 0],
                [1, 0]
            ];
            var query = {
                "pageIndex": pageNumber,
                "dataLength": $scope.dataLength,
                "sortingColumn": null,
                "sortDirection": null,
                "claimantName": null,
                "respondentName": null,
                "tempCaseNumber": null,
                "claimedAmountFrom": null,
                "claimedAmountTo": null,
                "dateFrom": null,
                "dateTo": null
            }
            getOutgoingPaymentCases(query);
        }

        $scope.goToPageNumber = function (pageNo) {
                get_outgoingpayment_caselist(pageNo);
            }
          
    $scope.$on('filterCases', function (event, filter) {
       
           
            if ($cookies.get('currentTab') == 'outgoingpayment') {
               
                var query = {
                    "claimantName": undefinedSetNull(filter.claimantName),
                    "respondentName": undefinedSetNull(filter.respondentName),
                    "tempCaseNumber": undefinedSetNull(filter.caseNumber),
                    "claimedAmountFrom": undefinedSetNull(filter.claimedAmountFrom),
                    "claimedAmountTo": undefinedSetNull(filter.claimedAmountTo),
                    "dateFrom": undefinedSetNull(filter.dateFrom),
                    "dateTo": undefinedSetNull(filter.dateTo)
                }
                 
                getOutgoingPaymentCases(query);
               
            }
        });
    
         $scope.$on('resetCases', function (event, reset) {
            if ($cookies.get('currentTab') == 'outgoingpayment') {
                get_outgoingpayment_caselist(0);
            }
        });
       

        function getOutgoingPaymentCases(query){
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
              DataService.post('GetOutgoingPaymentCases', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                    $scope.shownodataavailable = false;
                    $scope.outgoingpayment_Case_List = data.result.responseData;

                    for (var index = 0; index < $scope.outgoingpayment_Case_List.length; index++) {
                        $scope.caseNo = $scope.outgoingpayment_Case_List[index].caseNumber;
                        var result = $scope.caseNo;
                        result = result.search("SOP");
                        if (result == 0) {
                            $scope.outgoingpayment_Case_List[index].pattern_CaseNo = $scope.caseNo.substring(0, 3) + ' ' + $scope.caseNo.substring(3, 5) + ' ' + $scope.caseNo.substring(5, 9) + ' of ' + $scope.caseNo.substring(9, 13);
                        } else {
                            $scope.outgoingpayment_Case_List[index].pattern_CaseNo = $scope.caseNo;
                        }
                    }

                    $scope.max_pagenumber = data.result.totalData / $scope.dataLength;
                    var value = Math.round($scope.max_pagenumber);
                    if (value < $scope.max_pagenumber) {
                        $scope.max_pagenumber = value + 1;
                    } else {
                        $scope.max_pagenumber = value;
                    }
                } else {
                    $scope.shownodataavailable = true;
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
                if (error.errorCode == 100) {
                    $scope.shownodataavailable = true;
                }
            });
        }

        $scope.updateChequePostedDate = function(caseData){
             $scope.caseData=caseData;
             var viewDateOfSericeUrl = smcConfig.services.ViewChequePostedDate.url;
             viewDateOfSericeUrl = viewDateOfSericeUrl + caseData.caseNumber;   
             $http.get(viewDateOfSericeUrl).then(function (data) {                   
                 if(data.data.status=="SUCCESS"){
                   $scope.caseData.claimantChequeDate=data.data.result.claimantPostedDate;
                   $scope.caseData.respondentPostedDate=data.data.result.respondentPostedDate;
                   $scope.caseData.adjudicatorChequeDate=data.data.result.adjudicatorPostedDate;                     
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
                
             });
           
            angular.element(".update-cheque-posted-date-model").css("display","block");
            angular.element(".overlay").css("display","block");
        }

        $scope.submitChequePostedDate =function(caseData){
                if(caseData.caseType=='AA Case'){
                    var query = {
                         "caseNumber": caseData.caseNumber,
                         "smcOfficerId": parseInt($cookies.get('memberId')),
                         "tabType": "Outgoing Payment",
                         "adjudicatorPostedDate": undefinedSetNull(caseData.adjudicatorChequeDate),
                         "claimantPostedDate":undefinedSetNull(caseData.claimantChequeDate)
                    }
                 DataService.post('UpdateChequePostedDate', query).then(function (data) {
                         if (data.status == 'SUCCESS') {
                             angular.element(".update-cheque-posted-date-model").css("display","none");
                             angular.element(".overlay").css("display","none");
                             NotifyFactory.log('success', 'Cheque posted date updated');
                         } else {
                             NotifyFactory.log('error', data.errorMessage);
                         }
                     })
                     .catch(function (error) {
                         NotifyFactory.log('error', error.errorMessage);
                     });

                }else if(caseData.caseType=='ARA Case'){
                    var query = {
                         "caseNumber": caseData.caseNumber,
                         "smcOfficerId": parseInt($cookies.get('memberId')),
                         "tabType": "Outgoing Payment",
                         "adjudicatorPostedDate": undefinedSetNull(caseData.adjudicatorChequeDate),
                         "respondentPostedDate":undefinedSetNull(caseData.respondentPostedDate)
                    }
                 DataService.post('UpdateChequePostedDateARA', query).then(function (data) {
                         if (data.status == 'SUCCESS') {
                             angular.element(".update-cheque-posted-date-model").css("display","none");
                             angular.element(".overlay").css("display","none");
                             NotifyFactory.log('success', 'Cheque posted date updated');
                         } else {
                             NotifyFactory.log('error', data.errorMessage);
                         }
                     })
                     .catch(function (error) {
                         NotifyFactory.log('error', error.errorMessage);
                     });
                }

                  
        }
        $scope.closeUpdateChequepopup=function(){
            angular.element(".update-cheque-posted-date-model").css("display","none");
            angular.element(".overlay").css("display","none");
        }
        
        $scope.goNextInEmailLog=function(casenumber,pageNumber){
            getEmailLogList(casenumber,pageNumber)
        }
        // show email log 
        $scope.showEmailLog=function(casenumber,pageNumber){  
            getEmailLogList(casenumber,pageNumber)
        }

        function getEmailLogList(casenumber,pageNumber){
            angular.element(".overlay").css("display","block");
			angular.element(".loading-container").css("display","block");
            $scope.eMailLogCaseNumber = casenumber;
             if(pageNumber){
                $scope.emailLogPagenumber = pageNumber;
            }else{
                $scope.emailLogPagenumber = 0;
            }
            var query={
                    "caseNumber":casenumber,
                    "pageIndex":$scope.emailLogPagenumber,
                    "dataLength":10,
                    "sortingColumn":null,
                    "sortDirection":null
            }                           
            DataService.post('GetEmailLogDetail', query).then(function (data) {
                if (data.status == 'SUCCESS') {
			            angular.element(".loading-container").css("display","none");
                        angular.element(".overlay").css("display", "block");
                        angular.element(".show-email-log").css("display", "block");
                        $scope.EmailLogdata=data.result.responseData; 
                        $scope.max_EmailLog_Pagenumber  =  data.result.totalPages;
                } else {
                    NotifyFactory.log('error', data.errorMessage);
                    angular.element(".overlay").css("display","none");
			        angular.element(".loading-container").css("display","none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
                angular.element(".overlay").css("display","none");
			    angular.element(".loading-container").css("display","none");
            });
        }

        $scope.viewEmailLog=function(data){
            $scope.goingToEdit=data;
             $scope.disableEmailContent=true;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.editEmailLog=function(index){
            $scope.updateIndexContent = index;
            if($scope.EmailLogdata[index].updateContent){
                $scope.goingToEdit = $scope.EmailLogdata[index].updateContent;
            }else{
                $scope.goingToEdit = $scope.EmailLogdata[index].content;
            }
            $scope.disableEmailContent=false;
            angular.element(".overlay").css("display", "block");
            angular.element(".show-email-log").css("display", "none");
            angular.element(".view-email-log").css("display", "block");
        }

        $scope.resendEmailLog=function(data,index){ 
                         
                if(data.updateContent){
                   var contentData=data.updateContent;
                }else{
                    var contentData=data.content;
                }
                var query={
                    "id":data.id,
                    "content":contentData
                }
                DataService.post('ResendEmailLogDetail', query).then(function (data) {                                   
                    if (data.status == 'SUCCESS') {
                        $scope.EmailLogdata[index] = data.result;
                        NotifyFactory.log('success', 'Mail sent successfully');
                    } else {
                        NotifyFactory.log('error', data.errorMessage);
                    }
                }).catch(function (error) {
                    NotifyFactory.log('error', error.errorMessage);
                });
        }
           
        $scope.cancelModCaseLog=function(){
             angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        $scope.closelistLog=function(){
            angular.element(".overlay").css("display", "none");
            angular.element(".show-email-log").css("display", "none");      
        }

        $scope.updateContent = function(updatedContent, index){
            if($scope.EmailLogdata[index].updateContent){
                if($scope.EmailLogdata[index].updateContent!= updatedContent){
                    $scope.EmailLogdata[index].updateContent = updatedContent
                }
            }
            else if($scope.EmailLogdata[index].content != updatedContent){
                $scope.EmailLogdata[index].updateContent = updatedContent;
            }
            angular.element(".overlay").css("display", "block");
            angular.element(".view-email-log").css("display", "none");
            angular.element(".show-email-log").css("display", "block");
        }

        //E-fax
        $scope.viewEfaxStatus=function(caseNumber,pageNumber){
             $scope.eFaxCaseNumber =caseNumber;
             viewFaxData(pageNumber);
        } 

        $scope.nextEfax=function(pageNumber){
            viewFaxData(pageNumber);
        }

        function viewFaxData(pageNumber){
             if(pageNumber){
                     $scope.eFaxPagenumber  = pageNumber;
                }else{
                    $scope.eFaxPagenumber  = 0;
                }

              var query = {
                "pageIndex": pageNumber,
                "dataLength": 10,
                "sortingColumn": null,
                "sortDirection": null,
                "caseNumber": $scope.eFaxCaseNumber
                }

                DataService.post('ViewFaxLog', query).then(function (data) {
                    if (data.status == 'SUCCESS') {
                        if(data.result.totalData>0){
                            $scope.ifEfaxnoAvailable=false;
                        }else{
                            $scope.ifEfaxnoAvailable=true;
                        }
                        $scope.faxData=data.result.responseData;
                        $scope.max_Efax_Pagenumber  =  data.result.totalPages;
                        angular.element(".overlay").css("display","block");
                        angular.element(".eFax-status").css("display","block"); 
                    }
                }).catch(function (error) {
                    $scope.ifEfaxnoAvailable=true;
                    NotifyFactory.log('error', error.errorMessage);
                }); 
        }

       

        $scope.closeEfaxPopup=function(){
             angular.element(".overlay").css("display","none");
             angular.element(".eFax-status").css("display","none");
         }

         $scope.viewFaxDetail=function(faxId){
            $scope.faxId=faxId;
            var getFaxDetail = smcConfig.services.GetFaxDetail.url;
            var getFaxDetailUrl = getFaxDetail + faxId;
            var downloadFaxDetail = smcConfig.services.DownloadFaxData.url;
            $http.get(getFaxDetailUrl).then(function(data){
                $scope.faxDetailsView=data.data.result;
                angular.element(".overlay").css("display","block");
                angular.element(".eFax-status").css("display","none");
                angular.element("#view_fax").css("display", "block");
                
            })
            .catch(function(error){
                console.log('errorcaselist',error);
            });

         }

         $scope.closeViewfax=function(){
            angular.element("#view_fax").css("display", "none");
            angular.element(".eFax-status").css("display","block");

         }

    
        //to open update payee name modal
        $scope.updatePayeeModal = function (caseNumber) {
            $rootScope.payeeCaseNumber = caseNumber;
            $rootScope.payeedetails = {};
            $rootScope.supprtDocumentName = null;
            $rootScope.attachcopyStatus = false;
            angular.element(".overlay").css("display", "block");
            angular.element(".update-payee-name").css("display", "block");
            $rootScope.getPayeeName(); //call function
        }

        //to close update payee name modal
        $scope.closepayeepop = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".update-payee-name").css("display", "none");
        }

        //view time Sheet
        $scope.viewTimeSheet = function (caseData) {
            $scope.goingToApporve = false;
                $scope.ClaimantName = caseData.claimantName;
                $scope.Respond = caseData.respondentName;
                $scope.timesheetNumber = caseData.caseNumber;
                if(caseData.caseType == 'AA Case'){
                    if(caseData.caseStatus.indexOf('Adjudicator Time Cost Request') != -1 && caseData.caseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') == -1 && caseData.caseStatus.indexOf('SMC Officer Approve Adjudicator Time Sheet') == -1){
                        $scope.goingToApporve = true;
                    }else if(caseData.caseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') != -1 && caseData.caseStatus.indexOf('Time Sheet ReSubmitted') != -1){
                        $scope.goingToApporve = true;
                    }
                    getAATimesheet(caseData.caseNumber)
                }else{
                    if(caseData.araCaseStatus.indexOf('Adjudicator Time Cost Request') != -1 && caseData.araCaseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') == -1 && caseData.araCaseStatus.indexOf('SMC Officer Approve Adjudicator Time Sheet') == -1){
                        $scope.goingToApporve = true;
                    }else if(caseData.araCaseStatus.indexOf('SMC Officer Amend Adjudicator Time Sheet') != -1 && caseData.araCaseStatus.indexOf('Time Sheet ReSubmitted') != -1){
                        $scope.goingToApporve = true;
                    }
                    getARATimeSheet(caseData.caseNumber)
                }
        }

        function getAATimesheet(caseNo){
            var GetTimeSheetDataUrl = smcConfig.services.GetTimeSheetData.url;
                GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNo;
                angular.element(".overlay").css("display","block");
                angular.element(".loading-container").css("display","block");
                $http.get(GetTimeSheetDataUrl).then(function (data) {
                    console.log("data", data)
                    angular.element(".overlay").css("display","block");
                    angular.element(".loading-container").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                    $scope.timeSheetData = data.data.result;
                    if ($scope.timeSheetData.supportingDocument) {
                        $scope.supprtDocumentName = $scope.timeSheetData.supportingDocument.name;
                        $scope.supportingDocument = $scope.timeSheetData.supportingDocument.fileLocation;
                        $scope.attachcopyStatus = true;
                    }
                    $rootScope.workingDatas = $scope.timeSheetData.workedHours;
                }).catch(function (error) {
                    angular.element(".overlay").css("display","none");
                    angular.element(".loading-container").css("display","none");
                    NotifyFactory.log('error', error.errorMessage);
                });
        }

        function getARATimeSheet(caseNo){
            var GetTimeSheetDataUrl = smcConfig.services.ViewARATimeSheetOfficer.url;
             GetTimeSheetDataUrl = GetTimeSheetDataUrl + caseNo;
             $http.get(GetTimeSheetDataUrl).then(function (data) {
                 console.log("data", data)
                 angular.element(".overlay").css("display","block");
                    angular.element(".loading-container").css("display","none");
                    angular.element(".timeSheet-progress-modal").css("display","block");
                 $scope.fullTimeSheetData = data.data.result.timeSheetDTOs;
                 $scope.timeSheetData = data.data.result.timeSheetDTOs[0];
                 if ($scope.timeSheetData.workedHours) {
                     $scope.workingDatas = $scope.timeSheetData.workedHours;
                 }
                 if (data.data.result.timeSheetDTOs[1]) {
                     $scope.timeSheetData1 = data.data.result.timeSheetDTOs[1];
                     if ($scope.timeSheetData1.workedHours) {
                         $scope.workingDatas1 = $scope.timeSheetData1.workedHours;
                     }
                 }
                 if (data.data.result.timeSheetDTOs[2]) {
                     $scope.timeSheetData2 = data.data.result.timeSheetDTOs[2];
                     if ($scope.timeSheetData2.workedHours) {
                         $scope.workingDatas2 = $scope.timeSheetData2.workedHours;
                     }
                 }
             });
        }
            //close time sheet
        $scope.closetimesheetpopup = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".timeSheet-progress-modal").css("display", "none");
        }

        /* Resignation Proess Functionality */
         $scope.attachResignationStatus = false;
         //Open Resignation Withdraw Adjudicator model
         $scope.openResignationWithdrawPopUp = function (caseDetails) {
             $scope.isRequestInitiated = false;
             var adjResignationRequestApproveStatus = caseDetails.adjResignationRequestApproveStatus;
             $scope.resignationRequestApproveStatus = adjResignationRequestApproveStatus;
             if (!caseDetails.adjResignationRequestStatus) {
                 $scope.isRequestInitiated = true;
                 $scope.downLoadResignationDoc = true;
                 var ViewAdjudicatorResignUrl = smcConfig.services.ViewResignationRequest.url;
                 ViewAdjudicatorResignUrl = ViewAdjudicatorResignUrl + caseDetails.caseNumber;
                 $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                 $http.get(ViewAdjudicatorResignUrl).then(function (respon) {
                     var data = respon.data;
                     if (data.status == 'SUCCESS') {
                         $scope.resgPopUpData = {};
                         $scope.resgPopUpData.reason = data.result.reason;
                         $scope.resignationDocumentName = data.result.document.name;
                         $scope.resignationUploadedDocument = data.result.document.fileLocation;
                         $scope.attachResignationStatus = false;
                         $scope.downLoadResignationDocURL = smcConfig.services.DownloadSupportingDocument.url + data.result.document.id;
                         $scope.loginRole = $cookies.get('roleName');
                         angular.element(".overlay").css("display", "block");
                         angular.element(".resignation-withdraw-PopUp-Model").css("display", "block");
                     } else {
                         NotifyFactory.log('error', data.errorMessage);
                     }
                 }).catch(function (error) {
                     NotifyFactory.log('error', error.errorMessage);
                 });
             } else {
                 $scope.resgPopUpData = {};
                 $scope.resignationDocumentName = undefined;
                 $scope.resignationUploadedDocument = undefined;
                 $scope.attachResignationStatus = false;
                 $scope.loginRole = $cookies.get('roleName');
                 $scope.ResgPopUpCaseNumber = caseDetails.caseNumber;
                 angular.element(".overlay").css("display", "block");
                 angular.element(".resignation-withdraw-PopUp-Model").css("display", "block");
             }
         }

         //Open Resignation Withdraw Adjudicator model
         $scope.closeResignationWithdrawPopUp = function () {
             $scope.resgPopUpData = {};
             $scope.resignationDocumentName = undefined;
             $scope.resignationUploadedDocument = undefined;
             $scope.attachResignationStatus = false;
             angular.element(".overlay").css("display", "none");
             angular.element(".resignation-withdraw-PopUp-Model").css("display", "none");
         }



         //Submit Approval Adjudicator Resignation
         $scope.adjudicatorResignationSubmit = function (resgPopUpData, CaseNumber) {
             var query = {
                 "caseNumber": CaseNumber,
                 "smcOfficerId": $cookies.get('memberId'),
                 "comments": resgPopUpData.comments
             }
             console.log('query', query)
             DataService.post('ApproveResignationRequest', query).then(function (data) {
                 if (data.status == 'SUCCESS') {
                     NotifyFactory.log('success', 'Request submitted successfully');
                     angular.element(".overlay").css("display", "none");
                     angular.element(".resignation-withdraw-PopUp-Model").css("display", "none");
                     get_inprogress_caselist();
                 } else {
                     NotifyFactory.log('error', data.errorMessage);
                 }
             }).catch(function (error) {
                 NotifyFactory.log('error', error.errorMessage);
             });
         }

         //get generate memo
        $scope.getViewMemo = function (caseNumber) {
            $scope.memoCaseNumber = caseNumber;
            var GetViewGenerateMemoUrl = smcConfig.services.GetViewGenerateMemo.url;
            GetViewGenerateMemoUrl = GetViewGenerateMemoUrl + $scope.memoCaseNumber;

            $http.get(GetViewGenerateMemoUrl).then(function (data) {
                    $scope.paymentMemoData = data.data.result;
                    angular.element(".overlay").css("display", "block");
                    angular.element(".case-generate-memo").css("display", "block");
                })
                .catch(function (error) {
                    NotifyFactory.log('error', error.data.errorMessage);
                });
        }

        //close generate memo
        $scope.cancelMemo = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case-generate-memo").css("display", "none");
        }

        //sent approval to management
        $scope.sendApproval = function (sentData, caseNumber) {
            var query = buildApprovalQuery(sentData, caseNumber)
            DataService.post('SentDeterminedApproval', query).then(function (data) {
                if (data.status == 'SUCCESS') {
                    NotifyFactory.log('success', 'Memo sent for approval successfully');
                    get_determined_caselist();
                    angular.element(".overlay").css("display", "none");
                    angular.element(".case-generate-memo").css("display", "none");
                }
            }).catch(function (error) {
                NotifyFactory.log('error', error.errorMessage);
            });
        }

        function buildApprovalQuery(sentData, caseNumber) {
            var query = {
                "caseNumber": caseNumber,
                "smcOfficerId": $cookies.get('memberId'),
                "claimedAmount": undefinedSetNull(sentData.claimedAmount),
                "depositAmount": undefinedSetNull(sentData.depositAmount),
                "adjudicatorFee": undefinedSetNull(sentData.adjudicatorFee),
                "invoiceNumber": undefinedSetNull(sentData.invoiceNumber),
                "smcManagementFee": undefinedSetNull(sentData.smcManagementFee),
                "paymentDueToAdjudicator": undefinedSetNull(sentData.paymentDueToAdjudicator),
                "adjudicationCost": undefinedSetNull(sentData.adjudicationCost),
                "amountPaidByClaimant": undefinedSetNull(sentData.amountPaidByClaimant),
                "amountRefund": undefinedSetNull(sentData.amountRefund),
                "claimantPayableAmount": undefinedSetNull(sentData.claimantPayableAmount)
            }

            return query
        }

        $rootScope.updateCaseNumberSession = false;
        $scope.updateAA1Form = function (casenumber) {
            $cookies.put('currentActionMenu', 'Update AA-1 form');
            var casenumber = casenumber;
            getCaseDetail(casenumber);
        }
        $scope.updateARForm = function (casenumber) {
            $cookies.put('currentActionMenu', 'Update AR form');
            $rootScope.casenumber = casenumber;
            $state.go("smclayout.membershiplayout.updatear");
        }

        // download determination 

        $scope.getLatestDeterVer = function(caseNumber){
            $scope.deterverNumber = caseNumber;
            var getDetVer = smcConfig.services.GetLatestDeteminations.url + caseNumber;
            $http.get(getDetVer).then(function (data) {
                $scope.LatestDeterVers = data.data.result;
                angular.element(".overlay").css("display", "block");
                angular.element(".download-determination-modal").css("display", "block");
            })
            .catch(function (error) {
                NotifyFactory.log('error', error.data.errorMessage);
            });
        }

        $scope.closeDownloadDeter = function(caseNumber){
            angular.element(".overlay").css("display", "none");
            angular.element(".download-determination-modal").css("display", "none");
        }

           function undefinedSetNull(val) {

            if (val) {
                return val;
            } else {
                var val = null;
                return val;
            }
            return val;
        }

        $scope.caseStatusPopup = function (index, caseNo, caseType) { //function that sets the value of selectedRow to current index
                $scope.loading = true;
                $scope.selectedRow = index;
                $scope.caseStatusCaseNo = caseNo;
                /*Getting full status list */
                if (caseType == 'AA Case') {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.AACaseStatusList;
                } else {
                    $scope.fullStatusList = healthCheckConfig.Adjudication.ARACaseStatusList;
                }


                console.log("caseNO" + caseNo);
                $scope.missedStatus = false;
                var healthCheck = smcConfig.services.GetHealthCheckForAdjudicationCase.url;
                var healthCheckUrl = healthCheck + caseNo;
                $http.get(healthCheckUrl).then(function (healthData) {
                    if (healthData.data.status == 'SUCCESS') {
                        $scope.loading = false;
                        $scope.yetToProcessStatusList = healthData.data.result.yetToProcessStatusList;
                        $scope.missedStatusList = healthData.data.result.missedStatusList;
                        $scope.processStatusList = healthData.data.result.processStatusList;

                    } else {
                        NotifyFactory.log('error', "error");
                    }
                });
                angular.element(".overlay").css("display", "block");
                angular.element(".case_status_modal").css("display", "block");

            }
            //close refund notify popup
        $scope.caseStatusPopupClose = function () {
            angular.element(".overlay").css("display", "none");
            angular.element(".case_status_modal").css("display", "none");
        }
        $scope.options = {
            readOnly : true,
            toolbar: []
        };

    }
})();
