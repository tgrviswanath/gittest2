(function() {
    'use strict';
    angular
        .module('smc')
        .controller('memberloginCtrl',memberloginCtrl);

    memberloginCtrl.$inject = ['$rootScope','$scope','$state','$cookies','DataService','$http','patternConfig','httpPostFactory','smcConfig','NotifyFactory'];

    function memberloginCtrl($rootScope,$scope,$state,$cookies,DataService,$http,patternConfig,httpPostFactory,smcConfig,NotifyFactory){
    	if($cookies.get('roleName') == 'SMC Officer' || $cookies.get('roleName') == 'SMC Mangement'){
			$state.go('smclayout.membershiplayout.memberdashboard')
		}
		$scope.isDisabled=false;

    	
    	// login as a smc officer into admin page
    	$rootScope.MemberLogin = function(memberlogin){
    		$scope.isDisabled=true;
    		$rootScope.roles=[];
			$rootScope.modules=[];
	      	if($scope.memberlogin.username && $scope.memberlogin.password ){
		        var query = {
		            "userId": $scope.memberlogin.username,
		            "password": $scope.memberlogin.password,
		        };
		        DataService.post('SmcMemberLogin',query).then(function (data) {
		        	$scope.isDisabled=false;
		        	$cookies.put('userMail',$scope.memberlogin.username);
					$cookies.put('Password',$scope.memberlogin.password);
					$cookies.put('memberType','Staff');
		        	if(data.status == 'SUCCESS'){
						$cookies.put('userName',data.result.memberName);
						$cookies.put('memberId',data.result.memberId);
						$cookies.put('systemPassword',data.result.isSystemGenerated);
						$rootScope.loginModuleRoles = data.result.moduleRoles
						if(data.result.isSystemGenerated){
			            	$state.go('smclayout.membershiplayout.changepassword');
			            }else{
							$state.go('smclayout.membershiplayout.memberdashboard');
							NotifyFactory.log('success', "Logged in successfully.");
						}
		        	}else{
		        		NotifyFactory.log('error', data.errorMessage);
		        	}
		        }, function (error) {
		        	$scope.isDisabled=false;
					NotifyFactory.log('error', error.errorMessage);
					if(error.errorMessage == "Your account has been locked"){
						angular.element(".overlay").css("display","block");
						angular.element("#login_locked_information").css("display","block");
					}
		        });
	        }
	    }
	    

		$scope.goToResetPage = function(){
			$rootScope.loginType = 'member';
			$state.go('smclayout.membershiplayout.resetpassword');
		}
		$scope.cancelLogin=function(){
			$scope.memberlogin={};
		}
		$scope.closeLoginLock=function(){
			angular.element(".overlay").css("display","none");
			angular.element("#login_locked_information").css("display","none");
		}
	}
})();